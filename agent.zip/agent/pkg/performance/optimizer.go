package performance

import (
	"context"
	"runtime"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/cache"
)

// Optimizer handles performance optimization
type Optimizer struct {
	logger       logger.Logger
	cache        cache.Cache
	config       *Config
	
	// Resource pools
	workerPool   *WorkerPool
	connPool     *ConnectionPool
	memoryPool   *MemoryPool
	
	// Optimization strategies
	strategies   map[string]Strategy
	
	// Metrics
	metrics      *Metrics
	mutex        sync.RWMutex
}

// Config holds optimization configuration
type Config struct {
	MaxWorkers        int
	MaxConnections    int
	MemoryPoolSize    int64
	CacheSize         int64
	GCTargetPercent   int
	MaxGoroutines     int
	EnableProfiling   bool
	EnableMetrics     bool
	OptimizationLevel OptimizationLevel
}

// WorkerPool manages a pool of workers for concurrent processing
type WorkerPool struct {
	workers    chan chan Job
	jobQueue   chan Job
	quit       chan bool
	workerWg   sync.WaitGroup
	maxWorkers int
	logger     logger.Logger
}

// ConnectionPool manages database/API connections
type ConnectionPool struct {
	connections chan interface{}
	factory     ConnectionFactory
	maxConns    int
	activeConns int
	mutex       sync.RWMutex
}

// MemoryPool manages memory allocation
type MemoryPool struct {
	pools   map[int]*sync.Pool
	sizes   []int
	mutex   sync.RWMutex
}

// Job represents a unit of work
type Job struct {
	ID       string
	Task     func() error
	Priority Priority
	Timeout  time.Duration
	Context  context.Context
	Result   chan JobResult
}

// JobResult represents the result of a job
type JobResult struct {
	ID       string
	Error    error
	Duration time.Duration
	Data     interface{}
}

// Strategy represents an optimization strategy
type Strategy interface {
	Name() string
	Apply(ctx context.Context, data interface{}) (interface{}, error)
	CanApply(data interface{}) bool
	Priority() Priority
}

// ConnectionFactory creates new connections
type ConnectionFactory func() (interface{}, error)

// Metrics tracks performance metrics
type Metrics struct {
	JobsProcessed     int64
	AverageLatency    time.Duration
	ThroughputPerSec  float64
	MemoryUsage       int64
	GoroutineCount    int
	ConnectionsActive int
	CacheHitRate      float64
	ErrorRate         float64
	LastUpdated       time.Time
	mutex             sync.RWMutex
}

// Enums
type OptimizationLevel int
const (
	OptimizationLevelNone OptimizationLevel = iota
	OptimizationLevelBasic
	OptimizationLevelAggressive
	OptimizationLevelMaximum
)

type Priority int
const (
	PriorityLow Priority = iota
	PriorityNormal
	PriorityHigh
	PriorityCritical
)

// NewOptimizer creates a new performance optimizer
func NewOptimizer(logger logger.Logger, cache cache.Cache, config *Config) *Optimizer {
	if config == nil {
		config = &Config{
			MaxWorkers:        runtime.NumCPU() * 2,
			MaxConnections:    100,
			MemoryPoolSize:    100 * 1024 * 1024, // 100MB
			CacheSize:         50 * 1024 * 1024,  // 50MB
			GCTargetPercent:   100,
			MaxGoroutines:     10000,
			EnableProfiling:   false,
			EnableMetrics:     true,
			OptimizationLevel: OptimizationLevelBasic,
		}
	}

	optimizer := &Optimizer{
		logger:     logger,
		cache:      cache,
		config:     config,
		strategies: make(map[string]Strategy),
		metrics:    NewMetrics(),
	}

	// Initialize components
	optimizer.workerPool = NewWorkerPool(config.MaxWorkers, logger)
	optimizer.connPool = NewConnectionPool(config.MaxConnections)
	optimizer.memoryPool = NewMemoryPool()

	// Register optimization strategies
	optimizer.registerStrategies()

	// Apply initial optimizations
	optimizer.applyInitialOptimizations()

	// Start background monitoring
	go optimizer.startMonitoring()

	logger.Info("Performance optimizer initialized", 
		"workers", config.MaxWorkers,
		"connections", config.MaxConnections,
		"level", config.OptimizationLevel)

	return optimizer
}

// NewWorkerPool creates a new worker pool
func NewWorkerPool(maxWorkers int, logger logger.Logger) *WorkerPool {
	pool := &WorkerPool{
		workers:    make(chan chan Job, maxWorkers),
		jobQueue:   make(chan Job, maxWorkers*10),
		quit:       make(chan bool),
		maxWorkers: maxWorkers,
		logger:     logger,
	}

	// Start workers
	for i := 0; i < maxWorkers; i++ {
		worker := NewWorker(i, pool.workers, pool.quit, logger)
		worker.Start()
		pool.workerWg.Add(1)
	}

	// Start dispatcher
	go pool.dispatch()

	return pool
}

// Worker represents a worker in the pool
type Worker struct {
	ID          int
	WorkerPool  chan chan Job
	JobChannel  chan Job
	Quit        chan bool
	logger      logger.Logger
}

// NewWorker creates a new worker
func NewWorker(id int, workerPool chan chan Job, quit chan bool, logger logger.Logger) *Worker {
	return &Worker{
		ID:         id,
		WorkerPool: workerPool,
		JobChannel: make(chan Job),
		Quit:       quit,
		logger:     logger,
	}
}

// Start starts the worker
func (w *Worker) Start() {
	go func() {
		for {
			// Register worker in pool
			w.WorkerPool <- w.JobChannel

			select {
			case job := <-w.JobChannel:
				// Process job
				w.processJob(job)

			case <-w.Quit:
				return
			}
		}
	}()
}

// processJob processes a single job
func (w *Worker) processJob(job Job) {
	startTime := time.Now()
	
	// Create timeout context if specified
	ctx := job.Context
	if job.Timeout > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(job.Context, job.Timeout)
		defer cancel()
	}

	// Execute job with timeout
	done := make(chan error, 1)
	go func() {
		done <- job.Task()
	}()

	var err error
	select {
	case err = <-done:
		// Job completed
	case <-ctx.Done():
		// Job timed out or cancelled
		err = ctx.Err()
	}

	duration := time.Since(startTime)

	// Send result
	if job.Result != nil {
		job.Result <- JobResult{
			ID:       job.ID,
			Error:    err,
			Duration: duration,
		}
	}

	if err != nil {
		w.logger.Warn("Job failed", "worker", w.ID, "job", job.ID, "error", err)
	}
}

// dispatch dispatches jobs to workers
func (wp *WorkerPool) dispatch() {
	for {
		select {
		case job := <-wp.jobQueue:
			// Get available worker
			go func(job Job) {
				worker := <-wp.workers
				worker <- job
			}(job)

		case <-wp.quit:
			return
		}
	}
}

// SubmitJob submits a job to the worker pool
func (wp *WorkerPool) SubmitJob(job Job) {
	wp.jobQueue <- job
}

// Stop stops the worker pool
func (wp *WorkerPool) Stop() {
	close(wp.quit)
	wp.workerWg.Wait()
}

// NewConnectionPool creates a new connection pool
func NewConnectionPool(maxConns int) *ConnectionPool {
	return &ConnectionPool{
		connections: make(chan interface{}, maxConns),
		maxConns:    maxConns,
	}
}

// SetFactory sets the connection factory
func (cp *ConnectionPool) SetFactory(factory ConnectionFactory) {
	cp.factory = factory
}

// Get gets a connection from the pool
func (cp *ConnectionPool) Get() (interface{}, error) {
	select {
	case conn := <-cp.connections:
		return conn, nil
	default:
		// Create new connection if under limit
		cp.mutex.Lock()
		if cp.activeConns < cp.maxConns {
			cp.activeConns++
			cp.mutex.Unlock()
			
			if cp.factory != nil {
				return cp.factory()
			}
			return nil, fmt.Errorf("no connection factory set")
		}
		cp.mutex.Unlock()
		
		// Wait for available connection
		return <-cp.connections, nil
	}
}

// Put returns a connection to the pool
func (cp *ConnectionPool) Put(conn interface{}) {
	select {
	case cp.connections <- conn:
		// Connection returned to pool
	default:
		// Pool is full, close connection
		cp.mutex.Lock()
		cp.activeConns--
		cp.mutex.Unlock()
	}
}

// NewMemoryPool creates a new memory pool
func NewMemoryPool() *MemoryPool {
	sizes := []int{64, 128, 256, 512, 1024, 2048, 4096, 8192}
	pools := make(map[int]*sync.Pool)
	
	for _, size := range sizes {
		size := size // capture loop variable
		pools[size] = &sync.Pool{
			New: func() interface{} {
				return make([]byte, size)
			},
		}
	}

	return &MemoryPool{
		pools: pools,
		sizes: sizes,
	}
}

// Get gets a buffer from the memory pool
func (mp *MemoryPool) Get(size int) []byte {
	mp.mutex.RLock()
	defer mp.mutex.RUnlock()

	// Find the smallest pool that can accommodate the size
	for _, poolSize := range mp.sizes {
		if poolSize >= size {
			if pool, exists := mp.pools[poolSize]; exists {
				buf := pool.Get().([]byte)
				return buf[:size]
			}
		}
	}

	// No suitable pool found, allocate directly
	return make([]byte, size)
}

// Put returns a buffer to the memory pool
func (mp *MemoryPool) Put(buf []byte) {
	size := cap(buf)
	
	mp.mutex.RLock()
	defer mp.mutex.RUnlock()

	if pool, exists := mp.pools[size]; exists {
		pool.Put(buf)
	}
}

// registerStrategies registers optimization strategies
func (o *Optimizer) registerStrategies() {
	strategies := []Strategy{
		NewCachingStrategy(o.cache, o.logger),
		NewCompressionStrategy(o.logger),
		NewBatchingStrategy(o.logger),
		NewParallelizationStrategy(o.workerPool, o.logger),
	}

	for _, strategy := range strategies {
		o.strategies[strategy.Name()] = strategy
	}
}

// applyInitialOptimizations applies initial system optimizations
func (o *Optimizer) applyInitialOptimizations() {
	// Set GC target percentage
	runtime.SetGCPercent(o.config.GCTargetPercent)

	// Set max processors
	runtime.GOMAXPROCS(runtime.NumCPU())

	// Apply optimization level specific settings
	switch o.config.OptimizationLevel {
	case OptimizationLevelAggressive:
		runtime.SetGCPercent(50) // More aggressive GC
	case OptimizationLevelMaximum:
		runtime.SetGCPercent(25) // Very aggressive GC
	}

	o.logger.Info("Applied initial optimizations", 
		"gc_percent", runtime.SetGCPercent(-1),
		"max_procs", runtime.GOMAXPROCS(0))
}

// startMonitoring starts background monitoring
func (o *Optimizer) startMonitoring() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		o.updateMetrics()
		o.checkResourceUsage()
		o.optimizeIfNeeded()
	}
}

// updateMetrics updates performance metrics
func (o *Optimizer) updateMetrics() {
	o.metrics.mutex.Lock()
	defer o.metrics.mutex.Unlock()

	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	o.metrics.MemoryUsage = int64(m.Alloc)
	o.metrics.GoroutineCount = runtime.NumGoroutine()
	o.metrics.LastUpdated = time.Now()

	// Update cache hit rate if available
	if cacheStats := o.cache.Stats(); cacheStats != nil {
		o.metrics.CacheHitRate = cacheStats.HitRate
	}
}

// checkResourceUsage checks resource usage and triggers optimizations
func (o *Optimizer) checkResourceUsage() {
	o.metrics.mutex.RLock()
	memUsage := o.metrics.MemoryUsage
	goroutines := o.metrics.GoroutineCount
	o.metrics.mutex.RUnlock()

	// Check memory usage
	if memUsage > o.config.MemoryPoolSize {
		o.logger.Warn("High memory usage detected", "usage", memUsage)
		runtime.GC() // Force garbage collection
	}

	// Check goroutine count
	if goroutines > o.config.MaxGoroutines {
		o.logger.Warn("High goroutine count detected", "count", goroutines)
	}
}

// optimizeIfNeeded applies optimizations based on current metrics
func (o *Optimizer) optimizeIfNeeded() {
	// Implementation would analyze metrics and apply optimizations
	// This is a simplified version
	
	o.metrics.mutex.RLock()
	cacheHitRate := o.metrics.CacheHitRate
	o.metrics.mutex.RUnlock()

	// If cache hit rate is low, consider increasing cache size
	if cacheHitRate < 0.8 {
		o.logger.Debug("Low cache hit rate", "rate", cacheHitRate)
		// Could trigger cache optimization here
	}
}

// OptimizeData applies optimization strategies to data
func (o *Optimizer) OptimizeData(ctx context.Context, data interface{}) (interface{}, error) {
	// Apply applicable strategies in priority order
	strategies := o.getSortedStrategies(data)
	
	result := data
	for _, strategy := range strategies {
		if strategy.CanApply(result) {
			optimized, err := strategy.Apply(ctx, result)
			if err != nil {
				o.logger.Warn("Strategy failed", "strategy", strategy.Name(), "error", err)
				continue
			}
			result = optimized
		}
	}

	return result, nil
}

// getSortedStrategies returns strategies sorted by priority
func (o *Optimizer) getSortedStrategies(data interface{}) []Strategy {
	var applicable []Strategy
	
	for _, strategy := range o.strategies {
		if strategy.CanApply(data) {
			applicable = append(applicable, strategy)
		}
	}

	// Sort by priority (simplified)
	// In practice, you'd implement proper sorting
	return applicable
}

// GetMetrics returns current performance metrics
func (o *Optimizer) GetMetrics() *Metrics {
	o.metrics.mutex.RLock()
	defer o.metrics.mutex.RUnlock()

	// Return a copy to avoid race conditions
	return &Metrics{
		JobsProcessed:     o.metrics.JobsProcessed,
		AverageLatency:    o.metrics.AverageLatency,
		ThroughputPerSec:  o.metrics.ThroughputPerSec,
		MemoryUsage:       o.metrics.MemoryUsage,
		GoroutineCount:    o.metrics.GoroutineCount,
		ConnectionsActive: o.metrics.ConnectionsActive,
		CacheHitRate:      o.metrics.CacheHitRate,
		ErrorRate:         o.metrics.ErrorRate,
		LastUpdated:       o.metrics.LastUpdated,
	}
}

// NewMetrics creates new metrics instance
func NewMetrics() *Metrics {
	return &Metrics{
		LastUpdated: time.Now(),
	}
}

// CachingStrategy implements caching optimization
type CachingStrategy struct {
	cache  cache.Cache
	logger logger.Logger
}

func NewCachingStrategy(cache cache.Cache, logger logger.Logger) *CachingStrategy {
	return &CachingStrategy{cache: cache, logger: logger}
}

func (s *CachingStrategy) Name() string { return "caching" }
func (s *CachingStrategy) Priority() Priority { return PriorityHigh }
func (s *CachingStrategy) CanApply(data interface{}) bool { return true }

func (s *CachingStrategy) Apply(ctx context.Context, data interface{}) (interface{}, error) {
	// Implementation would cache frequently accessed data
	return data, nil
}

// CompressionStrategy implements compression optimization
type CompressionStrategy struct {
	logger logger.Logger
}

func NewCompressionStrategy(logger logger.Logger) *CompressionStrategy {
	return &CompressionStrategy{logger: logger}
}

func (s *CompressionStrategy) Name() string { return "compression" }
func (s *CompressionStrategy) Priority() Priority { return PriorityNormal }
func (s *CompressionStrategy) CanApply(data interface{}) bool { return true }

func (s *CompressionStrategy) Apply(ctx context.Context, data interface{}) (interface{}, error) {
	// Implementation would compress large data
	return data, nil
}

// BatchingStrategy implements batching optimization
type BatchingStrategy struct {
	logger logger.Logger
}

func NewBatchingStrategy(logger logger.Logger) *BatchingStrategy {
	return &BatchingStrategy{logger: logger}
}

func (s *BatchingStrategy) Name() string { return "batching" }
func (s *BatchingStrategy) Priority() Priority { return PriorityNormal }
func (s *BatchingStrategy) CanApply(data interface{}) bool { return true }

func (s *BatchingStrategy) Apply(ctx context.Context, data interface{}) (interface{}, error) {
	// Implementation would batch operations
	return data, nil
}

// ParallelizationStrategy implements parallelization optimization
type ParallelizationStrategy struct {
	workerPool *WorkerPool
	logger     logger.Logger
}

func NewParallelizationStrategy(workerPool *WorkerPool, logger logger.Logger) *ParallelizationStrategy {
	return &ParallelizationStrategy{workerPool: workerPool, logger: logger}
}

func (s *ParallelizationStrategy) Name() string { return "parallelization" }
func (s *ParallelizationStrategy) Priority() Priority { return PriorityHigh }
func (s *ParallelizationStrategy) CanApply(data interface{}) bool { return true }

func (s *ParallelizationStrategy) Apply(ctx context.Context, data interface{}) (interface{}, error) {
	// Implementation would parallelize operations
	return data, nil
}

// Close closes the optimizer and cleans up resources
func (o *Optimizer) Close() error {
	if o.workerPool != nil {
		o.workerPool.Stop()
	}

	o.logger.Info("Performance optimizer closed")
	return nil
}
