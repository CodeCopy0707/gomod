package intelligence

import (
	"context"
	"fmt"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
)

// Manager handles predictive intelligence and smart suggestions
type Manager struct {
	ai           *ai.Manager
	cache        cache.Cache
	logger       logger.Logger
	predictor    *Predictor
	suggester    *Suggester
	prefetcher   *Prefetcher
	analyzer     *ContextAnalyzer
	learner      *PatternLearner
	mutex        sync.RWMutex
	running      bool
	ctx          context.Context
	cancel       context.CancelFunc
}

// Predictor handles predictive analysis
type Predictor struct {
	patterns map[string]*Pattern
	mutex    sync.RWMutex
}

// Suggester provides smart suggestions
type Suggester struct {
	suggestions map[string][]*Suggestion
	mutex       sync.RWMutex
}

// Prefetcher handles context-aware prefetching
type Prefetcher struct {
	cache   cache.Cache
	queue   chan *PrefetchRequest
	workers int
}

// ContextAnalyzer analyzes context for predictions
type ContextAnalyzer struct {
	contexts map[string]*Context
	mutex    sync.RWMutex
}

// PatternLearner learns from user patterns
type PatternLearner struct {
	patterns map[string]*LearnedPattern
	mutex    sync.RWMutex
}

// Pattern represents a learned pattern
type Pattern struct {
	ID          string
	Type        string
	Context     map[string]interface{}
	Frequency   int
	Confidence  float64
	LastSeen    time.Time
	Predictions []*Prediction
}

// Prediction represents a prediction
type Prediction struct {
	ID          string
	Type        string
	Content     string
	Confidence  float64
	Context     map[string]interface{}
	CreatedAt   time.Time
	ValidUntil  time.Time
}

// Suggestion represents a smart suggestion
type Suggestion struct {
	ID          string
	Type        string
	Title       string
	Description string
	Action      string
	Parameters  map[string]interface{}
	Confidence  float64
	Priority    int
	CreatedAt   time.Time
}

// PrefetchRequest represents a prefetch request
type PrefetchRequest struct {
	Key     string
	Type    string
	Context map[string]interface{}
	TTL     time.Duration
}

// Context represents analysis context
type Context struct {
	ID           string
	Type         string
	Data         map[string]interface{}
	Timestamp    time.Time
	Relevance    float64
	Dependencies []string
}

// LearnedPattern represents a learned user pattern
type LearnedPattern struct {
	ID        string
	Pattern   string
	Frequency int
	Context   map[string]interface{}
	LastUsed  time.Time
	Strength  float64
}

// Intent represents user intent analysis
type Intent struct {
	Type       string
	Confidence float64
	Context    map[string]interface{}
	Actions    []string
}

// NewManager creates a new intelligence manager
func NewManager(ai *ai.Manager, cache cache.Cache, logger logger.Logger) (*Manager, error) {
	ctx, cancel := context.WithCancel(context.Background())

	manager := &Manager{
		ai:        ai,
		cache:     cache,
		logger:    logger,
		predictor: NewPredictor(),
		suggester: NewSuggester(),
		prefetcher: NewPrefetcher(cache, 5), // 5 workers
		analyzer:  NewContextAnalyzer(),
		learner:   NewPatternLearner(),
		ctx:       ctx,
		cancel:    cancel,
	}

	return manager, nil
}

// NewPredictor creates a new predictor
func NewPredictor() *Predictor {
	return &Predictor{
		patterns: make(map[string]*Pattern),
	}
}

// NewSuggester creates a new suggester
func NewSuggester() *Suggester {
	return &Suggester{
		suggestions: make(map[string][]*Suggestion),
	}
}

// NewPrefetcher creates a new prefetcher
func NewPrefetcher(cache cache.Cache, workers int) *Prefetcher {
	return &Prefetcher{
		cache:   cache,
		queue:   make(chan *PrefetchRequest, 1000),
		workers: workers,
	}
}

// NewContextAnalyzer creates a new context analyzer
func NewContextAnalyzer() *ContextAnalyzer {
	return &ContextAnalyzer{
		contexts: make(map[string]*Context),
	}
}

// NewPatternLearner creates a new pattern learner
func NewPatternLearner() *PatternLearner {
	return &PatternLearner{
		patterns: make(map[string]*LearnedPattern),
	}
}

// StartPrefetching starts the prefetching workers
func (m *Manager) StartPrefetching(ctx context.Context) {
	m.mutex.Lock()
	if m.running {
		m.mutex.Unlock()
		return
	}
	m.running = true
	m.mutex.Unlock()

	// Start prefetch workers
	for i := 0; i < m.prefetcher.workers; i++ {
		go m.prefetchWorker(ctx, i)
	}

	// Start background tasks
	go m.backgroundAnalysis(ctx)
	go m.patternLearning(ctx)
	go m.suggestionGeneration(ctx)

	m.logger.Info("Predictive intelligence system started", "workers", m.prefetcher.workers)
}

// AnalyzeIntent analyzes user intent from input
func (m *Manager) AnalyzeIntent(ctx context.Context, input string, context interface{}) (*Intent, error) {
	m.logger.Debug("Analyzing intent", "input", input)

	// Use AI to analyze intent
	prompt := fmt.Sprintf(`Analyze the following user input and determine their intent:

Input: "%s"

Classify the intent into one of these categories:
- code_generation: User wants to generate new code
- code_modification: User wants to modify existing code
- debugging: User wants to debug or fix issues
- explanation: User wants code explained
- testing: User wants to create or run tests
- documentation: User wants to create documentation
- project_management: User wants to manage project structure
- information: User wants information or help
- other: Other intents

Provide confidence score (0-1) and relevant context.

Response format:
Intent: <category>
Confidence: <0-1>
Context: <relevant context>
Actions: <suggested actions>`, input)

	response, err := m.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: []*ai.Message{
			{Role: "user", Content: prompt},
		},
		Temperature: 0.3,
		MaxTokens:   500,
	})

	if err != nil {
		return nil, fmt.Errorf("failed to analyze intent: %w", err)
	}

	// Parse response (simplified)
	intent := &Intent{
		Type:       "other",
		Confidence: 0.5,
		Context:    make(map[string]interface{}),
		Actions:    []string{},
	}

	// Extract intent from response
	lines := strings.Split(response, "\n")
	for _, line := range lines {
		if strings.HasPrefix(line, "Intent:") {
			intent.Type = strings.TrimSpace(strings.TrimPrefix(line, "Intent:"))
		} else if strings.HasPrefix(line, "Confidence:") {
			if conf, err := strconv.ParseFloat(strings.TrimSpace(strings.TrimPrefix(line, "Confidence:")), 64); err == nil {
				intent.Confidence = conf
			}
		}
	}

	// Learn from this interaction
	m.learner.LearnPattern(input, intent.Type, intent.Context)

	return intent, nil
}

// GetSuggestions returns smart suggestions for the current context
func (m *Manager) GetSuggestions(ctx context.Context, contextKey string) ([]*Suggestion, error) {
	m.suggester.mutex.RLock()
	suggestions := m.suggester.suggestions[contextKey]
	m.suggester.mutex.RUnlock()

	if len(suggestions) == 0 {
		// Generate new suggestions
		return m.generateSuggestions(ctx, contextKey)
	}

	return suggestions, nil
}

// generateSuggestions generates new suggestions for a context
func (m *Manager) generateSuggestions(ctx context.Context, contextKey string) ([]*Suggestion, error) {
	// Get context
	context := m.analyzer.GetContext(contextKey)
	if context == nil {
		return []*Suggestion{}, nil
	}

	// Generate suggestions based on context
	suggestions := []*Suggestion{}

	// Code completion suggestions
	if context.Type == "code_editing" {
		suggestions = append(suggestions, &Suggestion{
			ID:          generateID(),
			Type:        "code_completion",
			Title:       "Auto-complete function",
			Description: "Complete the current function based on context",
			Action:      "complete_function",
			Confidence:  0.8,
			Priority:    1,
			CreatedAt:   time.Now(),
		})
	}

	// Refactoring suggestions
	if context.Type == "code_review" {
		suggestions = append(suggestions, &Suggestion{
			ID:          generateID(),
			Type:        "refactoring",
			Title:       "Extract method",
			Description: "Extract repeated code into a separate method",
			Action:      "extract_method",
			Confidence:  0.7,
			Priority:    2,
			CreatedAt:   time.Now(),
		})
	}

	// Store suggestions
	m.suggester.mutex.Lock()
	m.suggester.suggestions[contextKey] = suggestions
	m.suggester.mutex.Unlock()

	return suggestions, nil
}

// PredictNext predicts the next likely action
func (m *Manager) PredictNext(ctx context.Context, currentContext map[string]interface{}) ([]*Prediction, error) {
	m.predictor.mutex.RLock()
	defer m.predictor.mutex.RUnlock()

	var predictions []*Prediction

	// Find matching patterns
	for _, pattern := range m.predictor.patterns {
		if m.matchesContext(pattern.Context, currentContext) {
			predictions = append(predictions, pattern.Predictions...)
		}
	}

	// Sort by confidence
	for i := 0; i < len(predictions)-1; i++ {
		for j := i + 1; j < len(predictions); j++ {
			if predictions[i].Confidence < predictions[j].Confidence {
				predictions[i], predictions[j] = predictions[j], predictions[i]
			}
		}
	}

	// Return top predictions
	if len(predictions) > 5 {
		predictions = predictions[:5]
	}

	return predictions, nil
}

// Prefetch prefetches data based on predictions
func (m *Manager) Prefetch(key, dataType string, context map[string]interface{}, ttl time.Duration) {
	request := &PrefetchRequest{
		Key:     key,
		Type:    dataType,
		Context: context,
		TTL:     ttl,
	}

	select {
	case m.prefetcher.queue <- request:
		m.logger.Debug("Queued prefetch request", "key", key, "type", dataType)
	default:
		m.logger.Warn("Prefetch queue full, dropping request", "key", key)
	}
}

// prefetchWorker processes prefetch requests
func (m *Manager) prefetchWorker(ctx context.Context, workerID int) {
	m.logger.Debug("Starting prefetch worker", "worker_id", workerID)

	for {
		select {
		case <-ctx.Done():
			return
		case request := <-m.prefetcher.queue:
			m.processPrefetchRequest(ctx, request)
		}
	}
}

// processPrefetchRequest processes a single prefetch request
func (m *Manager) processPrefetchRequest(ctx context.Context, request *PrefetchRequest) {
	m.logger.Debug("Processing prefetch request", "key", request.Key, "type", request.Type)

	// Generate or fetch data based on type
	var data interface{}
	var err error

	switch request.Type {
	case "code_completion":
		data, err = m.generateCodeCompletion(ctx, request.Context)
	case "documentation":
		data, err = m.fetchDocumentation(ctx, request.Context)
	case "suggestions":
		data, err = m.generateSuggestions(ctx, request.Key)
	default:
		m.logger.Warn("Unknown prefetch type", "type", request.Type)
		return
	}

	if err != nil {
		m.logger.Error("Prefetch failed", "key", request.Key, "error", err)
		return
	}

	// Store in cache
	if err := m.cache.Set(request.Key, data, request.TTL); err != nil {
		m.logger.Error("Failed to cache prefetched data", "key", request.Key, "error", err)
	}
}

// backgroundAnalysis runs background analysis tasks
func (m *Manager) backgroundAnalysis(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			m.analyzePatterns()
			m.cleanupOldData()
		}
	}
}

// patternLearning runs pattern learning tasks
func (m *Manager) patternLearning(ctx context.Context) {
	ticker := time.NewTicker(1 * time.Minute)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			m.updatePatternStrengths()
		}
	}
}

// suggestionGeneration runs suggestion generation tasks
func (m *Manager) suggestionGeneration(ctx context.Context) {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			m.refreshSuggestions()
		}
	}
}

// Helper methods

func (m *Manager) generateCodeCompletion(ctx context.Context, context map[string]interface{}) (interface{}, error) {
	// Placeholder for code completion generation
	return "// Generated code completion", nil
}

func (m *Manager) fetchDocumentation(ctx context.Context, context map[string]interface{}) (interface{}, error) {
	// Placeholder for documentation fetching
	return "Documentation content", nil
}

func (m *Manager) matchesContext(patternContext, currentContext map[string]interface{}) bool {
	// Simple context matching - in practice, this would be more sophisticated
	for key, value := range patternContext {
		if currentValue, exists := currentContext[key]; !exists || currentValue != value {
			return false
		}
	}
	return true
}

func (m *Manager) analyzePatterns() {
	m.logger.Debug("Analyzing patterns")
	// Pattern analysis implementation
}

func (m *Manager) cleanupOldData() {
	m.logger.Debug("Cleaning up old data")
	// Cleanup implementation
}

func (m *Manager) updatePatternStrengths() {
	m.logger.Debug("Updating pattern strengths")
	// Pattern strength update implementation
}

func (m *Manager) refreshSuggestions() {
	m.logger.Debug("Refreshing suggestions")
	// Suggestion refresh implementation
}

// GetContext returns a context by key
func (c *ContextAnalyzer) GetContext(key string) *Context {
	c.mutex.RLock()
	defer c.mutex.RUnlock()
	return c.contexts[key]
}

// LearnPattern learns a new pattern
func (p *PatternLearner) LearnPattern(input, intentType string, context map[string]interface{}) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	key := fmt.Sprintf("%s:%s", intentType, input)
	if pattern, exists := p.patterns[key]; exists {
		pattern.Frequency++
		pattern.LastUsed = time.Now()
		pattern.Strength = float64(pattern.Frequency) / 100.0
	} else {
		p.patterns[key] = &LearnedPattern{
			ID:        generateID(),
			Pattern:   input,
			Frequency: 1,
			Context:   context,
			LastUsed:  time.Now(),
			Strength:  0.01,
		}
	}
}

// generateID generates a unique ID
func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

// Close closes the intelligence manager
func (m *Manager) Close() error {
	m.cancel()
	return nil
}
