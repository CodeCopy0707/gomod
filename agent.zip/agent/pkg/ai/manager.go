package ai

import (
	"context"
	"fmt"
	"sync"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"
)

// Manager manages multiple AI providers with load balancing and fallback
type Manager struct {
	providers    map[string]Provider
	primary      string
	fallbacks    []string
	loadBalancer *LoadBalancer
	logger       logger.Logger
	config       *config.AIConfig
	metrics      *ProviderMetrics
	mutex        sync.RWMutex
}

// Provider interface for AI providers
type Provider interface {
	Name() string
	GenerateResponse(ctx context.Context, req *GenerateRequest) (*GenerateResponse, error)
	GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error)
	AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error)
	TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error)
	IsHealthy() bool
	GetUsage() *Usage
}

// GenerateRequest represents a request for text generation
type GenerateRequest struct {
	Messages    []*Message
	Context     interface{}
	Result      interface{}
	Temperature float64
	MaxTokens   int
	Model       string
}

// GenerateResponse represents a response from text generation
type GenerateResponse struct {
	Content   string
	Usage     *Usage
	Model     string
	Provider  string
	Duration  time.Duration
	Metadata  map[string]interface{}
}

// CodeGenerateRequest represents a request for code generation
type CodeGenerateRequest struct {
	Prompt      string
	Language    string
	Framework   string
	Context     *CodeContext
	Temperature float64
	MaxTokens   int
}

// CodeGenerateResponse represents a response from code generation
type CodeGenerateResponse struct {
	Code        string
	Language    string
	Explanation string
	Usage       *Usage
	Confidence  float64
}

// CodeAnalyzeRequest represents a request for code analysis
type CodeAnalyzeRequest struct {
	Code        string
	Language    string
	AnalysisType string // "bugs", "performance", "style", "security"
	Context     *CodeContext
}

// CodeAnalyzeResponse represents a response from code analysis
type CodeAnalyzeResponse struct {
	Issues      []*CodeIssue
	Suggestions []*CodeSuggestion
	Metrics     *CodeMetrics
	Usage       *Usage
}

// CodeTranslateRequest represents a request for code translation
type CodeTranslateRequest struct {
	Code         string
	FromLanguage string
	ToLanguage   string
	Context      *CodeContext
}

// CodeTranslateResponse represents a response from code translation
type CodeTranslateResponse struct {
	TranslatedCode string
	Language       string
	Explanation    string
	Usage          *Usage
	Confidence     float64
}

// Message represents a conversation message
type Message struct {
	Role      string
	Content   string
	Metadata  map[string]interface{}
	Timestamp time.Time
}

// CodeContext provides context for code operations
type CodeContext struct {
	ProjectPath   string
	Files         []string
	Dependencies  []string
	Framework     string
	Version       string
	Environment   string
}

// CodeIssue represents an issue found in code
type CodeIssue struct {
	Type        string
	Severity    string
	Message     string
	Line        int
	Column      int
	Suggestion  string
	Rule        string
}

// CodeSuggestion represents a suggestion for code improvement
type CodeSuggestion struct {
	Type        string
	Message     string
	Before      string
	After       string
	Confidence  float64
	Impact      string
}

// CodeMetrics represents metrics about code
type CodeMetrics struct {
	LinesOfCode     int
	Complexity      int
	Maintainability float64
	Readability     float64
	TestCoverage    float64
}

// Usage represents API usage statistics
type Usage struct {
	PromptTokens     int
	CompletionTokens int
	TotalTokens      int
	Cost             float64
}

// LoadBalancer handles load balancing across providers
type LoadBalancer struct {
	strategy string // "round_robin", "least_latency", "least_usage"
	counters map[string]int
	mutex    sync.Mutex
}

// ProviderMetrics tracks metrics for each provider
type ProviderMetrics struct {
	providers map[string]*ProviderStats
	mutex     sync.RWMutex
}

// ProviderStats holds statistics for a provider
type ProviderStats struct {
	RequestCount    int64
	SuccessCount    int64
	ErrorCount      int64
	AverageLatency  time.Duration
	TotalUsage      *Usage
	LastUsed        time.Time
	HealthStatus    bool
}

// NewManager creates a new AI manager
func NewManager(config *config.AIConfig, logger logger.Logger) (*Manager, error) {
	manager := &Manager{
		providers:    make(map[string]Provider),
		primary:      config.PrimaryProvider,
		fallbacks:    config.FallbackProviders,
		loadBalancer: NewLoadBalancer(config.LoadBalancingStrategy),
		logger:       logger,
		config:       config,
		metrics:      NewProviderMetrics(),
	}

	// Initialize providers
	if err := manager.initializeProviders(); err != nil {
		return nil, fmt.Errorf("failed to initialize providers: %w", err)
	}

	// Start health monitoring
	go manager.startHealthMonitoring()

	logger.Info("AI Manager initialized", 
		"primary", manager.primary, 
		"fallbacks", manager.fallbacks,
		"providers", len(manager.providers))

	return manager, nil
}

// initializeProviders initializes all configured AI providers
func (m *Manager) initializeProviders() error {
	// Initialize Gemini provider
	if m.config.Gemini.Enabled {
		gemini, err := NewGeminiProvider(m.config.Gemini, m.logger)
		if err != nil {
			m.logger.Error("Failed to initialize Gemini provider", "error", err)
		} else {
			m.providers["gemini"] = gemini
			m.logger.Info("Gemini provider initialized")
		}
	}

	// Initialize Mistral provider
	if m.config.Mistral.Enabled {
		mistral, err := NewMistralProvider(m.config.Mistral, m.logger)
		if err != nil {
			m.logger.Error("Failed to initialize Mistral provider", "error", err)
		} else {
			m.providers["mistral"] = mistral
			m.logger.Info("Mistral provider initialized")
		}
	}

	// Initialize DeepSeek provider
	if m.config.DeepSeek.Enabled {
		deepseek, err := NewDeepSeekProvider(m.config.DeepSeek, m.logger)
		if err != nil {
			m.logger.Error("Failed to initialize DeepSeek provider", "error", err)
		} else {
			m.providers["deepseek"] = deepseek
			m.logger.Info("DeepSeek provider initialized")
		}
	}

	// Initialize OpenAI provider (optional)
	if m.config.OpenAI.Enabled {
		openai, err := NewOpenAIProvider(m.config.OpenAI, m.logger)
		if err != nil {
			m.logger.Error("Failed to initialize OpenAI provider", "error", err)
		} else {
			m.providers["openai"] = openai
			m.logger.Info("OpenAI provider initialized")
		}
	}

	if len(m.providers) == 0 {
		return fmt.Errorf("no AI providers were successfully initialized")
	}

	return nil
}

// GenerateResponse generates a response using the best available provider
func (m *Manager) GenerateResponse(ctx context.Context, req *GenerateRequest) (string, error) {
	provider, err := m.selectProvider()
	if err != nil {
		return "", fmt.Errorf("no available provider: %w", err)
	}

	startTime := time.Now()
	response, err := provider.GenerateResponse(ctx, req)
	duration := time.Since(startTime)

	// Update metrics
	m.updateMetrics(provider.Name(), err == nil, duration)

	if err != nil {
		// Try fallback providers
		for _, fallbackName := range m.fallbacks {
			if fallbackProvider, exists := m.providers[fallbackName]; exists && fallbackProvider.Name() != provider.Name() {
				m.logger.Warn("Primary provider failed, trying fallback", 
					"primary", provider.Name(), 
					"fallback", fallbackName, 
					"error", err)

				startTime = time.Now()
				response, err = fallbackProvider.GenerateResponse(ctx, req)
				duration = time.Since(startTime)

				m.updateMetrics(fallbackProvider.Name(), err == nil, duration)

				if err == nil {
					return response.Content, nil
				}
			}
		}
		return "", fmt.Errorf("all providers failed: %w", err)
	}

	return response.Content, nil
}

// GenerateCode generates code using the best available provider
func (m *Manager) GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error) {
	provider, err := m.selectProvider()
	if err != nil {
		return nil, fmt.Errorf("no available provider: %w", err)
	}

	startTime := time.Now()
	response, err := provider.GenerateCode(ctx, req)
	duration := time.Since(startTime)

	m.updateMetrics(provider.Name(), err == nil, duration)

	if err != nil {
		// Try fallback providers
		for _, fallbackName := range m.fallbacks {
			if fallbackProvider, exists := m.providers[fallbackName]; exists && fallbackProvider.Name() != provider.Name() {
				startTime = time.Now()
				response, err = fallbackProvider.GenerateCode(ctx, req)
				duration = time.Since(startTime)

				m.updateMetrics(fallbackProvider.Name(), err == nil, duration)

				if err == nil {
					return response, nil
				}
			}
		}
		return nil, fmt.Errorf("all providers failed: %w", err)
	}

	return response, nil
}

// AnalyzeCode analyzes code using the best available provider
func (m *Manager) AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error) {
	provider, err := m.selectProvider()
	if err != nil {
		return nil, fmt.Errorf("no available provider: %w", err)
	}

	startTime := time.Now()
	response, err := provider.AnalyzeCode(ctx, req)
	duration := time.Since(startTime)

	m.updateMetrics(provider.Name(), err == nil, duration)

	if err != nil {
		// Try fallback providers
		for _, fallbackName := range m.fallbacks {
			if fallbackProvider, exists := m.providers[fallbackName]; exists && fallbackProvider.Name() != provider.Name() {
				startTime = time.Now()
				response, err = fallbackProvider.AnalyzeCode(ctx, req)
				duration = time.Since(startTime)

				m.updateMetrics(fallbackProvider.Name(), err == nil, duration)

				if err == nil {
					return response, nil
				}
			}
		}
		return nil, fmt.Errorf("all providers failed: %w", err)
	}

	return response, nil
}

// TranslateCode translates code between languages
func (m *Manager) TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error) {
	provider, err := m.selectProvider()
	if err != nil {
		return nil, fmt.Errorf("no available provider: %w", err)
	}

	startTime := time.Now()
	response, err := provider.TranslateCode(ctx, req)
	duration := time.Since(startTime)

	m.updateMetrics(provider.Name(), err == nil, duration)

	if err != nil {
		// Try fallback providers
		for _, fallbackName := range m.fallbacks {
			if fallbackProvider, exists := m.providers[fallbackName]; exists && fallbackProvider.Name() != provider.Name() {
				startTime = time.Now()
				response, err = fallbackProvider.TranslateCode(ctx, req)
				duration = time.Since(startTime)

				m.updateMetrics(fallbackProvider.Name(), err == nil, duration)

				if err == nil {
					return response, nil
				}
			}
		}
		return nil, fmt.Errorf("all providers failed: %w", err)
	}

	return response, nil
}

// selectProvider selects the best provider based on load balancing strategy
func (m *Manager) selectProvider() (Provider, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	// First try primary provider if healthy
	if primary, exists := m.providers[m.primary]; exists && primary.IsHealthy() {
		return primary, nil
	}

	// Try fallback providers
	for _, name := range m.fallbacks {
		if provider, exists := m.providers[name]; exists && provider.IsHealthy() {
			return provider, nil
		}
	}

	return nil, fmt.Errorf("no healthy providers available")
}

// updateMetrics updates provider metrics
func (m *Manager) updateMetrics(providerName string, success bool, duration time.Duration) {
	m.metrics.mutex.Lock()
	defer m.metrics.mutex.Unlock()

	stats, exists := m.metrics.providers[providerName]
	if !exists {
		stats = &ProviderStats{
			TotalUsage: &Usage{},
		}
		m.metrics.providers[providerName] = stats
	}

	stats.RequestCount++
	if success {
		stats.SuccessCount++
	} else {
		stats.ErrorCount++
	}

	// Update average latency
	if stats.AverageLatency == 0 {
		stats.AverageLatency = duration
	} else {
		stats.AverageLatency = (stats.AverageLatency + duration) / 2
	}

	stats.LastUsed = time.Now()
}

// startHealthMonitoring starts health monitoring for all providers
func (m *Manager) startHealthMonitoring() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			m.checkProviderHealth()
		}
	}
}

// checkProviderHealth checks the health of all providers
func (m *Manager) checkProviderHealth() {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	for name, provider := range m.providers {
		healthy := provider.IsHealthy()
		
		m.metrics.mutex.Lock()
		if stats, exists := m.metrics.providers[name]; exists {
			stats.HealthStatus = healthy
		}
		m.metrics.mutex.Unlock()

		if !healthy {
			m.logger.Warn("Provider unhealthy", "provider", name)
		}
	}
}

// GetMetrics returns current provider metrics
func (m *Manager) GetMetrics() map[string]*ProviderStats {
	m.metrics.mutex.RLock()
	defer m.metrics.mutex.RUnlock()

	result := make(map[string]*ProviderStats)
	for name, stats := range m.metrics.providers {
		result[name] = stats
	}
	return result
}

// NewLoadBalancer creates a new load balancer
func NewLoadBalancer(strategy string) *LoadBalancer {
	return &LoadBalancer{
		strategy: strategy,
		counters: make(map[string]int),
	}
}

// NewProviderMetrics creates a new provider metrics instance
func NewProviderMetrics() *ProviderMetrics {
	return &ProviderMetrics{
		providers: make(map[string]*ProviderStats),
	}
}
