package ai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"
)

// MistralProvider implements the Provider interface for Mistral AI
type MistralProvider struct {
	client   *http.Client
	config   *config.MistralConfig
	logger   logger.Logger
	baseURL  string
	healthy  bool
	lastUsed time.Time
	usage    *Usage
}

// MistralRequest represents a request to Mistral API
type MistralRequest struct {
	Model       string              `json:"model"`
	Messages    []MistralMessage    `json:"messages"`
	Temperature float64             `json:"temperature,omitempty"`
	MaxTokens   int                 `json:"max_tokens,omitempty"`
	TopP        float64             `json:"top_p,omitempty"`
	Stream      bool                `json:"stream,omitempty"`
	SafePrompt  bool                `json:"safe_prompt,omitempty"`
}

// MistralMessage represents a message in Mistral format
type MistralMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

// MistralResponse represents a response from Mistral API
type MistralResponse struct {
	ID      string           `json:"id"`
	Object  string           `json:"object"`
	Created int64            `json:"created"`
	Model   string           `json:"model"`
	Choices []MistralChoice  `json:"choices"`
	Usage   MistralUsage     `json:"usage"`
}

// MistralChoice represents a choice in Mistral response
type MistralChoice struct {
	Index        int            `json:"index"`
	Message      MistralMessage `json:"message"`
	FinishReason string         `json:"finish_reason"`
}

// MistralUsage represents usage statistics from Mistral
type MistralUsage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

// NewMistralProvider creates a new Mistral provider
func NewMistralProvider(config *config.MistralConfig, logger logger.Logger) (*MistralProvider, error) {
	client := &http.Client{
		Timeout: time.Duration(config.Timeout) * time.Second,
	}

	provider := &MistralProvider{
		client:   client,
		config:   config,
		logger:   logger,
		baseURL:  config.BaseURL,
		healthy:  true,
		usage:    &Usage{},
	}

	// Test the connection
	if err := provider.testConnection(); err != nil {
		logger.Warn("Mistral provider connection test failed", "error", err)
		provider.healthy = false
	}

	return provider, nil
}

// Name returns the provider name
func (m *MistralProvider) Name() string {
	return "mistral"
}

// GenerateResponse generates a response using Mistral
func (m *MistralProvider) GenerateResponse(ctx context.Context, req *GenerateRequest) (*GenerateResponse, error) {
	startTime := time.Now()
	m.lastUsed = startTime

	// Convert messages to Mistral format
	messages := make([]MistralMessage, 0, len(req.Messages))
	for _, msg := range req.Messages {
		messages = append(messages, MistralMessage{
			Role:    msg.Role,
			Content: msg.Content,
		})
	}

	// Create Mistral request
	mistralReq := MistralRequest{
		Model:       m.getModel(req.Model),
		Messages:    messages,
		Temperature: req.Temperature,
		MaxTokens:   req.MaxTokens,
		TopP:        m.config.TopP,
		SafePrompt:  true,
	}

	// Set defaults if not specified
	if mistralReq.Temperature == 0 {
		mistralReq.Temperature = m.config.Temperature
	}
	if mistralReq.MaxTokens == 0 {
		mistralReq.MaxTokens = m.config.MaxTokens
	}

	// Make API request
	response, err := m.makeRequest(ctx, mistralReq)
	if err != nil {
		m.healthy = false
		return nil, fmt.Errorf("Mistral API error: %w", err)
	}

	m.healthy = true

	// Extract content from response
	var content string
	if len(response.Choices) > 0 {
		content = response.Choices[0].Message.Content
	}

	// Convert usage statistics
	usage := &Usage{
		PromptTokens:     response.Usage.PromptTokens,
		CompletionTokens: response.Usage.CompletionTokens,
		TotalTokens:      response.Usage.TotalTokens,
		Cost:             m.calculateCost(response.Usage.TotalTokens),
	}

	m.updateUsage(usage)

	return &GenerateResponse{
		Content:  content,
		Usage:    usage,
		Model:    response.Model,
		Provider: "mistral",
		Duration: time.Since(startTime),
		Metadata: map[string]interface{}{
			"finish_reason": response.Choices[0].FinishReason,
			"id":           response.ID,
		},
	}, nil
}

// GenerateCode generates code using Mistral
func (m *MistralProvider) GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error) {
	// Create a specialized prompt for code generation
	prompt := m.buildCodeGenerationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert software engineer. Generate clean, efficient, and well-documented code.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: req.Temperature,
		MaxTokens:   req.MaxTokens,
		Model:       "mistral-large-latest", // Use the best model for code generation
	}

	response, err := m.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the response to extract code and explanation
	code, explanation := m.parseCodeResponse(response.Content)

	return &CodeGenerateResponse{
		Code:        code,
		Language:    req.Language,
		Explanation: explanation,
		Usage:       response.Usage,
		Confidence:  0.82, // Default confidence for Mistral
	}, nil
}

// AnalyzeCode analyzes code using Mistral
func (m *MistralProvider) AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error) {
	prompt := m.buildCodeAnalysisPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert code reviewer. Analyze the code for issues, bugs, and improvements.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.3, // Lower temperature for analysis
		MaxTokens:   2048,
		Model:       "mistral-large-latest",
	}

	response, err := m.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the analysis response
	issues, suggestions, metrics := m.parseAnalysisResponse(response.Content)

	return &CodeAnalyzeResponse{
		Issues:      issues,
		Suggestions: suggestions,
		Metrics:     metrics,
		Usage:       response.Usage,
	}, nil
}

// TranslateCode translates code between languages using Mistral
func (m *MistralProvider) TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error) {
	prompt := m.buildCodeTranslationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: fmt.Sprintf("You are an expert programmer. Translate code from %s to %s while preserving functionality and following best practices.", req.FromLanguage, req.ToLanguage),
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.2, // Lower temperature for translation
		MaxTokens:   4096,
		Model:       "mistral-large-latest",
	}

	response, err := m.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the translation response
	translatedCode, explanation := m.parseCodeResponse(response.Content)

	return &CodeTranslateResponse{
		TranslatedCode: translatedCode,
		Language:       req.ToLanguage,
		Explanation:    explanation,
		Usage:          response.Usage,
		Confidence:     0.78, // Default confidence for translation
	}, nil
}

// IsHealthy returns the health status of the provider
func (m *MistralProvider) IsHealthy() bool {
	return m.healthy
}

// GetUsage returns the current usage statistics
func (m *MistralProvider) GetUsage() *Usage {
	return m.usage
}

// makeRequest makes a request to the Mistral API
func (m *MistralProvider) makeRequest(ctx context.Context, req MistralRequest) (*MistralResponse, error) {
	// Marshal request to JSON
	jsonData, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	// Create HTTP request
	httpReq, err := http.NewRequestWithContext(ctx, "POST", m.baseURL+"/chat/completions", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Set headers
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+m.config.APIKey)

	// Make request
	resp, err := m.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	// Read response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	// Check for HTTP errors
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("API error: %d - %s", resp.StatusCode, string(body))
	}

	// Parse response
	var mistralResp MistralResponse
	if err := json.Unmarshal(body, &mistralResp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &mistralResp, nil
}

// testConnection tests the connection to Mistral API
func (m *MistralProvider) testConnection() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Simple test request
	req := MistralRequest{
		Model: m.config.Model,
		Messages: []MistralMessage{
			{Role: "user", Content: "Hello"},
		},
		MaxTokens: 10,
	}

	_, err := m.makeRequest(ctx, req)
	return err
}

// getModel returns the appropriate model name
func (m *MistralProvider) getModel(requestedModel string) string {
	if requestedModel != "" {
		return requestedModel
	}
	return m.config.Model
}

// buildCodeGenerationPrompt builds a prompt for code generation
func (m *MistralProvider) buildCodeGenerationPrompt(req *CodeGenerateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Generate %s code for the following request:\n\n", req.Language))
	prompt.WriteString(req.Prompt)
	
	if req.Framework != "" {
		prompt.WriteString(fmt.Sprintf("\n\nUse the %s framework.", req.Framework))
	}
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n\nProject framework: %s", req.Context.Framework))
		}
		if len(req.Context.Dependencies) > 0 {
			prompt.WriteString(fmt.Sprintf("\n\nAvailable dependencies: %s", strings.Join(req.Context.Dependencies, ", ")))
		}
	}
	
	prompt.WriteString("\n\nProvide clean, well-documented code with explanations.")
	
	return prompt.String()
}

// buildCodeAnalysisPrompt builds a prompt for code analysis
func (m *MistralProvider) buildCodeAnalysisPrompt(req *CodeAnalyzeRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Analyze the following %s code for %s:\n\n", req.Language, req.AnalysisType))
	prompt.WriteString("```" + req.Language + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	prompt.WriteString("Provide detailed analysis including issues, suggestions, and metrics.")
	
	return prompt.String()
}

// buildCodeTranslationPrompt builds a prompt for code translation
func (m *MistralProvider) buildCodeTranslationPrompt(req *CodeTranslateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Translate the following %s code to %s:\n\n", req.FromLanguage, req.ToLanguage))
	prompt.WriteString("```" + req.FromLanguage + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	prompt.WriteString("Preserve functionality and follow best practices for the target language.")
	
	return prompt.String()
}

// parseCodeResponse parses a code generation response
func (m *MistralProvider) parseCodeResponse(content string) (code, explanation string) {
	// Simple parsing - look for code blocks
	lines := strings.Split(content, "\n")
	var codeLines []string
	var explanationLines []string
	inCodeBlock := false
	
	for _, line := range lines {
		if strings.HasPrefix(line, "```") {
			inCodeBlock = !inCodeBlock
			continue
		}
		
		if inCodeBlock {
			codeLines = append(codeLines, line)
		} else {
			explanationLines = append(explanationLines, line)
		}
	}
	
	code = strings.Join(codeLines, "\n")
	explanation = strings.Join(explanationLines, "\n")
	
	return strings.TrimSpace(code), strings.TrimSpace(explanation)
}

// parseAnalysisResponse parses a code analysis response
func (m *MistralProvider) parseAnalysisResponse(content string) ([]*CodeIssue, []*CodeSuggestion, *CodeMetrics) {
	// Simplified parsing - in a real implementation, this would be more sophisticated
	issues := []*CodeIssue{}
	suggestions := []*CodeSuggestion{}
	metrics := &CodeMetrics{
		Maintainability: 0.75,
		Readability:     0.8,
		TestCoverage:    0.0,
	}
	
	return issues, suggestions, metrics
}

// calculateCost calculates the cost based on token usage
func (m *MistralProvider) calculateCost(tokens int) float64 {
	// Mistral pricing (example rates)
	costPerToken := 0.000015 // $0.000015 per token
	return float64(tokens) * costPerToken
}

// updateUsage updates the usage statistics
func (m *MistralProvider) updateUsage(usage *Usage) {
	m.usage.PromptTokens += usage.PromptTokens
	m.usage.CompletionTokens += usage.CompletionTokens
	m.usage.TotalTokens += usage.TotalTokens
	m.usage.Cost += usage.Cost
}
