package ai

import (
	"context"
	"fmt"
	"strings"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"

	"github.com/sashabaranov/go-openai"
)

// DeepSeekProvider implements the Provider interface for DeepSeek
type DeepSeekProvider struct {
	client   *openai.Client
	config   *config.DeepSeekConfig
	logger   logger.Logger
	healthy  bool
	lastUsed time.Time
	usage    *Usage
}

// NewDeepSeekProvider creates a new DeepSeek provider
func NewDeepSeekProvider(config *config.DeepSeekConfig, logger logger.Logger) (*DeepSeekProvider, error) {
	clientConfig := openai.DefaultConfig(config.APIKey)
	clientConfig.BaseURL = config.BaseURL
	
	client := openai.NewClientWithConfig(clientConfig)

	provider := &DeepSeekProvider{
		client:   client,
		config:   config,
		logger:   logger,
		healthy:  true,
		usage:    &Usage{},
	}

	// Test the connection
	if err := provider.testConnection(); err != nil {
		logger.Warn("DeepSeek provider connection test failed", "error", err)
		provider.healthy = false
	}

	return provider, nil
}

// Name returns the provider name
func (d *DeepSeekProvider) Name() string {
	return "deepseek"
}

// GenerateResponse generates a response using DeepSeek
func (d *DeepSeekProvider) GenerateResponse(ctx context.Context, req *GenerateRequest) (*GenerateResponse, error) {
	startTime := time.Now()
	d.lastUsed = startTime

	// Convert messages to OpenAI format
	messages := make([]openai.ChatCompletionMessage, 0, len(req.Messages))
	for _, msg := range req.Messages {
		messages = append(messages, openai.ChatCompletionMessage{
			Role:    msg.Role,
			Content: msg.Content,
		})
	}

	// Create request
	chatReq := openai.ChatCompletionRequest{
		Model:       d.getModel(req.Model),
		Messages:    messages,
		Temperature: float32(req.Temperature),
		MaxTokens:   req.MaxTokens,
		TopP:        float32(d.config.TopP),
		Stream:      false,
	}

	// Set defaults if not specified
	if chatReq.Temperature == 0 {
		chatReq.Temperature = float32(d.config.Temperature)
	}
	if chatReq.MaxTokens == 0 {
		chatReq.MaxTokens = d.config.MaxTokens
	}

	// Make API request
	response, err := d.client.CreateChatCompletion(ctx, chatReq)
	if err != nil {
		d.healthy = false
		return nil, fmt.Errorf("DeepSeek API error: %w", err)
	}

	d.healthy = true

	// Extract content from response
	var content string
	if len(response.Choices) > 0 {
		content = response.Choices[0].Message.Content
	}

	// Convert usage statistics
	usage := &Usage{
		PromptTokens:     response.Usage.PromptTokens,
		CompletionTokens: response.Usage.CompletionTokens,
		TotalTokens:      response.Usage.TotalTokens,
		Cost:             d.calculateCost(response.Usage.TotalTokens),
	}

	d.updateUsage(usage)

	return &GenerateResponse{
		Content:  content,
		Usage:    usage,
		Model:    response.Model,
		Provider: "deepseek",
		Duration: time.Since(startTime),
		Metadata: map[string]interface{}{
			"finish_reason": response.Choices[0].FinishReason,
			"id":           response.ID,
		},
	}, nil
}

// GenerateCode generates code using DeepSeek
func (d *DeepSeekProvider) GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error) {
	// Create a specialized prompt for code generation
	prompt := d.buildCodeGenerationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are DeepSeek Coder, an expert AI programming assistant. Generate clean, efficient, and well-documented code following best practices.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: req.Temperature,
		MaxTokens:   req.MaxTokens,
		Model:       "deepseek-coder", // Use the coding-specific model
	}

	response, err := d.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the response to extract code and explanation
	code, explanation := d.parseCodeResponse(response.Content)

	return &CodeGenerateResponse{
		Code:        code,
		Language:    req.Language,
		Explanation: explanation,
		Usage:       response.Usage,
		Confidence:  0.88, // DeepSeek is particularly good at coding
	}, nil
}

// AnalyzeCode analyzes code using DeepSeek
func (d *DeepSeekProvider) AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error) {
	prompt := d.buildCodeAnalysisPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are DeepSeek Coder, an expert code reviewer. Analyze the code thoroughly for issues, bugs, performance problems, and improvements.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.2, // Lower temperature for analysis
		MaxTokens:   2048,
		Model:       "deepseek-coder",
	}

	response, err := d.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the analysis response
	issues, suggestions, metrics := d.parseAnalysisResponse(response.Content)

	return &CodeAnalyzeResponse{
		Issues:      issues,
		Suggestions: suggestions,
		Metrics:     metrics,
		Usage:       response.Usage,
	}, nil
}

// TranslateCode translates code between languages using DeepSeek
func (d *DeepSeekProvider) TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error) {
	prompt := d.buildCodeTranslationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: fmt.Sprintf("You are DeepSeek Coder, an expert in multiple programming languages. Translate code from %s to %s while preserving functionality, following best practices, and maintaining code quality.", req.FromLanguage, req.ToLanguage),
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.1, // Very low temperature for translation accuracy
		MaxTokens:   4096,
		Model:       "deepseek-coder",
	}

	response, err := d.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the translation response
	translatedCode, explanation := d.parseCodeResponse(response.Content)

	return &CodeTranslateResponse{
		TranslatedCode: translatedCode,
		Language:       req.ToLanguage,
		Explanation:    explanation,
		Usage:          response.Usage,
		Confidence:     0.85, // High confidence for DeepSeek code translation
	}, nil
}

// IsHealthy returns the health status of the provider
func (d *DeepSeekProvider) IsHealthy() bool {
	return d.healthy
}

// GetUsage returns the current usage statistics
func (d *DeepSeekProvider) GetUsage() *Usage {
	return d.usage
}

// testConnection tests the connection to DeepSeek API
func (d *DeepSeekProvider) testConnection() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Simple test request
	req := openai.ChatCompletionRequest{
		Model: d.config.Model,
		Messages: []openai.ChatCompletionMessage{
			{Role: "user", Content: "Hello"},
		},
		MaxTokens: 10,
	}

	_, err := d.client.CreateChatCompletion(ctx, req)
	return err
}

// getModel returns the appropriate model name
func (d *DeepSeekProvider) getModel(requestedModel string) string {
	if requestedModel != "" {
		return requestedModel
	}
	return d.config.Model
}

// buildCodeGenerationPrompt builds a prompt for code generation
func (d *DeepSeekProvider) buildCodeGenerationPrompt(req *CodeGenerateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Generate high-quality %s code for the following request:\n\n", req.Language))
	prompt.WriteString(req.Prompt)
	
	if req.Framework != "" {
		prompt.WriteString(fmt.Sprintf("\n\nRequirements:\n- Use the %s framework", req.Framework))
	}
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n- Project framework: %s", req.Context.Framework))
		}
		if len(req.Context.Dependencies) > 0 {
			prompt.WriteString(fmt.Sprintf("\n- Available dependencies: %s", strings.Join(req.Context.Dependencies, ", ")))
		}
		if req.Context.Environment != "" {
			prompt.WriteString(fmt.Sprintf("\n- Target environment: %s", req.Context.Environment))
		}
	}
	
	prompt.WriteString("\n\nPlease provide:")
	prompt.WriteString("\n1. Clean, well-structured code")
	prompt.WriteString("\n2. Proper error handling")
	prompt.WriteString("\n3. Comprehensive comments")
	prompt.WriteString("\n4. Brief explanation of the implementation")
	
	return prompt.String()
}

// buildCodeAnalysisPrompt builds a prompt for code analysis
func (d *DeepSeekProvider) buildCodeAnalysisPrompt(req *CodeAnalyzeRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Perform a comprehensive %s analysis of the following %s code:\n\n", req.AnalysisType, req.Language))
	prompt.WriteString("```" + req.Language + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	
	switch req.AnalysisType {
	case "bugs":
		prompt.WriteString("Focus on identifying potential bugs, logic errors, and runtime issues.")
	case "performance":
		prompt.WriteString("Focus on performance bottlenecks, optimization opportunities, and efficiency improvements.")
	case "security":
		prompt.WriteString("Focus on security vulnerabilities, potential attack vectors, and security best practices.")
	case "style":
		prompt.WriteString("Focus on code style, formatting, naming conventions, and readability improvements.")
	default:
		prompt.WriteString("Provide a comprehensive analysis covering bugs, performance, security, and style issues.")
	}
	
	prompt.WriteString("\n\nProvide:")
	prompt.WriteString("\n1. Detailed list of issues found")
	prompt.WriteString("\n2. Specific suggestions for improvement")
	prompt.WriteString("\n3. Code quality metrics")
	prompt.WriteString("\n4. Priority levels for each issue")
	
	return prompt.String()
}

// buildCodeTranslationPrompt builds a prompt for code translation
func (d *DeepSeekProvider) buildCodeTranslationPrompt(req *CodeTranslateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Translate the following %s code to %s:\n\n", req.FromLanguage, req.ToLanguage))
	prompt.WriteString("```" + req.FromLanguage + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	
	prompt.WriteString("Translation requirements:")
	prompt.WriteString("\n1. Preserve all functionality and behavior")
	prompt.WriteString("\n2. Follow " + req.ToLanguage + " best practices and idioms")
	prompt.WriteString("\n3. Use appropriate " + req.ToLanguage + " libraries and patterns")
	prompt.WriteString("\n4. Maintain code structure and readability")
	prompt.WriteString("\n5. Add comments explaining any significant changes")
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n6. Target framework: %s", req.Context.Framework))
		}
		if req.Context.Version != "" {
			prompt.WriteString(fmt.Sprintf("\n7. Target version: %s", req.Context.Version))
		}
	}
	
	return prompt.String()
}

// parseCodeResponse parses a code generation response
func (d *DeepSeekProvider) parseCodeResponse(content string) (code, explanation string) {
	// Enhanced parsing for DeepSeek responses
	lines := strings.Split(content, "\n")
	var codeLines []string
	var explanationLines []string
	inCodeBlock := false
	codeBlockLang := ""
	
	for _, line := range lines {
		trimmedLine := strings.TrimSpace(line)
		
		if strings.HasPrefix(trimmedLine, "```") {
			if !inCodeBlock {
				// Starting code block
				inCodeBlock = true
				if len(trimmedLine) > 3 {
					codeBlockLang = trimmedLine[3:]
				}
			} else {
				// Ending code block
				inCodeBlock = false
				codeBlockLang = ""
			}
			continue
		}
		
		if inCodeBlock {
			codeLines = append(codeLines, line)
		} else {
			// Skip empty lines at the beginning of explanation
			if len(explanationLines) > 0 || trimmedLine != "" {
				explanationLines = append(explanationLines, line)
			}
		}
	}
	
	code = strings.Join(codeLines, "\n")
	explanation = strings.Join(explanationLines, "\n")
	
	return strings.TrimSpace(code), strings.TrimSpace(explanation)
}

// parseAnalysisResponse parses a code analysis response
func (d *DeepSeekProvider) parseAnalysisResponse(content string) ([]*CodeIssue, []*CodeSuggestion, *CodeMetrics) {
	// Enhanced parsing for DeepSeek analysis responses
	issues := []*CodeIssue{}
	suggestions := []*CodeSuggestion{}
	
	// DeepSeek typically provides high-quality analysis
	metrics := &CodeMetrics{
		Maintainability: 0.85,
		Readability:     0.82,
		TestCoverage:    0.0, // Would need actual test analysis
		Complexity:      calculateComplexity(content),
	}
	
	// Parse issues and suggestions from the response
	// This is a simplified implementation - in practice, you'd use more sophisticated parsing
	lines := strings.Split(content, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.Contains(strings.ToLower(line), "issue") || strings.Contains(strings.ToLower(line), "problem") {
			issue := &CodeIssue{
				Type:     "general",
				Severity: "medium",
				Message:  line,
				Line:     0, // Would need line number extraction
				Column:   0,
			}
			issues = append(issues, issue)
		}
		
		if strings.Contains(strings.ToLower(line), "suggest") || strings.Contains(strings.ToLower(line), "recommend") {
			suggestion := &CodeSuggestion{
				Type:       "improvement",
				Message:    line,
				Confidence: 0.8,
				Impact:     "medium",
			}
			suggestions = append(suggestions, suggestion)
		}
	}
	
	return issues, suggestions, metrics
}

// calculateComplexity calculates a simple complexity metric
func calculateComplexity(content string) int {
	// Simple complexity calculation based on keywords
	complexity := 0
	keywords := []string{"if", "for", "while", "switch", "case", "try", "catch"}
	
	for _, keyword := range keywords {
		complexity += strings.Count(strings.ToLower(content), keyword)
	}
	
	return complexity
}

// calculateCost calculates the cost based on token usage
func (d *DeepSeekProvider) calculateCost(tokens int) float64 {
	// DeepSeek pricing (example rates - very competitive)
	costPerToken := 0.000005 // $0.000005 per token
	return float64(tokens) * costPerToken
}

// updateUsage updates the usage statistics
func (d *DeepSeekProvider) updateUsage(usage *Usage) {
	d.usage.PromptTokens += usage.PromptTokens
	d.usage.CompletionTokens += usage.CompletionTokens
	d.usage.TotalTokens += usage.TotalTokens
	d.usage.Cost += usage.Cost
}
