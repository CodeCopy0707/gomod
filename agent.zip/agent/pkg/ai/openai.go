package ai

import (
	"context"
	"fmt"
	"strings"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"

	"github.com/sashabaranov/go-openai"
)

// OpenAIProvider implements the Provider interface for OpenAI
type OpenAIProvider struct {
	client   *openai.Client
	config   *config.OpenAIConfig
	logger   logger.Logger
	healthy  bool
	lastUsed time.Time
	usage    *Usage
}

// NewOpenAIProvider creates a new OpenAI provider
func NewOpenAIProvider(config *config.OpenAIConfig, logger logger.Logger) (*OpenAIProvider, error) {
	client := openai.NewClient(config.APIKey)

	provider := &OpenAIProvider{
		client:   client,
		config:   config,
		logger:   logger,
		healthy:  true,
		usage:    &Usage{},
	}

	// Test the connection
	if err := provider.testConnection(); err != nil {
		logger.Warn("OpenAI provider connection test failed", "error", err)
		provider.healthy = false
	}

	return provider, nil
}

// Name returns the provider name
func (o *OpenAIProvider) Name() string {
	return "openai"
}

// GenerateResponse generates a response using OpenAI
func (o *OpenAIProvider) GenerateResponse(ctx context.Context, req *GenerateRequest) (*GenerateResponse, error) {
	startTime := time.Now()
	o.lastUsed = startTime

	// Convert messages to OpenAI format
	messages := make([]openai.ChatCompletionMessage, 0, len(req.Messages))
	for _, msg := range req.Messages {
		messages = append(messages, openai.ChatCompletionMessage{
			Role:    msg.Role,
			Content: msg.Content,
		})
	}

	// Create request
	chatReq := openai.ChatCompletionRequest{
		Model:       o.getModel(req.Model),
		Messages:    messages,
		Temperature: float32(req.Temperature),
		MaxTokens:   req.MaxTokens,
		TopP:        float32(o.config.TopP),
		Stream:      false,
	}

	// Set defaults if not specified
	if chatReq.Temperature == 0 {
		chatReq.Temperature = float32(o.config.Temperature)
	}
	if chatReq.MaxTokens == 0 {
		chatReq.MaxTokens = o.config.MaxTokens
	}

	// Make API request
	response, err := o.client.CreateChatCompletion(ctx, chatReq)
	if err != nil {
		o.healthy = false
		return nil, fmt.Errorf("OpenAI API error: %w", err)
	}

	o.healthy = true

	// Extract content from response
	var content string
	if len(response.Choices) > 0 {
		content = response.Choices[0].Message.Content
	}

	// Convert usage statistics
	usage := &Usage{
		PromptTokens:     response.Usage.PromptTokens,
		CompletionTokens: response.Usage.CompletionTokens,
		TotalTokens:      response.Usage.TotalTokens,
		Cost:             o.calculateCost(response.Usage.TotalTokens, response.Model),
	}

	o.updateUsage(usage)

	return &GenerateResponse{
		Content:  content,
		Usage:    usage,
		Model:    response.Model,
		Provider: "openai",
		Duration: time.Since(startTime),
		Metadata: map[string]interface{}{
			"finish_reason": response.Choices[0].FinishReason,
			"id":           response.ID,
		},
	}, nil
}

// GenerateCode generates code using OpenAI
func (o *OpenAIProvider) GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error) {
	// Create a specialized prompt for code generation
	prompt := o.buildCodeGenerationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert software engineer and coding assistant. Generate clean, efficient, and well-documented code following best practices.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: req.Temperature,
		MaxTokens:   req.MaxTokens,
		Model:       "gpt-4", // Use GPT-4 for code generation
	}

	response, err := o.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the response to extract code and explanation
	code, explanation := o.parseCodeResponse(response.Content)

	return &CodeGenerateResponse{
		Code:        code,
		Language:    req.Language,
		Explanation: explanation,
		Usage:       response.Usage,
		Confidence:  0.90, // High confidence for GPT-4
	}, nil
}

// AnalyzeCode analyzes code using OpenAI
func (o *OpenAIProvider) AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error) {
	prompt := o.buildCodeAnalysisPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert code reviewer and software architect. Analyze the code thoroughly for issues, improvements, and best practices.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.3, // Lower temperature for analysis
		MaxTokens:   2048,
		Model:       "gpt-4",
	}

	response, err := o.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the analysis response
	issues, suggestions, metrics := o.parseAnalysisResponse(response.Content)

	return &CodeAnalyzeResponse{
		Issues:      issues,
		Suggestions: suggestions,
		Metrics:     metrics,
		Usage:       response.Usage,
	}, nil
}

// TranslateCode translates code between languages using OpenAI
func (o *OpenAIProvider) TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error) {
	prompt := o.buildCodeTranslationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: fmt.Sprintf("You are an expert programmer fluent in multiple programming languages. Translate code from %s to %s while preserving functionality and following language-specific best practices.", req.FromLanguage, req.ToLanguage),
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.2, // Lower temperature for translation
		MaxTokens:   4096,
		Model:       "gpt-4",
	}

	response, err := o.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the translation response
	translatedCode, explanation := o.parseCodeResponse(response.Content)

	return &CodeTranslateResponse{
		TranslatedCode: translatedCode,
		Language:       req.ToLanguage,
		Explanation:    explanation,
		Usage:          response.Usage,
		Confidence:     0.88, // High confidence for GPT-4 translation
	}, nil
}

// IsHealthy returns the health status of the provider
func (o *OpenAIProvider) IsHealthy() bool {
	return o.healthy
}

// GetUsage returns the current usage statistics
func (o *OpenAIProvider) GetUsage() *Usage {
	return o.usage
}

// testConnection tests the connection to OpenAI API
func (o *OpenAIProvider) testConnection() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Simple test request
	req := openai.ChatCompletionRequest{
		Model: o.config.Model,
		Messages: []openai.ChatCompletionMessage{
			{Role: "user", Content: "Hello"},
		},
		MaxTokens: 10,
	}

	_, err := o.client.CreateChatCompletion(ctx, req)
	return err
}

// getModel returns the appropriate model name
func (o *OpenAIProvider) getModel(requestedModel string) string {
	if requestedModel != "" {
		return requestedModel
	}
	return o.config.Model
}

// buildCodeGenerationPrompt builds a prompt for code generation
func (o *OpenAIProvider) buildCodeGenerationPrompt(req *CodeGenerateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Generate professional %s code for the following request:\n\n", req.Language))
	prompt.WriteString(req.Prompt)
	
	if req.Framework != "" {
		prompt.WriteString(fmt.Sprintf("\n\nRequirements:\n- Use the %s framework", req.Framework))
	}
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n- Project framework: %s", req.Context.Framework))
		}
		if len(req.Context.Dependencies) > 0 {
			prompt.WriteString(fmt.Sprintf("\n- Available dependencies: %s", strings.Join(req.Context.Dependencies, ", ")))
		}
		if req.Context.Environment != "" {
			prompt.WriteString(fmt.Sprintf("\n- Target environment: %s", req.Context.Environment))
		}
	}
	
	prompt.WriteString("\n\nPlease provide:")
	prompt.WriteString("\n1. Clean, production-ready code")
	prompt.WriteString("\n2. Proper error handling and validation")
	prompt.WriteString("\n3. Comprehensive documentation and comments")
	prompt.WriteString("\n4. Unit tests (if applicable)")
	prompt.WriteString("\n5. Brief explanation of the implementation approach")
	
	return prompt.String()
}

// buildCodeAnalysisPrompt builds a prompt for code analysis
func (o *OpenAIProvider) buildCodeAnalysisPrompt(req *CodeAnalyzeRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Perform a thorough %s analysis of the following %s code:\n\n", req.AnalysisType, req.Language))
	prompt.WriteString("```" + req.Language + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	
	switch req.AnalysisType {
	case "bugs":
		prompt.WriteString("Focus on identifying potential bugs, logic errors, edge cases, and runtime issues.")
	case "performance":
		prompt.WriteString("Focus on performance bottlenecks, algorithmic complexity, memory usage, and optimization opportunities.")
	case "security":
		prompt.WriteString("Focus on security vulnerabilities, potential attack vectors, input validation, and security best practices.")
	case "style":
		prompt.WriteString("Focus on code style, formatting, naming conventions, readability, and maintainability.")
	default:
		prompt.WriteString("Provide a comprehensive analysis covering bugs, performance, security, style, and architectural concerns.")
	}
	
	prompt.WriteString("\n\nProvide:")
	prompt.WriteString("\n1. Detailed list of issues with line numbers")
	prompt.WriteString("\n2. Specific, actionable suggestions for improvement")
	prompt.WriteString("\n3. Code quality metrics and scores")
	prompt.WriteString("\n4. Priority levels and impact assessment for each issue")
	prompt.WriteString("\n5. Refactored code examples where applicable")
	
	return prompt.String()
}

// buildCodeTranslationPrompt builds a prompt for code translation
func (o *OpenAIProvider) buildCodeTranslationPrompt(req *CodeTranslateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Translate the following %s code to idiomatic %s:\n\n", req.FromLanguage, req.ToLanguage))
	prompt.WriteString("```" + req.FromLanguage + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	
	prompt.WriteString("Translation requirements:")
	prompt.WriteString("\n1. Preserve all functionality and behavior exactly")
	prompt.WriteString("\n2. Follow " + req.ToLanguage + " best practices and idioms")
	prompt.WriteString("\n3. Use appropriate " + req.ToLanguage + " standard libraries")
	prompt.WriteString("\n4. Maintain or improve code structure and readability")
	prompt.WriteString("\n5. Handle language-specific features appropriately")
	prompt.WriteString("\n6. Add comments explaining significant changes or adaptations")
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n7. Target framework: %s", req.Context.Framework))
		}
		if req.Context.Version != "" {
			prompt.WriteString(fmt.Sprintf("\n8. Target language version: %s", req.Context.Version))
		}
	}
	
	prompt.WriteString("\n\nProvide the translated code with explanations of any significant changes or adaptations made.")
	
	return prompt.String()
}

// parseCodeResponse parses a code generation response
func (o *OpenAIProvider) parseCodeResponse(content string) (code, explanation string) {
	// Enhanced parsing for OpenAI responses
	lines := strings.Split(content, "\n")
	var codeLines []string
	var explanationLines []string
	inCodeBlock := false
	
	for _, line := range lines {
		trimmedLine := strings.TrimSpace(line)
		
		if strings.HasPrefix(trimmedLine, "```") {
			inCodeBlock = !inCodeBlock
			continue
		}
		
		if inCodeBlock {
			codeLines = append(codeLines, line)
		} else {
			// Skip empty lines at the beginning of explanation
			if len(explanationLines) > 0 || trimmedLine != "" {
				explanationLines = append(explanationLines, line)
			}
		}
	}
	
	code = strings.Join(codeLines, "\n")
	explanation = strings.Join(explanationLines, "\n")
	
	return strings.TrimSpace(code), strings.TrimSpace(explanation)
}

// parseAnalysisResponse parses a code analysis response
func (o *OpenAIProvider) parseAnalysisResponse(content string) ([]*CodeIssue, []*CodeSuggestion, *CodeMetrics) {
	// Enhanced parsing for OpenAI analysis responses
	issues := []*CodeIssue{}
	suggestions := []*CodeSuggestion{}
	
	// GPT-4 typically provides very high-quality analysis
	metrics := &CodeMetrics{
		Maintainability: 0.88,
		Readability:     0.85,
		TestCoverage:    0.0, // Would need actual test analysis
		Complexity:      calculateComplexity(content),
	}
	
	// Parse issues and suggestions from the response
	// This is a simplified implementation - in practice, you'd use more sophisticated parsing
	lines := strings.Split(content, "\n")
	for i, line := range lines {
		line = strings.TrimSpace(line)
		
		// Look for issue patterns
		if strings.Contains(strings.ToLower(line), "issue") || 
		   strings.Contains(strings.ToLower(line), "problem") ||
		   strings.Contains(strings.ToLower(line), "bug") {
			severity := "medium"
			if strings.Contains(strings.ToLower(line), "critical") || strings.Contains(strings.ToLower(line), "severe") {
				severity = "high"
			} else if strings.Contains(strings.ToLower(line), "minor") {
				severity = "low"
			}
			
			issue := &CodeIssue{
				Type:     "general",
				Severity: severity,
				Message:  line,
				Line:     extractLineNumber(line),
				Column:   0,
			}
			issues = append(issues, issue)
		}
		
		// Look for suggestion patterns
		if strings.Contains(strings.ToLower(line), "suggest") || 
		   strings.Contains(strings.ToLower(line), "recommend") ||
		   strings.Contains(strings.ToLower(line), "consider") {
			confidence := 0.8
			impact := "medium"
			
			if strings.Contains(strings.ToLower(line), "strongly") {
				confidence = 0.9
				impact = "high"
			}
			
			suggestion := &CodeSuggestion{
				Type:       "improvement",
				Message:    line,
				Confidence: confidence,
				Impact:     impact,
			}
			
			// Try to get the next line as "after" if it looks like code
			if i+1 < len(lines) && strings.Contains(lines[i+1], "```") {
				// Extract code block
				for j := i + 2; j < len(lines) && !strings.Contains(lines[j], "```"); j++ {
					suggestion.After += lines[j] + "\n"
				}
			}
			
			suggestions = append(suggestions, suggestion)
		}
	}
	
	return issues, suggestions, metrics
}

// extractLineNumber tries to extract a line number from a string
func extractLineNumber(text string) int {
	// Simple regex to find "line X" patterns
	// In a real implementation, you'd use proper regex
	words := strings.Fields(strings.ToLower(text))
	for i, word := range words {
		if word == "line" && i+1 < len(words) {
			// Try to parse the next word as a number
			// This is simplified - you'd use strconv.Atoi in practice
			return 0 // Placeholder
		}
	}
	return 0
}

// calculateCost calculates the cost based on token usage and model
func (o *OpenAIProvider) calculateCost(tokens int, model string) float64 {
	// OpenAI pricing varies by model
	var costPerToken float64
	
	switch model {
	case "gpt-4":
		costPerToken = 0.00003 // $0.03 per 1K tokens
	case "gpt-4-turbo":
		costPerToken = 0.00001 // $0.01 per 1K tokens
	case "gpt-3.5-turbo":
		costPerToken = 0.000002 // $0.002 per 1K tokens
	default:
		costPerToken = 0.00001 // Default rate
	}
	
	return float64(tokens) * costPerToken
}

// updateUsage updates the usage statistics
func (o *OpenAIProvider) updateUsage(usage *Usage) {
	o.usage.PromptTokens += usage.PromptTokens
	o.usage.CompletionTokens += usage.CompletionTokens
	o.usage.TotalTokens += usage.TotalTokens
	o.usage.Cost += usage.Cost
}
