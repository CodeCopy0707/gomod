package ai

import (
	"context"
	"fmt"
	"strings"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"

	"github.com/google/generative-ai-go/genai"
	"google.golang.org/api/option"
)

// GeminiProvider implements the Provider interface for Google Gemini
type GeminiProvider struct {
	client   *genai.Client
	config   *config.GeminiConfig
	logger   logger.Logger
	model    *genai.GenerativeModel
	healthy  bool
	lastUsed time.Time
	usage    *Usage
}

// NewGeminiProvider creates a new Gemini provider
func NewGeminiProvider(config *config.GeminiConfig, logger logger.Logger) (*GeminiProvider, error) {
	ctx := context.Background()
	
	client, err := genai.NewClient(ctx, option.WithAPIKey(config.APIKey))
	if err != nil {
		return nil, fmt.Errorf("failed to create Gemini client: %w", err)
	}

	model := client.GenerativeModel(config.Model)
	
	// Configure model parameters
	model.SetTemperature(float32(config.Temperature))
	model.SetMaxOutputTokens(int32(config.MaxTokens))
	model.SetTopP(float32(config.TopP))
	model.SetTopK(int32(config.TopK))

	// Set safety settings
	model.SafetySettings = []*genai.SafetySetting{
		{
			Category:  genai.HarmCategoryHarassment,
			Threshold: genai.HarmBlockMediumAndAbove,
		},
		{
			Category:  genai.HarmCategoryHateSpeech,
			Threshold: genai.HarmBlockMediumAndAbove,
		},
		{
			Category:  genai.HarmCategorySexuallyExplicit,
			Threshold: genai.HarmBlockMediumAndAbove,
		},
		{
			Category:  genai.HarmCategoryDangerousContent,
			Threshold: genai.HarmBlockMediumAndAbove,
		},
	}

	provider := &GeminiProvider{
		client:   client,
		config:   config,
		logger:   logger,
		model:    model,
		healthy:  true,
		usage:    &Usage{},
	}

	// Test the connection
	if err := provider.testConnection(); err != nil {
		logger.Warn("Gemini provider connection test failed", "error", err)
		provider.healthy = false
	}

	return provider, nil
}

// Name returns the provider name
func (g *GeminiProvider) Name() string {
	return "gemini"
}

// GenerateResponse generates a response using Gemini
func (g *GeminiProvider) GenerateResponse(ctx context.Context, req *GenerateRequest) (*GenerateResponse, error) {
	startTime := time.Now()
	g.lastUsed = startTime

	// Convert messages to Gemini format
	parts := make([]genai.Part, 0, len(req.Messages))
	
	for _, msg := range req.Messages {
		switch msg.Role {
		case "user", "assistant", "system":
			parts = append(parts, genai.Text(msg.Content))
		}
	}

	// Create the prompt
	session := g.model.StartChat()
	
	// Set temperature if specified
	if req.Temperature > 0 {
		g.model.SetTemperature(float32(req.Temperature))
	}
	
	// Set max tokens if specified
	if req.MaxTokens > 0 {
		g.model.SetMaxOutputTokens(int32(req.MaxTokens))
	}

	// Generate response
	resp, err := session.SendMessage(ctx, parts...)
	if err != nil {
		g.healthy = false
		return nil, fmt.Errorf("Gemini API error: %w", err)
	}

	g.healthy = true

	// Extract content from response
	var content strings.Builder
	for _, candidate := range resp.Candidates {
		if candidate.Content != nil {
			for _, part := range candidate.Content.Parts {
				if textPart, ok := part.(genai.Text); ok {
					content.WriteString(string(textPart))
				}
			}
		}
	}

	// Update usage statistics
	usage := &Usage{}
	if resp.UsageMetadata != nil {
		usage.PromptTokens = int(resp.UsageMetadata.PromptTokenCount)
		usage.CompletionTokens = int(resp.UsageMetadata.CandidatesTokenCount)
		usage.TotalTokens = int(resp.UsageMetadata.TotalTokenCount)
		usage.Cost = g.calculateCost(usage.TotalTokens)
	}

	g.updateUsage(usage)

	return &GenerateResponse{
		Content:  content.String(),
		Usage:    usage,
		Model:    g.config.Model,
		Provider: "gemini",
		Duration: time.Since(startTime),
		Metadata: map[string]interface{}{
			"finish_reason": getFinishReason(resp),
			"safety_ratings": resp.Candidates[0].SafetyRatings,
		},
	}, nil
}

// GenerateCode generates code using Gemini
func (g *GeminiProvider) GenerateCode(ctx context.Context, req *CodeGenerateRequest) (*CodeGenerateResponse, error) {
	// Create a specialized prompt for code generation
	prompt := g.buildCodeGenerationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert software engineer. Generate clean, efficient, and well-documented code.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: req.Temperature,
		MaxTokens:   req.MaxTokens,
	}

	response, err := g.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the response to extract code and explanation
	code, explanation := g.parseCodeResponse(response.Content)

	return &CodeGenerateResponse{
		Code:        code,
		Language:    req.Language,
		Explanation: explanation,
		Usage:       response.Usage,
		Confidence:  0.85, // Default confidence for Gemini
	}, nil
}

// AnalyzeCode analyzes code using Gemini
func (g *GeminiProvider) AnalyzeCode(ctx context.Context, req *CodeAnalyzeRequest) (*CodeAnalyzeResponse, error) {
	prompt := g.buildCodeAnalysisPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: "You are an expert code reviewer. Analyze the code for issues, bugs, and improvements.",
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.3, // Lower temperature for analysis
		MaxTokens:   2048,
	}

	response, err := g.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the analysis response
	issues, suggestions, metrics := g.parseAnalysisResponse(response.Content)

	return &CodeAnalyzeResponse{
		Issues:      issues,
		Suggestions: suggestions,
		Metrics:     metrics,
		Usage:       response.Usage,
	}, nil
}

// TranslateCode translates code between languages using Gemini
func (g *GeminiProvider) TranslateCode(ctx context.Context, req *CodeTranslateRequest) (*CodeTranslateResponse, error) {
	prompt := g.buildCodeTranslationPrompt(req)
	
	messages := []*Message{
		{
			Role:    "system",
			Content: fmt.Sprintf("You are an expert programmer. Translate code from %s to %s while preserving functionality and following best practices.", req.FromLanguage, req.ToLanguage),
		},
		{
			Role:    "user",
			Content: prompt,
		},
	}

	genReq := &GenerateRequest{
		Messages:    messages,
		Temperature: 0.2, // Lower temperature for translation
		MaxTokens:   4096,
	}

	response, err := g.GenerateResponse(ctx, genReq)
	if err != nil {
		return nil, err
	}

	// Parse the translation response
	translatedCode, explanation := g.parseCodeResponse(response.Content)

	return &CodeTranslateResponse{
		TranslatedCode: translatedCode,
		Language:       req.ToLanguage,
		Explanation:    explanation,
		Usage:          response.Usage,
		Confidence:     0.80, // Default confidence for translation
	}, nil
}

// IsHealthy returns the health status of the provider
func (g *GeminiProvider) IsHealthy() bool {
	return g.healthy
}

// GetUsage returns the current usage statistics
func (g *GeminiProvider) GetUsage() *Usage {
	return g.usage
}

// testConnection tests the connection to Gemini API
func (g *GeminiProvider) testConnection() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Simple test request
	session := g.model.StartChat()
	_, err := session.SendMessage(ctx, genai.Text("Hello"))
	
	return err
}

// buildCodeGenerationPrompt builds a prompt for code generation
func (g *GeminiProvider) buildCodeGenerationPrompt(req *CodeGenerateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Generate %s code for the following request:\n\n", req.Language))
	prompt.WriteString(req.Prompt)
	
	if req.Framework != "" {
		prompt.WriteString(fmt.Sprintf("\n\nUse the %s framework.", req.Framework))
	}
	
	if req.Context != nil {
		if req.Context.Framework != "" {
			prompt.WriteString(fmt.Sprintf("\n\nProject framework: %s", req.Context.Framework))
		}
		if len(req.Context.Dependencies) > 0 {
			prompt.WriteString(fmt.Sprintf("\n\nAvailable dependencies: %s", strings.Join(req.Context.Dependencies, ", ")))
		}
	}
	
	prompt.WriteString("\n\nProvide clean, well-documented code with explanations.")
	
	return prompt.String()
}

// buildCodeAnalysisPrompt builds a prompt for code analysis
func (g *GeminiProvider) buildCodeAnalysisPrompt(req *CodeAnalyzeRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Analyze the following %s code for %s:\n\n", req.Language, req.AnalysisType))
	prompt.WriteString("```" + req.Language + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	prompt.WriteString("Provide detailed analysis including issues, suggestions, and metrics.")
	
	return prompt.String()
}

// buildCodeTranslationPrompt builds a prompt for code translation
func (g *GeminiProvider) buildCodeTranslationPrompt(req *CodeTranslateRequest) string {
	var prompt strings.Builder
	
	prompt.WriteString(fmt.Sprintf("Translate the following %s code to %s:\n\n", req.FromLanguage, req.ToLanguage))
	prompt.WriteString("```" + req.FromLanguage + "\n")
	prompt.WriteString(req.Code)
	prompt.WriteString("\n```\n\n")
	prompt.WriteString("Preserve functionality and follow best practices for the target language.")
	
	return prompt.String()
}

// parseCodeResponse parses a code generation response
func (g *GeminiProvider) parseCodeResponse(content string) (code, explanation string) {
	// Simple parsing - look for code blocks
	lines := strings.Split(content, "\n")
	var codeLines []string
	var explanationLines []string
	inCodeBlock := false
	
	for _, line := range lines {
		if strings.HasPrefix(line, "```") {
			inCodeBlock = !inCodeBlock
			continue
		}
		
		if inCodeBlock {
			codeLines = append(codeLines, line)
		} else {
			explanationLines = append(explanationLines, line)
		}
	}
	
	code = strings.Join(codeLines, "\n")
	explanation = strings.Join(explanationLines, "\n")
	
	return strings.TrimSpace(code), strings.TrimSpace(explanation)
}

// parseAnalysisResponse parses a code analysis response
func (g *GeminiProvider) parseAnalysisResponse(content string) ([]*CodeIssue, []*CodeSuggestion, *CodeMetrics) {
	// Simplified parsing - in a real implementation, this would be more sophisticated
	issues := []*CodeIssue{}
	suggestions := []*CodeSuggestion{}
	metrics := &CodeMetrics{
		Maintainability: 0.8,
		Readability:     0.7,
		TestCoverage:    0.0,
	}
	
	return issues, suggestions, metrics
}

// calculateCost calculates the cost based on token usage
func (g *GeminiProvider) calculateCost(tokens int) float64 {
	// Gemini pricing (example rates)
	costPerToken := 0.00001 // $0.00001 per token
	return float64(tokens) * costPerToken
}

// updateUsage updates the usage statistics
func (g *GeminiProvider) updateUsage(usage *Usage) {
	g.usage.PromptTokens += usage.PromptTokens
	g.usage.CompletionTokens += usage.CompletionTokens
	g.usage.TotalTokens += usage.TotalTokens
	g.usage.Cost += usage.Cost
}

// getFinishReason extracts the finish reason from the response
func getFinishReason(resp *genai.GenerateContentResponse) string {
	if len(resp.Candidates) > 0 && resp.Candidates[0].FinishReason != nil {
		return resp.Candidates[0].FinishReason.String()
	}
	return "unknown"
}
