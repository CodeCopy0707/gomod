package planning

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"
)

// Manager handles task planning and memory management
type Manager struct {
	ai       *ai.Manager
	database database.Database
	cache    cache.Cache
	logger   logger.Logger
	
	// Planning components
	planner      *TaskPlanner
	tracker      *ProgressTracker
	memory       *MemoryEngine
	goalDetector *GoalDetector
	
	// Active plans and tasks
	activePlans map[string]*Plan
	activeTasks map[string]*Task
	mutex       sync.RWMutex
	
	// Configuration
	config *Config
}

// Config holds planning configuration
type Config struct {
	MaxPlanDepth        int
	MaxTasksPerPlan     int
	MemoryRetentionDays int
	AutoPlanningEnabled bool
	GoalDetectionEnabled bool
	ProgressTrackingEnabled bool
}

// Plan represents a high-level plan
type Plan struct {
	ID          string                 `json:"id"`
	Title       string                 `json:"title"`
	Description string                 `json:"description"`
	Goal        *Goal                  `json:"goal"`
	Tasks       []*Task                `json:"tasks"`
	Status      PlanStatus             `json:"status"`
	Priority    Priority               `json:"priority"`
	CreatedAt   time.Time              `json:"created_at"`
	UpdatedAt   time.Time              `json:"updated_at"`
	CompletedAt *time.Time             `json:"completed_at,omitempty"`
	Metadata    map[string]interface{} `json:"metadata"`
	Progress    *Progress              `json:"progress"`
}

// Task represents a specific task
type Task struct {
	ID           string                 `json:"id"`
	PlanID       string                 `json:"plan_id"`
	Title        string                 `json:"title"`
	Description  string                 `json:"description"`
	Type         TaskType               `json:"type"`
	Status       TaskStatus             `json:"status"`
	Priority     Priority               `json:"priority"`
	Dependencies []string               `json:"dependencies"`
	Subtasks     []*Task                `json:"subtasks"`
	EstimatedTime time.Duration         `json:"estimated_time"`
	ActualTime   time.Duration          `json:"actual_time"`
	CreatedAt    time.Time              `json:"created_at"`
	UpdatedAt    time.Time              `json:"updated_at"`
	StartedAt    *time.Time             `json:"started_at,omitempty"`
	CompletedAt  *time.Time             `json:"completed_at,omitempty"`
	Metadata     map[string]interface{} `json:"metadata"`
	Progress     *Progress              `json:"progress"`
}

// Goal represents a user goal
type Goal struct {
	ID          string                 `json:"id"`
	Description string                 `json:"description"`
	Type        GoalType               `json:"type"`
	Context     map[string]interface{} `json:"context"`
	Confidence  float64                `json:"confidence"`
	DetectedAt  time.Time              `json:"detected_at"`
	Achieved    bool                   `json:"achieved"`
	AchievedAt  *time.Time             `json:"achieved_at,omitempty"`
}

// Progress represents progress information
type Progress struct {
	Percentage    float64   `json:"percentage"`
	CompletedTasks int      `json:"completed_tasks"`
	TotalTasks    int       `json:"total_tasks"`
	EstimatedTime time.Duration `json:"estimated_time"`
	ElapsedTime   time.Duration `json:"elapsed_time"`
	UpdatedAt     time.Time `json:"updated_at"`
}

// Memory represents stored memory
type Memory struct {
	ID        string                 `json:"id"`
	Type      MemoryType             `json:"type"`
	Content   interface{}            `json:"content"`
	Context   map[string]interface{} `json:"context"`
	Importance float64               `json:"importance"`
	CreatedAt time.Time              `json:"created_at"`
	AccessedAt time.Time             `json:"accessed_at"`
	AccessCount int                  `json:"access_count"`
	Tags      []string               `json:"tags"`
	Metadata  map[string]interface{} `json:"metadata"`
}

// Enums
type PlanStatus string
const (
	PlanStatusDraft      PlanStatus = "draft"
	PlanStatusActive     PlanStatus = "active"
	PlanStatusPaused     PlanStatus = "paused"
	PlanStatusCompleted  PlanStatus = "completed"
	PlanStatusCancelled  PlanStatus = "cancelled"
)

type TaskStatus string
const (
	TaskStatusPending    TaskStatus = "pending"
	TaskStatusInProgress TaskStatus = "in_progress"
	TaskStatusCompleted  TaskStatus = "completed"
	TaskStatusBlocked    TaskStatus = "blocked"
	TaskStatusCancelled  TaskStatus = "cancelled"
)

type TaskType string
const (
	TaskTypeCodeGeneration TaskType = "code_generation"
	TaskTypeDebugging      TaskType = "debugging"
	TaskTypeRefactoring    TaskType = "refactoring"
	TaskTypeTesting        TaskType = "testing"
	TaskTypeDocumentation  TaskType = "documentation"
	TaskTypeResearch       TaskType = "research"
	TaskTypeReview         TaskType = "review"
)

type Priority string
const (
	PriorityLow    Priority = "low"
	PriorityMedium Priority = "medium"
	PriorityHigh   Priority = "high"
	PriorityCritical Priority = "critical"
)

type GoalType string
const (
	GoalTypeProject     GoalType = "project"
	GoalTypeFeature     GoalType = "feature"
	GoalTypeBugFix      GoalType = "bug_fix"
	GoalTypeLearning    GoalType = "learning"
	GoalTypeOptimization GoalType = "optimization"
)

type MemoryType string
const (
	MemoryTypeConversation MemoryType = "conversation"
	MemoryTypeCode         MemoryType = "code"
	MemoryTypeDecision     MemoryType = "decision"
	MemoryTypePattern      MemoryType = "pattern"
	MemoryTypeKnowledge    MemoryType = "knowledge"
)

// NewManager creates a new planning manager
func NewManager(ai *ai.Manager, database database.Database, cache cache.Cache, logger logger.Logger) (*Manager, error) {
	config := &Config{
		MaxPlanDepth:            5,
		MaxTasksPerPlan:         50,
		MemoryRetentionDays:     90,
		AutoPlanningEnabled:     true,
		GoalDetectionEnabled:    true,
		ProgressTrackingEnabled: true,
	}

	manager := &Manager{
		ai:          ai,
		database:    database,
		cache:       cache,
		logger:      logger,
		config:      config,
		activePlans: make(map[string]*Plan),
		activeTasks: make(map[string]*Task),
		planner:     NewTaskPlanner(ai, logger),
		tracker:     NewProgressTracker(logger),
		memory:      NewMemoryEngine(database, cache, logger),
		goalDetector: NewGoalDetector(ai, logger),
	}

	// Start background processes
	go manager.startBackgroundProcesses()

	logger.Info("Planning manager initialized")
	return manager, nil
}

// CreatePlan creates a new plan from a user request
func (m *Manager) CreatePlan(ctx context.Context, request string, context map[string]interface{}) (*Plan, error) {
	m.logger.Info("Creating plan", "request", request)

	// Detect goal from request
	goal, err := m.goalDetector.DetectGoal(ctx, request, context)
	if err != nil {
		m.logger.Warn("Failed to detect goal", "error", err)
		goal = &Goal{
			ID:          generateID(),
			Description: request,
			Type:        GoalTypeProject,
			Context:     context,
			Confidence:  0.5,
			DetectedAt:  time.Now(),
		}
	}

	// Generate plan using AI
	plan, err := m.planner.GeneratePlan(ctx, goal, context)
	if err != nil {
		return nil, fmt.Errorf("failed to generate plan: %w", err)
	}

	// Store plan
	m.mutex.Lock()
	m.activePlans[plan.ID] = plan
	m.mutex.Unlock()

	// Store in database
	if err := m.storePlan(plan); err != nil {
		m.logger.Warn("Failed to store plan in database", "error", err)
	}

	// Store in memory
	m.memory.Store(&Memory{
		ID:        generateID(),
		Type:      MemoryTypeDecision,
		Content:   plan,
		Context:   context,
		Importance: 0.8,
		CreatedAt: time.Now(),
		AccessedAt: time.Now(),
		Tags:      []string{"plan", "creation"},
	})

	m.logger.Info("Plan created", "plan_id", plan.ID, "tasks", len(plan.Tasks))
	return plan, nil
}

// UpdateTaskStatus updates the status of a task
func (m *Manager) UpdateTaskStatus(taskID string, status TaskStatus) error {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	task, exists := m.activeTasks[taskID]
	if !exists {
		return fmt.Errorf("task not found: %s", taskID)
	}

	oldStatus := task.Status
	task.Status = status
	task.UpdatedAt = time.Now()

	// Handle status transitions
	switch status {
	case TaskStatusInProgress:
		if task.StartedAt == nil {
			now := time.Now()
			task.StartedAt = &now
		}
	case TaskStatusCompleted:
		now := time.Now()
		task.CompletedAt = &now
		if task.StartedAt != nil {
			task.ActualTime = now.Sub(*task.StartedAt)
		}
	}

	// Update progress
	if plan, exists := m.activePlans[task.PlanID]; exists {
		m.tracker.UpdateProgress(plan)
	}

	m.logger.Info("Task status updated", 
		"task_id", taskID, 
		"old_status", oldStatus, 
		"new_status", status)

	return nil
}

// GetActivePlans returns all active plans
func (m *Manager) GetActivePlans() []*Plan {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	plans := make([]*Plan, 0, len(m.activePlans))
	for _, plan := range m.activePlans {
		plans = append(plans, plan)
	}

	return plans
}

// GetPlan returns a plan by ID
func (m *Manager) GetPlan(planID string) (*Plan, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	plan, exists := m.activePlans[planID]
	if !exists {
		return nil, fmt.Errorf("plan not found: %s", planID)
	}

	return plan, nil
}

// GetTask returns a task by ID
func (m *Manager) GetTask(taskID string) (*Task, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	task, exists := m.activeTasks[taskID]
	if !exists {
		return nil, fmt.Errorf("task not found: %s", taskID)
	}

	return task, nil
}

// GetNextTask returns the next task to work on
func (m *Manager) GetNextTask(context map[string]interface{}) (*Task, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	var nextTask *Task
	var highestPriority Priority = PriorityLow

	for _, task := range m.activeTasks {
		if task.Status == TaskStatusPending {
			// Check dependencies
			if m.areDependenciesMet(task) {
				if nextTask == nil || m.comparePriority(task.Priority, highestPriority) > 0 {
					nextTask = task
					highestPriority = task.Priority
				}
			}
		}
	}

	if nextTask == nil {
		return nil, fmt.Errorf("no available tasks")
	}

	return nextTask, nil
}

// Helper methods

func (m *Manager) storePlan(plan *Plan) error {
	data, err := json.Marshal(plan)
	if err != nil {
		return err
	}

	query := "INSERT INTO plans (id, data, created_at) VALUES (?, ?, ?)"
	return m.database.Exec(query, plan.ID, data, plan.CreatedAt)
}

func (m *Manager) areDependenciesMet(task *Task) bool {
	for _, depID := range task.Dependencies {
		if depTask, exists := m.activeTasks[depID]; exists {
			if depTask.Status != TaskStatusCompleted {
				return false
			}
		}
	}
	return true
}

func (m *Manager) comparePriority(p1, p2 Priority) int {
	priorities := map[Priority]int{
		PriorityLow:      1,
		PriorityMedium:   2,
		PriorityHigh:     3,
		PriorityCritical: 4,
	}

	return priorities[p1] - priorities[p2]
}

func (m *Manager) startBackgroundProcesses() {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		m.cleanupCompletedPlans()
		m.updateProgress()
		m.cleanupOldMemories()
	}
}

func (m *Manager) cleanupCompletedPlans() {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	for id, plan := range m.activePlans {
		if plan.Status == PlanStatusCompleted && 
		   plan.CompletedAt != nil && 
		   time.Since(*plan.CompletedAt) > 24*time.Hour {
			delete(m.activePlans, id)
		}
	}
}

func (m *Manager) updateProgress() {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	for _, plan := range m.activePlans {
		m.tracker.UpdateProgress(plan)
	}
}

func (m *Manager) cleanupOldMemories() {
	cutoff := time.Now().AddDate(0, 0, -m.config.MemoryRetentionDays)
	m.memory.Cleanup(cutoff)
}

func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}
