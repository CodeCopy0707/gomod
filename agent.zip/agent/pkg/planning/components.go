package planning

import (
	"context"
	"fmt"
	"strings"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"
)

// TaskPlanner generates plans and tasks
type TaskPlanner struct {
	ai     *ai.Manager
	logger logger.Logger
}

// ProgressTracker tracks progress of plans and tasks
type ProgressTracker struct {
	logger logger.Logger
}

// MemoryEngine handles memory storage and retrieval
type MemoryEngine struct {
	database database.Database
	cache    cache.Cache
	logger   logger.Logger
	memories map[string]*Memory
}

// GoalDetector detects goals from user input
type GoalDetector struct {
	ai     *ai.Manager
	logger logger.Logger
}

// NewTaskPlanner creates a new task planner
func NewTaskPlanner(ai *ai.Manager, logger logger.Logger) *TaskPlanner {
	return &TaskPlanner{
		ai:     ai,
		logger: logger,
	}
}

// GeneratePlan generates a plan from a goal
func (tp *TaskPlanner) GeneratePlan(ctx context.Context, goal *Goal, context map[string]interface{}) (*Plan, error) {
	tp.logger.Info("Generating plan for goal", "goal", goal.Description)

	// Create AI prompt for plan generation
	prompt := tp.buildPlanPrompt(goal, context)

	// Generate plan using AI
	response, err := tp.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: []*ai.Message{
			{Role: "user", Content: prompt},
		},
		Temperature: 0.7,
		MaxTokens:   2000,
	})

	if err != nil {
		return nil, fmt.Errorf("failed to generate plan: %w", err)
	}

	// Parse the AI response into a plan
	plan, err := tp.parsePlanResponse(response, goal)
	if err != nil {
		return nil, fmt.Errorf("failed to parse plan response: %w", err)
	}

	return plan, nil
}

// buildPlanPrompt builds the prompt for plan generation
func (tp *TaskPlanner) buildPlanPrompt(goal *Goal, context map[string]interface{}) string {
	prompt := fmt.Sprintf(`Create a detailed plan to achieve the following goal:

Goal: %s
Type: %s
Context: %v

Please provide:
1. A clear plan title
2. A detailed description
3. A list of specific tasks (5-10 tasks)
4. For each task:
   - Clear title and description
   - Task type (code_generation, debugging, refactoring, testing, documentation, research, review)
   - Priority (low, medium, high, critical)
   - Estimated time in minutes
   - Dependencies (if any)

Format your response as a structured plan with clear sections.`, 
		goal.Description, goal.Type, context)

	return prompt
}

// parsePlanResponse parses the AI response into a Plan struct
func (tp *TaskPlanner) parsePlanResponse(response string, goal *Goal) (*Plan, error) {
	// This is a simplified parser - in practice, you'd want more robust parsing
	lines := strings.Split(response, "\n")
	
	plan := &Plan{
		ID:          generateID(),
		Goal:        goal,
		Status:      PlanStatusDraft,
		Priority:    PriorityMedium,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
		Metadata:    make(map[string]interface{}),
		Tasks:       make([]*Task, 0),
	}

	// Extract title and description
	for i, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "Title:") || strings.HasPrefix(line, "Plan:") {
			plan.Title = strings.TrimSpace(strings.TrimPrefix(line, "Title:"))
			plan.Title = strings.TrimSpace(strings.TrimPrefix(plan.Title, "Plan:"))
		} else if strings.HasPrefix(line, "Description:") {
			// Collect description lines
			desc := strings.TrimSpace(strings.TrimPrefix(line, "Description:"))
			for j := i + 1; j < len(lines) && !strings.Contains(lines[j], "Task"); j++ {
				if strings.TrimSpace(lines[j]) != "" {
					desc += " " + strings.TrimSpace(lines[j])
				}
			}
			plan.Description = desc
		}
	}

	// Set defaults if not found
	if plan.Title == "" {
		plan.Title = fmt.Sprintf("Plan for: %s", goal.Description)
	}
	if plan.Description == "" {
		plan.Description = fmt.Sprintf("Automatically generated plan to achieve: %s", goal.Description)
	}

	// Extract tasks (simplified)
	taskCount := 0
	for _, line := range lines {
		if strings.Contains(line, "Task") || strings.Contains(line, "task") {
			taskCount++
			task := &Task{
				ID:            generateID(),
				PlanID:        plan.ID,
				Title:         fmt.Sprintf("Task %d", taskCount),
				Description:   strings.TrimSpace(line),
				Type:          tp.inferTaskType(line),
				Status:        TaskStatusPending,
				Priority:      PriorityMedium,
				Dependencies:  []string{},
				EstimatedTime: 30 * time.Minute, // Default estimate
				CreatedAt:     time.Now(),
				UpdatedAt:     time.Now(),
				Metadata:      make(map[string]interface{}),
			}
			plan.Tasks = append(plan.Tasks, task)
		}
	}

	// Ensure we have at least one task
	if len(plan.Tasks) == 0 {
		defaultTask := &Task{
			ID:            generateID(),
			PlanID:        plan.ID,
			Title:         "Complete Goal",
			Description:   goal.Description,
			Type:          TaskTypeCodeGeneration,
			Status:        TaskStatusPending,
			Priority:      PriorityHigh,
			Dependencies:  []string{},
			EstimatedTime: 60 * time.Minute,
			CreatedAt:     time.Now(),
			UpdatedAt:     time.Now(),
			Metadata:      make(map[string]interface{}),
		}
		plan.Tasks = append(plan.Tasks, defaultTask)
	}

	return plan, nil
}

// inferTaskType infers task type from description
func (tp *TaskPlanner) inferTaskType(description string) TaskType {
	desc := strings.ToLower(description)
	
	if strings.Contains(desc, "test") || strings.Contains(desc, "unit") {
		return TaskTypeTesting
	} else if strings.Contains(desc, "debug") || strings.Contains(desc, "fix") || strings.Contains(desc, "bug") {
		return TaskTypeDebugging
	} else if strings.Contains(desc, "refactor") || strings.Contains(desc, "optimize") {
		return TaskTypeRefactoring
	} else if strings.Contains(desc, "document") || strings.Contains(desc, "readme") {
		return TaskTypeDocumentation
	} else if strings.Contains(desc, "research") || strings.Contains(desc, "investigate") {
		return TaskTypeResearch
	} else if strings.Contains(desc, "review") || strings.Contains(desc, "check") {
		return TaskTypeReview
	}
	
	return TaskTypeCodeGeneration
}

// NewProgressTracker creates a new progress tracker
func NewProgressTracker(logger logger.Logger) *ProgressTracker {
	return &ProgressTracker{
		logger: logger,
	}
}

// UpdateProgress updates the progress of a plan
func (pt *ProgressTracker) UpdateProgress(plan *Plan) {
	if plan == nil || len(plan.Tasks) == 0 {
		return
	}

	completedTasks := 0
	totalEstimatedTime := time.Duration(0)
	totalElapsedTime := time.Duration(0)

	for _, task := range plan.Tasks {
		if task.Status == TaskStatusCompleted {
			completedTasks++
		}
		totalEstimatedTime += task.EstimatedTime
		totalElapsedTime += task.ActualTime
	}

	percentage := float64(completedTasks) / float64(len(plan.Tasks)) * 100

	plan.Progress = &Progress{
		Percentage:     percentage,
		CompletedTasks: completedTasks,
		TotalTasks:     len(plan.Tasks),
		EstimatedTime:  totalEstimatedTime,
		ElapsedTime:    totalElapsedTime,
		UpdatedAt:      time.Now(),
	}

	// Update plan status based on progress
	if percentage == 100 {
		plan.Status = PlanStatusCompleted
		if plan.CompletedAt == nil {
			now := time.Now()
			plan.CompletedAt = &now
		}
	} else if percentage > 0 {
		plan.Status = PlanStatusActive
	}

	pt.logger.Debug("Progress updated", 
		"plan_id", plan.ID, 
		"percentage", percentage, 
		"completed", completedTasks, 
		"total", len(plan.Tasks))
}

// NewMemoryEngine creates a new memory engine
func NewMemoryEngine(database database.Database, cache cache.Cache, logger logger.Logger) *MemoryEngine {
	return &MemoryEngine{
		database: database,
		cache:    cache,
		logger:   logger,
		memories: make(map[string]*Memory),
	}
}

// Store stores a memory
func (me *MemoryEngine) Store(memory *Memory) error {
	me.memories[memory.ID] = memory
	
	// Store in cache for quick access
	cacheKey := fmt.Sprintf("memory:%s", memory.ID)
	if data, err := json.Marshal(memory); err == nil {
		me.cache.Set(cacheKey, data, 24*time.Hour)
	}

	me.logger.Debug("Memory stored", "id", memory.ID, "type", memory.Type)
	return nil
}

// Retrieve retrieves memories by type and context
func (me *MemoryEngine) Retrieve(memoryType MemoryType, context map[string]interface{}) ([]*Memory, error) {
	var results []*Memory

	for _, memory := range me.memories {
		if memory.Type == memoryType {
			// Simple context matching
			if me.matchesContext(memory.Context, context) {
				memory.AccessCount++
				memory.AccessedAt = time.Now()
				results = append(results, memory)
			}
		}
	}

	return results, nil
}

// matchesContext checks if memory context matches query context
func (me *MemoryEngine) matchesContext(memoryContext, queryContext map[string]interface{}) bool {
	if len(queryContext) == 0 {
		return true
	}

	matches := 0
	for key, value := range queryContext {
		if memValue, exists := memoryContext[key]; exists && memValue == value {
			matches++
		}
	}

	// Return true if at least 50% of query context matches
	return float64(matches)/float64(len(queryContext)) >= 0.5
}

// Cleanup removes old memories
func (me *MemoryEngine) Cleanup(cutoff time.Time) {
	for id, memory := range me.memories {
		if memory.CreatedAt.Before(cutoff) && memory.Importance < 0.7 {
			delete(me.memories, id)
			me.logger.Debug("Memory cleaned up", "id", id)
		}
	}
}

// NewGoalDetector creates a new goal detector
func NewGoalDetector(ai *ai.Manager, logger logger.Logger) *GoalDetector {
	return &GoalDetector{
		ai:     ai,
		logger: logger,
	}
}

// DetectGoal detects a goal from user input
func (gd *GoalDetector) DetectGoal(ctx context.Context, input string, context map[string]interface{}) (*Goal, error) {
	gd.logger.Debug("Detecting goal from input", "input", input)

	prompt := fmt.Sprintf(`Analyze the following user request and extract the goal:

Request: "%s"
Context: %v

Determine:
1. The main goal/objective
2. Goal type (project, feature, bug_fix, learning, optimization)
3. Confidence level (0-1)

Provide a clear, actionable goal description.`, input, context)

	response, err := gd.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: []*ai.Message{
			{Role: "user", Content: prompt},
		},
		Temperature: 0.3,
		MaxTokens:   500,
	})

	if err != nil {
		return nil, fmt.Errorf("failed to detect goal: %w", err)
	}

	// Parse response into goal
	goal := &Goal{
		ID:          generateID(),
		Description: gd.extractGoalDescription(response, input),
		Type:        gd.extractGoalType(response),
		Context:     context,
		Confidence:  gd.extractConfidence(response),
		DetectedAt:  time.Now(),
		Achieved:    false,
	}

	return goal, nil
}

// extractGoalDescription extracts goal description from AI response
func (gd *GoalDetector) extractGoalDescription(response, fallback string) string {
	lines := strings.Split(response, "\n")
	for _, line := range lines {
		if strings.Contains(strings.ToLower(line), "goal") && len(line) > 10 {
			return strings.TrimSpace(line)
		}
	}
	return fallback
}

// extractGoalType extracts goal type from AI response
func (gd *GoalDetector) extractGoalType(response string) GoalType {
	response = strings.ToLower(response)
	
	if strings.Contains(response, "project") {
		return GoalTypeProject
	} else if strings.Contains(response, "feature") {
		return GoalTypeFeature
	} else if strings.Contains(response, "bug") || strings.Contains(response, "fix") {
		return GoalTypeBugFix
	} else if strings.Contains(response, "learn") || strings.Contains(response, "understand") {
		return GoalTypeLearning
	} else if strings.Contains(response, "optimize") || strings.Contains(response, "improve") {
		return GoalTypeOptimization
	}
	
	return GoalTypeProject
}

// extractConfidence extracts confidence from AI response
func (gd *GoalDetector) extractConfidence(response string) float64 {
	// Simple confidence extraction - in practice, this would be more sophisticated
	if strings.Contains(strings.ToLower(response), "high confidence") {
		return 0.9
	} else if strings.Contains(strings.ToLower(response), "medium confidence") {
		return 0.7
	} else if strings.Contains(strings.ToLower(response), "low confidence") {
		return 0.5
	}
	
	return 0.6 // Default confidence
}
