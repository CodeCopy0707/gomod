package web

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/cache"
)

// RetrievalManager handles web information retrieval
type RetrievalManager struct {
	logger     logger.Logger
	cache      cache.Cache
	httpClient *http.Client
	config     *Config
	scrapers   map[string]Scraper
	mutex      sync.RWMutex
}

// Config holds web retrieval configuration
type Config struct {
	SearchAPIKey    string
	SearchEngineID  string
	UserAgent       string
	Timeout         time.Duration
	MaxResults      int
	CacheTTL        time.Duration
	RateLimitDelay  time.Duration
	AllowedDomains  []string
	BlockedDomains  []string
}

// SearchResult represents a web search result
type SearchResult struct {
	Title       string                 `json:"title"`
	URL         string                 `json:"url"`
	Snippet     string                 `json:"snippet"`
	Content     string                 `json:"content"`
	Domain      string                 `json:"domain"`
	Language    string                 `json:"language"`
	Relevance   float64                `json:"relevance"`
	Timestamp   time.Time              `json:"timestamp"`
	Metadata    map[string]interface{} `json:"metadata"`
	CodeBlocks  []*CodeBlock           `json:"code_blocks"`
}

// CodeBlock represents extracted code
type CodeBlock struct {
	Language string `json:"language"`
	Code     string `json:"code"`
	Context  string `json:"context"`
	LineNum  int    `json:"line_num"`
}

// DocumentationResult represents documentation lookup result
type DocumentationResult struct {
	Library     string                 `json:"library"`
	Version     string                 `json:"version"`
	Function    string                 `json:"function"`
	Description string                 `json:"description"`
	Parameters  []*Parameter           `json:"parameters"`
	Returns     string                 `json:"returns"`
	Examples    []*Example             `json:"examples"`
	URL         string                 `json:"url"`
	Metadata    map[string]interface{} `json:"metadata"`
}

// Parameter represents a function parameter
type Parameter struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Description string `json:"description"`
	Required    bool   `json:"required"`
	Default     string `json:"default"`
}

// Example represents a code example
type Example struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	Code        string `json:"code"`
	Output      string `json:"output"`
}

// Scraper interface for different website scrapers
type Scraper interface {
	CanScrape(url string) bool
	Scrape(ctx context.Context, url string) (*SearchResult, error)
	GetName() string
}

// RAGDocument represents a document for RAG
type RAGDocument struct {
	ID          string                 `json:"id"`
	Content     string                 `json:"content"`
	Title       string                 `json:"title"`
	URL         string                 `json:"url"`
	Chunks      []*DocumentChunk       `json:"chunks"`
	Embeddings  []float64              `json:"embeddings"`
	Metadata    map[string]interface{} `json:"metadata"`
	IndexedAt   time.Time              `json:"indexed_at"`
}

// DocumentChunk represents a chunk of a document
type DocumentChunk struct {
	ID         string    `json:"id"`
	Content    string    `json:"content"`
	StartPos   int       `json:"start_pos"`
	EndPos     int       `json:"end_pos"`
	Embeddings []float64 `json:"embeddings"`
}

// NewRetrievalManager creates a new web retrieval manager
func NewRetrievalManager(logger logger.Logger, cache cache.Cache, config *Config) *RetrievalManager {
	if config == nil {
		config = &Config{
			UserAgent:      "AI-Coding-Agent/1.0",
			Timeout:        30 * time.Second,
			MaxResults:     10,
			CacheTTL:       1 * time.Hour,
			RateLimitDelay: 1 * time.Second,
			AllowedDomains: []string{
				"stackoverflow.com",
				"github.com",
				"docs.python.org",
				"golang.org",
				"developer.mozilla.org",
				"reactjs.org",
				"nodejs.org",
			},
		}
	}

	manager := &RetrievalManager{
		logger: logger,
		cache:  cache,
		config: config,
		httpClient: &http.Client{
			Timeout: config.Timeout,
		},
		scrapers: make(map[string]Scraper),
	}

	// Register scrapers
	manager.registerScrapers()

	return manager
}

// registerScrapers registers website-specific scrapers
func (r *RetrievalManager) registerScrapers() {
	scrapers := []Scraper{
		NewStackOverflowScraper(r.logger),
		NewGitHubScraper(r.logger),
		NewDocumentationScraper(r.logger),
		NewGenericScraper(r.logger),
	}

	for _, scraper := range scrapers {
		r.scrapers[scraper.GetName()] = scraper
	}
}

// SearchWeb performs web search for coding-related queries
func (r *RetrievalManager) SearchWeb(ctx context.Context, query string, language string) ([]*SearchResult, error) {
	r.logger.Info("Performing web search", "query", query, "language", language)

	// Check cache first
	cacheKey := fmt.Sprintf("search:%s:%s", query, language)
	if cached, err := r.cache.Get(cacheKey); err == nil {
		var results []*SearchResult
		if err := json.Unmarshal(cached.([]byte), &results); err == nil {
			r.logger.Debug("Returning cached search results", "count", len(results))
			return results, nil
		}
	}

	// Enhance query for coding context
	enhancedQuery := r.enhanceQuery(query, language)

	// Perform search
	results, err := r.performSearch(ctx, enhancedQuery)
	if err != nil {
		return nil, fmt.Errorf("search failed: %w", err)
	}

	// Filter and rank results
	filteredResults := r.filterResults(results, query, language)
	rankedResults := r.rankResults(filteredResults, query, language)

	// Extract code blocks from results
	for _, result := range rankedResults {
		result.CodeBlocks = r.extractCodeBlocks(result.Content)
	}

	// Cache results
	if data, err := json.Marshal(rankedResults); err == nil {
		r.cache.Set(cacheKey, data, r.config.CacheTTL)
	}

	r.logger.Info("Web search completed", "query", query, "results", len(rankedResults))
	return rankedResults, nil
}

// LookupDocumentation looks up documentation for a specific function or library
func (r *RetrievalManager) LookupDocumentation(ctx context.Context, library, function, language string) (*DocumentationResult, error) {
	r.logger.Info("Looking up documentation", "library", library, "function", function, "language", language)

	// Check cache first
	cacheKey := fmt.Sprintf("docs:%s:%s:%s", library, function, language)
	if cached, err := r.cache.Get(cacheKey); err == nil {
		var result DocumentationResult
		if err := json.Unmarshal(cached.([]byte), &result); err == nil {
			return &result, nil
		}
	}

	// Build documentation query
	query := r.buildDocumentationQuery(library, function, language)

	// Search for documentation
	searchResults, err := r.SearchWeb(ctx, query, language)
	if err != nil {
		return nil, fmt.Errorf("documentation search failed: %w", err)
	}

	// Extract documentation from results
	docResult := r.extractDocumentation(searchResults, library, function)

	// Cache result
	if data, err := json.Marshal(docResult); err == nil {
		r.cache.Set(cacheKey, data, r.config.CacheTTL)
	}

	return docResult, nil
}

// ExtractCodeSnippets extracts code snippets from web content
func (r *RetrievalManager) ExtractCodeSnippets(ctx context.Context, url string) ([]*CodeBlock, error) {
	r.logger.Debug("Extracting code snippets", "url", url)

	// Get appropriate scraper
	scraper := r.getScraper(url)
	if scraper == nil {
		return nil, fmt.Errorf("no suitable scraper for URL: %s", url)
	}

	// Scrape content
	result, err := scraper.Scrape(ctx, url)
	if err != nil {
		return nil, fmt.Errorf("scraping failed: %w", err)
	}

	// Extract code blocks
	codeBlocks := r.extractCodeBlocks(result.Content)

	return codeBlocks, nil
}

// performSearch performs the actual web search
func (r *RetrievalManager) performSearch(ctx context.Context, query string) ([]*SearchResult, error) {
	if r.config.SearchAPIKey == "" {
		return r.performFallbackSearch(ctx, query)
	}

	// Use Google Custom Search API
	searchURL := fmt.Sprintf("https://www.googleapis.com/customsearch/v1?key=%s&cx=%s&q=%s&num=%d",
		r.config.SearchAPIKey,
		r.config.SearchEngineID,
		url.QueryEscape(query),
		r.config.MaxResults)

	req, err := http.NewRequestWithContext(ctx, "GET", searchURL, nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", r.config.UserAgent)

	resp, err := r.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	// Parse Google Search API response
	var searchResponse struct {
		Items []struct {
			Title   string `json:"title"`
			Link    string `json:"link"`
			Snippet string `json:"snippet"`
		} `json:"items"`
	}

	if err := json.Unmarshal(body, &searchResponse); err != nil {
		return nil, err
	}

	// Convert to SearchResult format
	var results []*SearchResult
	for _, item := range searchResponse.Items {
		result := &SearchResult{
			Title:     item.Title,
			URL:       item.Link,
			Snippet:   item.Snippet,
			Domain:    r.extractDomain(item.Link),
			Timestamp: time.Now(),
			Metadata:  make(map[string]interface{}),
		}

		// Scrape full content
		if content, err := r.scrapeContent(ctx, item.Link); err == nil {
			result.Content = content
		}

		results = append(results, result)
	}

	return results, nil
}

// performFallbackSearch performs search without API key
func (r *RetrievalManager) performFallbackSearch(ctx context.Context, query string) ([]*SearchResult, error) {
	// Implement fallback search using direct scraping or other methods
	// This is a simplified implementation
	
	searchTerms := strings.Fields(query)
	var results []*SearchResult

	// Search specific documentation sites
	docSites := map[string]string{
		"python": "https://docs.python.org/3/search.html?q=%s",
		"go":     "https://pkg.go.dev/search?q=%s",
		"js":     "https://developer.mozilla.org/en-US/search?q=%s",
	}

	for lang, urlTemplate := range docSites {
		if strings.Contains(strings.ToLower(query), lang) {
			searchURL := fmt.Sprintf(urlTemplate, url.QueryEscape(query))
			if result, err := r.scrapeSearchResult(ctx, searchURL, query); err == nil {
				results = append(results, result)
			}
		}
	}

	return results, nil
}

// enhanceQuery enhances the search query for better coding results
func (r *RetrievalManager) enhanceQuery(query, language string) string {
	enhanced := query

	// Add language context
	if language != "" {
		enhanced = fmt.Sprintf("%s %s", enhanced, language)
	}

	// Add coding-specific terms
	codingTerms := []string{"programming", "code", "example", "tutorial"}
	for _, term := range codingTerms {
		if !strings.Contains(strings.ToLower(enhanced), term) {
			enhanced = fmt.Sprintf("%s %s", enhanced, term)
			break
		}
	}

	// Add site restrictions for better results
	enhanced = fmt.Sprintf("%s site:stackoverflow.com OR site:github.com OR site:docs.python.org", enhanced)

	return enhanced
}

// filterResults filters search results based on relevance and domain
func (r *RetrievalManager) filterResults(results []*SearchResult, query, language string) []*SearchResult {
	var filtered []*SearchResult

	for _, result := range results {
		// Check if domain is allowed
		if !r.isDomainAllowed(result.Domain) {
			continue
		}

		// Check if domain is blocked
		if r.isDomainBlocked(result.Domain) {
			continue
		}

		// Calculate relevance
		result.Relevance = r.calculateRelevance(result, query, language)

		// Filter by minimum relevance
		if result.Relevance > 0.3 {
			filtered = append(filtered, result)
		}
	}

	return filtered
}

// rankResults ranks search results by relevance
func (r *RetrievalManager) rankResults(results []*SearchResult, query, language string) []*SearchResult {
	// Sort by relevance score
	for i := 0; i < len(results)-1; i++ {
		for j := i + 1; j < len(results); j++ {
			if results[i].Relevance < results[j].Relevance {
				results[i], results[j] = results[j], results[i]
			}
		}
	}

	return results
}

// extractCodeBlocks extracts code blocks from content
func (r *RetrievalManager) extractCodeBlocks(content string) []*CodeBlock {
	var blocks []*CodeBlock

	// Regex patterns for different code block formats
	patterns := []*regexp.Regexp{
		regexp.MustCompile("```([a-zA-Z]*)\n(.*?)\n```"),           // Markdown code blocks
		regexp.MustCompile("<code[^>]*>(.*?)</code>"),              // HTML code tags
		regexp.MustCompile("<pre[^>]*><code[^>]*>(.*?)</code></pre>"), // HTML pre+code
	}

	for _, pattern := range patterns {
		matches := pattern.FindAllStringSubmatch(content, -1)
		for i, match := range matches {
			if len(match) >= 2 {
				language := ""
				code := match[1]
				
				if len(match) >= 3 {
					language = match[1]
					code = match[2]
				}

				block := &CodeBlock{
					Language: language,
					Code:     strings.TrimSpace(code),
					Context:  r.extractContext(content, match[0]),
					LineNum:  i + 1,
				}
				blocks = append(blocks, block)
			}
		}
	}

	return blocks
}

// Helper methods

func (r *RetrievalManager) getScraper(url string) Scraper {
	for _, scraper := range r.scrapers {
		if scraper.CanScrape(url) {
			return scraper
		}
	}
	return r.scrapers["generic"] // fallback to generic scraper
}

func (r *RetrievalManager) extractDomain(url string) string {
	if u, err := url.Parse(url); err == nil {
		return u.Host
	}
	return ""
}

func (r *RetrievalManager) isDomainAllowed(domain string) bool {
	if len(r.config.AllowedDomains) == 0 {
		return true
	}
	
	for _, allowed := range r.config.AllowedDomains {
		if strings.Contains(domain, allowed) {
			return true
		}
	}
	return false
}

func (r *RetrievalManager) isDomainBlocked(domain string) bool {
	for _, blocked := range r.config.BlockedDomains {
		if strings.Contains(domain, blocked) {
			return true
		}
	}
	return false
}

func (r *RetrievalManager) calculateRelevance(result *SearchResult, query, language string) float64 {
	relevance := 0.0
	
	queryTerms := strings.Fields(strings.ToLower(query))
	content := strings.ToLower(result.Title + " " + result.Snippet + " " + result.Content)
	
	// Term frequency
	for _, term := range queryTerms {
		count := strings.Count(content, term)
		relevance += float64(count) * 0.1
	}
	
	// Domain bonus
	domainBonus := map[string]float64{
		"stackoverflow.com": 0.3,
		"github.com":        0.2,
		"docs.python.org":   0.25,
		"golang.org":        0.25,
	}
	
	if bonus, exists := domainBonus[result.Domain]; exists {
		relevance += bonus
	}
	
	// Language match bonus
	if language != "" && strings.Contains(content, strings.ToLower(language)) {
		relevance += 0.2
	}
	
	// Code block bonus
	if len(result.CodeBlocks) > 0 {
		relevance += 0.15
	}
	
	return min(relevance, 1.0)
}

func (r *RetrievalManager) buildDocumentationQuery(library, function, language string) string {
	query := fmt.Sprintf("%s %s documentation", library, function)
	if language != "" {
		query = fmt.Sprintf("%s %s", query, language)
	}
	return query
}

func (r *RetrievalManager) extractDocumentation(results []*SearchResult, library, function string) *DocumentationResult {
	// Extract documentation from the best matching result
	if len(results) == 0 {
		return &DocumentationResult{
			Library:  library,
			Function: function,
		}
	}
	
	bestResult := results[0]
	
	return &DocumentationResult{
		Library:     library,
		Function:    function,
		Description: bestResult.Snippet,
		URL:         bestResult.URL,
		Examples:    r.convertCodeBlocksToExamples(bestResult.CodeBlocks),
		Metadata:    bestResult.Metadata,
	}
}

func (r *RetrievalManager) convertCodeBlocksToExamples(blocks []*CodeBlock) []*Example {
	var examples []*Example
	
	for i, block := range blocks {
		example := &Example{
			Title: fmt.Sprintf("Example %d", i+1),
			Code:  block.Code,
		}
		examples = append(examples, example)
	}
	
	return examples
}

func (r *RetrievalManager) extractContext(content, match string) string {
	index := strings.Index(content, match)
	if index == -1 {
		return ""
	}
	
	start := max(0, index-100)
	end := min(len(content), index+len(match)+100)
	
	return content[start:end]
}

func (r *RetrievalManager) scrapeContent(ctx context.Context, url string) (string, error) {
	scraper := r.getScraper(url)
	if scraper == nil {
		return "", fmt.Errorf("no scraper available")
	}
	
	result, err := scraper.Scrape(ctx, url)
	if err != nil {
		return "", err
	}
	
	return result.Content, nil
}

func (r *RetrievalManager) scrapeSearchResult(ctx context.Context, url, query string) (*SearchResult, error) {
	// Simplified implementation
	return &SearchResult{
		Title:     "Documentation Result",
		URL:       url,
		Snippet:   fmt.Sprintf("Documentation for: %s", query),
		Domain:    r.extractDomain(url),
		Timestamp: time.Now(),
		Relevance: 0.8,
	}, nil
}

// Helper functions
// StackOverflowScraper scrapes Stack Overflow content
type StackOverflowScraper struct {
	logger logger.Logger
}

func NewStackOverflowScraper(logger logger.Logger) *StackOverflowScraper {
	return &StackOverflowScraper{logger: logger}
}

func (s *StackOverflowScraper) GetName() string {
	return "stackoverflow"
}

func (s *StackOverflowScraper) CanScrape(url string) bool {
	return strings.Contains(url, "stackoverflow.com")
}

func (s *StackOverflowScraper) Scrape(ctx context.Context, url string) (*SearchResult, error) {
	// Simplified Stack Overflow scraping
	return &SearchResult{
		Title:   "Stack Overflow Answer",
		URL:     url,
		Content: "Stack Overflow content would be scraped here",
		Domain:  "stackoverflow.com",
	}, nil
}

// GitHubScraper scrapes GitHub content
type GitHubScraper struct {
	logger logger.Logger
}

func NewGitHubScraper(logger logger.Logger) *GitHubScraper {
	return &GitHubScraper{logger: logger}
}

func (g *GitHubScraper) GetName() string {
	return "github"
}

func (g *GitHubScraper) CanScrape(url string) bool {
	return strings.Contains(url, "github.com")
}

func (g *GitHubScraper) Scrape(ctx context.Context, url string) (*SearchResult, error) {
	// Simplified GitHub scraping
	return &SearchResult{
		Title:   "GitHub Repository",
		URL:     url,
		Content: "GitHub content would be scraped here",
		Domain:  "github.com",
	}, nil
}

// DocumentationScraper scrapes documentation sites
type DocumentationScraper struct {
	logger logger.Logger
}

func NewDocumentationScraper(logger logger.Logger) *DocumentationScraper {
	return &DocumentationScraper{logger: logger}
}

func (d *DocumentationScraper) GetName() string {
	return "documentation"
}

func (d *DocumentationScraper) CanScrape(url string) bool {
	docSites := []string{"docs.python.org", "golang.org", "developer.mozilla.org"}
	for _, site := range docSites {
		if strings.Contains(url, site) {
			return true
		}
	}
	return false
}

func (d *DocumentationScraper) Scrape(ctx context.Context, url string) (*SearchResult, error) {
	// Simplified documentation scraping
	return &SearchResult{
		Title:   "Documentation",
		URL:     url,
		Content: "Documentation content would be scraped here",
		Domain:  d.extractDomain(url),
	}, nil
}

func (d *DocumentationScraper) extractDomain(url string) string {
	if u, err := url.Parse(url); err == nil {
		return u.Host
	}
	return ""
}

// GenericScraper is a fallback scraper
type GenericScraper struct {
	logger logger.Logger
}

func NewGenericScraper(logger logger.Logger) *GenericScraper {
	return &GenericScraper{logger: logger}
}

func (g *GenericScraper) GetName() string {
	return "generic"
}

func (g *GenericScraper) CanScrape(url string) bool {
	return true // Can scrape any URL as fallback
}

func (g *GenericScraper) Scrape(ctx context.Context, url string) (*SearchResult, error) {
	// Simplified generic scraping
	return &SearchResult{
		Title:   "Web Content",
		URL:     url,
		Content: "Generic web content would be scraped here",
		Domain:  g.extractDomain(url),
	}, nil
}

func (g *GenericScraper) extractDomain(url string) string {
	if u, err := url.Parse(url); err == nil {
		return u.Host
	}
	return ""
}

func min(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
