package security

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"regexp"
	"strings"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
)

// Manager handles security and validation
type Manager struct {
	logger     logger.Logger
	validator  *Validator
	sanitizer  *Sanitizer
	scanner    *SecurityScanner
	monitor    *SecurityMonitor
	config     *Config
	
	// Rate limiting
	rateLimiter map[string]*RateLimit
	rateMutex   sync.RWMutex
	
	// Security events
	events     []*SecurityEvent
	eventMutex sync.RWMutex
}

// Config holds security configuration
type Config struct {
	MaxInputLength      int
	MaxOutputLength     int
	AllowedCommands     []string
	BlockedCommands     []string
	AllowedFileTypes    []string
	BlockedFileTypes    []string
	RateLimitRequests   int
	RateLimitWindow     time.Duration
	EnableSandboxing    bool
	EnableInputSanitization bool
	EnableOutputValidation  bool
	EnableSecurityScanning  bool
}

// Validator validates inputs and outputs
type Validator struct {
	logger logger.Logger
	config *Config
}

// Sanitizer sanitizes inputs
type Sanitizer struct {
	logger logger.Logger
	config *Config
}

// SecurityScanner scans for security issues
type SecurityScanner struct {
	logger logger.Logger
	config *Config
}

// SecurityMonitor monitors security events
type SecurityMonitor struct {
	logger logger.Logger
	events chan *SecurityEvent
}

// SecurityEvent represents a security event
type SecurityEvent struct {
	ID          string                 `json:"id"`
	Type        EventType              `json:"type"`
	Severity    Severity               `json:"severity"`
	Message     string                 `json:"message"`
	Source      string                 `json:"source"`
	UserID      string                 `json:"user_id"`
	SessionID   string                 `json:"session_id"`
	Timestamp   time.Time              `json:"timestamp"`
	Context     map[string]interface{} `json:"context"`
	Mitigated   bool                   `json:"mitigated"`
	MitigatedAt *time.Time             `json:"mitigated_at,omitempty"`
}

// RateLimit tracks rate limiting
type RateLimit struct {
	Requests  int
	Window    time.Time
	Blocked   bool
	BlockedAt time.Time
}

// ValidationResult represents validation result
type ValidationResult struct {
	Valid   bool     `json:"valid"`
	Errors  []string `json:"errors"`
	Warnings []string `json:"warnings"`
	Sanitized string `json:"sanitized,omitempty"`
}

// ScanResult represents security scan result
type ScanResult struct {
	Safe        bool               `json:"safe"`
	Issues      []*SecurityIssue   `json:"issues"`
	Risk        RiskLevel          `json:"risk"`
	Suggestions []string           `json:"suggestions"`
}

// SecurityIssue represents a security issue
type SecurityIssue struct {
	Type        IssueType `json:"type"`
	Severity    Severity  `json:"severity"`
	Message     string    `json:"message"`
	Line        int       `json:"line,omitempty"`
	Column      int       `json:"column,omitempty"`
	Suggestion  string    `json:"suggestion,omitempty"`
}

// Enums
type EventType string
const (
	EventTypeInputValidation    EventType = "input_validation"
	EventTypeOutputValidation   EventType = "output_validation"
	EventTypeCommandExecution   EventType = "command_execution"
	EventTypeFileAccess         EventType = "file_access"
	EventTypeRateLimit          EventType = "rate_limit"
	EventTypeSecurityScan       EventType = "security_scan"
	EventTypeAuthentication     EventType = "authentication"
	EventTypeAuthorization      EventType = "authorization"
)

type Severity string
const (
	SeverityLow      Severity = "low"
	SeverityMedium   Severity = "medium"
	SeverityHigh     Severity = "high"
	SeverityCritical Severity = "critical"
)

type RiskLevel string
const (
	RiskLevelLow      RiskLevel = "low"
	RiskLevelMedium   RiskLevel = "medium"
	RiskLevelHigh     RiskLevel = "high"
	RiskLevelCritical RiskLevel = "critical"
)

type IssueType string
const (
	IssueTypeInjection         IssueType = "injection"
	IssueTypeXSS               IssueType = "xss"
	IssueTypePathTraversal     IssueType = "path_traversal"
	IssueTypeCommandInjection  IssueType = "command_injection"
	IssueTypeCodeInjection     IssueType = "code_injection"
	IssueTypeMaliciousCode     IssueType = "malicious_code"
	IssueTypeDataExfiltration  IssueType = "data_exfiltration"
	IssueTypePrivilegeEscalation IssueType = "privilege_escalation"
)

// NewManager creates a new security manager
func NewManager(logger logger.Logger, config *Config) *Manager {
	if config == nil {
		config = &Config{
			MaxInputLength:         10000,
			MaxOutputLength:        50000,
			AllowedCommands:        []string{"ls", "cat", "grep", "find", "git"},
			BlockedCommands:        []string{"rm", "rmdir", "del", "format", "fdisk", "sudo", "su"},
			AllowedFileTypes:       []string{".go", ".py", ".js", ".ts", ".java", ".cpp", ".c", ".h", ".md", ".txt", ".json", ".yaml"},
			BlockedFileTypes:       []string{".exe", ".bat", ".sh", ".ps1", ".cmd"},
			RateLimitRequests:      100,
			RateLimitWindow:        time.Hour,
			EnableSandboxing:       true,
			EnableInputSanitization: true,
			EnableOutputValidation:  true,
			EnableSecurityScanning:  true,
		}
	}

	manager := &Manager{
		logger:      logger,
		config:      config,
		validator:   NewValidator(logger, config),
		sanitizer:   NewSanitizer(logger, config),
		scanner:     NewSecurityScanner(logger, config),
		monitor:     NewSecurityMonitor(logger),
		rateLimiter: make(map[string]*RateLimit),
		events:      make([]*SecurityEvent, 0),
	}

	// Start monitoring
	go manager.monitor.Start()

	logger.Info("Security manager initialized")
	return manager
}

// ValidateInput validates user input
func (m *Manager) ValidateInput(ctx context.Context, input string, userID, sessionID string) (*ValidationResult, error) {
	m.logger.Debug("Validating input", "user_id", userID, "length", len(input))

	// Check rate limiting
	if !m.checkRateLimit(userID) {
		m.logSecurityEvent(EventTypeRateLimit, SeverityMedium, "Rate limit exceeded", userID, sessionID, map[string]interface{}{
			"input_length": len(input),
		})
		return &ValidationResult{
			Valid:  false,
			Errors: []string{"Rate limit exceeded"},
		}, nil
	}

	// Validate input
	result := m.validator.ValidateInput(input)
	
	// Sanitize if needed
	if m.config.EnableInputSanitization {
		result.Sanitized = m.sanitizer.SanitizeInput(input)
	}

	// Log validation event
	if !result.Valid {
		m.logSecurityEvent(EventTypeInputValidation, SeverityMedium, "Input validation failed", userID, sessionID, map[string]interface{}{
			"errors": result.Errors,
			"input_length": len(input),
		})
	}

	return result, nil
}

// ValidateOutput validates AI output
func (m *Manager) ValidateOutput(ctx context.Context, output string, userID, sessionID string) (*ValidationResult, error) {
	m.logger.Debug("Validating output", "user_id", userID, "length", len(output))

	if !m.config.EnableOutputValidation {
		return &ValidationResult{Valid: true}, nil
	}

	result := m.validator.ValidateOutput(output)

	// Log validation event
	if !result.Valid {
		m.logSecurityEvent(EventTypeOutputValidation, SeverityHigh, "Output validation failed", userID, sessionID, map[string]interface{}{
			"errors": result.Errors,
			"output_length": len(output),
		})
	}

	return result, nil
}

// ValidateCommand validates command execution
func (m *Manager) ValidateCommand(ctx context.Context, command string, args []string, userID, sessionID string) (*ValidationResult, error) {
	m.logger.Debug("Validating command", "command", command, "user_id", userID)

	result := m.validator.ValidateCommand(command, args)

	// Log command execution event
	severity := SeverityLow
	if !result.Valid {
		severity = SeverityHigh
	}

	m.logSecurityEvent(EventTypeCommandExecution, severity, fmt.Sprintf("Command validation: %s", command), userID, sessionID, map[string]interface{}{
		"command": command,
		"args":    args,
		"valid":   result.Valid,
	})

	return result, nil
}

// ValidateFileAccess validates file access
func (m *Manager) ValidateFileAccess(ctx context.Context, path string, operation string, userID, sessionID string) (*ValidationResult, error) {
	m.logger.Debug("Validating file access", "path", path, "operation", operation, "user_id", userID)

	result := m.validator.ValidateFileAccess(path, operation)

	// Log file access event
	severity := SeverityLow
	if !result.Valid {
		severity = SeverityHigh
	}

	m.logSecurityEvent(EventTypeFileAccess, severity, fmt.Sprintf("File access: %s %s", operation, path), userID, sessionID, map[string]interface{}{
		"path":      path,
		"operation": operation,
		"valid":     result.Valid,
	})

	return result, nil
}

// ScanCode scans code for security issues
func (m *Manager) ScanCode(ctx context.Context, code string, language string, userID, sessionID string) (*ScanResult, error) {
	m.logger.Debug("Scanning code", "language", language, "user_id", userID)

	if !m.config.EnableSecurityScanning {
		return &ScanResult{Safe: true, Risk: RiskLevelLow}, nil
	}

	result := m.scanner.ScanCode(code, language)

	// Log security scan event
	severity := SeverityLow
	if result.Risk == RiskLevelHigh || result.Risk == RiskLevelCritical {
		severity = SeverityHigh
	}

	m.logSecurityEvent(EventTypeSecurityScan, severity, fmt.Sprintf("Code scan completed: %s", result.Risk), userID, sessionID, map[string]interface{}{
		"language":    language,
		"safe":        result.Safe,
		"risk":        result.Risk,
		"issues":      len(result.Issues),
	})

	return result, nil
}

// checkRateLimit checks if user is within rate limits
func (m *Manager) checkRateLimit(userID string) bool {
	m.rateMutex.Lock()
	defer m.rateMutex.Unlock()

	now := time.Now()
	limit, exists := m.rateLimiter[userID]

	if !exists {
		m.rateLimiter[userID] = &RateLimit{
			Requests: 1,
			Window:   now,
		}
		return true
	}

	// Reset window if expired
	if now.Sub(limit.Window) > m.config.RateLimitWindow {
		limit.Requests = 1
		limit.Window = now
		limit.Blocked = false
		return true
	}

	// Check if blocked
	if limit.Blocked && now.Sub(limit.BlockedAt) < m.config.RateLimitWindow {
		return false
	}

	// Increment requests
	limit.Requests++

	// Check if limit exceeded
	if limit.Requests > m.config.RateLimitRequests {
		limit.Blocked = true
		limit.BlockedAt = now
		return false
	}

	return true
}

// logSecurityEvent logs a security event
func (m *Manager) logSecurityEvent(eventType EventType, severity Severity, message, userID, sessionID string, context map[string]interface{}) {
	event := &SecurityEvent{
		ID:        generateSecureID(),
		Type:      eventType,
		Severity:  severity,
		Message:   message,
		Source:    "security_manager",
		UserID:    userID,
		SessionID: sessionID,
		Timestamp: time.Now(),
		Context:   context,
		Mitigated: false,
	}

	m.eventMutex.Lock()
	m.events = append(m.events, event)
	m.eventMutex.Unlock()

	// Send to monitor
	select {
	case m.monitor.events <- event:
	default:
		m.logger.Warn("Security monitor channel full, dropping event")
	}

	m.logger.Info("Security event logged", 
		"type", eventType, 
		"severity", severity, 
		"user_id", userID,
		"message", message)
}

// GetSecurityEvents returns recent security events
func (m *Manager) GetSecurityEvents(limit int) []*SecurityEvent {
	m.eventMutex.RLock()
	defer m.eventMutex.RUnlock()

	if limit <= 0 || limit > len(m.events) {
		limit = len(m.events)
	}

	// Return most recent events
	start := len(m.events) - limit
	if start < 0 {
		start = 0
	}

	return m.events[start:]
}

// NewValidator creates a new validator
func NewValidator(logger logger.Logger, config *Config) *Validator {
	return &Validator{
		logger: logger,
		config: config,
	}
}

// ValidateInput validates user input
func (v *Validator) ValidateInput(input string) *ValidationResult {
	result := &ValidationResult{
		Valid:    true,
		Errors:   []string{},
		Warnings: []string{},
	}

	// Check length
	if len(input) > v.config.MaxInputLength {
		result.Valid = false
		result.Errors = append(result.Errors, fmt.Sprintf("Input too long: %d > %d", len(input), v.config.MaxInputLength))
	}

	// Check for malicious patterns
	maliciousPatterns := []string{
		`<script.*?>.*?</script>`,
		`javascript:`,
		`eval\s*\(`,
		`exec\s*\(`,
		`system\s*\(`,
		`\.\./`,
		`\.\.\\`,
	}

	for _, pattern := range maliciousPatterns {
		if matched, _ := regexp.MatchString(pattern, input); matched {
			result.Valid = false
			result.Errors = append(result.Errors, fmt.Sprintf("Potentially malicious pattern detected: %s", pattern))
		}
	}

	return result
}

// ValidateOutput validates AI output
func (v *Validator) ValidateOutput(output string) *ValidationResult {
	result := &ValidationResult{
		Valid:    true,
		Errors:   []string{},
		Warnings: []string{},
	}

	// Check length
	if len(output) > v.config.MaxOutputLength {
		result.Valid = false
		result.Errors = append(result.Errors, fmt.Sprintf("Output too long: %d > %d", len(output), v.config.MaxOutputLength))
	}

	// Check for sensitive information patterns
	sensitivePatterns := []string{
		`(?i)password\s*[:=]\s*[^\s]+`,
		`(?i)api[_-]?key\s*[:=]\s*[^\s]+`,
		`(?i)secret\s*[:=]\s*[^\s]+`,
		`(?i)token\s*[:=]\s*[^\s]+`,
		`\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b`, // Credit card pattern
		`\b\d{3}-\d{2}-\d{4}\b`, // SSN pattern
	}

	for _, pattern := range sensitivePatterns {
		if matched, _ := regexp.MatchString(pattern, output); matched {
			result.Warnings = append(result.Warnings, "Potentially sensitive information detected")
		}
	}

	return result
}

// ValidateCommand validates command execution
func (v *Validator) ValidateCommand(command string, args []string) *ValidationResult {
	result := &ValidationResult{
		Valid:    true,
		Errors:   []string{},
		Warnings: []string{},
	}

	// Check if command is blocked
	for _, blocked := range v.config.BlockedCommands {
		if command == blocked {
			result.Valid = false
			result.Errors = append(result.Errors, fmt.Sprintf("Command blocked: %s", command))
			return result
		}
	}

	// Check if command is allowed (if allowlist is defined)
	if len(v.config.AllowedCommands) > 0 {
		allowed := false
		for _, allowedCmd := range v.config.AllowedCommands {
			if command == allowedCmd {
				allowed = true
				break
			}
		}
		if !allowed {
			result.Valid = false
			result.Errors = append(result.Errors, fmt.Sprintf("Command not allowed: %s", command))
		}
	}

	return result
}

// ValidateFileAccess validates file access
func (v *Validator) ValidateFileAccess(path, operation string) *ValidationResult {
	result := &ValidationResult{
		Valid:    true,
		Errors:   []string{},
		Warnings: []string{},
	}

	// Check for path traversal
	if strings.Contains(path, "..") {
		result.Valid = false
		result.Errors = append(result.Errors, "Path traversal detected")
	}

	// Check file extension
	for _, blocked := range v.config.BlockedFileTypes {
		if strings.HasSuffix(strings.ToLower(path), blocked) {
			result.Valid = false
			result.Errors = append(result.Errors, fmt.Sprintf("File type blocked: %s", blocked))
		}
	}

	return result
}

// NewSanitizer creates a new sanitizer
func NewSanitizer(logger logger.Logger, config *Config) *Sanitizer {
	return &Sanitizer{
		logger: logger,
		config: config,
	}
}

// SanitizeInput sanitizes user input
func (s *Sanitizer) SanitizeInput(input string) string {
	// Remove potentially dangerous characters
	sanitized := input
	
	// Remove script tags
	scriptRegex := regexp.MustCompile(`<script.*?>.*?</script>`)
	sanitized = scriptRegex.ReplaceAllString(sanitized, "")
	
	// Remove javascript: URLs
	jsRegex := regexp.MustCompile(`javascript:`)
	sanitized = jsRegex.ReplaceAllString(sanitized, "")
	
	// Escape HTML
	sanitized = strings.ReplaceAll(sanitized, "<", "&lt;")
	sanitized = strings.ReplaceAll(sanitized, ">", "&gt;")
	
	return sanitized
}

// NewSecurityScanner creates a new security scanner
func NewSecurityScanner(logger logger.Logger, config *Config) *SecurityScanner {
	return &SecurityScanner{
		logger: logger,
		config: config,
	}
}

// ScanCode scans code for security issues
func (s *SecurityScanner) ScanCode(code, language string) *ScanResult {
	result := &ScanResult{
		Safe:        true,
		Issues:      []*SecurityIssue{},
		Risk:        RiskLevelLow,
		Suggestions: []string{},
	}

	// Define security patterns by language
	patterns := s.getSecurityPatterns(language)
	
	lines := strings.Split(code, "\n")
	for i, line := range lines {
		for _, pattern := range patterns {
			if matched, _ := regexp.MatchString(pattern.Pattern, line); matched {
				issue := &SecurityIssue{
					Type:       pattern.Type,
					Severity:   pattern.Severity,
					Message:    pattern.Message,
					Line:       i + 1,
					Suggestion: pattern.Suggestion,
				}
				result.Issues = append(result.Issues, issue)
				
				if pattern.Severity == SeverityHigh || pattern.Severity == SeverityCritical {
					result.Safe = false
					result.Risk = RiskLevelHigh
				}
			}
		}
	}

	return result
}

// SecurityPattern represents a security pattern
type SecurityPattern struct {
	Pattern    string
	Type       IssueType
	Severity   Severity
	Message    string
	Suggestion string
}

// getSecurityPatterns returns security patterns for a language
func (s *SecurityScanner) getSecurityPatterns(language string) []*SecurityPattern {
	patterns := []*SecurityPattern{
		{
			Pattern:    `eval\s*\(`,
			Type:       IssueTypeCodeInjection,
			Severity:   SeverityCritical,
			Message:    "Use of eval() function detected",
			Suggestion: "Avoid using eval() as it can execute arbitrary code",
		},
		{
			Pattern:    `exec\s*\(`,
			Type:       IssueTypeCommandInjection,
			Severity:   SeverityHigh,
			Message:    "Use of exec() function detected",
			Suggestion: "Validate and sanitize input before using exec()",
		},
		{
			Pattern:    `system\s*\(`,
			Type:       IssueTypeCommandInjection,
			Severity:   SeverityHigh,
			Message:    "Use of system() function detected",
			Suggestion: "Use safer alternatives to system() calls",
		},
	}

	// Add language-specific patterns
	switch language {
	case "python":
		patterns = append(patterns, &SecurityPattern{
			Pattern:    `__import__\s*\(`,
			Type:       IssueTypeCodeInjection,
			Severity:   SeverityHigh,
			Message:    "Dynamic import detected",
			Suggestion: "Use static imports when possible",
		})
	case "javascript":
		patterns = append(patterns, &SecurityPattern{
			Pattern:    `innerHTML\s*=`,
			Type:       IssueTypeXSS,
			Severity:   SeverityMedium,
			Message:    "innerHTML assignment detected",
			Suggestion: "Use textContent or sanitize HTML content",
		})
	}

	return patterns
}

// NewSecurityMonitor creates a new security monitor
func NewSecurityMonitor(logger logger.Logger) *SecurityMonitor {
	return &SecurityMonitor{
		logger: logger,
		events: make(chan *SecurityEvent, 1000),
	}
}

// Start starts the security monitor
func (sm *SecurityMonitor) Start() {
	for event := range sm.events {
		sm.processEvent(event)
	}
}

// processEvent processes a security event
func (sm *SecurityMonitor) processEvent(event *SecurityEvent) {
	sm.logger.Info("Processing security event", 
		"type", event.Type, 
		"severity", event.Severity,
		"user_id", event.UserID)

	// Implement alerting logic here
	if event.Severity == SeverityCritical {
		sm.logger.Error("Critical security event", 
			"event_id", event.ID,
			"message", event.Message)
	}
}

// generateSecureID generates a secure random ID
func generateSecureID() string {
	bytes := make([]byte, 16)
	rand.Read(bytes)
	hash := sha256.Sum256(bytes)
	return hex.EncodeToString(hash[:8])
}
