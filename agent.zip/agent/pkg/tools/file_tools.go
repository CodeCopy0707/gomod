package tools

import (
	"context"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"

	"ai-coding-agent/internal/logger"
)

// FileReaderTool reads file contents
type FileReaderTool struct {
	logger logger.Logger
}

func NewFileReaderTool(logger logger.Logger) *FileReaderTool {
	return &FileReaderTool{logger: logger}
}

func (f *FileReaderTool) Name() string {
	return "file_reader"
}

func (f *FileReaderTool) Description() string {
	return "Reads the contents of a file"
}

func (f *FileReaderTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	path, ok := params["path"].(string)
	if !ok {
		return nil, fmt.Errorf("path parameter is required and must be a string")
	}

	content, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %w", err)
	}

	return map[string]interface{}{
		"path":    path,
		"content": string(content),
		"size":    len(content),
	}, nil
}

func (f *FileReaderTool) Validate(params map[string]interface{}) error {
	if _, ok := params["path"]; !ok {
		return fmt.Errorf("path parameter is required")
	}
	return nil
}

func (f *FileReaderTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        f.Name(),
		Description: f.Description(),
		Parameters: map[string]*Parameter{
			"path": {
				Type:        "string",
				Description: "Path to the file to read",
				Required:    true,
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "File content and metadata",
		},
		Examples: []*Example{
			{
				Description: "Read a Python file",
				Parameters:  map[string]interface{}{"path": "main.py"},
				Expected:    map[string]interface{}{"path": "main.py", "content": "print('Hello, World!')", "size": 21},
			},
		},
	}
}

// FileWriterTool writes content to files
type FileWriterTool struct {
	logger logger.Logger
}

func NewFileWriterTool(logger logger.Logger) *FileWriterTool {
	return &FileWriterTool{logger: logger}
}

func (f *FileWriterTool) Name() string {
	return "file_writer"
}

func (f *FileWriterTool) Description() string {
	return "Writes content to a file"
}

func (f *FileWriterTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	path, ok := params["path"].(string)
	if !ok {
		return nil, fmt.Errorf("path parameter is required and must be a string")
	}

	content, ok := params["content"].(string)
	if !ok {
		return nil, fmt.Errorf("content parameter is required and must be a string")
	}

	// Create directory if it doesn't exist
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create directory: %w", err)
	}

	// Write file
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		return nil, fmt.Errorf("failed to write file: %w", err)
	}

	return map[string]interface{}{
		"path":    path,
		"size":    len(content),
		"success": true,
	}, nil
}

func (f *FileWriterTool) Validate(params map[string]interface{}) error {
	if _, ok := params["path"]; !ok {
		return fmt.Errorf("path parameter is required")
	}
	if _, ok := params["content"]; !ok {
		return fmt.Errorf("content parameter is required")
	}
	return nil
}

func (f *FileWriterTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        f.Name(),
		Description: f.Description(),
		Parameters: map[string]*Parameter{
			"path": {
				Type:        "string",
				Description: "Path to the file to write",
				Required:    true,
			},
			"content": {
				Type:        "string",
				Description: "Content to write to the file",
				Required:    true,
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Write operation result",
		},
	}
}

// FileSearchTool searches for files and content
type FileSearchTool struct {
	logger logger.Logger
}

func NewFileSearchTool(logger logger.Logger) *FileSearchTool {
	return &FileSearchTool{logger: logger}
}

func (f *FileSearchTool) Name() string {
	return "file_search"
}

func (f *FileSearchTool) Description() string {
	return "Searches for files by name or content"
}

func (f *FileSearchTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	query, ok := params["query"].(string)
	if !ok {
		return nil, fmt.Errorf("query parameter is required and must be a string")
	}

	searchPath := "."
	if path, ok := params["path"].(string); ok {
		searchPath = path
	}

	searchType := "filename"
	if sType, ok := params["type"].(string); ok {
		searchType = sType
	}

	var results []map[string]interface{}

	err := filepath.WalkDir(searchPath, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// Skip hidden files and directories
		if strings.HasPrefix(d.Name(), ".") {
			if d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		switch searchType {
		case "filename":
			if strings.Contains(strings.ToLower(d.Name()), strings.ToLower(query)) {
				results = append(results, map[string]interface{}{
					"path":  path,
					"name":  d.Name(),
					"type":  getFileType(d),
					"match": "filename",
				})
			}

		case "content":
			if !d.IsDir() {
				if matches, err := f.searchFileContent(path, query); err == nil && len(matches) > 0 {
					results = append(results, map[string]interface{}{
						"path":    path,
						"name":    d.Name(),
						"type":    getFileType(d),
						"match":   "content",
						"matches": matches,
					})
				}
			}
		}

		return nil
	})

	if err != nil {
		return nil, fmt.Errorf("search failed: %w", err)
	}

	return map[string]interface{}{
		"query":   query,
		"path":    searchPath,
		"type":    searchType,
		"results": results,
		"count":   len(results),
	}, nil
}

func (f *FileSearchTool) searchFileContent(path, query string) ([]map[string]interface{}, error) {
	content, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var matches []map[string]interface{}
	lines := strings.Split(string(content), "\n")

	for i, line := range lines {
		if strings.Contains(strings.ToLower(line), strings.ToLower(query)) {
			matches = append(matches, map[string]interface{}{
				"line":    i + 1,
				"content": strings.TrimSpace(line),
			})
		}
	}

	return matches, nil
}

func (f *FileSearchTool) Validate(params map[string]interface{}) error {
	if _, ok := params["query"]; !ok {
		return fmt.Errorf("query parameter is required")
	}
	return nil
}

func (f *FileSearchTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        f.Name(),
		Description: f.Description(),
		Parameters: map[string]*Parameter{
			"query": {
				Type:        "string",
				Description: "Search query",
				Required:    true,
			},
			"path": {
				Type:        "string",
				Description: "Path to search in (default: current directory)",
				Required:    false,
				Default:     ".",
			},
			"type": {
				Type:        "string",
				Description: "Search type: filename or content",
				Required:    false,
				Default:     "filename",
				Enum:        []string{"filename", "content"},
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Search results",
		},
	}
}

// DirectoryListerTool lists directory contents
type DirectoryListerTool struct {
	logger logger.Logger
}

func NewDirectoryListerTool(logger logger.Logger) *DirectoryListerTool {
	return &DirectoryListerTool{logger: logger}
}

func (d *DirectoryListerTool) Name() string {
	return "directory_lister"
}

func (d *DirectoryListerTool) Description() string {
	return "Lists the contents of a directory"
}

func (d *DirectoryListerTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	path := "."
	if p, ok := params["path"].(string); ok {
		path = p
	}

	recursive := false
	if r, ok := params["recursive"].(bool); ok {
		recursive = r
	}

	var items []map[string]interface{}

	if recursive {
		err := filepath.WalkDir(path, func(filePath string, d fs.DirEntry, err error) error {
			if err != nil {
				return err
			}

			// Skip hidden files unless explicitly requested
			if strings.HasPrefix(d.Name(), ".") && filePath != path {
				if d.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}

			info, err := d.Info()
			if err != nil {
				return err
			}

			items = append(items, map[string]interface{}{
				"name":     d.Name(),
				"path":     filePath,
				"type":     getFileType(d),
				"size":     info.Size(),
				"modified": info.ModTime(),
			})

			return nil
		})

		if err != nil {
			return nil, fmt.Errorf("failed to walk directory: %w", err)
		}
	} else {
		entries, err := os.ReadDir(path)
		if err != nil {
			return nil, fmt.Errorf("failed to read directory: %w", err)
		}

		for _, entry := range entries {
			info, err := entry.Info()
			if err != nil {
				continue
			}

			items = append(items, map[string]interface{}{
				"name":     entry.Name(),
				"path":     filepath.Join(path, entry.Name()),
				"type":     getFileType(entry),
				"size":     info.Size(),
				"modified": info.ModTime(),
			})
		}
	}

	return map[string]interface{}{
		"path":      path,
		"recursive": recursive,
		"items":     items,
		"count":     len(items),
	}, nil
}

func (d *DirectoryListerTool) Validate(params map[string]interface{}) error {
	// All parameters are optional
	return nil
}

func (d *DirectoryListerTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        d.Name(),
		Description: d.Description(),
		Parameters: map[string]*Parameter{
			"path": {
				Type:        "string",
				Description: "Path to the directory (default: current directory)",
				Required:    false,
				Default:     ".",
			},
			"recursive": {
				Type:        "boolean",
				Description: "Whether to list recursively",
				Required:    false,
				Default:     false,
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Directory listing",
		},
	}
}

// Helper function to determine file type
func getFileType(entry fs.DirEntry) string {
	if entry.IsDir() {
		return "directory"
	}

	ext := strings.ToLower(filepath.Ext(entry.Name()))
	switch ext {
	case ".go":
		return "go"
	case ".py":
		return "python"
	case ".js", ".jsx":
		return "javascript"
	case ".ts", ".tsx":
		return "typescript"
	case ".java":
		return "java"
	case ".cpp", ".cc", ".cxx":
		return "cpp"
	case ".c":
		return "c"
	case ".rs":
		return "rust"
	case ".rb":
		return "ruby"
	case ".php":
		return "php"
	case ".cs":
		return "csharp"
	case ".kt":
		return "kotlin"
	case ".swift":
		return "swift"
	case ".md":
		return "markdown"
	case ".json":
		return "json"
	case ".yaml", ".yml":
		return "yaml"
	case ".xml":
		return "xml"
	case ".html":
		return "html"
	case ".css":
		return "css"
	case ".txt":
		return "text"
	default:
		return "file"
	}
}
