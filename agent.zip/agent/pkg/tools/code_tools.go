package tools

import (
	"context"
	"fmt"
	"os/exec"
	"strings"

	"ai-coding-agent/internal/logger"
)

// CodeGeneratorTool generates code based on specifications
type CodeGeneratorTool struct {
	logger logger.Logger
}

func NewCodeGeneratorTool(logger logger.Logger) *CodeGeneratorTool {
	return &CodeGeneratorTool{logger: logger}
}

func (c *CodeGeneratorTool) Name() string {
	return "code_generator"
}

func (c *CodeGeneratorTool) Description() string {
	return "Generates code based on natural language specifications"
}

func (c *CodeGeneratorTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	specification, ok := params["specification"].(string)
	if !ok {
		return nil, fmt.Errorf("specification parameter is required and must be a string")
	}

	language := "python"
	if lang, ok := params["language"].(string); ok {
		language = lang
	}

	framework := ""
	if fw, ok := params["framework"].(string); ok {
		framework = fw
	}

	// This would integrate with AI providers to generate code
	// For now, we'll return a placeholder implementation
	generatedCode := c.generateCodePlaceholder(specification, language, framework)

	return map[string]interface{}{
		"specification": specification,
		"language":      language,
		"framework":     framework,
		"code":          generatedCode,
		"explanation":   c.generateExplanation(specification, language),
	}, nil
}

func (c *CodeGeneratorTool) generateCodePlaceholder(spec, language, framework string) string {
	switch language {
	case "python":
		return fmt.Sprintf(`# Generated Python code for: %s
def main():
    """
    %s
    """
    # TODO: Implement the functionality
    pass

if __name__ == "__main__":
    main()
`, spec, spec)

	case "go":
		return fmt.Sprintf(`// Generated Go code for: %s
package main

import "fmt"

func main() {
    // TODO: Implement the functionality
    fmt.Println("Hello, World!")
}
`, spec)

	case "javascript":
		return fmt.Sprintf(`// Generated JavaScript code for: %s
function main() {
    /**
     * %s
     */
    // TODO: Implement the functionality
    console.log("Hello, World!");
}

main();
`, spec, spec)

	default:
		return fmt.Sprintf("// Generated %s code for: %s\n// TODO: Implement the functionality", language, spec)
	}
}

func (c *CodeGeneratorTool) generateExplanation(spec, language string) string {
	return fmt.Sprintf("Generated %s code based on the specification: %s. The code provides a basic structure that needs to be implemented according to the requirements.", language, spec)
}

func (c *CodeGeneratorTool) Validate(params map[string]interface{}) error {
	if _, ok := params["specification"]; !ok {
		return fmt.Errorf("specification parameter is required")
	}
	return nil
}

func (c *CodeGeneratorTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        c.Name(),
		Description: c.Description(),
		Parameters: map[string]*Parameter{
			"specification": {
				Type:        "string",
				Description: "Natural language specification of what to generate",
				Required:    true,
			},
			"language": {
				Type:        "string",
				Description: "Programming language to generate code in",
				Required:    false,
				Default:     "python",
				Enum:        []string{"python", "go", "javascript", "typescript", "java", "cpp", "rust"},
			},
			"framework": {
				Type:        "string",
				Description: "Framework to use (optional)",
				Required:    false,
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Generated code and explanation",
		},
	}
}

// CodeRefactorTool refactors existing code
type CodeRefactorTool struct {
	logger logger.Logger
}

func NewCodeRefactorTool(logger logger.Logger) *CodeRefactorTool {
	return &CodeRefactorTool{logger: logger}
}

func (c *CodeRefactorTool) Name() string {
	return "code_refactor"
}

func (c *CodeRefactorTool) Description() string {
	return "Refactors existing code to improve quality, performance, or maintainability"
}

func (c *CodeRefactorTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	code, ok := params["code"].(string)
	if !ok {
		return nil, fmt.Errorf("code parameter is required and must be a string")
	}

	language := "python"
	if lang, ok := params["language"].(string); ok {
		language = lang
	}

	refactorType := "general"
	if rType, ok := params["type"].(string); ok {
		refactorType = rType
	}

	// Perform refactoring based on type
	refactoredCode, suggestions := c.performRefactoring(code, language, refactorType)

	return map[string]interface{}{
		"original_code":    code,
		"refactored_code":  refactoredCode,
		"language":         language,
		"refactor_type":    refactorType,
		"suggestions":      suggestions,
		"improvements":     c.analyzeImprovements(code, refactoredCode),
	}, nil
}

func (c *CodeRefactorTool) performRefactoring(code, language, refactorType string) (string, []string) {
	suggestions := []string{}
	refactoredCode := code

	switch refactorType {
	case "extract_function":
		// Placeholder for function extraction logic
		suggestions = append(suggestions, "Consider extracting repeated code into separate functions")
		
	case "remove_duplicates":
		// Placeholder for duplicate removal logic
		suggestions = append(suggestions, "Identified potential code duplicates that could be consolidated")
		
	case "improve_naming":
		// Placeholder for naming improvement logic
		suggestions = append(suggestions, "Consider using more descriptive variable and function names")
		
	case "optimize_performance":
		// Placeholder for performance optimization logic
		suggestions = append(suggestions, "Consider optimizing loops and data structures for better performance")
		
	default:
		suggestions = append(suggestions, "General code improvements applied")
	}

	// Add language-specific improvements
	switch language {
	case "python":
		suggestions = append(suggestions, "Consider using list comprehensions where appropriate")
		suggestions = append(suggestions, "Follow PEP 8 style guidelines")
		
	case "go":
		suggestions = append(suggestions, "Consider using goroutines for concurrent operations")
		suggestions = append(suggestions, "Follow Go naming conventions")
		
	case "javascript":
		suggestions = append(suggestions, "Consider using const/let instead of var")
		suggestions = append(suggestions, "Use arrow functions where appropriate")
	}

	return refactoredCode, suggestions
}

func (c *CodeRefactorTool) analyzeImprovements(original, refactored string) map[string]interface{} {
	return map[string]interface{}{
		"lines_reduced":     max(0, len(strings.Split(original, "\n"))-len(strings.Split(refactored, "\n"))),
		"complexity_score":  "improved", // Placeholder
		"readability_score": "improved", // Placeholder
	}
}

func (c *CodeRefactorTool) Validate(params map[string]interface{}) error {
	if _, ok := params["code"]; !ok {
		return fmt.Errorf("code parameter is required")
	}
	return nil
}

func (c *CodeRefactorTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        c.Name(),
		Description: c.Description(),
		Parameters: map[string]*Parameter{
			"code": {
				Type:        "string",
				Description: "Code to refactor",
				Required:    true,
			},
			"language": {
				Type:        "string",
				Description: "Programming language of the code",
				Required:    false,
				Default:     "python",
			},
			"type": {
				Type:        "string",
				Description: "Type of refactoring to perform",
				Required:    false,
				Default:     "general",
				Enum:        []string{"general", "extract_function", "remove_duplicates", "improve_naming", "optimize_performance"},
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Refactored code and analysis",
		},
	}
}

// CodeAnalyzerTool analyzes code for issues and improvements
type CodeAnalyzerTool struct {
	logger logger.Logger
}

func NewCodeAnalyzerTool(logger logger.Logger) *CodeAnalyzerTool {
	return &CodeAnalyzerTool{logger: logger}
}

func (c *CodeAnalyzerTool) Name() string {
	return "code_analyzer"
}

func (c *CodeAnalyzerTool) Description() string {
	return "Analyzes code for bugs, performance issues, security vulnerabilities, and style problems"
}

func (c *CodeAnalyzerTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	code, ok := params["code"].(string)
	if !ok {
		return nil, fmt.Errorf("code parameter is required and must be a string")
	}

	language := "python"
	if lang, ok := params["language"].(string); ok {
		language = lang
	}

	analysisType := "all"
	if aType, ok := params["analysis_type"].(string); ok {
		analysisType = aType
	}

	// Perform analysis
	issues := c.analyzeCode(code, language, analysisType)
	metrics := c.calculateMetrics(code, language)
	suggestions := c.generateSuggestions(issues, language)

	return map[string]interface{}{
		"code":          code,
		"language":      language,
		"analysis_type": analysisType,
		"issues":        issues,
		"metrics":       metrics,
		"suggestions":   suggestions,
		"score":         c.calculateOverallScore(issues, metrics),
	}, nil
}

func (c *CodeAnalyzerTool) analyzeCode(code, language, analysisType string) []map[string]interface{} {
	var issues []map[string]interface{}

	lines := strings.Split(code, "\n")

	// Basic analysis - in a real implementation, this would use proper static analysis tools
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)

		// Check for common issues
		if strings.Contains(trimmed, "TODO") || strings.Contains(trimmed, "FIXME") {
			issues = append(issues, map[string]interface{}{
				"type":        "todo",
				"severity":    "info",
				"line":        i + 1,
				"message":     "TODO or FIXME comment found",
				"suggestion":  "Consider implementing or removing this TODO",
			})
		}

		// Language-specific checks
		switch language {
		case "python":
			if strings.Contains(trimmed, "print(") && !strings.Contains(trimmed, "#") {
				issues = append(issues, map[string]interface{}{
					"type":        "debug",
					"severity":    "warning",
					"line":        i + 1,
					"message":     "Debug print statement found",
					"suggestion":  "Consider using logging instead of print statements",
				})
			}

		case "javascript":
			if strings.Contains(trimmed, "console.log") {
				issues = append(issues, map[string]interface{}{
					"type":        "debug",
					"severity":    "warning",
					"line":        i + 1,
					"message":     "Console.log statement found",
					"suggestion":  "Remove debug console.log statements before production",
				})
			}
		}
	}

	return issues
}

func (c *CodeAnalyzerTool) calculateMetrics(code, language string) map[string]interface{} {
	lines := strings.Split(code, "\n")
	
	return map[string]interface{}{
		"lines_of_code":    len(lines),
		"blank_lines":      c.countBlankLines(lines),
		"comment_lines":    c.countCommentLines(lines, language),
		"complexity":       c.calculateComplexity(code, language),
		"maintainability":  85.0, // Placeholder
		"readability":      80.0, // Placeholder
	}
}

func (c *CodeAnalyzerTool) countBlankLines(lines []string) int {
	count := 0
	for _, line := range lines {
		if strings.TrimSpace(line) == "" {
			count++
		}
	}
	return count
}

func (c *CodeAnalyzerTool) countCommentLines(lines []string, language string) int {
	count := 0
	commentPrefix := "//"
	
	switch language {
	case "python":
		commentPrefix = "#"
	case "go", "javascript", "typescript", "java", "cpp", "rust":
		commentPrefix = "//"
	}
	
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, commentPrefix) {
			count++
		}
	}
	return count
}

func (c *CodeAnalyzerTool) calculateComplexity(code, language string) int {
	complexity := 1 // Base complexity
	
	// Count control flow statements
	keywords := []string{"if", "else", "for", "while", "switch", "case", "try", "catch"}
	
	for _, keyword := range keywords {
		complexity += strings.Count(strings.ToLower(code), keyword+" ")
		complexity += strings.Count(strings.ToLower(code), keyword+"(")
	}
	
	return complexity
}

func (c *CodeAnalyzerTool) generateSuggestions(issues []map[string]interface{}, language string) []string {
	suggestions := []string{}
	
	if len(issues) > 0 {
		suggestions = append(suggestions, fmt.Sprintf("Found %d issues that should be addressed", len(issues)))
	}
	
	// Language-specific suggestions
	switch language {
	case "python":
		suggestions = append(suggestions, "Consider using type hints for better code documentation")
		suggestions = append(suggestions, "Follow PEP 8 style guidelines")
		
	case "go":
		suggestions = append(suggestions, "Use gofmt to format your code")
		suggestions = append(suggestions, "Consider adding error handling")
		
	case "javascript":
		suggestions = append(suggestions, "Consider using ESLint for code quality checks")
		suggestions = append(suggestions, "Use strict mode ('use strict')")
	}
	
	return suggestions
}

func (c *CodeAnalyzerTool) calculateOverallScore(issues []map[string]interface{}, metrics map[string]interface{}) float64 {
	score := 100.0
	
	// Deduct points for issues
	for _, issue := range issues {
		severity, _ := issue["severity"].(string)
		switch severity {
		case "error":
			score -= 10
		case "warning":
			score -= 5
		case "info":
			score -= 1
		}
	}
	
	// Ensure score doesn't go below 0
	if score < 0 {
		score = 0
	}
	
	return score
}

func (c *CodeAnalyzerTool) Validate(params map[string]interface{}) error {
	if _, ok := params["code"]; !ok {
		return fmt.Errorf("code parameter is required")
	}
	return nil
}

func (c *CodeAnalyzerTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        c.Name(),
		Description: c.Description(),
		Parameters: map[string]*Parameter{
			"code": {
				Type:        "string",
				Description: "Code to analyze",
				Required:    true,
			},
			"language": {
				Type:        "string",
				Description: "Programming language of the code",
				Required:    false,
				Default:     "python",
			},
			"analysis_type": {
				Type:        "string",
				Description: "Type of analysis to perform",
				Required:    false,
				Default:     "all",
				Enum:        []string{"all", "bugs", "performance", "security", "style"},
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Code analysis results",
		},
	}
}

// CodeFormatterTool formats code according to language standards
type CodeFormatterTool struct {
	logger logger.Logger
}

func NewCodeFormatterTool(logger logger.Logger) *CodeFormatterTool {
	return &CodeFormatterTool{logger: logger}
}

func (c *CodeFormatterTool) Name() string {
	return "code_formatter"
}

func (c *CodeFormatterTool) Description() string {
	return "Formats code according to language-specific style guidelines"
}

func (c *CodeFormatterTool) Execute(ctx context.Context, params map[string]interface{}) (interface{}, error) {
	code, ok := params["code"].(string)
	if !ok {
		return nil, fmt.Errorf("code parameter is required and must be a string")
	}

	language := "python"
	if lang, ok := params["language"].(string); ok {
		language = lang
	}

	formattedCode, err := c.formatCode(code, language)
	if err != nil {
		return nil, fmt.Errorf("formatting failed: %w", err)
	}

	return map[string]interface{}{
		"original_code":  code,
		"formatted_code": formattedCode,
		"language":       language,
		"changes_made":   c.analyzeChanges(code, formattedCode),
	}, nil
}

func (c *CodeFormatterTool) formatCode(code, language string) (string, error) {
	switch language {
	case "python":
		return c.formatPython(code)
	case "go":
		return c.formatGo(code)
	case "javascript", "typescript":
		return c.formatJavaScript(code)
	default:
		// For unsupported languages, return the original code
		return code, nil
	}
}

func (c *CodeFormatterTool) formatPython(code string) (string, error) {
	// Try to use black formatter if available
	cmd := exec.Command("black", "--code", code)
	output, err := cmd.Output()
	if err != nil {
		// Fallback to basic formatting
		return c.basicPythonFormat(code), nil
	}
	return string(output), nil
}

func (c *CodeFormatterTool) formatGo(code string) (string, error) {
	// Try to use gofmt if available
	cmd := exec.Command("gofmt")
	cmd.Stdin = strings.NewReader(code)
	output, err := cmd.Output()
	if err != nil {
		// Fallback to basic formatting
		return c.basicGoFormat(code), nil
	}
	return string(output), nil
}

func (c *CodeFormatterTool) formatJavaScript(code string) (string, error) {
	// Try to use prettier if available
	cmd := exec.Command("prettier", "--parser", "babel", "--stdin-filepath", "temp.js")
	cmd.Stdin = strings.NewReader(code)
	output, err := cmd.Output()
	if err != nil {
		// Fallback to basic formatting
		return c.basicJavaScriptFormat(code), nil
	}
	return string(output), nil
}

func (c *CodeFormatterTool) basicPythonFormat(code string) string {
	// Basic Python formatting - add proper indentation, spacing, etc.
	lines := strings.Split(code, "\n")
	var formatted []string
	
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed != "" {
			formatted = append(formatted, trimmed)
		}
	}
	
	return strings.Join(formatted, "\n")
}

func (c *CodeFormatterTool) basicGoFormat(code string) string {
	// Basic Go formatting
	return code // Placeholder
}

func (c *CodeFormatterTool) basicJavaScriptFormat(code string) string {
	// Basic JavaScript formatting
	return code // Placeholder
}

func (c *CodeFormatterTool) analyzeChanges(original, formatted string) []string {
	changes := []string{}
	
	if len(strings.Split(original, "\n")) != len(strings.Split(formatted, "\n")) {
		changes = append(changes, "Line count changed")
	}
	
	if strings.TrimSpace(original) != strings.TrimSpace(formatted) {
		changes = append(changes, "Whitespace and indentation adjusted")
	}
	
	return changes
}

func (c *CodeFormatterTool) Validate(params map[string]interface{}) error {
	if _, ok := params["code"]; !ok {
		return fmt.Errorf("code parameter is required")
	}
	return nil
}

func (c *CodeFormatterTool) GetSchema() *ToolSchema {
	return &ToolSchema{
		Name:        c.Name(),
		Description: c.Description(),
		Parameters: map[string]*Parameter{
			"code": {
				Type:        "string",
				Description: "Code to format",
				Required:    true,
			},
			"language": {
				Type:        "string",
				Description: "Programming language of the code",
				Required:    false,
				Default:     "python",
			},
		},
		Returns: &ReturnType{
			Type:        "object",
			Description: "Formatted code and changes",
		},
	}
}

// Helper function
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
