package tools

import (
	"context"
	"fmt"
	"sync"

	"ai-coding-agent/internal/logger"
)

// Manager manages all available tools
type Manager struct {
	tools  map[string]Tool
	logger logger.Logger
	mutex  sync.RWMutex
}

// Tool interface that all tools must implement
type Tool interface {
	Name() string
	Description() string
	Execute(ctx context.Context, params map[string]interface{}) (interface{}, error)
	Validate(params map[string]interface{}) error
	GetSchema() *ToolSchema
}

// ToolSchema defines the parameters and return types for a tool
type ToolSchema struct {
	Name        string                 `json:"name"`
	Description string                 `json:"description"`
	Parameters  map[string]*Parameter  `json:"parameters"`
	Returns     *ReturnType            `json:"returns"`
	Examples    []*Example             `json:"examples"`
}

// Parameter defines a tool parameter
type Parameter struct {
	Type        string      `json:"type"`
	Description string      `json:"description"`
	Required    bool        `json:"required"`
	Default     interface{} `json:"default,omitempty"`
	Enum        []string    `json:"enum,omitempty"`
	Pattern     string      `json:"pattern,omitempty"`
	MinLength   *int        `json:"minLength,omitempty"`
	MaxLength   *int        `json:"maxLength,omitempty"`
}

// ReturnType defines the return type of a tool
type ReturnType struct {
	Type        string `json:"type"`
	Description string `json:"description"`
}

// Example provides usage examples for a tool
type Example struct {
	Description string                 `json:"description"`
	Parameters  map[string]interface{} `json:"parameters"`
	Expected    interface{}            `json:"expected"`
}

// NewManager creates a new tools manager
func NewManager(logger logger.Logger) (*Manager, error) {
	manager := &Manager{
		tools:  make(map[string]Tool),
		logger: logger,
	}

	// Register all tools
	if err := manager.registerTools(); err != nil {
		return nil, fmt.Errorf("failed to register tools: %w", err)
	}

	logger.Info("Tools manager initialized", "tools_count", len(manager.tools))
	return manager, nil
}

// registerTools registers all available tools
func (m *Manager) registerTools() error {
	tools := []Tool{
		// File operations
		NewFileReaderTool(m.logger),
		NewFileWriterTool(m.logger),
		NewFileSearchTool(m.logger),
		NewDirectoryListerTool(m.logger),
		
		// Code operations
		NewCodeGeneratorTool(m.logger),
		NewCodeRefactorTool(m.logger),
		NewCodeAnalyzerTool(m.logger),
		NewCodeFormatterTool(m.logger),
		NewCodeLinterTool(m.logger),
		NewCodeTranslatorTool(m.logger),
		
		// Testing tools
		NewTestGeneratorTool(m.logger),
		NewTestRunnerTool(m.logger),
		NewCoverageAnalyzerTool(m.logger),
		
		// Terminal operations
		NewCommandExecutorTool(m.logger),
		NewProcessManagerTool(m.logger),
		NewShellTool(m.logger),
		
		// Git operations
		NewGitTool(m.logger),
		NewGitAnalyzerTool(m.logger),
		
		// Web operations
		NewWebSearchTool(m.logger),
		NewWebScraperTool(m.logger),
		NewDocumentationFetcherTool(m.logger),
		
		// Project management
		NewProjectScaffolderTool(m.logger),
		NewDependencyManagerTool(m.logger),
		NewBuildTool(m.logger),
		NewDeploymentTool(m.logger),
		
		// Analysis tools
		NewPerformanceProfilerTool(m.logger),
		NewSecurityScannerTool(m.logger),
		NewComplexityAnalyzerTool(m.logger),
		
		// Documentation tools
		NewDocumentationGeneratorTool(m.logger),
		NewAPIDocGeneratorTool(m.logger),
		NewReadmeGeneratorTool(m.logger),
	}

	for _, tool := range tools {
		if err := m.RegisterTool(tool); err != nil {
			m.logger.Warn("Failed to register tool", "tool", tool.Name(), "error", err)
		}
	}

	return nil
}

// RegisterTool registers a new tool
func (m *Manager) RegisterTool(tool Tool) error {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	name := tool.Name()
	if _, exists := m.tools[name]; exists {
		return fmt.Errorf("tool %s already registered", name)
	}

	m.tools[name] = tool
	m.logger.Debug("Tool registered", "name", name)
	return nil
}

// Execute executes a tool with the given parameters
func (m *Manager) Execute(ctx context.Context, toolName string, params map[string]interface{}) (interface{}, error) {
	m.mutex.RLock()
	tool, exists := m.tools[toolName]
	m.mutex.RUnlock()

	if !exists {
		return nil, fmt.Errorf("tool %s not found", toolName)
	}

	// Validate parameters
	if err := tool.Validate(params); err != nil {
		return nil, fmt.Errorf("parameter validation failed: %w", err)
	}

	m.logger.Debug("Executing tool", "name", toolName, "params", params)

	// Execute the tool
	result, err := tool.Execute(ctx, params)
	if err != nil {
		m.logger.Error("Tool execution failed", "name", toolName, "error", err)
		return nil, fmt.Errorf("tool execution failed: %w", err)
	}

	m.logger.Debug("Tool executed successfully", "name", toolName)
	return result, nil
}

// GetTool returns a tool by name
func (m *Manager) GetTool(name string) (Tool, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	tool, exists := m.tools[name]
	if !exists {
		return nil, fmt.Errorf("tool %s not found", name)
	}

	return tool, nil
}

// ListTools returns a list of all available tools
func (m *Manager) ListTools() []string {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	var names []string
	for name := range m.tools {
		names = append(names, name)
	}

	return names
}

// GetToolSchemas returns schemas for all tools
func (m *Manager) GetToolSchemas() map[string]*ToolSchema {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	schemas := make(map[string]*ToolSchema)
	for name, tool := range m.tools {
		schemas[name] = tool.GetSchema()
	}

	return schemas
}

// GetToolsByCategory returns tools grouped by category
func (m *Manager) GetToolsByCategory() map[string][]string {
	categories := map[string][]string{
		"file_operations": {
			"file_reader", "file_writer", "file_search", "directory_lister",
		},
		"code_operations": {
			"code_generator", "code_refactor", "code_analyzer", "code_formatter",
			"code_linter", "code_translator",
		},
		"testing": {
			"test_generator", "test_runner", "coverage_analyzer",
		},
		"terminal": {
			"command_executor", "process_manager", "shell",
		},
		"git": {
			"git", "git_analyzer",
		},
		"web": {
			"web_search", "web_scraper", "documentation_fetcher",
		},
		"project_management": {
			"project_scaffolder", "dependency_manager", "build", "deployment",
		},
		"analysis": {
			"performance_profiler", "security_scanner", "complexity_analyzer",
		},
		"documentation": {
			"documentation_generator", "api_doc_generator", "readme_generator",
		},
	}

	return categories
}

// ValidateToolExists checks if a tool exists
func (m *Manager) ValidateToolExists(name string) bool {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	_, exists := m.tools[name]
	return exists
}

// GetToolDescription returns the description of a tool
func (m *Manager) GetToolDescription(name string) (string, error) {
	tool, err := m.GetTool(name)
	if err != nil {
		return "", err
	}

	return tool.Description(), nil
}

// ExecuteMultiple executes multiple tools in sequence
func (m *Manager) ExecuteMultiple(ctx context.Context, executions []ToolExecution) ([]interface{}, error) {
	results := make([]interface{}, len(executions))
	
	for i, execution := range executions {
		result, err := m.Execute(ctx, execution.ToolName, execution.Parameters)
		if err != nil {
			return nil, fmt.Errorf("execution %d failed: %w", i, err)
		}
		results[i] = result
	}

	return results, nil
}

// ExecuteParallel executes multiple tools in parallel
func (m *Manager) ExecuteParallel(ctx context.Context, executions []ToolExecution) ([]interface{}, error) {
	results := make([]interface{}, len(executions))
	errors := make([]error, len(executions))
	
	var wg sync.WaitGroup
	
	for i, execution := range executions {
		wg.Add(1)
		go func(index int, exec ToolExecution) {
			defer wg.Done()
			result, err := m.Execute(ctx, exec.ToolName, exec.Parameters)
			results[index] = result
			errors[index] = err
		}(i, execution)
	}
	
	wg.Wait()
	
	// Check for errors
	for i, err := range errors {
		if err != nil {
			return nil, fmt.Errorf("parallel execution %d failed: %w", i, err)
		}
	}

	return results, nil
}

// ToolExecution represents a tool execution request
type ToolExecution struct {
	ToolName   string                 `json:"tool_name"`
	Parameters map[string]interface{} `json:"parameters"`
}

// GetToolMetrics returns metrics for tool usage
func (m *Manager) GetToolMetrics() map[string]*ToolMetrics {
	// This would be implemented with actual metrics collection
	// For now, return empty metrics
	return make(map[string]*ToolMetrics)
}

// ToolMetrics contains usage metrics for a tool
type ToolMetrics struct {
	ExecutionCount   int64         `json:"execution_count"`
	SuccessCount     int64         `json:"success_count"`
	ErrorCount       int64         `json:"error_count"`
	AverageExecTime  float64       `json:"average_exec_time"`
	LastExecuted     *string       `json:"last_executed,omitempty"`
}

// Close cleans up resources used by the tools manager
func (m *Manager) Close() error {
	m.logger.Info("Closing tools manager")
	
	// Close any tools that need cleanup
	m.mutex.RLock()
	defer m.mutex.RUnlock()
	
	for name, tool := range m.tools {
		if closer, ok := tool.(interface{ Close() error }); ok {
			if err := closer.Close(); err != nil {
				m.logger.Warn("Error closing tool", "name", name, "error", err)
			}
		}
	}
	
	return nil
}
