package terminal

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
)

// Manager handles terminal operations and command execution
type Manager struct {
	logger    logger.Logger
	sessions  map[string]*Session
	mutex     sync.RWMutex
	config    *Config
}

// Config holds terminal configuration
type Config struct {
	DefaultShell    string
	Timeout         time.Duration
	MaxCmdLength    int
	AllowedCommands []string
	BlockedCommands []string
	WorkingDir      string
	Environment     map[string]string
}

// Session represents a terminal session
type Session struct {
	ID          string
	Shell       string
	WorkingDir  string
	Environment map[string]string
	Process     *exec.Cmd
	Stdin       io.WriteCloser
	Stdout      io.ReadCloser
	Stderr      io.ReadCloser
	History     []*Command
	Active      bool
	CreatedAt   time.Time
	LastUsed    time.Time
	mutex       sync.RWMutex
}

// Command represents an executed command
type Command struct {
	ID        string
	Command   string
	Args      []string
	StartTime time.Time
	EndTime   time.Time
	ExitCode  int
	Output    string
	Error     string
	Duration  time.Duration
}

// ExecuteRequest represents a command execution request
type ExecuteRequest struct {
	Command     string
	Args        []string
	WorkingDir  string
	Environment map[string]string
	Timeout     time.Duration
	Interactive bool
	SessionID   string
}

// ExecuteResponse represents a command execution response
type ExecuteResponse struct {
	Command    *Command
	Output     string
	Error      string
	ExitCode   int
	Duration   time.Duration
	Success    bool
	Truncated  bool
}

// NewManager creates a new terminal manager
func NewManager(logger logger.Logger, config *Config) *Manager {
	if config == nil {
		config = &Config{
			DefaultShell:    getDefaultShell(),
			Timeout:         30 * time.Second,
			MaxCmdLength:    1000,
			AllowedCommands: []string{},
			BlockedCommands: []string{"rm", "rmdir", "del", "format", "fdisk"},
			WorkingDir:      ".",
			Environment:     make(map[string]string),
		}
	}

	return &Manager{
		logger:   logger,
		sessions: make(map[string]*Session),
		config:   config,
	}
}

// Execute executes a command
func (m *Manager) Execute(ctx context.Context, req *ExecuteRequest) (*ExecuteResponse, error) {
	m.logger.Info("Executing command", "command", req.Command, "args", req.Args)

	// Validate command
	if err := m.validateCommand(req.Command); err != nil {
		return nil, fmt.Errorf("command validation failed: %w", err)
	}

	// Create command
	cmd := &Command{
		ID:        generateID(),
		Command:   req.Command,
		Args:      req.Args,
		StartTime: time.Now(),
	}

	// Set timeout
	timeout := req.Timeout
	if timeout == 0 {
		timeout = m.config.Timeout
	}

	cmdCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// Execute command
	var output, errorOutput string
	var exitCode int
	var err error

	if req.Interactive && req.SessionID != "" {
		// Execute in session
		output, errorOutput, exitCode, err = m.executeInSession(cmdCtx, req)
	} else {
		// Execute standalone
		output, errorOutput, exitCode, err = m.executeStandalone(cmdCtx, req)
	}

	cmd.EndTime = time.Now()
	cmd.Duration = cmd.EndTime.Sub(cmd.StartTime)
	cmd.Output = output
	cmd.Error = errorOutput
	cmd.ExitCode = exitCode

	response := &ExecuteResponse{
		Command:   cmd,
		Output:    output,
		Error:     errorOutput,
		ExitCode:  exitCode,
		Duration:  cmd.Duration,
		Success:   exitCode == 0 && err == nil,
		Truncated: false,
	}

	// Truncate output if too long
	if len(output) > 10000 {
		response.Output = output[:10000] + "\n... (output truncated)"
		response.Truncated = true
	}

	m.logger.Info("Command executed", 
		"command", req.Command, 
		"exit_code", exitCode, 
		"duration", cmd.Duration,
		"success", response.Success)

	return response, err
}

// executeStandalone executes a command standalone
func (m *Manager) executeStandalone(ctx context.Context, req *ExecuteRequest) (string, string, int, error) {
	// Create command
	cmd := exec.CommandContext(ctx, req.Command, req.Args...)

	// Set working directory
	if req.WorkingDir != "" {
		cmd.Dir = req.WorkingDir
	} else {
		cmd.Dir = m.config.WorkingDir
	}

	// Set environment
	cmd.Env = os.Environ()
	for key, value := range m.config.Environment {
		cmd.Env = append(cmd.Env, fmt.Sprintf("%s=%s", key, value))
	}
	for key, value := range req.Environment {
		cmd.Env = append(cmd.Env, fmt.Sprintf("%s=%s", key, value))
	}

	// Execute command
	output, err := cmd.CombinedOutput()
	
	exitCode := 0
	if err != nil {
		if exitError, ok := err.(*exec.ExitError); ok {
			exitCode = exitError.ExitCode()
		} else {
			exitCode = 1
		}
	}

	return string(output), "", exitCode, err
}

// executeInSession executes a command in a session
func (m *Manager) executeInSession(ctx context.Context, req *ExecuteRequest) (string, string, int, error) {
	session, err := m.getOrCreateSession(req.SessionID)
	if err != nil {
		return "", "", 1, fmt.Errorf("failed to get session: %w", err)
	}

	// Send command to session
	commandLine := req.Command
	if len(req.Args) > 0 {
		commandLine += " " + strings.Join(req.Args, " ")
	}
	commandLine += "\n"

	_, err = session.Stdin.Write([]byte(commandLine))
	if err != nil {
		return "", "", 1, fmt.Errorf("failed to write to session: %w", err)
	}

	// Read output with timeout
	outputChan := make(chan string, 1)
	errorChan := make(chan error, 1)

	go func() {
		output, err := m.readSessionOutput(session, 5*time.Second)
		if err != nil {
			errorChan <- err
		} else {
			outputChan <- output
		}
	}()

	select {
	case output := <-outputChan:
		return output, "", 0, nil
	case err := <-errorChan:
		return "", "", 1, err
	case <-ctx.Done():
		return "", "", 1, ctx.Err()
	}
}

// getOrCreateSession gets or creates a terminal session
func (m *Manager) getOrCreateSession(sessionID string) (*Session, error) {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	if session, exists := m.sessions[sessionID]; exists {
		session.LastUsed = time.Now()
		return session, nil
	}

	// Create new session
	session, err := m.createSession(sessionID)
	if err != nil {
		return nil, err
	}

	m.sessions[sessionID] = session
	return session, nil
}

// createSession creates a new terminal session
func (m *Manager) createSession(sessionID string) (*Session, error) {
	shell := m.config.DefaultShell
	
	// Create command
	cmd := exec.Command(shell)
	cmd.Dir = m.config.WorkingDir
	cmd.Env = os.Environ()

	// Set up pipes
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return nil, fmt.Errorf("failed to create stdin pipe: %w", err)
	}

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, fmt.Errorf("failed to create stdout pipe: %w", err)
	}

	stderr, err := cmd.StderrPipe()
	if err != nil {
		return nil, fmt.Errorf("failed to create stderr pipe: %w", err)
	}

	// Start process
	if err := cmd.Start(); err != nil {
		return nil, fmt.Errorf("failed to start shell: %w", err)
	}

	session := &Session{
		ID:          sessionID,
		Shell:       shell,
		WorkingDir:  m.config.WorkingDir,
		Environment: make(map[string]string),
		Process:     cmd,
		Stdin:       stdin,
		Stdout:      stdout,
		Stderr:      stderr,
		History:     make([]*Command, 0),
		Active:      true,
		CreatedAt:   time.Now(),
		LastUsed:    time.Now(),
	}

	// Start monitoring the session
	go m.monitorSession(session)

	m.logger.Info("Created terminal session", "session_id", sessionID, "shell", shell)
	return session, nil
}

// readSessionOutput reads output from a session
func (m *Manager) readSessionOutput(session *Session, timeout time.Duration) (string, error) {
	var output strings.Builder
	reader := bufio.NewReader(session.Stdout)

	deadline := time.Now().Add(timeout)
	
	for time.Now().Before(deadline) {
		// Set read deadline
		if file, ok := session.Stdout.(*os.File); ok {
			file.SetReadDeadline(time.Now().Add(100 * time.Millisecond))
		}

		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			// Check if it's a timeout
			if strings.Contains(err.Error(), "timeout") {
				continue
			}
			return output.String(), err
		}

		output.WriteString(line)

		// Check for prompt (simple heuristic)
		if strings.Contains(line, "$") || strings.Contains(line, ">") {
			break
		}
	}

	return output.String(), nil
}

// monitorSession monitors a session for completion
func (m *Manager) monitorSession(session *Session) {
	session.Process.Wait()
	
	session.mutex.Lock()
	session.Active = false
	session.mutex.Unlock()

	m.logger.Info("Terminal session ended", "session_id", session.ID)
}

// validateCommand validates a command before execution
func (m *Manager) validateCommand(command string) error {
	// Check command length
	if len(command) > m.config.MaxCmdLength {
		return fmt.Errorf("command too long: %d > %d", len(command), m.config.MaxCmdLength)
	}

	// Check blocked commands
	for _, blocked := range m.config.BlockedCommands {
		if strings.HasPrefix(strings.ToLower(command), strings.ToLower(blocked)) {
			return fmt.Errorf("command blocked: %s", command)
		}
	}

	// Check allowed commands (if specified)
	if len(m.config.AllowedCommands) > 0 {
		allowed := false
		for _, allowedCmd := range m.config.AllowedCommands {
			if strings.HasPrefix(strings.ToLower(command), strings.ToLower(allowedCmd)) {
				allowed = true
				break
			}
		}
		if !allowed {
			return fmt.Errorf("command not allowed: %s", command)
		}
	}

	return nil
}

// GetSession returns a session by ID
func (m *Manager) GetSession(sessionID string) (*Session, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	session, exists := m.sessions[sessionID]
	if !exists {
		return nil, fmt.Errorf("session not found: %s", sessionID)
	}

	return session, nil
}

// ListSessions returns all active sessions
func (m *Manager) ListSessions() []*Session {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	sessions := make([]*Session, 0, len(m.sessions))
	for _, session := range m.sessions {
		sessions = append(sessions, session)
	}

	return sessions
}

// CloseSession closes a terminal session
func (m *Manager) CloseSession(sessionID string) error {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	session, exists := m.sessions[sessionID]
	if !exists {
		return fmt.Errorf("session not found: %s", sessionID)
	}

	// Close pipes
	session.Stdin.Close()
	session.Stdout.Close()
	session.Stderr.Close()

	// Kill process
	if session.Process != nil {
		session.Process.Process.Kill()
	}

	// Remove from sessions
	delete(m.sessions, sessionID)

	m.logger.Info("Closed terminal session", "session_id", sessionID)
	return nil
}

// Close closes the terminal manager
func (m *Manager) Close() error {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	// Close all sessions
	for sessionID := range m.sessions {
		m.CloseSession(sessionID)
	}

	return nil
}

// Helper functions

// getDefaultShell returns the default shell for the current OS
func getDefaultShell() string {
	switch runtime.GOOS {
	case "windows":
		return "cmd"
	default:
		shell := os.Getenv("SHELL")
		if shell == "" {
			shell = "/bin/bash"
		}
		return shell
	}
}

// generateID generates a unique ID
func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

// IsActive returns whether the session is active
func (s *Session) IsActive() bool {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	return s.Active
}

// AddCommand adds a command to the session history
func (s *Session) AddCommand(cmd *Command) {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.History = append(s.History, cmd)
	s.LastUsed = time.Now()
}

// GetHistory returns the command history
func (s *Session) GetHistory() []*Command {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	return s.History
}
