package languages

import (
	"context"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
	"sync"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
)

// Manager handles multi-language support and translation
type Manager struct {
	logger      logger.Logger
	ai          *ai.Manager
	languages   map[string]*Language
	translators map[string]*Translator
	parsers     map[string]*Parser
	mutex       sync.RWMutex
}

// Language represents a programming language
type Language struct {
	Name         string            `json:"name"`
	Extensions   []string          `json:"extensions"`
	Keywords     []string          `json:"keywords"`
	Syntax       *SyntaxRules      `json:"syntax"`
	Features     *LanguageFeatures `json:"features"`
	Frameworks   []string          `json:"frameworks"`
	PackageManager string          `json:"package_manager"`
	TestFrameworks []string        `json:"test_frameworks"`
	Linters      []string          `json:"linters"`
	Formatters   []string          `json:"formatters"`
}

// SyntaxRules defines syntax rules for a language
type SyntaxRules struct {
	CommentSingle   string            `json:"comment_single"`
	CommentMulti    []string          `json:"comment_multi"`
	StringDelimiters []string         `json:"string_delimiters"`
	BlockDelimiters map[string]string `json:"block_delimiters"`
	StatementEnd    string            `json:"statement_end"`
	CaseSensitive   bool              `json:"case_sensitive"`
	Indentation     string            `json:"indentation"`
}

// LanguageFeatures defines features supported by a language
type LanguageFeatures struct {
	ObjectOriented   bool `json:"object_oriented"`
	Functional       bool `json:"functional"`
	StaticTyping     bool `json:"static_typing"`
	DynamicTyping    bool `json:"dynamic_typing"`
	GarbageCollection bool `json:"garbage_collection"`
	Concurrency      bool `json:"concurrency"`
	Metaprogramming  bool `json:"metaprogramming"`
	Generics         bool `json:"generics"`
}

// Translator handles code translation between languages
type Translator struct {
	FromLanguage string
	ToLanguage   string
	ai           *ai.Manager
	logger       logger.Logger
}

// Parser handles language-specific parsing
type Parser struct {
	Language string
	logger   logger.Logger
}

// TranslationRequest represents a translation request
type TranslationRequest struct {
	Code         string                 `json:"code"`
	FromLanguage string                 `json:"from_language"`
	ToLanguage   string                 `json:"to_language"`
	Context      map[string]interface{} `json:"context"`
	Options      *TranslationOptions    `json:"options"`
}

// TranslationOptions defines translation options
type TranslationOptions struct {
	PreserveComments bool `json:"preserve_comments"`
	PreserveStyle    bool `json:"preserve_style"`
	AddDocumentation bool `json:"add_documentation"`
	OptimizeCode     bool `json:"optimize_code"`
	TargetFramework  string `json:"target_framework"`
}

// TranslationResult represents the result of a translation
type TranslationResult struct {
	TranslatedCode string                 `json:"translated_code"`
	FromLanguage   string                 `json:"from_language"`
	ToLanguage     string                 `json:"to_language"`
	Changes        []*TranslationChange   `json:"changes"`
	Warnings       []string               `json:"warnings"`
	Suggestions    []string               `json:"suggestions"`
	Metadata       map[string]interface{} `json:"metadata"`
}

// TranslationChange represents a change made during translation
type TranslationChange struct {
	Type        string `json:"type"`
	Description string `json:"description"`
	FromLine    int    `json:"from_line"`
	ToLine      int    `json:"to_line"`
	Reason      string `json:"reason"`
}

// NewManager creates a new language manager
func NewManager(logger logger.Logger, ai *ai.Manager) *Manager {
	manager := &Manager{
		logger:      logger,
		ai:          ai,
		languages:   make(map[string]*Language),
		translators: make(map[string]*Translator),
		parsers:     make(map[string]*Parser),
	}

	// Initialize supported languages
	manager.initializeLanguages()
	manager.initializeTranslators()
	manager.initializeParsers()

	logger.Info("Language manager initialized with support for 20+ languages")
	return manager
}

// initializeLanguages initializes all supported languages
func (m *Manager) initializeLanguages() {
	languages := []*Language{
		// Systems Programming
		{
			Name:           "go",
			Extensions:     []string{".go"},
			Keywords:       []string{"package", "import", "func", "var", "const", "type", "struct", "interface", "if", "else", "for", "range", "switch", "case", "default", "return", "defer", "go", "chan", "select"},
			PackageManager: "go mod",
			TestFrameworks: []string{"testing", "testify", "ginkgo"},
			Linters:        []string{"golint", "golangci-lint", "staticcheck"},
			Formatters:     []string{"gofmt", "goimports"},
			Syntax: &SyntaxRules{
				CommentSingle:   "//",
				CommentMulti:    []string{"/*", "*/"},
				StringDelimiters: []string{"\"", "`"},
				BlockDelimiters: map[string]string{"{": "}", "(": ")", "[": "]"},
				StatementEnd:    "",
				CaseSensitive:   true,
				Indentation:     "tab",
			},
			Features: &LanguageFeatures{
				ObjectOriented:    false,
				Functional:        true,
				StaticTyping:      true,
				DynamicTyping:     false,
				GarbageCollection: true,
				Concurrency:       true,
				Metaprogramming:   false,
				Generics:          true,
			},
		},
		{
			Name:           "rust",
			Extensions:     []string{".rs"},
			Keywords:       []string{"fn", "let", "mut", "const", "static", "struct", "enum", "impl", "trait", "mod", "use", "pub", "if", "else", "match", "loop", "while", "for", "in", "return", "break", "continue"},
			PackageManager: "cargo",
			TestFrameworks: []string{"built-in", "proptest", "quickcheck"},
			Linters:        []string{"clippy", "rustfmt"},
			Formatters:     []string{"rustfmt"},
		},
		{
			Name:           "c",
			Extensions:     []string{".c", ".h"},
			Keywords:       []string{"int", "char", "float", "double", "void", "if", "else", "while", "for", "do", "switch", "case", "default", "return", "break", "continue", "struct", "union", "enum", "typedef", "static", "extern"},
			PackageManager: "make",
			TestFrameworks: []string{"unity", "cmocka", "check"},
			Linters:        []string{"cppcheck", "clang-tidy"},
			Formatters:     []string{"clang-format"},
		},
		{
			Name:           "cpp",
			Extensions:     []string{".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx"},
			Keywords:       []string{"class", "public", "private", "protected", "virtual", "override", "template", "typename", "namespace", "using", "new", "delete", "try", "catch", "throw"},
			PackageManager: "cmake",
			TestFrameworks: []string{"gtest", "catch2", "boost.test"},
			Linters:        []string{"cppcheck", "clang-tidy"},
			Formatters:     []string{"clang-format"},
		},
		// Web Development
		{
			Name:           "javascript",
			Extensions:     []string{".js", ".mjs"},
			Keywords:       []string{"var", "let", "const", "function", "class", "if", "else", "for", "while", "do", "switch", "case", "default", "return", "break", "continue", "try", "catch", "finally", "throw", "async", "await"},
			PackageManager: "npm",
			TestFrameworks: []string{"jest", "mocha", "jasmine", "cypress"},
			Linters:        []string{"eslint", "jshint"},
			Formatters:     []string{"prettier"},
			Frameworks:     []string{"react", "vue", "angular", "express", "node"},
		},
		{
			Name:           "typescript",
			Extensions:     []string{".ts", ".tsx"},
			Keywords:       []string{"interface", "type", "enum", "namespace", "module", "declare", "abstract", "implements", "extends", "public", "private", "protected", "readonly"},
			PackageManager: "npm",
			TestFrameworks: []string{"jest", "mocha", "jasmine"},
			Linters:        []string{"tslint", "eslint"},
			Formatters:     []string{"prettier"},
			Frameworks:     []string{"react", "vue", "angular", "express", "nest"},
		},
		{
			Name:           "python",
			Extensions:     []string{".py", ".pyw"},
			Keywords:       []string{"def", "class", "if", "elif", "else", "for", "while", "try", "except", "finally", "with", "as", "import", "from", "return", "yield", "lambda", "and", "or", "not", "in", "is"},
			PackageManager: "pip",
			TestFrameworks: []string{"unittest", "pytest", "nose"},
			Linters:        []string{"pylint", "flake8", "mypy"},
			Formatters:     []string{"black", "autopep8"},
			Frameworks:     []string{"django", "flask", "fastapi", "pandas", "numpy"},
		},
		// JVM Languages
		{
			Name:           "java",
			Extensions:     []string{".java"},
			Keywords:       []string{"public", "private", "protected", "static", "final", "abstract", "class", "interface", "extends", "implements", "package", "import", "if", "else", "for", "while", "do", "switch", "case", "default", "try", "catch", "finally", "throw", "throws"},
			PackageManager: "maven",
			TestFrameworks: []string{"junit", "testng", "mockito"},
			Linters:        []string{"checkstyle", "pmd", "spotbugs"},
			Formatters:     []string{"google-java-format"},
			Frameworks:     []string{"spring", "hibernate", "struts"},
		},
		{
			Name:           "kotlin",
			Extensions:     []string{".kt", ".kts"},
			Keywords:       []string{"fun", "val", "var", "class", "object", "interface", "when", "is", "in", "out", "override", "open", "final", "abstract", "sealed", "data", "inner", "companion"},
			PackageManager: "gradle",
			TestFrameworks: []string{"junit", "kotest", "spek"},
			Linters:        []string{"ktlint", "detekt"},
			Formatters:     []string{"ktlint"},
			Frameworks:     []string{"spring", "ktor", "android"},
		},
		{
			Name:           "scala",
			Extensions:     []string{".scala"},
			Keywords:       []string{"def", "val", "var", "class", "object", "trait", "case", "match", "if", "else", "for", "while", "do", "try", "catch", "finally", "throw", "import", "package"},
			PackageManager: "sbt",
			TestFrameworks: []string{"scalatest", "specs2", "utest"},
			Linters:        []string{"scalastyle", "scalafix"},
			Formatters:     []string{"scalafmt"},
			Frameworks:     []string{"akka", "play", "spark"},
		},
		// .NET Languages
		{
			Name:           "csharp",
			Extensions:     []string{".cs"},
			Keywords:       []string{"public", "private", "protected", "internal", "static", "readonly", "const", "class", "struct", "interface", "enum", "namespace", "using", "if", "else", "for", "foreach", "while", "do", "switch", "case", "default", "try", "catch", "finally", "throw"},
			PackageManager: "nuget",
			TestFrameworks: []string{"nunit", "xunit", "mstest"},
			Linters:        []string{"stylecop", "roslynator"},
			Formatters:     []string{"dotnet format"},
			Frameworks:     []string{"asp.net", "entity framework", "xamarin"},
		},
		{
			Name:           "fsharp",
			Extensions:     []string{".fs", ".fsx"},
			Keywords:       []string{"let", "and", "rec", "type", "module", "namespace", "open", "if", "then", "else", "elif", "match", "with", "function", "fun", "try", "finally", "exception"},
			PackageManager: "nuget",
			TestFrameworks: []string{"nunit", "xunit", "expecto"},
			Linters:        []string{"fantomas"},
			Formatters:     []string{"fantomas"},
		},
		// Functional Languages
		{
			Name:           "haskell",
			Extensions:     []string{".hs", ".lhs"},
			Keywords:       []string{"data", "type", "newtype", "class", "instance", "where", "let", "in", "case", "of", "if", "then", "else", "do", "import", "module", "qualified", "as"},
			PackageManager: "cabal",
			TestFrameworks: []string{"hspec", "quickcheck", "tasty"},
			Linters:        []string{"hlint"},
			Formatters:     []string{"brittany", "ormolu"},
		},
		{
			Name:           "erlang",
			Extensions:     []string{".erl", ".hrl"},
			Keywords:       []string{"module", "export", "import", "if", "case", "of", "when", "andalso", "orelse", "not", "div", "rem", "band", "bor", "bxor", "bnot", "bsl", "bsr"},
			PackageManager: "rebar3",
			TestFrameworks: []string{"eunit", "common_test", "proper"},
		},
		{
			Name:           "elixir",
			Extensions:     []string{".ex", ".exs"},
			Keywords:       []string{"def", "defp", "defmodule", "defstruct", "defprotocol", "defimpl", "if", "unless", "case", "cond", "with", "for", "try", "rescue", "catch", "after", "raise", "throw"},
			PackageManager: "mix",
			TestFrameworks: []string{"exunit", "bypass", "mock"},
			Linters:        []string{"credo", "dialyzer"},
			Formatters:     []string{"mix format"},
			Frameworks:     []string{"phoenix", "nerves", "broadway"},
		},
		// Scripting Languages
		{
			Name:           "ruby",
			Extensions:     []string{".rb", ".rbw"},
			Keywords:       []string{"def", "class", "module", "if", "unless", "else", "elsif", "case", "when", "for", "while", "until", "do", "end", "begin", "rescue", "ensure", "return", "yield", "break", "next"},
			PackageManager: "gem",
			TestFrameworks: []string{"rspec", "minitest", "cucumber"},
			Linters:        []string{"rubocop", "reek"},
			Formatters:     []string{"rubocop"},
			Frameworks:     []string{"rails", "sinatra", "hanami"},
		},
		{
			Name:           "php",
			Extensions:     []string{".php", ".phtml"},
			Keywords:       []string{"class", "interface", "trait", "extends", "implements", "public", "private", "protected", "static", "final", "abstract", "if", "else", "elseif", "switch", "case", "default", "for", "foreach", "while", "do", "try", "catch", "finally", "throw"},
			PackageManager: "composer",
			TestFrameworks: []string{"phpunit", "codeception", "behat"},
			Linters:        []string{"phpcs", "phpstan", "psalm"},
			Formatters:     []string{"php-cs-fixer"},
			Frameworks:     []string{"laravel", "symfony", "codeigniter"},
		},
		{
			Name:           "perl",
			Extensions:     []string{".pl", ".pm"},
			Keywords:       []string{"sub", "package", "use", "require", "if", "unless", "else", "elsif", "for", "foreach", "while", "until", "do", "given", "when", "default", "last", "next", "redo", "return"},
			PackageManager: "cpan",
			TestFrameworks: []string{"test::more", "test::simple", "prove"},
		},
		// Mobile Development
		{
			Name:           "swift",
			Extensions:     []string{".swift"},
			Keywords:       []string{"func", "var", "let", "class", "struct", "enum", "protocol", "extension", "if", "else", "guard", "switch", "case", "default", "for", "while", "repeat", "do", "try", "catch", "throw", "throws"},
			PackageManager: "swift package manager",
			TestFrameworks: []string{"xctest", "quick", "nimble"},
			Linters:        []string{"swiftlint"},
			Formatters:     []string{"swiftformat"},
			Frameworks:     []string{"uikit", "swiftui", "combine"},
		},
		{
			Name:           "dart",
			Extensions:     []string{".dart"},
			Keywords:       []string{"class", "abstract", "interface", "mixin", "enum", "typedef", "var", "final", "const", "static", "if", "else", "for", "while", "do", "switch", "case", "default", "try", "catch", "finally", "throw", "rethrow", "async", "await"},
			PackageManager: "pub",
			TestFrameworks: []string{"test", "flutter_test", "mockito"},
			Linters:        []string{"dartanalyzer", "pedantic"},
			Formatters:     []string{"dartfmt"},
			Frameworks:     []string{"flutter", "aqueduct", "angel"},
		},
		// Database Languages
		{
			Name:           "sql",
			Extensions:     []string{".sql"},
			Keywords:       []string{"SELECT", "FROM", "WHERE", "JOIN", "INNER", "LEFT", "RIGHT", "FULL", "ON", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE", "CREATE", "TABLE", "ALTER", "DROP", "INDEX"},
			PackageManager: "",
			TestFrameworks: []string{"tSQLt", "pgTAP"},
		},
		// Configuration Languages
		{
			Name:           "yaml",
			Extensions:     []string{".yaml", ".yml"},
			Keywords:       []string{},
			PackageManager: "",
			TestFrameworks: []string{},
		},
		{
			Name:           "json",
			Extensions:     []string{".json"},
			Keywords:       []string{},
			PackageManager: "",
			TestFrameworks: []string{},
		},
	}

	for _, lang := range languages {
		m.languages[lang.Name] = lang
	}
}

// initializeTranslators initializes translators for language pairs
func (m *Manager) initializeTranslators() {
	// Create translators for common language pairs
	commonPairs := [][]string{
		{"python", "go"},
		{"javascript", "typescript"},
		{"java", "kotlin"},
		{"c", "cpp"},
		{"python", "java"},
		{"go", "rust"},
		{"javascript", "python"},
		{"typescript", "go"},
	}

	for _, pair := range commonPairs {
		from, to := pair[0], pair[1]
		key := fmt.Sprintf("%s-%s", from, to)
		m.translators[key] = &Translator{
			FromLanguage: from,
			ToLanguage:   to,
			ai:           m.ai,
			logger:       m.logger,
		}
		
		// Also create reverse translator
		reverseKey := fmt.Sprintf("%s-%s", to, from)
		m.translators[reverseKey] = &Translator{
			FromLanguage: to,
			ToLanguage:   from,
			ai:           m.ai,
			logger:       m.logger,
		}
	}
}

// initializeParsers initializes parsers for each language
func (m *Manager) initializeParsers() {
	for langName := range m.languages {
		m.parsers[langName] = &Parser{
			Language: langName,
			logger:   m.logger,
		}
	}
}

// GetSupportedLanguages returns all supported languages
func (m *Manager) GetSupportedLanguages() []*Language {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	languages := make([]*Language, 0, len(m.languages))
	for _, lang := range m.languages {
		languages = append(languages, lang)
	}
	return languages
}

// DetectLanguage detects the programming language from file extension or content
func (m *Manager) DetectLanguage(filename string, content string) string {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	// First try by file extension
	ext := strings.ToLower(filepath.Ext(filename))
	for name, lang := range m.languages {
		for _, langExt := range lang.Extensions {
			if ext == langExt {
				return name
			}
		}
	}

	// If no extension match, try to detect by content
	return m.detectByContent(content)
}

// detectByContent detects language by analyzing code content
func (m *Manager) detectByContent(content string) string {
	content = strings.ToLower(content)
	
	// Simple heuristics for language detection
	patterns := map[string][]string{
		"python":     {"def ", "import ", "from ", "class ", "if __name__"},
		"go":         {"package ", "func ", "import ", "type ", "var "},
		"javascript": {"function", "var ", "let ", "const ", "console.log"},
		"java":       {"public class", "public static", "import java", "System.out"},
		"cpp":        {"#include", "using namespace", "std::", "cout"},
		"c":          {"#include", "int main", "printf", "malloc"},
		"rust":       {"fn ", "let ", "use ", "struct ", "impl "},
		"ruby":       {"def ", "class ", "require ", "puts ", "end"},
		"php":        {"<?php", "function ", "class ", "echo ", "$"},
		"csharp":     {"using System", "public class", "Console.WriteLine", "namespace"},
	}

	maxScore := 0
	detectedLang := "text"
	
	for lang, keywords := range patterns {
		score := 0
		for _, keyword := range keywords {
			if strings.Contains(content, keyword) {
				score++
			}
		}
		if score > maxScore {
			maxScore = score
			detectedLang = lang
		}
	}

	return detectedLang
}

// TranslateCode translates code from one language to another
func (m *Manager) TranslateCode(ctx context.Context, request *TranslationRequest) (*TranslationResult, error) {
	m.logger.Info("Translating code", 
		"from", request.FromLanguage, 
		"to", request.ToLanguage,
		"lines", strings.Count(request.Code, "\n")+1)

	// Get translator
	translatorKey := fmt.Sprintf("%s-%s", request.FromLanguage, request.ToLanguage)
	translator, exists := m.translators[translatorKey]
	if !exists {
		// Create on-demand translator
		translator = &Translator{
			FromLanguage: request.FromLanguage,
			ToLanguage:   request.ToLanguage,
			ai:           m.ai,
			logger:       m.logger,
		}
		m.mutex.Lock()
		m.translators[translatorKey] = translator
		m.mutex.Unlock()
	}

	// Perform translation
	result, err := translator.Translate(ctx, request)
	if err != nil {
		return nil, fmt.Errorf("translation failed: %w", err)
	}

	return result, nil
}

// GetLanguageInfo returns information about a specific language
func (m *Manager) GetLanguageInfo(languageName string) (*Language, error) {
	m.mutex.RLock()
	defer m.mutex.RUnlock()

	lang, exists := m.languages[languageName]
	if !exists {
		return nil, fmt.Errorf("language not supported: %s", languageName)
	}

	return lang, nil
}

// Translate performs the actual code translation
func (t *Translator) Translate(ctx context.Context, request *TranslationRequest) (*TranslationResult, error) {
	prompt := t.buildTranslationPrompt(request)

	response, err := t.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: []*ai.Message{
			{Role: "user", Content: prompt},
		},
		Temperature: 0.3,
		MaxTokens:   4000,
	})

	if err != nil {
		return nil, fmt.Errorf("AI translation failed: %w", err)
	}

	// Parse the response
	result := &TranslationResult{
		FromLanguage: request.FromLanguage,
		ToLanguage:   request.ToLanguage,
		Changes:      []*TranslationChange{},
		Warnings:     []string{},
		Suggestions:  []string{},
		Metadata:     make(map[string]interface{}),
	}

	// Extract translated code from response
	result.TranslatedCode = t.extractTranslatedCode(response)
	result.Changes = t.extractChanges(response)
	result.Warnings = t.extractWarnings(response)
	result.Suggestions = t.extractSuggestions(response)

	return result, nil
}

// buildTranslationPrompt builds the prompt for code translation
func (t *Translator) buildTranslationPrompt(request *TranslationRequest) string {
	prompt := fmt.Sprintf(`Translate the following %s code to %s:

Original %s code:
```%s
%s
```

Requirements:
- Maintain the same functionality and logic
- Follow %s best practices and conventions
- Preserve code structure where possible
- Add appropriate error handling for %s
- Include necessary imports/dependencies
- Add comments explaining any significant changes

Please provide:
1. The translated code
2. List of major changes made
3. Any warnings or considerations
4. Suggestions for improvements

Translated %s code:`,
		request.FromLanguage, request.ToLanguage,
		request.FromLanguage, request.FromLanguage, request.Code,
		request.ToLanguage, request.ToLanguage, request.ToLanguage)

	if request.Options != nil {
		if request.Options.PreserveComments {
			prompt += "\n- Preserve all comments from the original code"
		}
		if request.Options.AddDocumentation {
			prompt += "\n- Add comprehensive documentation"
		}
		if request.Options.OptimizeCode {
			prompt += "\n- Optimize the code for performance"
		}
		if request.Options.TargetFramework != "" {
			prompt += fmt.Sprintf("\n- Target framework: %s", request.Options.TargetFramework)
		}
	}

	return prompt
}

// extractTranslatedCode extracts the translated code from AI response
func (t *Translator) extractTranslatedCode(response string) string {
	// Look for code blocks in the response
	codeBlockRegex := regexp.MustCompile("```[a-zA-Z]*\n(.*?)\n```")
	matches := codeBlockRegex.FindStringSubmatch(response)
	
	if len(matches) > 1 {
		return strings.TrimSpace(matches[1])
	}

	// If no code block found, try to extract from the response
	lines := strings.Split(response, "\n")
	var codeLines []string
	inCode := false

	for _, line := range lines {
		if strings.Contains(strings.ToLower(line), "translated") && strings.Contains(line, ":") {
			inCode = true
			continue
		}
		if inCode && (strings.HasPrefix(line, "Changes:") || strings.HasPrefix(line, "Warnings:")) {
			break
		}
		if inCode {
			codeLines = append(codeLines, line)
		}
	}

	return strings.TrimSpace(strings.Join(codeLines, "\n"))
}

// extractChanges extracts changes from AI response
func (t *Translator) extractChanges(response string) []*TranslationChange {
	changes := []*TranslationChange{}
	
	// Simple extraction - in practice, this would be more sophisticated
	if strings.Contains(response, "Changes:") || strings.Contains(response, "changes:") {
		changes = append(changes, &TranslationChange{
			Type:        "translation",
			Description: "Code translated between languages",
			Reason:      "Language syntax differences",
		})
	}

	return changes
}

// extractWarnings extracts warnings from AI response
func (t *Translator) extractWarnings(response string) []string {
	warnings := []string{}
	
	// Look for warning indicators
	if strings.Contains(strings.ToLower(response), "warning") {
		warnings = append(warnings, "Please review the translated code for accuracy")
	}
	
	return warnings
}

// extractSuggestions extracts suggestions from AI response
func (t *Translator) extractSuggestions(response string) []string {
	suggestions := []string{}
	
	// Look for suggestion indicators
	if strings.Contains(strings.ToLower(response), "suggest") || strings.Contains(strings.ToLower(response), "recommend") {
		suggestions = append(suggestions, "Consider reviewing the translated code for optimization opportunities")
	}
	
	return suggestions
}
