package files

import (
	"go/ast"
	"go/parser"
	"go/token"
	"strings"

	"ai-coding-agent/internal/logger"
)

// registerParsers registers all language parsers
func (p *ASTParser) registerParsers() {
	// Register Go parser
	p.parsers["go"] = &GoParser{logger: p.logger}
	
	// Register Python parser (simplified)
	p.parsers["python"] = &PythonParser{logger: p.logger}
	
	// Register JavaScript parser (simplified)
	p.parsers["javascript"] = &JavaScriptParser{logger: p.logger}
	
	// Register TypeScript parser (simplified)
	p.parsers["typescript"] = &TypeScriptParser{logger: p.logger}
}

// GoParser implements parsing for Go files
type GoParser struct {
	logger logger.Logger
}

func (g *GoParser) GetLanguage() string {
	return "go"
}

func (g *GoParser) GetExtensions() []string {
	return []string{".go"}
}

func (g *GoParser) Parse(content []byte) (*ParseResult, error) {
	fset := token.NewFileSet()
	
	// Parse the Go source code
	file, err := parser.ParseFile(fset, "", content, parser.ParseComments)
	if err != nil {
		return &ParseResult{
			Errors: []ParseError{{Message: err.Error()}},
		}, err
	}

	result := &ParseResult{
		Functions: []*FunctionInfo{},
		Classes:   []*ClassInfo{},
		Imports:   []string{},
		Variables: []string{},
	}

	// Extract imports
	for _, imp := range file.Imports {
		path := strings.Trim(imp.Path.Value, `"`)
		result.Imports = append(result.Imports, path)
	}

	// Walk the AST to extract functions, types, etc.
	ast.Inspect(file, func(n ast.Node) bool {
		switch node := n.(type) {
		case *ast.FuncDecl:
			if node.Name != nil {
				funcInfo := &FunctionInfo{
					Name:      node.Name.Name,
					StartLine: fset.Position(node.Pos()).Line,
					EndLine:   fset.Position(node.End()).Line,
				}

				// Extract parameters
				if node.Type.Params != nil {
					for _, param := range node.Type.Params.List {
						for _, name := range param.Names {
							funcInfo.Parameters = append(funcInfo.Parameters, name.Name)
						}
					}
				}

				// Extract return type
				if node.Type.Results != nil && len(node.Type.Results.List) > 0 {
					// Simplified return type extraction
					funcInfo.ReturnType = "multiple" // Could be more specific
				}

				// Extract doc string
				if node.Doc != nil {
					funcInfo.DocString = node.Doc.Text()
				}

				result.Functions = append(result.Functions, funcInfo)
			}

		case *ast.TypeSpec:
			if node.Name != nil {
				// Handle struct types as classes
				if _, ok := node.Type.(*ast.StructType); ok {
					classInfo := &ClassInfo{
						Name:      node.Name.Name,
						StartLine: fset.Position(node.Pos()).Line,
						EndLine:   fset.Position(node.End()).Line,
						Methods:   []*FunctionInfo{},
						Fields:    []string{},
					}

					// Extract struct fields
					if structType, ok := node.Type.(*ast.StructType); ok {
						for _, field := range structType.Fields.List {
							for _, name := range field.Names {
								classInfo.Fields = append(classInfo.Fields, name.Name)
							}
						}
					}

					result.Classes = append(result.Classes, classInfo)
				}
			}

		case *ast.GenDecl:
			// Handle variable declarations
			if node.Tok == token.VAR {
				for _, spec := range node.Specs {
					if valueSpec, ok := spec.(*ast.ValueSpec); ok {
						for _, name := range valueSpec.Names {
							result.Variables = append(result.Variables, name.Name)
						}
					}
				}
			}
		}
		return true
	})

	// Calculate complexity (simplified)
	result.Complexity = g.calculateComplexity(file)

	return result, nil
}

func (g *GoParser) calculateComplexity(file *ast.File) int {
	complexity := 0
	
	ast.Inspect(file, func(n ast.Node) bool {
		switch n.(type) {
		case *ast.IfStmt, *ast.ForStmt, *ast.RangeStmt, *ast.SwitchStmt, *ast.TypeSwitchStmt:
			complexity++
		}
		return true
	})
	
	return complexity
}

// PythonParser implements parsing for Python files (simplified)
type PythonParser struct {
	logger logger.Logger
}

func (p *PythonParser) GetLanguage() string {
	return "python"
}

func (p *PythonParser) GetExtensions() []string {
	return []string{".py"}
}

func (p *PythonParser) Parse(content []byte) (*ParseResult, error) {
	// Simplified Python parsing using regex and string analysis
	// In a real implementation, you'd use a proper Python AST parser
	
	result := &ParseResult{
		Functions: []*FunctionInfo{},
		Classes:   []*ClassInfo{},
		Imports:   []string{},
		Variables: []string{},
	}

	lines := strings.Split(string(content), "\n")
	
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		
		// Extract imports
		if strings.HasPrefix(trimmed, "import ") {
			module := strings.TrimSpace(strings.TrimPrefix(trimmed, "import "))
			result.Imports = append(result.Imports, module)
		} else if strings.HasPrefix(trimmed, "from ") && strings.Contains(trimmed, " import ") {
			parts := strings.Split(trimmed, " import ")
			if len(parts) > 0 {
				module := strings.TrimSpace(strings.TrimPrefix(parts[0], "from "))
				result.Imports = append(result.Imports, module)
			}
		}
		
		// Extract function definitions
		if strings.HasPrefix(trimmed, "def ") {
			funcName := p.extractPythonFunctionName(trimmed)
			if funcName != "" {
				funcInfo := &FunctionInfo{
					Name:      funcName,
					StartLine: i + 1,
					EndLine:   p.findPythonBlockEnd(lines, i),
				}
				
				// Extract docstring
				if i+1 < len(lines) {
					nextLine := strings.TrimSpace(lines[i+1])
					if strings.HasPrefix(nextLine, `"""`) || strings.HasPrefix(nextLine, `'''`) {
						funcInfo.DocString = p.extractPythonDocstring(lines, i+1)
					}
				}
				
				result.Functions = append(result.Functions, funcInfo)
			}
		}
		
		// Extract class definitions
		if strings.HasPrefix(trimmed, "class ") {
			className := p.extractPythonClassName(trimmed)
			if className != "" {
				classInfo := &ClassInfo{
					Name:      className,
					StartLine: i + 1,
					EndLine:   p.findPythonBlockEnd(lines, i),
					Methods:   []*FunctionInfo{},
					Fields:    []string{},
				}
				
				result.Classes = append(result.Classes, classInfo)
			}
		}
	}
	
	// Calculate complexity
	result.Complexity = p.calculatePythonComplexity(string(content))
	
	return result, nil
}

func (p *PythonParser) extractPythonFunctionName(line string) string {
	// Extract function name from "def function_name(params):"
	if !strings.HasPrefix(strings.TrimSpace(line), "def ") {
		return ""
	}
	
	start := strings.Index(line, "def ") + 4
	end := strings.Index(line[start:], "(")
	if end == -1 {
		return ""
	}
	
	return strings.TrimSpace(line[start : start+end])
}

func (p *PythonParser) extractPythonClassName(line string) string {
	// Extract class name from "class ClassName(BaseClass):"
	if !strings.HasPrefix(strings.TrimSpace(line), "class ") {
		return ""
	}
	
	start := strings.Index(line, "class ") + 6
	end := strings.IndexAny(line[start:], "(:")
	if end == -1 {
		end = len(line) - start
	}
	
	return strings.TrimSpace(line[start : start+end])
}

func (p *PythonParser) findPythonBlockEnd(lines []string, start int) int {
	// Find the end of a Python block based on indentation
	if start >= len(lines) {
		return start
	}
	
	baseIndent := len(lines[start]) - len(strings.TrimLeft(lines[start], " \t"))
	
	for i := start + 1; i < len(lines); i++ {
		line := lines[i]
		if strings.TrimSpace(line) == "" {
			continue // Skip empty lines
		}
		
		indent := len(line) - len(strings.TrimLeft(line, " \t"))
		if indent <= baseIndent {
			return i
		}
	}
	
	return len(lines)
}

func (p *PythonParser) extractPythonDocstring(lines []string, start int) string {
	// Extract Python docstring
	if start >= len(lines) {
		return ""
	}
	
	line := strings.TrimSpace(lines[start])
	quote := ""
	if strings.HasPrefix(line, `"""`) {
		quote = `"""`
	} else if strings.HasPrefix(line, `'''`) {
		quote = `'''`
	} else {
		return ""
	}
	
	// Single line docstring
	if strings.HasSuffix(line, quote) && len(line) > len(quote)*2 {
		return strings.Trim(line, quote)
	}
	
	// Multi-line docstring
	var docstring strings.Builder
	docstring.WriteString(strings.TrimPrefix(line, quote))
	
	for i := start + 1; i < len(lines); i++ {
		line := lines[i]
		if strings.Contains(line, quote) {
			docstring.WriteString(strings.Split(line, quote)[0])
			break
		}
		docstring.WriteString("\n" + line)
	}
	
	return docstring.String()
}

func (p *PythonParser) calculatePythonComplexity(content string) int {
	complexity := 0
	keywords := []string{"if", "elif", "for", "while", "try", "except", "with"}
	
	for _, keyword := range keywords {
		complexity += strings.Count(content, keyword+" ")
	}
	
	return complexity
}

// JavaScriptParser implements parsing for JavaScript files (simplified)
type JavaScriptParser struct {
	logger logger.Logger
}

func (j *JavaScriptParser) GetLanguage() string {
	return "javascript"
}

func (j *JavaScriptParser) GetExtensions() []string {
	return []string{".js", ".jsx"}
}

func (j *JavaScriptParser) Parse(content []byte) (*ParseResult, error) {
	// Simplified JavaScript parsing
	// In a real implementation, you'd use a proper JavaScript AST parser like Babel
	
	result := &ParseResult{
		Functions: []*FunctionInfo{},
		Classes:   []*ClassInfo{},
		Imports:   []string{},
		Variables: []string{},
	}

	lines := strings.Split(string(content), "\n")
	
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		
		// Extract imports
		if strings.HasPrefix(trimmed, "import ") {
			result.Imports = append(result.Imports, trimmed)
		} else if strings.HasPrefix(trimmed, "const ") && strings.Contains(trimmed, "require(") {
			result.Imports = append(result.Imports, trimmed)
		}
		
		// Extract function declarations
		if strings.Contains(trimmed, "function ") {
			funcName := j.extractJSFunctionName(trimmed)
			if funcName != "" {
				funcInfo := &FunctionInfo{
					Name:      funcName,
					StartLine: i + 1,
					EndLine:   j.findJSBlockEnd(lines, i),
				}
				result.Functions = append(result.Functions, funcInfo)
			}
		}
		
		// Extract arrow functions
		if strings.Contains(trimmed, " => ") {
			funcName := j.extractJSArrowFunctionName(trimmed)
			if funcName != "" {
				funcInfo := &FunctionInfo{
					Name:      funcName,
					StartLine: i + 1,
					EndLine:   i + 1, // Arrow functions are usually single line
				}
				result.Functions = append(result.Functions, funcInfo)
			}
		}
		
		// Extract class declarations
		if strings.HasPrefix(trimmed, "class ") {
			className := j.extractJSClassName(trimmed)
			if className != "" {
				classInfo := &ClassInfo{
					Name:      className,
					StartLine: i + 1,
					EndLine:   j.findJSBlockEnd(lines, i),
					Methods:   []*FunctionInfo{},
					Fields:    []string{},
				}
				result.Classes = append(result.Classes, classInfo)
			}
		}
	}
	
	// Calculate complexity
	result.Complexity = j.calculateJSComplexity(string(content))
	
	return result, nil
}

func (j *JavaScriptParser) extractJSFunctionName(line string) string {
	// Extract function name from various JavaScript function declarations
	if strings.Contains(line, "function ") {
		start := strings.Index(line, "function ") + 9
		end := strings.Index(line[start:], "(")
		if end == -1 {
			return ""
		}
		return strings.TrimSpace(line[start : start+end])
	}
	return ""
}

func (j *JavaScriptParser) extractJSArrowFunctionName(line string) string {
	// Extract function name from arrow function declarations
	if strings.Contains(line, " => ") {
		parts := strings.Split(line, "=")
		if len(parts) > 0 {
			name := strings.TrimSpace(parts[0])
			// Remove 'const', 'let', 'var' keywords
			name = strings.TrimPrefix(name, "const ")
			name = strings.TrimPrefix(name, "let ")
			name = strings.TrimPrefix(name, "var ")
			return strings.TrimSpace(name)
		}
	}
	return ""
}

func (j *JavaScriptParser) extractJSClassName(line string) string {
	// Extract class name from "class ClassName extends BaseClass {"
	if !strings.HasPrefix(strings.TrimSpace(line), "class ") {
		return ""
	}
	
	start := strings.Index(line, "class ") + 6
	end := strings.IndexAny(line[start:], " {")
	if end == -1 {
		end = len(line) - start
	}
	
	return strings.TrimSpace(line[start : start+end])
}

func (j *JavaScriptParser) findJSBlockEnd(lines []string, start int) int {
	// Find the end of a JavaScript block based on braces
	if start >= len(lines) {
		return start
	}
	
	braceCount := 0
	for i := start; i < len(lines); i++ {
		line := lines[i]
		braceCount += strings.Count(line, "{")
		braceCount -= strings.Count(line, "}")
		
		if braceCount == 0 && i > start {
			return i + 1
		}
	}
	
	return len(lines)
}

func (j *JavaScriptParser) calculateJSComplexity(content string) int {
	complexity := 0
	keywords := []string{"if", "else", "for", "while", "switch", "case", "try", "catch"}
	
	for _, keyword := range keywords {
		complexity += strings.Count(content, keyword+" ")
		complexity += strings.Count(content, keyword+"(")
	}
	
	return complexity
}

// TypeScriptParser implements parsing for TypeScript files (simplified)
type TypeScriptParser struct {
	logger logger.Logger
}

func (t *TypeScriptParser) GetLanguage() string {
	return "typescript"
}

func (t *TypeScriptParser) GetExtensions() []string {
	return []string{".ts", ".tsx"}
}

func (t *TypeScriptParser) Parse(content []byte) (*ParseResult, error) {
	// TypeScript parsing is similar to JavaScript but with type annotations
	// For simplicity, we'll reuse the JavaScript parser and extend it
	
	jsParser := &JavaScriptParser{logger: t.logger}
	result, err := jsParser.Parse(content)
	
	// Add TypeScript-specific parsing here
	// For now, we'll just return the JavaScript parsing result
	
	return result, err
}
