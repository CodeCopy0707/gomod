package files

import (
	"context"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/cache"

	"github.com/fsnotify/fsnotify"
	"github.com/sahilm/fuzzy"
)

// Manager handles advanced file operations
type Manager struct {
	logger    logger.Logger
	cache     cache.Cache
	watcher   *fsnotify.Watcher
	index     *FileIndex
	searcher  *Searcher
	parser    *ASTParser
	mutex     sync.RWMutex
	watchDirs map[string]bool
}

// FileIndex maintains an index of all files in the project
type FileIndex struct {
	files     map[string]*FileInfo
	languages map[string][]*FileInfo
	mutex     sync.RWMutex
	lastScan  time.Time
}

// FileInfo contains metadata about a file
type FileInfo struct {
	Path         string
	Name         string
	Extension    string
	Language     string
	Size         int64
	ModTime      time.Time
	Checksum     string
	Functions    []*FunctionInfo
	Classes      []*ClassInfo
	Imports      []string
	Dependencies []string
	Complexity   int
	Lines        int
}

// FunctionInfo contains information about a function
type FunctionInfo struct {
	Name       string
	StartLine  int
	EndLine    int
	Parameters []string
	ReturnType string
	Complexity int
	DocString  string
}

// ClassInfo contains information about a class
type ClassInfo struct {
	Name      string
	StartLine int
	EndLine   int
	Methods   []*FunctionInfo
	Fields    []string
	DocString string
}

// Searcher provides advanced search capabilities
type Searcher struct {
	patterns map[string]*regexp.Regexp
	cache    cache.Cache
	logger   logger.Logger
}

// SearchRequest represents a search request
type SearchRequest struct {
	Query       string
	Path        string
	Language    string
	Type        SearchType
	CaseSensitive bool
	Regex       bool
	MaxResults  int
	Context     int // Lines of context around matches
}

// SearchType defines the type of search
type SearchType string

const (
	SearchTypeContent   SearchType = "content"
	SearchTypeFunction  SearchType = "function"
	SearchTypeClass     SearchType = "class"
	SearchTypeVariable  SearchType = "variable"
	SearchTypeImport    SearchType = "import"
	SearchTypeFilename  SearchType = "filename"
)

// SearchResult represents a search result
type SearchResult struct {
	File      *FileInfo
	Line      int
	Column    int
	Match     string
	Context   []string
	Type      SearchType
	Relevance float64
}

// ASTParser provides AST parsing capabilities
type ASTParser struct {
	parsers map[string]LanguageParser
	logger  logger.Logger
}

// LanguageParser interface for language-specific parsers
type LanguageParser interface {
	Parse(content []byte) (*ParseResult, error)
	GetLanguage() string
	GetExtensions() []string
}

// ParseResult contains the result of parsing a file
type ParseResult struct {
	Functions    []*FunctionInfo
	Classes      []*ClassInfo
	Imports      []string
	Variables    []string
	Complexity   int
	Errors       []ParseError
}

// ParseError represents a parsing error
type ParseError struct {
	Line    int
	Column  int
	Message string
}

// NewManager creates a new file manager
func NewManager(logger logger.Logger, cache cache.Cache) (*Manager, error) {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		return nil, fmt.Errorf("failed to create file watcher: %w", err)
	}

	manager := &Manager{
		logger:    logger,
		cache:     cache,
		watcher:   watcher,
		index:     NewFileIndex(),
		searcher:  NewSearcher(cache, logger),
		parser:    NewASTParser(logger),
		watchDirs: make(map[string]bool),
	}

	// Start file watcher
	go manager.watchFiles()

	return manager, nil
}

// NewFileIndex creates a new file index
func NewFileIndex() *FileIndex {
	return &FileIndex{
		files:     make(map[string]*FileInfo),
		languages: make(map[string][]*FileInfo),
	}
}

// NewSearcher creates a new searcher
func NewSearcher(cache cache.Cache, logger logger.Logger) *Searcher {
	return &Searcher{
		patterns: make(map[string]*regexp.Regexp),
		cache:    cache,
		logger:   logger,
	}
}

// NewASTParser creates a new AST parser
func NewASTParser(logger logger.Logger) *ASTParser {
	parser := &ASTParser{
		parsers: make(map[string]LanguageParser),
		logger:  logger,
	}

	// Register language parsers
	parser.registerParsers()

	return parser
}

// IndexDirectory indexes all files in a directory
func (m *Manager) IndexDirectory(path string) error {
	m.logger.Info("Indexing directory", "path", path)
	
	start := time.Now()
	fileCount := 0

	err := filepath.WalkDir(path, func(filePath string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// Skip hidden files and directories
		if strings.HasPrefix(d.Name(), ".") {
			if d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		// Skip excluded directories
		if d.IsDir() && m.isExcludedDirectory(d.Name()) {
			return filepath.SkipDir
		}

		if !d.IsDir() {
			if err := m.indexFile(filePath); err != nil {
				m.logger.Warn("Failed to index file", "path", filePath, "error", err)
			} else {
				fileCount++
			}
		}

		return nil
	})

	if err != nil {
		return fmt.Errorf("failed to walk directory: %w", err)
	}

	// Add directory to watcher
	if err := m.addWatchDir(path); err != nil {
		m.logger.Warn("Failed to add directory to watcher", "path", path, "error", err)
	}

	duration := time.Since(start)
	m.logger.Info("Directory indexing completed", 
		"path", path, 
		"files", fileCount, 
		"duration", duration)

	m.index.lastScan = time.Now()
	return nil
}

// indexFile indexes a single file
func (m *Manager) indexFile(path string) error {
	info, err := os.Stat(path)
	if err != nil {
		return err
	}

	// Skip large files
	if info.Size() > 10*1024*1024 { // 10MB
		return nil
	}

	// Read file content
	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	// Detect language
	language := m.detectLanguage(path, content)

	// Parse file if supported
	var parseResult *ParseResult
	if parser, exists := m.parser.parsers[language]; exists {
		parseResult, err = parser.Parse(content)
		if err != nil {
			m.logger.Warn("Failed to parse file", "path", path, "error", err)
		}
	}

	// Create file info
	fileInfo := &FileInfo{
		Path:      path,
		Name:      filepath.Base(path),
		Extension: filepath.Ext(path),
		Language:  language,
		Size:      info.Size(),
		ModTime:   info.ModTime(),
		Checksum:  calculateChecksum(content),
		Lines:     strings.Count(string(content), "\n") + 1,
	}

	if parseResult != nil {
		fileInfo.Functions = parseResult.Functions
		fileInfo.Classes = parseResult.Classes
		fileInfo.Imports = parseResult.Imports
		fileInfo.Complexity = parseResult.Complexity
	}

	// Add to index
	m.index.mutex.Lock()
	m.index.files[path] = fileInfo
	m.index.languages[language] = append(m.index.languages[language], fileInfo)
	m.index.mutex.Unlock()

	return nil
}

// Search performs advanced search across files
func (m *Manager) Search(ctx context.Context, req *SearchRequest) ([]*SearchResult, error) {
	m.logger.Info("Performing search", "query", req.Query, "type", req.Type)

	var results []*SearchResult

	switch req.Type {
	case SearchTypeContent:
		results = m.searcher.searchContent(ctx, req, m.index)
	case SearchTypeFunction:
		results = m.searcher.searchFunctions(ctx, req, m.index)
	case SearchTypeClass:
		results = m.searcher.searchClasses(ctx, req, m.index)
	case SearchTypeFilename:
		results = m.searcher.searchFilenames(ctx, req, m.index)
	default:
		results = m.searcher.searchAll(ctx, req, m.index)
	}

	// Sort by relevance
	m.sortResultsByRelevance(results)

	// Limit results
	if req.MaxResults > 0 && len(results) > req.MaxResults {
		results = results[:req.MaxResults]
	}

	m.logger.Info("Search completed", "query", req.Query, "results", len(results))
	return results, nil
}

// FuzzySearch performs fuzzy search for files
func (m *Manager) FuzzySearch(query string, maxResults int) ([]*FileInfo, error) {
	m.index.mutex.RLock()
	defer m.index.mutex.RUnlock()

	// Prepare file list for fuzzy search
	var files []string
	fileMap := make(map[string]*FileInfo)

	for path, info := range m.index.files {
		files = append(files, info.Name)
		fileMap[info.Name] = info
	}

	// Perform fuzzy search
	matches := fuzzy.Find(query, files)

	// Convert to FileInfo slice
	var results []*FileInfo
	for i, match := range matches {
		if maxResults > 0 && i >= maxResults {
			break
		}
		if info, exists := fileMap[match.Str]; exists {
			results = append(results, info)
		}
	}

	return results, nil
}

// GetFileInfo returns information about a file
func (m *Manager) GetFileInfo(path string) (*FileInfo, error) {
	m.index.mutex.RLock()
	defer m.index.mutex.RUnlock()

	if info, exists := m.index.files[path]; exists {
		return info, nil
	}

	return nil, fmt.Errorf("file not found in index: %s", path)
}

// GetFilesByLanguage returns all files for a specific language
func (m *Manager) GetFilesByLanguage(language string) []*FileInfo {
	m.index.mutex.RLock()
	defer m.index.mutex.RUnlock()

	return m.index.languages[language]
}

// watchFiles watches for file system changes
func (m *Manager) watchFiles() {
	for {
		select {
		case event, ok := <-m.watcher.Events:
			if !ok {
				return
			}
			m.handleFileEvent(event)

		case err, ok := <-m.watcher.Errors:
			if !ok {
				return
			}
			m.logger.Error("File watcher error", "error", err)
		}
	}
}

// handleFileEvent handles file system events
func (m *Manager) handleFileEvent(event fsnotify.Event) {
	switch {
	case event.Op&fsnotify.Create == fsnotify.Create:
		m.logger.Debug("File created", "path", event.Name)
		if err := m.indexFile(event.Name); err != nil {
			m.logger.Warn("Failed to index new file", "path", event.Name, "error", err)
		}

	case event.Op&fsnotify.Write == fsnotify.Write:
		m.logger.Debug("File modified", "path", event.Name)
		if err := m.indexFile(event.Name); err != nil {
			m.logger.Warn("Failed to reindex modified file", "path", event.Name, "error", err)
		}

	case event.Op&fsnotify.Remove == fsnotify.Remove:
		m.logger.Debug("File removed", "path", event.Name)
		m.removeFromIndex(event.Name)

	case event.Op&fsnotify.Rename == fsnotify.Rename:
		m.logger.Debug("File renamed", "path", event.Name)
		m.removeFromIndex(event.Name)
	}
}

// addWatchDir adds a directory to the file watcher
func (m *Manager) addWatchDir(path string) error {
	if m.watchDirs[path] {
		return nil
	}

	if err := m.watcher.Add(path); err != nil {
		return err
	}

	m.watchDirs[path] = true
	return nil
}

// removeFromIndex removes a file from the index
func (m *Manager) removeFromIndex(path string) {
	m.index.mutex.Lock()
	defer m.index.mutex.Unlock()

	if info, exists := m.index.files[path]; exists {
		delete(m.index.files, path)

		// Remove from language index
		if langFiles, exists := m.index.languages[info.Language]; exists {
			for i, file := range langFiles {
				if file.Path == path {
					m.index.languages[info.Language] = append(langFiles[:i], langFiles[i+1:]...)
					break
				}
			}
		}
	}
}

// detectLanguage detects the programming language of a file
func (m *Manager) detectLanguage(path string, content []byte) string {
	ext := strings.ToLower(filepath.Ext(path))
	
	// Language detection by extension
	languageMap := map[string]string{
		".go":   "go",
		".py":   "python",
		".js":   "javascript",
		".ts":   "typescript",
		".java": "java",
		".cpp":  "cpp",
		".c":    "c",
		".h":    "c",
		".hpp":  "cpp",
		".rs":   "rust",
		".rb":   "ruby",
		".php":  "php",
		".cs":   "csharp",
		".kt":   "kotlin",
		".swift": "swift",
		".scala": "scala",
		".hs":   "haskell",
		".lua":  "lua",
		".r":    "r",
		".sql":  "sql",
		".sh":   "bash",
		".ps1":  "powershell",
		".yaml": "yaml",
		".yml":  "yaml",
		".json": "json",
		".xml":  "xml",
		".html": "html",
		".css":  "css",
		".md":   "markdown",
		".txt":  "text",
	}

	if lang, exists := languageMap[ext]; exists {
		return lang
	}

	// Content-based detection for files without extensions
	contentStr := string(content)
	if strings.Contains(contentStr, "#!/bin/bash") || strings.Contains(contentStr, "#!/bin/sh") {
		return "bash"
	}
	if strings.Contains(contentStr, "#!/usr/bin/env python") {
		return "python"
	}
	if strings.Contains(contentStr, "#!/usr/bin/env node") {
		return "javascript"
	}

	return "unknown"
}

// isExcludedDirectory checks if a directory should be excluded from indexing
func (m *Manager) isExcludedDirectory(name string) bool {
	excluded := []string{
		"node_modules", ".git", ".svn", ".hg", "vendor", "target",
		"build", "dist", ".cache", "__pycache__", ".pytest_cache",
		".vscode", ".idea", ".vs", "bin", "obj",
	}

	for _, dir := range excluded {
		if name == dir {
			return true
		}
	}

	return false
}

// sortResultsByRelevance sorts search results by relevance score
func (m *Manager) sortResultsByRelevance(results []*SearchResult) {
	// Simple relevance sorting - in practice, this would be more sophisticated
	for i := 0; i < len(results)-1; i++ {
		for j := i + 1; j < len(results); j++ {
			if results[i].Relevance < results[j].Relevance {
				results[i], results[j] = results[j], results[i]
			}
		}
	}
}

// calculateChecksum calculates a simple checksum for file content
func calculateChecksum(content []byte) string {
	// Simple checksum - in practice, you'd use a proper hash function
	sum := 0
	for _, b := range content {
		sum += int(b)
	}
	return fmt.Sprintf("%x", sum)
}

// searchContent searches for content within files
func (s *Searcher) searchContent(ctx context.Context, req *SearchRequest, index *FileIndex) []*SearchResult {
	var results []*SearchResult

	index.mutex.RLock()
	defer index.mutex.RUnlock()

	pattern := s.getPattern(req.Query, req.Regex, req.CaseSensitive)

	for _, fileInfo := range index.files {
		if req.Language != "" && fileInfo.Language != req.Language {
			continue
		}

		if req.Path != "" && !strings.Contains(fileInfo.Path, req.Path) {
			continue
		}

		// Read file content
		content, err := os.ReadFile(fileInfo.Path)
		if err != nil {
			continue
		}

		lines := strings.Split(string(content), "\n")
		for i, line := range lines {
			if pattern.MatchString(line) {
				match := pattern.FindString(line)
				result := &SearchResult{
					File:      fileInfo,
					Line:      i + 1,
					Match:     match,
					Type:      SearchTypeContent,
					Relevance: s.calculateRelevance(req.Query, match, fileInfo),
				}

				// Add context lines
				if req.Context > 0 {
					start := max(0, i-req.Context)
					end := min(len(lines), i+req.Context+1)
					result.Context = lines[start:end]
				}

				results = append(results, result)
			}
		}
	}

	return results
}

// searchFunctions searches for functions
func (s *Searcher) searchFunctions(ctx context.Context, req *SearchRequest, index *FileIndex) []*SearchResult {
	var results []*SearchResult

	index.mutex.RLock()
	defer index.mutex.RUnlock()

	pattern := s.getPattern(req.Query, req.Regex, req.CaseSensitive)

	for _, fileInfo := range index.files {
		if req.Language != "" && fileInfo.Language != req.Language {
			continue
		}

		for _, function := range fileInfo.Functions {
			if pattern.MatchString(function.Name) {
				result := &SearchResult{
					File:      fileInfo,
					Line:      function.StartLine,
					Match:     function.Name,
					Type:      SearchTypeFunction,
					Relevance: s.calculateRelevance(req.Query, function.Name, fileInfo),
				}
				results = append(results, result)
			}
		}
	}

	return results
}

// searchClasses searches for classes
func (s *Searcher) searchClasses(ctx context.Context, req *SearchRequest, index *FileIndex) []*SearchResult {
	var results []*SearchResult

	index.mutex.RLock()
	defer index.mutex.RUnlock()

	pattern := s.getPattern(req.Query, req.Regex, req.CaseSensitive)

	for _, fileInfo := range index.files {
		if req.Language != "" && fileInfo.Language != req.Language {
			continue
		}

		for _, class := range fileInfo.Classes {
			if pattern.MatchString(class.Name) {
				result := &SearchResult{
					File:      fileInfo,
					Line:      class.StartLine,
					Match:     class.Name,
					Type:      SearchTypeClass,
					Relevance: s.calculateRelevance(req.Query, class.Name, fileInfo),
				}
				results = append(results, result)
			}
		}
	}

	return results
}

// searchFilenames searches for filenames
func (s *Searcher) searchFilenames(ctx context.Context, req *SearchRequest, index *FileIndex) []*SearchResult {
	var results []*SearchResult

	index.mutex.RLock()
	defer index.mutex.RUnlock()

	pattern := s.getPattern(req.Query, req.Regex, req.CaseSensitive)

	for _, fileInfo := range index.files {
		if pattern.MatchString(fileInfo.Name) {
			result := &SearchResult{
				File:      fileInfo,
				Line:      1,
				Match:     fileInfo.Name,
				Type:      SearchTypeFilename,
				Relevance: s.calculateRelevance(req.Query, fileInfo.Name, fileInfo),
			}
			results = append(results, result)
		}
	}

	return results
}

// searchAll performs a comprehensive search
func (s *Searcher) searchAll(ctx context.Context, req *SearchRequest, index *FileIndex) []*SearchResult {
	var results []*SearchResult

	// Search content
	results = append(results, s.searchContent(ctx, req, index)...)

	// Search functions
	results = append(results, s.searchFunctions(ctx, req, index)...)

	// Search classes
	results = append(results, s.searchClasses(ctx, req, index)...)

	// Search filenames
	results = append(results, s.searchFilenames(ctx, req, index)...)

	return results
}

// getPattern returns a compiled regex pattern
func (s *Searcher) getPattern(query string, isRegex, caseSensitive bool) *regexp.Regexp {
	key := fmt.Sprintf("%s_%t_%t", query, isRegex, caseSensitive)

	if pattern, exists := s.patterns[key]; exists {
		return pattern
	}

	var patternStr string
	if isRegex {
		patternStr = query
	} else {
		patternStr = regexp.QuoteMeta(query)
	}

	if !caseSensitive {
		patternStr = "(?i)" + patternStr
	}

	pattern, err := regexp.Compile(patternStr)
	if err != nil {
		// Fallback to literal search
		pattern = regexp.MustCompile(regexp.QuoteMeta(query))
	}

	s.patterns[key] = pattern
	return pattern
}

// calculateRelevance calculates the relevance score for a search result
func (s *Searcher) calculateRelevance(query, match string, fileInfo *FileInfo) float64 {
	relevance := 0.0

	// Exact match gets highest score
	if strings.EqualFold(query, match) {
		relevance += 1.0
	}

	// Prefix match gets high score
	if strings.HasPrefix(strings.ToLower(match), strings.ToLower(query)) {
		relevance += 0.8
	}

	// Contains match gets medium score
	if strings.Contains(strings.ToLower(match), strings.ToLower(query)) {
		relevance += 0.6
	}

	// Boost score for certain file types
	switch fileInfo.Language {
	case "go", "python", "javascript", "typescript":
		relevance += 0.1
	}

	// Boost score for recently modified files
	if time.Since(fileInfo.ModTime) < 24*time.Hour {
		relevance += 0.1
	}

	return relevance
}

// Helper functions
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// Close closes the file manager and cleans up resources
func (m *Manager) Close() error {
	if m.watcher != nil {
		return m.watcher.Close()
	}
	return nil
}
