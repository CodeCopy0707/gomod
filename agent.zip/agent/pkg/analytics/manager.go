package analytics

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"
)

// Manager handles performance monitoring and analytics
type Manager struct {
	database database.Database
	cache    cache.Cache
	logger   logger.Logger
	
	// Metrics collection
	metrics     *MetricsCollector
	profiler    *PerformanceProfiler
	monitor     *SystemMonitor
	analyzer    *UsageAnalyzer
	
	// Configuration
	config *Config
	
	// Real-time data
	activeMetrics map[string]*Metric
	metricsMutex  sync.RWMutex
	
	// Background processes
	ctx    context.Context
	cancel context.CancelFunc
}

// Config holds analytics configuration
type Config struct {
	MetricsRetentionDays   int
	SamplingRate          float64
	EnableProfiling       bool
	EnableSystemMonitoring bool
	EnableUsageAnalytics  bool
	MetricsFlushInterval  time.Duration
	ProfilingInterval     time.Duration
}

// MetricsCollector collects various metrics
type MetricsCollector struct {
	logger   logger.Logger
	counters map[string]*Counter
	gauges   map[string]*Gauge
	histograms map[string]*Histogram
	mutex    sync.RWMutex
}

// PerformanceProfiler profiles application performance
type PerformanceProfiler struct {
	logger logger.Logger
	profiles map[string]*Profile
	mutex   sync.RWMutex
}

// SystemMonitor monitors system resources
type SystemMonitor struct {
	logger logger.Logger
	stats  *SystemStats
	mutex  sync.RWMutex
}

// UsageAnalyzer analyzes usage patterns
type UsageAnalyzer struct {
	logger   logger.Logger
	database database.Database
	patterns map[string]*UsagePattern
	mutex    sync.RWMutex
}

// Metric represents a generic metric
type Metric struct {
	Name      string                 `json:"name"`
	Type      MetricType             `json:"type"`
	Value     interface{}            `json:"value"`
	Tags      map[string]string      `json:"tags"`
	Timestamp time.Time              `json:"timestamp"`
	Metadata  map[string]interface{} `json:"metadata"`
}

// Counter represents a counter metric
type Counter struct {
	Name  string            `json:"name"`
	Value int64             `json:"value"`
	Tags  map[string]string `json:"tags"`
	mutex sync.RWMutex
}

// Gauge represents a gauge metric
type Gauge struct {
	Name  string            `json:"name"`
	Value float64           `json:"value"`
	Tags  map[string]string `json:"tags"`
	mutex sync.RWMutex
}

// Histogram represents a histogram metric
type Histogram struct {
	Name    string            `json:"name"`
	Buckets map[float64]int64 `json:"buckets"`
	Count   int64             `json:"count"`
	Sum     float64           `json:"sum"`
	Tags    map[string]string `json:"tags"`
	mutex   sync.RWMutex
}

// Profile represents a performance profile
type Profile struct {
	Name      string        `json:"name"`
	StartTime time.Time     `json:"start_time"`
	EndTime   time.Time     `json:"end_time"`
	Duration  time.Duration `json:"duration"`
	CPUUsage  float64       `json:"cpu_usage"`
	MemUsage  int64         `json:"mem_usage"`
	Samples   []*Sample     `json:"samples"`
}

// Sample represents a profiling sample
type Sample struct {
	Timestamp time.Time `json:"timestamp"`
	CPUUsage  float64   `json:"cpu_usage"`
	MemUsage  int64     `json:"mem_usage"`
	Goroutines int      `json:"goroutines"`
}

// SystemStats represents system statistics
type SystemStats struct {
	Timestamp    time.Time `json:"timestamp"`
	CPUUsage     float64   `json:"cpu_usage"`
	MemoryUsage  int64     `json:"memory_usage"`
	MemoryTotal  int64     `json:"memory_total"`
	DiskUsage    int64     `json:"disk_usage"`
	DiskTotal    int64     `json:"disk_total"`
	NetworkIn    int64     `json:"network_in"`
	NetworkOut   int64     `json:"network_out"`
	Goroutines   int       `json:"goroutines"`
	GCPauses     []time.Duration `json:"gc_pauses"`
}

// UsagePattern represents a usage pattern
type UsagePattern struct {
	Pattern     string                 `json:"pattern"`
	Frequency   int                    `json:"frequency"`
	LastSeen    time.Time              `json:"last_seen"`
	Context     map[string]interface{} `json:"context"`
	Confidence  float64                `json:"confidence"`
}

// AnalyticsReport represents an analytics report
type AnalyticsReport struct {
	Period      string                 `json:"period"`
	StartTime   time.Time              `json:"start_time"`
	EndTime     time.Time              `json:"end_time"`
	Metrics     map[string]interface{} `json:"metrics"`
	Insights    []string               `json:"insights"`
	Recommendations []string           `json:"recommendations"`
	GeneratedAt time.Time              `json:"generated_at"`
}

// Enums
type MetricType string
const (
	MetricTypeCounter   MetricType = "counter"
	MetricTypeGauge     MetricType = "gauge"
	MetricTypeHistogram MetricType = "histogram"
	MetricTypeTimer     MetricType = "timer"
)

// NewManager creates a new analytics manager
func NewManager(database database.Database, cache cache.Cache, logger logger.Logger) (*Manager, error) {
	config := &Config{
		MetricsRetentionDays:   30,
		SamplingRate:          1.0,
		EnableProfiling:       true,
		EnableSystemMonitoring: true,
		EnableUsageAnalytics:  true,
		MetricsFlushInterval:  30 * time.Second,
		ProfilingInterval:     5 * time.Minute,
	}

	ctx, cancel := context.WithCancel(context.Background())

	manager := &Manager{
		database:      database,
		cache:         cache,
		logger:        logger,
		config:        config,
		activeMetrics: make(map[string]*Metric),
		ctx:           ctx,
		cancel:        cancel,
		
		metrics:  NewMetricsCollector(logger),
		profiler: NewPerformanceProfiler(logger),
		monitor:  NewSystemMonitor(logger),
		analyzer: NewUsageAnalyzer(database, logger),
	}

	// Start background processes
	go manager.startMetricsCollection()
	go manager.startProfiling()
	go manager.startSystemMonitoring()

	logger.Info("Analytics manager initialized")
	return manager, nil
}

// RecordMetric records a metric
func (m *Manager) RecordMetric(name string, metricType MetricType, value interface{}, tags map[string]string) {
	metric := &Metric{
		Name:      name,
		Type:      metricType,
		Value:     value,
		Tags:      tags,
		Timestamp: time.Now(),
		Metadata:  make(map[string]interface{}),
	}

	m.metricsMutex.Lock()
	m.activeMetrics[name] = metric
	m.metricsMutex.Unlock()

	// Record in appropriate collector
	switch metricType {
	case MetricTypeCounter:
		if val, ok := value.(int64); ok {
			m.metrics.IncrementCounter(name, val, tags)
		}
	case MetricTypeGauge:
		if val, ok := value.(float64); ok {
			m.metrics.SetGauge(name, val, tags)
		}
	case MetricTypeHistogram:
		if val, ok := value.(float64); ok {
			m.metrics.RecordHistogram(name, val, tags)
		}
	}

	m.logger.Debug("Metric recorded", "name", name, "type", metricType, "value", value)
}

// StartProfile starts a performance profile
func (m *Manager) StartProfile(name string) string {
	if !m.config.EnableProfiling {
		return ""
	}

	profileID := fmt.Sprintf("%s_%d", name, time.Now().UnixNano())
	m.profiler.StartProfile(profileID, name)
	return profileID
}

// EndProfile ends a performance profile
func (m *Manager) EndProfile(profileID string) *Profile {
	if !m.config.EnableProfiling || profileID == "" {
		return nil
	}

	return m.profiler.EndProfile(profileID)
}

// RecordUsage records usage information
func (m *Manager) RecordUsage(action string, context map[string]interface{}) {
	if !m.config.EnableUsageAnalytics {
		return
	}

	m.analyzer.RecordUsage(action, context)
}

// GetMetrics returns current metrics
func (m *Manager) GetMetrics() map[string]*Metric {
	m.metricsMutex.RLock()
	defer m.metricsMutex.RUnlock()

	metrics := make(map[string]*Metric)
	for k, v := range m.activeMetrics {
		metrics[k] = v
	}

	return metrics
}

// GetSystemStats returns current system statistics
func (m *Manager) GetSystemStats() *SystemStats {
	return m.monitor.GetStats()
}

// GenerateReport generates an analytics report
func (m *Manager) GenerateReport(period string, startTime, endTime time.Time) (*AnalyticsReport, error) {
	m.logger.Info("Generating analytics report", "period", period, "start", startTime, "end", endTime)

	report := &AnalyticsReport{
		Period:      period,
		StartTime:   startTime,
		EndTime:     endTime,
		Metrics:     make(map[string]interface{}),
		Insights:    []string{},
		Recommendations: []string{},
		GeneratedAt: time.Now(),
	}

	// Collect metrics for the period
	report.Metrics["counters"] = m.metrics.GetCounters()
	report.Metrics["gauges"] = m.metrics.GetGauges()
	report.Metrics["histograms"] = m.metrics.GetHistograms()

	// Generate insights
	report.Insights = m.generateInsights(report.Metrics)
	report.Recommendations = m.generateRecommendations(report.Metrics)

	return report, nil
}

// NewMetricsCollector creates a new metrics collector
func NewMetricsCollector(logger logger.Logger) *MetricsCollector {
	return &MetricsCollector{
		logger:     logger,
		counters:   make(map[string]*Counter),
		gauges:     make(map[string]*Gauge),
		histograms: make(map[string]*Histogram),
	}
}

// IncrementCounter increments a counter
func (mc *MetricsCollector) IncrementCounter(name string, value int64, tags map[string]string) {
	mc.mutex.Lock()
	defer mc.mutex.Unlock()

	counter, exists := mc.counters[name]
	if !exists {
		counter = &Counter{
			Name:  name,
			Value: 0,
			Tags:  tags,
		}
		mc.counters[name] = counter
	}

	counter.mutex.Lock()
	counter.Value += value
	counter.mutex.Unlock()
}

// SetGauge sets a gauge value
func (mc *MetricsCollector) SetGauge(name string, value float64, tags map[string]string) {
	mc.mutex.Lock()
	defer mc.mutex.Unlock()

	gauge, exists := mc.gauges[name]
	if !exists {
		gauge = &Gauge{
			Name:  name,
			Value: 0,
			Tags:  tags,
		}
		mc.gauges[name] = gauge
	}

	gauge.mutex.Lock()
	gauge.Value = value
	gauge.mutex.Unlock()
}

// RecordHistogram records a histogram value
func (mc *MetricsCollector) RecordHistogram(name string, value float64, tags map[string]string) {
	mc.mutex.Lock()
	defer mc.mutex.Unlock()

	histogram, exists := mc.histograms[name]
	if !exists {
		histogram = &Histogram{
			Name:    name,
			Buckets: make(map[float64]int64),
			Count:   0,
			Sum:     0,
			Tags:    tags,
		}
		mc.histograms[name] = histogram
	}

	histogram.mutex.Lock()
	histogram.Count++
	histogram.Sum += value

	// Find appropriate bucket
	buckets := []float64{0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 25.0, 50.0, 100.0}
	for _, bucket := range buckets {
		if value <= bucket {
			histogram.Buckets[bucket]++
			break
		}
	}
	histogram.mutex.Unlock()
}

// GetCounters returns all counters
func (mc *MetricsCollector) GetCounters() map[string]*Counter {
	mc.mutex.RLock()
	defer mc.mutex.RUnlock()

	counters := make(map[string]*Counter)
	for k, v := range mc.counters {
		counters[k] = v
	}
	return counters
}

// GetGauges returns all gauges
func (mc *MetricsCollector) GetGauges() map[string]*Gauge {
	mc.mutex.RLock()
	defer mc.mutex.RUnlock()

	gauges := make(map[string]*Gauge)
	for k, v := range mc.gauges {
		gauges[k] = v
	}
	return gauges
}

// GetHistograms returns all histograms
func (mc *MetricsCollector) GetHistograms() map[string]*Histogram {
	mc.mutex.RLock()
	defer mc.mutex.RUnlock()

	histograms := make(map[string]*Histogram)
	for k, v := range mc.histograms {
		histograms[k] = v
	}
	return histograms
}

// NewPerformanceProfiler creates a new performance profiler
func NewPerformanceProfiler(logger logger.Logger) *PerformanceProfiler {
	return &PerformanceProfiler{
		logger:   logger,
		profiles: make(map[string]*Profile),
	}
}

// StartProfile starts a new profile
func (pp *PerformanceProfiler) StartProfile(profileID, name string) {
	pp.mutex.Lock()
	defer pp.mutex.Unlock()

	profile := &Profile{
		Name:      name,
		StartTime: time.Now(),
		Samples:   make([]*Sample, 0),
	}

	pp.profiles[profileID] = profile
}

// EndProfile ends a profile and returns the result
func (pp *PerformanceProfiler) EndProfile(profileID string) *Profile {
	pp.mutex.Lock()
	defer pp.mutex.Unlock()

	profile, exists := pp.profiles[profileID]
	if !exists {
		return nil
	}

	profile.EndTime = time.Now()
	profile.Duration = profile.EndTime.Sub(profile.StartTime)

	// Collect final sample
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	finalSample := &Sample{
		Timestamp:  time.Now(),
		MemUsage:   int64(m.Alloc),
		Goroutines: runtime.NumGoroutine(),
	}

	profile.Samples = append(profile.Samples, finalSample)
	profile.MemUsage = finalSample.MemUsage

	delete(pp.profiles, profileID)
	return profile
}

// NewSystemMonitor creates a new system monitor
func NewSystemMonitor(logger logger.Logger) *SystemMonitor {
	return &SystemMonitor{
		logger: logger,
		stats:  &SystemStats{},
	}
}

// GetStats returns current system statistics
func (sm *SystemMonitor) GetStats() *SystemStats {
	sm.mutex.RLock()
	defer sm.mutex.RUnlock()

	// Create a copy to avoid race conditions
	stats := *sm.stats
	return &stats
}

// updateStats updates system statistics
func (sm *SystemMonitor) updateStats() {
	sm.mutex.Lock()
	defer sm.mutex.Unlock()

	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	sm.stats = &SystemStats{
		Timestamp:   time.Now(),
		MemoryUsage: int64(m.Alloc),
		MemoryTotal: int64(m.Sys),
		Goroutines:  runtime.NumGoroutine(),
		GCPauses:    make([]time.Duration, len(m.PauseNs)),
	}

	// Convert GC pause times
	for i, pause := range m.PauseNs {
		sm.stats.GCPauses[i] = time.Duration(pause)
	}
}

// NewUsageAnalyzer creates a new usage analyzer
func NewUsageAnalyzer(database database.Database, logger logger.Logger) *UsageAnalyzer {
	return &UsageAnalyzer{
		logger:   logger,
		database: database,
		patterns: make(map[string]*UsagePattern),
	}
}

// RecordUsage records a usage event
func (ua *UsageAnalyzer) RecordUsage(action string, context map[string]interface{}) {
	ua.mutex.Lock()
	defer ua.mutex.Unlock()

	pattern, exists := ua.patterns[action]
	if !exists {
		pattern = &UsagePattern{
			Pattern:    action,
			Frequency:  0,
			Context:    context,
			Confidence: 0.5,
		}
		ua.patterns[action] = pattern
	}

	pattern.Frequency++
	pattern.LastSeen = time.Now()
	pattern.Confidence = min(1.0, pattern.Confidence+0.1)
}

// Background processes

func (m *Manager) startMetricsCollection() {
	ticker := time.NewTicker(m.config.MetricsFlushInterval)
	defer ticker.Stop()

	for {
		select {
		case <-m.ctx.Done():
			return
		case <-ticker.C:
			m.flushMetrics()
		}
	}
}

func (m *Manager) startProfiling() {
	if !m.config.EnableProfiling {
		return
	}

	ticker := time.NewTicker(m.config.ProfilingInterval)
	defer ticker.Stop()

	for {
		select {
		case <-m.ctx.Done():
			return
		case <-ticker.C:
			m.collectProfilingData()
		}
	}
}

func (m *Manager) startSystemMonitoring() {
	if !m.config.EnableSystemMonitoring {
		return
	}

	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-m.ctx.Done():
			return
		case <-ticker.C:
			m.monitor.updateStats()
		}
	}
}

func (m *Manager) flushMetrics() {
	// Store metrics in database
	m.logger.Debug("Flushing metrics to database")
	
	metrics := m.GetMetrics()
	for _, metric := range metrics {
		if data, err := json.Marshal(metric); err == nil {
			// Store in database (simplified)
			m.database.Exec("INSERT INTO metrics (name, type, data, timestamp) VALUES (?, ?, ?, ?)",
				metric.Name, metric.Type, data, metric.Timestamp)
		}
	}
}

func (m *Manager) collectProfilingData() {
	// Collect runtime profiling data
	var memStats runtime.MemStats
	runtime.ReadMemStats(&memStats)

	m.RecordMetric("runtime.memory.alloc", MetricTypeGauge, float64(memStats.Alloc), nil)
	m.RecordMetric("runtime.memory.sys", MetricTypeGauge, float64(memStats.Sys), nil)
	m.RecordMetric("runtime.goroutines", MetricTypeGauge, float64(runtime.NumGoroutine()), nil)
	m.RecordMetric("runtime.gc.num", MetricTypeCounter, int64(memStats.NumGC), nil)
}

func (m *Manager) generateInsights(metrics map[string]interface{}) []string {
	insights := []string{}

	// Analyze metrics and generate insights
	if counters, ok := metrics["counters"].(map[string]*Counter); ok {
		for name, counter := range counters {
			if counter.Value > 1000 {
				insights = append(insights, fmt.Sprintf("High activity detected in %s: %d events", name, counter.Value))
			}
		}
	}

	return insights
}

func (m *Manager) generateRecommendations(metrics map[string]interface{}) []string {
	recommendations := []string{}

	// Generate recommendations based on metrics
	stats := m.GetSystemStats()
	if stats.MemoryUsage > stats.MemoryTotal/2 {
		recommendations = append(recommendations, "Consider optimizing memory usage - currently using over 50% of available memory")
	}

	if stats.Goroutines > 1000 {
		recommendations = append(recommendations, "High number of goroutines detected - consider reviewing concurrent operations")
	}

	return recommendations
}

// Helper function
func min(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}

// Close closes the analytics manager
func (m *Manager) Close() error {
	m.cancel()
	return nil
}
