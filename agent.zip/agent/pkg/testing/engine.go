package testing

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/files"
	"ai-coding-agent/pkg/terminal"
)

// Engine handles automated testing and validation
type Engine struct {
	logger       logger.Logger
	ai           *ai.Manager
	fileManager  *files.Manager
	terminal     *terminal.Manager
	generators   map[string]*TestGenerator
	executors    map[string]*TestExecutor
	validators   map[string]*TestValidator
	config       *Config
	mutex        sync.RWMutex
}

// Config holds testing configuration
type Config struct {
	TestTimeout        time.Duration
	MaxConcurrentTests int
	CoverageThreshold  float64
	RetryAttempts      int
	TestDataDir        string
	ReportFormat       string
	EnableCoverage     bool
	EnableBenchmarks   bool
	EnableIntegration  bool
}

// TestGenerator generates tests for code
type TestGenerator struct {
	Language string
	ai       *ai.Manager
	logger   logger.Logger
}

// TestExecutor executes tests
type TestExecutor struct {
	Language string
	terminal *terminal.Manager
	logger   logger.Logger
}

// TestValidator validates test results
type TestValidator struct {
	Language string
	logger   logger.Logger
}

// TestRequest represents a test generation request
type TestRequest struct {
	Code            string                 `json:"code"`
	Language        string                 `json:"language"`
	TestType        TestType               `json:"test_type"`
	Framework       string                 `json:"framework"`
	CoverageTarget  float64                `json:"coverage_target"`
	Options         *TestOptions           `json:"options"`
	Context         map[string]interface{} `json:"context"`
}

// TestOptions defines test generation options
type TestOptions struct {
	IncludeEdgeCases    bool     `json:"include_edge_cases"`
	IncludeBenchmarks   bool     `json:"include_benchmarks"`
	IncludeIntegration  bool     `json:"include_integration"`
	MockDependencies    bool     `json:"mock_dependencies"`
	GenerateTestData    bool     `json:"generate_test_data"`
	TestNamingPattern   string   `json:"test_naming_pattern"`
	ExcludePatterns     []string `json:"exclude_patterns"`
}

// TestResult represents test execution results
type TestResult struct {
	TestSuite      string                 `json:"test_suite"`
	Language       string                 `json:"language"`
	Framework      string                 `json:"framework"`
	Status         TestStatus             `json:"status"`
	Duration       time.Duration          `json:"duration"`
	TestCases      []*TestCase            `json:"test_cases"`
	Coverage       *CoverageReport        `json:"coverage"`
	Performance    *PerformanceReport     `json:"performance"`
	Errors         []string               `json:"errors"`
	Warnings       []string               `json:"warnings"`
	Metadata       map[string]interface{} `json:"metadata"`
	GeneratedAt    time.Time              `json:"generated_at"`
	ExecutedAt     time.Time              `json:"executed_at"`
}

// TestCase represents a single test case
type TestCase struct {
	Name        string        `json:"name"`
	Description string        `json:"description"`
	Status      TestStatus    `json:"status"`
	Duration    time.Duration `json:"duration"`
	Output      string        `json:"output"`
	Error       string        `json:"error"`
	Assertions  int           `json:"assertions"`
	LinesCovered []int        `json:"lines_covered"`
}

// CoverageReport represents code coverage information
type CoverageReport struct {
	TotalLines    int                    `json:"total_lines"`
	CoveredLines  int                    `json:"covered_lines"`
	Percentage    float64                `json:"percentage"`
	Files         map[string]*FileCoverage `json:"files"`
	Functions     map[string]*FunctionCoverage `json:"functions"`
	Branches      *BranchCoverage        `json:"branches"`
}

// FileCoverage represents coverage for a single file
type FileCoverage struct {
	Path         string  `json:"path"`
	TotalLines   int     `json:"total_lines"`
	CoveredLines int     `json:"covered_lines"`
	Percentage   float64 `json:"percentage"`
	UncoveredLines []int `json:"uncovered_lines"`
}

// FunctionCoverage represents coverage for a function
type FunctionCoverage struct {
	Name       string  `json:"name"`
	StartLine  int     `json:"start_line"`
	EndLine    int     `json:"end_line"`
	Covered    bool    `json:"covered"`
	CallCount  int     `json:"call_count"`
}

// BranchCoverage represents branch coverage information
type BranchCoverage struct {
	TotalBranches   int     `json:"total_branches"`
	CoveredBranches int     `json:"covered_branches"`
	Percentage      float64 `json:"percentage"`
}

// PerformanceReport represents performance test results
type PerformanceReport struct {
	Benchmarks    []*Benchmark `json:"benchmarks"`
	MemoryUsage   int64        `json:"memory_usage"`
	CPUUsage      float64      `json:"cpu_usage"`
	ExecutionTime time.Duration `json:"execution_time"`
}

// Benchmark represents a performance benchmark
type Benchmark struct {
	Name           string        `json:"name"`
	Iterations     int           `json:"iterations"`
	Duration       time.Duration `json:"duration"`
	MemoryAllocs   int64         `json:"memory_allocs"`
	BytesAllocated int64         `json:"bytes_allocated"`
}

// Enums
type TestType string
const (
	TestTypeUnit        TestType = "unit"
	TestTypeIntegration TestType = "integration"
	TestTypeBenchmark   TestType = "benchmark"
	TestTypeEnd2End     TestType = "e2e"
	TestTypeFuzz        TestType = "fuzz"
	TestTypeProperty    TestType = "property"
)

type TestStatus string
const (
	TestStatusPending TestStatus = "pending"
	TestStatusRunning TestStatus = "running"
	TestStatusPassed  TestStatus = "passed"
	TestStatusFailed  TestStatus = "failed"
	TestStatusSkipped TestStatus = "skipped"
	TestStatusError   TestStatus = "error"
)

// NewEngine creates a new testing engine
func NewEngine(logger logger.Logger, ai *ai.Manager, fileManager *files.Manager, terminal *terminal.Manager) *Engine {
	config := &Config{
		TestTimeout:        5 * time.Minute,
		MaxConcurrentTests: 4,
		CoverageThreshold:  80.0,
		RetryAttempts:      3,
		TestDataDir:        "testdata",
		ReportFormat:       "json",
		EnableCoverage:     true,
		EnableBenchmarks:   true,
		EnableIntegration:  true,
	}

	engine := &Engine{
		logger:      logger,
		ai:          ai,
		fileManager: fileManager,
		terminal:    terminal,
		config:      config,
		generators:  make(map[string]*TestGenerator),
		executors:   make(map[string]*TestExecutor),
		validators:  make(map[string]*TestValidator),
	}

	// Initialize generators, executors, and validators for supported languages
	engine.initializeComponents()

	logger.Info("Testing engine initialized")
	return engine
}

// initializeComponents initializes testing components for each language
func (e *Engine) initializeComponents() {
	languages := []string{"go", "python", "javascript", "typescript", "java", "rust", "cpp", "csharp"}

	for _, lang := range languages {
		e.generators[lang] = &TestGenerator{
			Language: lang,
			ai:       e.ai,
			logger:   e.logger,
		}

		e.executors[lang] = &TestExecutor{
			Language: lang,
			terminal: e.terminal,
			logger:   e.logger,
		}

		e.validators[lang] = &TestValidator{
			Language: lang,
			logger:   e.logger,
		}
	}
}

// GenerateTests generates tests for the given code
func (e *Engine) GenerateTests(ctx context.Context, request *TestRequest) (*TestResult, error) {
	e.logger.Info("Generating tests", 
		"language", request.Language, 
		"type", request.TestType,
		"framework", request.Framework)

	generator, exists := e.generators[request.Language]
	if !exists {
		return nil, fmt.Errorf("test generator not available for language: %s", request.Language)
	}

	// Generate test code
	testCode, err := generator.GenerateTestCode(ctx, request)
	if err != nil {
		return nil, fmt.Errorf("test generation failed: %w", err)
	}

	// Create test result
	result := &TestResult{
		TestSuite:   fmt.Sprintf("%s_tests", request.Language),
		Language:    request.Language,
		Framework:   request.Framework,
		Status:      TestStatusPending,
		TestCases:   []*TestCase{},
		Errors:      []string{},
		Warnings:    []string{},
		Metadata:    make(map[string]interface{}),
		GeneratedAt: time.Now(),
	}

	// Parse generated test code to extract test cases
	result.TestCases = e.parseTestCases(testCode, request.Language)

	// Store generated test code
	result.Metadata["generated_code"] = testCode

	return result, nil
}

// ExecuteTests executes the generated tests
func (e *Engine) ExecuteTests(ctx context.Context, testResult *TestResult) error {
	e.logger.Info("Executing tests", 
		"suite", testResult.TestSuite, 
		"language", testResult.Language)

	executor, exists := e.executors[testResult.Language]
	if !exists {
		return fmt.Errorf("test executor not available for language: %s", testResult.Language)
	}

	testResult.Status = TestStatusRunning
	testResult.ExecutedAt = time.Now()

	// Execute tests
	err := executor.ExecuteTests(ctx, testResult)
	if err != nil {
		testResult.Status = TestStatusError
		testResult.Errors = append(testResult.Errors, err.Error())
		return fmt.Errorf("test execution failed: %w", err)
	}

	// Generate coverage report if enabled
	if e.config.EnableCoverage {
		coverage, err := e.generateCoverageReport(ctx, testResult)
		if err != nil {
			e.logger.Warn("Failed to generate coverage report", "error", err)
		} else {
			testResult.Coverage = coverage
		}
	}

	// Validate test results
	validator, exists := e.validators[testResult.Language]
	if exists {
		err = validator.ValidateResults(testResult)
		if err != nil {
			e.logger.Warn("Test validation failed", "error", err)
		}
	}

	// Determine overall status
	e.determineOverallStatus(testResult)

	e.logger.Info("Test execution completed", 
		"suite", testResult.TestSuite, 
		"status", testResult.Status,
		"duration", testResult.Duration)

	return nil
}

// GenerateTestCode generates test code using AI
func (tg *TestGenerator) GenerateTestCode(ctx context.Context, request *TestRequest) (string, error) {
	prompt := tg.buildTestPrompt(request)

	response, err := tg.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: []*ai.Message{
			{Role: "user", Content: prompt},
		},
		Temperature: 0.3,
		MaxTokens:   3000,
	})

	if err != nil {
		return "", fmt.Errorf("AI test generation failed: %w", err)
	}

	// Extract test code from response
	testCode := tg.extractTestCode(response, request.Language)
	return testCode, nil
}

// buildTestPrompt builds the prompt for test generation
func (tg *TestGenerator) buildTestPrompt(request *TestRequest) string {
	prompt := fmt.Sprintf(`Generate comprehensive %s tests for the following %s code:

Code to test:
```%s
%s
```

Requirements:
- Use %s testing framework
- Target %s test type
- Aim for %.1f%% code coverage
- Include edge cases and error scenarios
- Follow %s testing best practices
- Generate meaningful test names and descriptions

Please provide:
1. Complete test code with proper imports
2. Multiple test cases covering different scenarios
3. Setup and teardown if needed
4. Mock objects for dependencies if required
5. Assertions for expected behavior

Test code:`,
		request.Framework, request.Language,
		request.Language, request.Code,
		request.Framework, request.TestType, request.CoverageTarget,
		request.Language)

	if request.Options != nil {
		if request.Options.IncludeEdgeCases {
			prompt += "\n- Include comprehensive edge case testing"
		}
		if request.Options.IncludeBenchmarks {
			prompt += "\n- Include performance benchmarks"
		}
		if request.Options.MockDependencies {
			prompt += "\n- Mock external dependencies"
		}
		if request.Options.GenerateTestData {
			prompt += "\n- Generate appropriate test data"
		}
	}

	return prompt
}

// extractTestCode extracts test code from AI response
func (tg *TestGenerator) extractTestCode(response, language string) string {
	// Look for code blocks
	codeBlockRegex := regexp.MustCompile("```[a-zA-Z]*\n(.*?)\n```")
	matches := codeBlockRegex.FindStringSubmatch(response)
	
	if len(matches) > 1 {
		return strings.TrimSpace(matches[1])
	}

	// Fallback: extract everything after "Test code:" or similar
	lines := strings.Split(response, "\n")
	var testLines []string
	inTest := false

	for _, line := range lines {
		if strings.Contains(strings.ToLower(line), "test code") && strings.Contains(line, ":") {
			inTest = true
			continue
		}
		if inTest {
			testLines = append(testLines, line)
		}
	}

	return strings.TrimSpace(strings.Join(testLines, "\n"))
}

// ExecuteTests executes the test suite
func (te *TestExecutor) ExecuteTests(ctx context.Context, testResult *TestResult) error {
	// Get test code from metadata
	testCode, exists := testResult.Metadata["generated_code"].(string)
	if !exists {
		return fmt.Errorf("no test code found in metadata")
	}

	// Create temporary test file
	testFile, err := te.createTestFile(testCode, testResult.Language)
	if err != nil {
		return fmt.Errorf("failed to create test file: %w", err)
	}
	defer os.Remove(testFile)

	// Execute tests based on language
	startTime := time.Now()
	
	var output string
	var execErr error

	switch testResult.Language {
	case "go":
		output, execErr = te.executeGoTests(ctx, testFile)
	case "python":
		output, execErr = te.executePythonTests(ctx, testFile)
	case "javascript", "typescript":
		output, execErr = te.executeJSTests(ctx, testFile)
	case "java":
		output, execErr = te.executeJavaTests(ctx, testFile)
	default:
		return fmt.Errorf("test execution not implemented for language: %s", testResult.Language)
	}

	testResult.Duration = time.Since(startTime)

	if execErr != nil {
		testResult.Errors = append(testResult.Errors, execErr.Error())
	}

	// Parse test output to update test cases
	te.parseTestOutput(output, testResult)

	return nil
}

// createTestFile creates a temporary test file
func (te *TestExecutor) createTestFile(testCode, language string) (string, error) {
	var ext string
	switch language {
	case "go":
		ext = ".go"
	case "python":
		ext = ".py"
	case "javascript":
		ext = ".js"
	case "typescript":
		ext = ".ts"
	case "java":
		ext = ".java"
	default:
		ext = ".txt"
	}

	file, err := os.CreateTemp("", fmt.Sprintf("test_*%s", ext))
	if err != nil {
		return "", err
	}

	_, err = file.WriteString(testCode)
	if err != nil {
		file.Close()
		os.Remove(file.Name())
		return "", err
	}

	file.Close()
	return file.Name(), nil
}

// executeGoTests executes Go tests
func (te *TestExecutor) executeGoTests(ctx context.Context, testFile string) (string, error) {
	cmd := exec.CommandContext(ctx, "go", "test", "-v", testFile)
	output, err := cmd.CombinedOutput()
	return string(output), err
}

// executePythonTests executes Python tests
func (te *TestExecutor) executePythonTests(ctx context.Context, testFile string) (string, error) {
	cmd := exec.CommandContext(ctx, "python", "-m", "pytest", "-v", testFile)
	output, err := cmd.CombinedOutput()
	return string(output), err
}

// executeJSTests executes JavaScript/TypeScript tests
func (te *TestExecutor) executeJSTests(ctx context.Context, testFile string) (string, error) {
	cmd := exec.CommandContext(ctx, "npm", "test", testFile)
	output, err := cmd.CombinedOutput()
	return string(output), err
}

// executeJavaTests executes Java tests
func (te *TestExecutor) executeJavaTests(ctx context.Context, testFile string) (string, error) {
	// Compile first
	className := strings.TrimSuffix(filepath.Base(testFile), ".java")
	compileCmd := exec.CommandContext(ctx, "javac", testFile)
	_, err := compileCmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("compilation failed: %w", err)
	}

	// Run tests
	runCmd := exec.CommandContext(ctx, "java", className)
	output, err := runCmd.CombinedOutput()
	return string(output), err
}

// parseTestOutput parses test execution output
func (te *TestExecutor) parseTestOutput(output string, testResult *TestResult) {
	lines := strings.Split(output, "\n")
	
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		// Parse test case results based on common patterns
		if strings.Contains(line, "PASS") || strings.Contains(line, "✓") {
			testCase := &TestCase{
				Name:   te.extractTestName(line),
				Status: TestStatusPassed,
			}
			testResult.TestCases = append(testResult.TestCases, testCase)
		} else if strings.Contains(line, "FAIL") || strings.Contains(line, "✗") {
			testCase := &TestCase{
				Name:   te.extractTestName(line),
				Status: TestStatusFailed,
				Error:  line,
			}
			testResult.TestCases = append(testResult.TestCases, testCase)
		}
	}
}

// extractTestName extracts test name from output line
func (te *TestExecutor) extractTestName(line string) string {
	// Simple extraction - in practice, this would be more sophisticated
	parts := strings.Fields(line)
	for _, part := range parts {
		if strings.HasPrefix(part, "Test") || strings.Contains(part, "test") {
			return part
		}
	}
	return "unknown_test"
}

// parseTestCases parses test cases from generated code
func (e *Engine) parseTestCases(testCode, language string) []*TestCase {
	testCases := []*TestCase{}
	
	// Simple parsing based on common test patterns
	lines := strings.Split(testCode, "\n")
	
	for _, line := range lines {
		line = strings.TrimSpace(line)
		
		// Look for test function definitions
		if e.isTestFunction(line, language) {
			testCase := &TestCase{
				Name:        e.extractTestFunctionName(line, language),
				Description: "Generated test case",
				Status:      TestStatusPending,
			}
			testCases = append(testCases, testCase)
		}
	}

	return testCases
}

// isTestFunction checks if a line defines a test function
func (e *Engine) isTestFunction(line, language string) bool {
	switch language {
	case "go":
		return strings.HasPrefix(line, "func Test")
	case "python":
		return strings.HasPrefix(line, "def test_")
	case "javascript", "typescript":
		return strings.Contains(line, "test(") || strings.Contains(line, "it(")
	case "java":
		return strings.Contains(line, "@Test")
	default:
		return false
	}
}

// extractTestFunctionName extracts test function name
func (e *Engine) extractTestFunctionName(line, language string) string {
	switch language {
	case "go":
		re := regexp.MustCompile(`func (Test\w+)`)
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			return matches[1]
		}
	case "python":
		re := regexp.MustCompile(`def (test_\w+)`)
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			return matches[1]
		}
	case "javascript", "typescript":
		re := regexp.MustCompile(`(?:test|it)\(['"]([^'"]+)['"]`)
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			return matches[1]
		}
	}
	return "unknown_test"
}

// generateCoverageReport generates a coverage report
func (e *Engine) generateCoverageReport(ctx context.Context, testResult *TestResult) (*CoverageReport, error) {
	// This is a simplified implementation
	// In practice, you'd integrate with language-specific coverage tools
	
	coverage := &CoverageReport{
		TotalLines:   100,
		CoveredLines: 85,
		Percentage:   85.0,
		Files:        make(map[string]*FileCoverage),
		Functions:    make(map[string]*FunctionCoverage),
		Branches: &BranchCoverage{
			TotalBranches:   20,
			CoveredBranches: 18,
			Percentage:      90.0,
		},
	}

	return coverage, nil
}

// ValidateResults validates test results
func (tv *TestValidator) ValidateResults(testResult *TestResult) error {
	// Check if any tests failed
	failedTests := 0
	for _, testCase := range testResult.TestCases {
		if testCase.Status == TestStatusFailed {
			failedTests++
		}
	}

	if failedTests > 0 {
		testResult.Warnings = append(testResult.Warnings, 
			fmt.Sprintf("%d test(s) failed", failedTests))
	}

	// Check coverage threshold
	if testResult.Coverage != nil && testResult.Coverage.Percentage < 80.0 {
		testResult.Warnings = append(testResult.Warnings, 
			fmt.Sprintf("Coverage %.1f%% is below threshold", testResult.Coverage.Percentage))
	}

	return nil
}

// determineOverallStatus determines the overall test status
func (e *Engine) determineOverallStatus(testResult *TestResult) {
	if len(testResult.Errors) > 0 {
		testResult.Status = TestStatusError
		return
	}

	passedTests := 0
	failedTests := 0
	
	for _, testCase := range testResult.TestCases {
		switch testCase.Status {
		case TestStatusPassed:
			passedTests++
		case TestStatusFailed:
			failedTests++
		}
	}

	if failedTests > 0 {
		testResult.Status = TestStatusFailed
	} else if passedTests > 0 {
		testResult.Status = TestStatusPassed
	} else {
		testResult.Status = TestStatusSkipped
	}
}
