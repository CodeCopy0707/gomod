package memory

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"
)

// Manager handles memory and context management
type Manager struct {
	database database.Database
	cache    cache.Cache
	logger   logger.Logger
	
	// Memory stores
	shortTerm  *ShortTermMemory
	longTerm   *LongTermMemory
	working    *WorkingMemory
	episodic   *EpisodicMemory
	semantic   *SemanticMemory
	
	// Context management
	contexts   map[string]*Context
	contextMux sync.RWMutex
	
	// Configuration
	config *Config
}

// Config holds memory configuration
type Config struct {
	ShortTermTTL    time.Duration
	WorkingMemSize  int
	EpisodicRetention time.Duration
	SemanticThreshold float64
	ContextWindow   int
	CompressionRatio float64
}

// ShortTermMemory handles temporary information
type ShortTermMemory struct {
	items   map[string]*MemoryItem
	mutex   sync.RWMutex
	ttl     time.Duration
	cache   cache.Cache
}

// LongTermMemory handles persistent information
type LongTermMemory struct {
	database database.Database
	logger   logger.Logger
}

// WorkingMemory handles active context
type WorkingMemory struct {
	items    []*MemoryItem
	maxSize  int
	mutex    sync.RWMutex
}

// EpisodicMemory handles event-based memories
type EpisodicMemory struct {
	episodes map[string]*Episode
	mutex    sync.RWMutex
	database database.Database
}

// SemanticMemory handles knowledge and facts
type SemanticMemory struct {
	knowledge map[string]*Knowledge
	mutex     sync.RWMutex
	database  database.Database
}

// MemoryItem represents a single memory item
type MemoryItem struct {
	ID          string                 `json:"id"`
	Type        MemoryType             `json:"type"`
	Content     interface{}            `json:"content"`
	Context     map[string]interface{} `json:"context"`
	Importance  float64                `json:"importance"`
	Timestamp   time.Time              `json:"timestamp"`
	AccessCount int                    `json:"access_count"`
	LastAccess  time.Time              `json:"last_access"`
	TTL         time.Duration          `json:"ttl"`
	Tags        []string               `json:"tags"`
	Metadata    map[string]interface{} `json:"metadata"`
}

// Episode represents an episodic memory
type Episode struct {
	ID          string                 `json:"id"`
	Title       string                 `json:"title"`
	Description string                 `json:"description"`
	Events      []*Event               `json:"events"`
	Context     map[string]interface{} `json:"context"`
	StartTime   time.Time              `json:"start_time"`
	EndTime     time.Time              `json:"end_time"`
	Importance  float64                `json:"importance"`
	Tags        []string               `json:"tags"`
}

// Event represents a single event in an episode
type Event struct {
	ID        string                 `json:"id"`
	Type      string                 `json:"type"`
	Content   interface{}            `json:"content"`
	Timestamp time.Time              `json:"timestamp"`
	Context   map[string]interface{} `json:"context"`
}

// Knowledge represents semantic knowledge
type Knowledge struct {
	ID          string                 `json:"id"`
	Subject     string                 `json:"subject"`
	Predicate   string                 `json:"predicate"`
	Object      interface{}            `json:"object"`
	Confidence  float64                `json:"confidence"`
	Source      string                 `json:"source"`
	Timestamp   time.Time              `json:"timestamp"`
	Context     map[string]interface{} `json:"context"`
	References  []string               `json:"references"`
}

// Context represents conversation/session context
type Context struct {
	ID           string                 `json:"id"`
	SessionID    string                 `json:"session_id"`
	Messages     []*Message             `json:"messages"`
	Variables    map[string]interface{} `json:"variables"`
	State        map[string]interface{} `json:"state"`
	Metadata     map[string]interface{} `json:"metadata"`
	CreatedAt    time.Time              `json:"created_at"`
	UpdatedAt    time.Time              `json:"updated_at"`
	WindowSize   int                    `json:"window_size"`
	Compressed   bool                   `json:"compressed"`
}

// Message represents a conversation message
type Message struct {
	ID        string                 `json:"id"`
	Role      string                 `json:"role"`
	Content   string                 `json:"content"`
	Timestamp time.Time              `json:"timestamp"`
	Context   map[string]interface{} `json:"context"`
	Metadata  map[string]interface{} `json:"metadata"`
}

// MemoryType defines types of memory
type MemoryType string

const (
	MemoryTypeConversation MemoryType = "conversation"
	MemoryTypeCode         MemoryType = "code"
	MemoryTypeFile         MemoryType = "file"
	MemoryTypeProject      MemoryType = "project"
	MemoryTypeUser         MemoryType = "user"
	MemoryTypeSystem       MemoryType = "system"
	MemoryTypeKnowledge    MemoryType = "knowledge"
	MemoryTypePattern      MemoryType = "pattern"
)

// NewManager creates a new memory manager
func NewManager(database database.Database, cache cache.Cache, logger logger.Logger) (*Manager, error) {
	config := &Config{
		ShortTermTTL:      1 * time.Hour,
		WorkingMemSize:    100,
		EpisodicRetention: 30 * 24 * time.Hour, // 30 days
		SemanticThreshold: 0.7,
		ContextWindow:     50,
		CompressionRatio:  0.5,
	}

	manager := &Manager{
		database: database,
		cache:    cache,
		logger:   logger,
		config:   config,
		contexts: make(map[string]*Context),
		
		shortTerm: &ShortTermMemory{
			items: make(map[string]*MemoryItem),
			ttl:   config.ShortTermTTL,
			cache: cache,
		},
		
		longTerm: &LongTermMemory{
			database: database,
			logger:   logger,
		},
		
		working: &WorkingMemory{
			items:   make([]*MemoryItem, 0, config.WorkingMemSize),
			maxSize: config.WorkingMemSize,
		},
		
		episodic: &EpisodicMemory{
			episodes: make(map[string]*Episode),
			database: database,
		},
		
		semantic: &SemanticMemory{
			knowledge: make(map[string]*Knowledge),
			database:  database,
		},
	}

	// Start background processes
	go manager.startCleanupProcess()
	go manager.startCompressionProcess()

	logger.Info("Memory manager initialized")
	return manager, nil
}

// Store stores a memory item
func (m *Manager) Store(ctx context.Context, sessionID string, userMessage, assistantMessage *Message) error {
	// Create memory items for both messages
	userItem := &MemoryItem{
		ID:          generateID(),
		Type:        MemoryTypeConversation,
		Content:     userMessage,
		Context:     map[string]interface{}{"session_id": sessionID},
		Importance:  m.calculateImportance(userMessage),
		Timestamp:   userMessage.Timestamp,
		AccessCount: 0,
		LastAccess:  time.Now(),
		TTL:         m.config.ShortTermTTL,
		Tags:        m.extractTags(userMessage.Content),
		Metadata:    userMessage.Metadata,
	}

	assistantItem := &MemoryItem{
		ID:          generateID(),
		Type:        MemoryTypeConversation,
		Content:     assistantMessage,
		Context:     map[string]interface{}{"session_id": sessionID},
		Importance:  m.calculateImportance(assistantMessage),
		Timestamp:   assistantMessage.Timestamp,
		AccessCount: 0,
		LastAccess:  time.Now(),
		TTL:         m.config.ShortTermTTL,
		Tags:        m.extractTags(assistantMessage.Content),
		Metadata:    assistantMessage.Metadata,
	}

	// Store in short-term memory
	if err := m.shortTerm.Store(userItem); err != nil {
		return fmt.Errorf("failed to store user message: %w", err)
	}

	if err := m.shortTerm.Store(assistantItem); err != nil {
		return fmt.Errorf("failed to store assistant message: %w", err)
	}

	// Add to working memory
	m.working.Add(userItem)
	m.working.Add(assistantItem)

	// Update context
	if err := m.updateContext(sessionID, userMessage, assistantMessage); err != nil {
		m.logger.Warn("Failed to update context", "error", err)
	}

	// Create episode if significant
	if userItem.Importance > 0.7 || assistantItem.Importance > 0.7 {
		m.createEpisode(sessionID, userMessage, assistantMessage)
	}

	// Extract knowledge if applicable
	m.extractKnowledge(userMessage, assistantMessage)

	return nil
}

// Retrieve retrieves memories based on query
func (m *Manager) Retrieve(ctx context.Context, query string, limit int) ([]*MemoryItem, error) {
	var results []*MemoryItem

	// Search short-term memory
	shortTermResults := m.shortTerm.Search(query, limit/2)
	results = append(results, shortTermResults...)

	// Search long-term memory
	longTermResults, err := m.longTerm.Search(ctx, query, limit/2)
	if err != nil {
		m.logger.Warn("Failed to search long-term memory", "error", err)
	} else {
		results = append(results, longTermResults...)
	}

	// Sort by relevance and importance
	m.sortByRelevance(results, query)

	// Limit results
	if len(results) > limit {
		results = results[:limit]
	}

	// Update access counts
	for _, item := range results {
		item.AccessCount++
		item.LastAccess = time.Now()
	}

	return results, nil
}

// GetContext retrieves context for a session
func (m *Manager) GetContext(sessionID string) (*Context, error) {
	m.contextMux.RLock()
	defer m.contextMux.RUnlock()

	context, exists := m.contexts[sessionID]
	if !exists {
		return nil, fmt.Errorf("context not found for session: %s", sessionID)
	}

	return context, nil
}

// updateContext updates the context for a session
func (m *Manager) updateContext(sessionID string, userMessage, assistantMessage *Message) error {
	m.contextMux.Lock()
	defer m.contextMux.Unlock()

	context, exists := m.contexts[sessionID]
	if !exists {
		context = &Context{
			ID:         generateID(),
			SessionID:  sessionID,
			Messages:   make([]*Message, 0),
			Variables:  make(map[string]interface{}),
			State:      make(map[string]interface{}),
			Metadata:   make(map[string]interface{}),
			CreatedAt:  time.Now(),
			WindowSize: m.config.ContextWindow,
		}
		m.contexts[sessionID] = context
	}

	// Add messages
	context.Messages = append(context.Messages, userMessage, assistantMessage)
	context.UpdatedAt = time.Now()

	// Maintain window size
	if len(context.Messages) > context.WindowSize {
		// Compress older messages
		if !context.Compressed {
			m.compressContext(context)
		} else {
			// Remove oldest messages
			excess := len(context.Messages) - context.WindowSize
			context.Messages = context.Messages[excess:]
		}
	}

	return nil
}

// Store stores a memory item in short-term memory
func (s *ShortTermMemory) Store(item *MemoryItem) error {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	s.items[item.ID] = item

	// Store in cache with TTL
	data, err := json.Marshal(item)
	if err != nil {
		return fmt.Errorf("failed to marshal memory item: %w", err)
	}

	return s.cache.Set(fmt.Sprintf("memory:%s", item.ID), data, item.TTL)
}

// Search searches short-term memory
func (s *ShortTermMemory) Search(query string, limit int) []*MemoryItem {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	var results []*MemoryItem
	
	for _, item := range s.items {
		if s.matchesQuery(item, query) {
			results = append(results, item)
		}
		
		if len(results) >= limit {
			break
		}
	}

	return results
}

// matchesQuery checks if an item matches the query
func (s *ShortTermMemory) matchesQuery(item *MemoryItem, query string) bool {
	// Simple text matching - in practice, this would use more sophisticated matching
	if message, ok := item.Content.(*Message); ok {
		return contains(strings.ToLower(message.Content), strings.ToLower(query))
	}
	return false
}

// Search searches long-term memory
func (l *LongTermMemory) Search(ctx context.Context, query string, limit int) ([]*MemoryItem, error) {
	// This would query the database for matching items
	// For now, return empty results
	return []*MemoryItem{}, nil
}

// Add adds an item to working memory
func (w *WorkingMemory) Add(item *MemoryItem) {
	w.mutex.Lock()
	defer w.mutex.Unlock()

	w.items = append(w.items, item)

	// Maintain size limit
	if len(w.items) > w.maxSize {
		// Remove oldest item
		w.items = w.items[1:]
	}
}

// Helper methods

func (m *Manager) calculateImportance(message *Message) float64 {
	// Calculate importance based on various factors
	importance := 0.5 // Base importance

	// Length factor
	if len(message.Content) > 100 {
		importance += 0.1
	}

	// Question factor
	if strings.Contains(message.Content, "?") {
		importance += 0.2
	}

	// Code factor
	if strings.Contains(message.Content, "```") {
		importance += 0.3
	}

	// Error factor
	if strings.Contains(strings.ToLower(message.Content), "error") ||
		strings.Contains(strings.ToLower(message.Content), "bug") {
		importance += 0.2
	}

	return min(importance, 1.0)
}

func (m *Manager) extractTags(content string) []string {
	var tags []string

	// Extract programming languages
	languages := []string{"python", "go", "javascript", "java", "cpp", "rust"}
	for _, lang := range languages {
		if strings.Contains(strings.ToLower(content), lang) {
			tags = append(tags, lang)
		}
	}

	// Extract action types
	actions := []string{"debug", "fix", "create", "generate", "explain", "test"}
	for _, action := range actions {
		if strings.Contains(strings.ToLower(content), action) {
			tags = append(tags, action)
		}
	}

	return tags
}

func (m *Manager) createEpisode(sessionID string, userMessage, assistantMessage *Message) {
	episode := &Episode{
		ID:          generateID(),
		Title:       fmt.Sprintf("Conversation at %s", userMessage.Timestamp.Format("15:04:05")),
		Description: truncateString(userMessage.Content, 100),
		Events: []*Event{
			{
				ID:        generateID(),
				Type:      "user_message",
				Content:   userMessage,
				Timestamp: userMessage.Timestamp,
				Context:   map[string]interface{}{"session_id": sessionID},
			},
			{
				ID:        generateID(),
				Type:      "assistant_message",
				Content:   assistantMessage,
				Timestamp: assistantMessage.Timestamp,
				Context:   map[string]interface{}{"session_id": sessionID},
			},
		},
		Context:    map[string]interface{}{"session_id": sessionID},
		StartTime:  userMessage.Timestamp,
		EndTime:    assistantMessage.Timestamp,
		Importance: (m.calculateImportance(userMessage) + m.calculateImportance(assistantMessage)) / 2,
		Tags:       append(m.extractTags(userMessage.Content), m.extractTags(assistantMessage.Content)...),
	}

	m.episodic.mutex.Lock()
	m.episodic.episodes[episode.ID] = episode
	m.episodic.mutex.Unlock()
}

func (m *Manager) extractKnowledge(userMessage, assistantMessage *Message) {
	// Extract knowledge from the conversation
	// This is a simplified implementation
	if strings.Contains(strings.ToLower(assistantMessage.Content), "is") {
		knowledge := &Knowledge{
			ID:         generateID(),
			Subject:    "conversation",
			Predicate:  "contains",
			Object:     assistantMessage.Content,
			Confidence: 0.8,
			Source:     "conversation",
			Timestamp:  assistantMessage.Timestamp,
			Context:    map[string]interface{}{"type": "conversation"},
		}

		m.semantic.mutex.Lock()
		m.semantic.knowledge[knowledge.ID] = knowledge
		m.semantic.mutex.Unlock()
	}
}

func (m *Manager) sortByRelevance(items []*MemoryItem, query string) {
	// Simple relevance sorting - in practice, this would be more sophisticated
	for i := 0; i < len(items)-1; i++ {
		for j := i + 1; j < len(items); j++ {
			if items[i].Importance < items[j].Importance {
				items[i], items[j] = items[j], items[i]
			}
		}
	}
}

func (m *Manager) compressContext(context *Context) {
	// Compress older messages to save space
	// This is a simplified implementation
	if len(context.Messages) > context.WindowSize {
		compressCount := int(float64(len(context.Messages)) * m.config.CompressionRatio)
		
		// Create summary of compressed messages
		summary := fmt.Sprintf("Summary of %d messages", compressCount)
		
		summaryMessage := &Message{
			ID:        generateID(),
			Role:      "system",
			Content:   summary,
			Timestamp: time.Now(),
			Context:   map[string]interface{}{"compressed": true},
		}

		// Replace compressed messages with summary
		context.Messages = append([]*Message{summaryMessage}, context.Messages[compressCount:]...)
		context.Compressed = true
	}
}

func (m *Manager) startCleanupProcess() {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for range ticker.C {
		m.cleanupExpiredItems()
	}
}

func (m *Manager) startCompressionProcess() {
	ticker := time.NewTicker(30 * time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		m.compressOldMemories()
	}
}

func (m *Manager) cleanupExpiredItems() {
	m.logger.Debug("Cleaning up expired memory items")
	
	m.shortTerm.mutex.Lock()
	defer m.shortTerm.mutex.Unlock()

	now := time.Now()
	for id, item := range m.shortTerm.items {
		if now.Sub(item.Timestamp) > item.TTL {
			delete(m.shortTerm.items, id)
		}
	}
}

func (m *Manager) compressOldMemories() {
	m.logger.Debug("Compressing old memories")
	// Implementation for memory compression
}

// Helper functions
func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

func contains(s, substr string) bool {
	return strings.Contains(s, substr)
}

func truncateString(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}

func min(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}
