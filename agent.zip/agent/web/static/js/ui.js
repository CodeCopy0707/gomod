/**
 * UI Manager for AI Coding Agent
 * Handles all user interface interactions and state management
 */

class UIManager {
    constructor() {
        this.modals = new Map();
        this.notifications = [];
        this.contextMenus = new Map();
        this.shortcuts = new Map();
        this.themes = ['light', 'dark', 'auto'];
        this.currentTheme = localStorage.getItem('theme') || 'dark';
        this.sidebarCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
        this.rightPanelOpen = false;
        
        this.init();
    }

    // Initialize UI manager
    init() {
        this.setupEventListeners();
        this.setupModals();
        this.setupNotifications();
        this.setupContextMenus();
        this.setupKeyboardShortcuts();
        this.applyTheme();
        this.restoreUIState();
        
        console.log('UI Manager initialized');
    }

    // Setup global event listeners
    setupEventListeners() {
        // Window events
        window.addEventListener('resize', this.handleResize.bind(this));
        window.addEventListener('beforeunload', this.saveUIState.bind(this));
        
        // Document events
        document.addEventListener('click', this.handleDocumentClick.bind(this));
        document.addEventListener('keydown', this.handleKeyDown.bind(this));
        document.addEventListener('contextmenu', this.handleContextMenu.bind(this));
        
        // Custom events
        document.addEventListener('theme-change', this.handleThemeChange.bind(this));
        document.addEventListener('notification', this.handleNotification.bind(this));
    }

    // Setup modal dialogs
    setupModals() {
        const modalElements = document.querySelectorAll('.modal');
        modalElements.forEach(modal => {
            this.modals.set(modal.id, {
                element: modal,
                isOpen: false,
                backdrop: true,
                keyboard: true
            });

            // Setup close buttons
            const closeButtons = modal.querySelectorAll('.modal-close, [data-dismiss="modal"]');
            closeButtons.forEach(button => {
                button.addEventListener('click', () => this.hideModal(modal.id));
            });

            // Setup backdrop click
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal(modal.id);
                }
            });
        });
    }

    // Setup notification system
    setupNotifications() {
        // Create notifications container if it doesn't exist
        if (!document.getElementById('notifications')) {
            const container = document.createElement('div');
            container.id = 'notifications';
            container.className = 'notifications';
            document.body.appendChild(container);
        }
    }

    // Setup context menus
    setupContextMenus() {
        // File explorer context menu
        this.registerContextMenu('file-explorer', [
            { label: 'Open', action: 'open-file', icon: 'fas fa-folder-open' },
            { label: 'Rename', action: 'rename-file', icon: 'fas fa-edit' },
            { label: 'Delete', action: 'delete-file', icon: 'fas fa-trash', danger: true },
            { separator: true },
            { label: 'Copy Path', action: 'copy-path', icon: 'fas fa-copy' }
        ]);

        // Code editor context menu
        this.registerContextMenu('code-editor', [
            { label: 'Generate Code', action: 'generate-code', icon: 'fas fa-magic' },
            { label: 'Analyze Code', action: 'analyze-code', icon: 'fas fa-search' },
            { label: 'Refactor', action: 'refactor-code', icon: 'fas fa-tools' },
            { separator: true },
            { label: 'Copy', action: 'copy', icon: 'fas fa-copy' },
            { label: 'Paste', action: 'paste', icon: 'fas fa-paste' }
        ]);
    }

    // Setup keyboard shortcuts
    setupKeyboardShortcuts() {
        this.registerShortcut('Ctrl+N', () => this.showModal('new-file-modal'));
        this.registerShortcut('Ctrl+O', () => this.showModal('open-file-modal'));
        this.registerShortcut('Ctrl+S', () => this.saveCurrentFile());
        this.registerShortcut('Ctrl+Shift+P', () => this.showCommandPalette());
        this.registerShortcut('Ctrl+`', () => this.toggleTerminal());
        this.registerShortcut('Ctrl+B', () => this.toggleSidebar());
        this.registerShortcut('F1', () => this.showModal('help-modal'));
        this.registerShortcut('Escape', () => this.closeActiveModal());
    }

    // Modal management
    showModal(modalId, options = {}) {
        const modal = this.modals.get(modalId);
        if (!modal) {
            console.warn(`Modal ${modalId} not found`);
            return;
        }

        // Close other modals first
        this.closeAllModals();

        modal.element.classList.remove('hidden');
        modal.element.classList.add('show');
        modal.isOpen = true;

        // Focus first input
        const firstInput = modal.element.querySelector('input, textarea, select, button');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }

        // Add body class to prevent scrolling
        document.body.classList.add('modal-open');

        // Emit event
        this.emit('modal-show', { modalId, modal });
    }

    hideModal(modalId) {
        const modal = this.modals.get(modalId);
        if (!modal || !modal.isOpen) return;

        modal.element.classList.remove('show');
        modal.element.classList.add('hidden');
        modal.isOpen = false;

        // Remove body class if no modals are open
        const hasOpenModals = Array.from(this.modals.values()).some(m => m.isOpen);
        if (!hasOpenModals) {
            document.body.classList.remove('modal-open');
        }

        // Emit event
        this.emit('modal-hide', { modalId, modal });
    }

    closeAllModals() {
        this.modals.forEach((modal, modalId) => {
            if (modal.isOpen) {
                this.hideModal(modalId);
            }
        });
    }

    closeActiveModal() {
        const activeModal = Array.from(this.modals.entries())
            .find(([id, modal]) => modal.isOpen);
        
        if (activeModal) {
            this.hideModal(activeModal[0]);
        }
    }

    // Notification system
    showNotification(message, type = 'info', duration = 5000, actions = []) {
        const notification = {
            id: `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            message,
            type,
            duration,
            actions,
            timestamp: new Date()
        };

        this.notifications.push(notification);
        this.renderNotification(notification);

        // Auto-remove after duration
        if (duration > 0) {
            setTimeout(() => {
                this.removeNotification(notification.id);
            }, duration);
        }

        return notification.id;
    }

    renderNotification(notification) {
        const container = document.getElementById('notifications');
        const element = document.createElement('div');
        element.id = notification.id;
        element.className = `notification notification-${notification.type}`;
        
        element.innerHTML = `
            <div class="notification-content">
                <div class="notification-icon">
                    <i class="fas ${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-body">
                    <div class="notification-message">${notification.message}</div>
                    ${notification.actions.length > 0 ? this.renderNotificationActions(notification.actions) : ''}
                </div>
                <button class="notification-close" onclick="ui.removeNotification('${notification.id}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        container.appendChild(element);

        // Animate in
        setTimeout(() => element.classList.add('show'), 10);
    }

    renderNotificationActions(actions) {
        return `
            <div class="notification-actions">
                ${actions.map(action => `
                    <button class="btn btn-sm ${action.primary ? 'btn-primary' : 'btn-secondary'}" 
                            onclick="${action.handler}">
                        ${action.label}
                    </button>
                `).join('')}
            </div>
        `;
    }

    removeNotification(notificationId) {
        const element = document.getElementById(notificationId);
        if (element) {
            element.classList.add('hide');
            setTimeout(() => {
                element.remove();
                this.notifications = this.notifications.filter(n => n.id !== notificationId);
            }, 300);
        }
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    // Context menu system
    registerContextMenu(id, items) {
        this.contextMenus.set(id, items);
    }

    showContextMenu(id, x, y, context = {}) {
        const items = this.contextMenus.get(id);
        if (!items) return;

        this.hideContextMenu();

        const menu = document.createElement('div');
        menu.id = 'active-context-menu';
        menu.className = 'context-menu';
        menu.style.left = `${x}px`;
        menu.style.top = `${y}px`;

        menu.innerHTML = items.map(item => {
            if (item.separator) {
                return '<div class="context-menu-separator"></div>';
            }
            
            return `
                <div class="context-menu-item ${item.danger ? 'danger' : ''}" 
                     data-action="${item.action}">
                    ${item.icon ? `<i class="${item.icon}"></i>` : ''}
                    <span>${item.label}</span>
                </div>
            `;
        }).join('');

        document.body.appendChild(menu);

        // Position adjustment if menu goes off screen
        const rect = menu.getBoundingClientRect();
        if (rect.right > window.innerWidth) {
            menu.style.left = `${x - rect.width}px`;
        }
        if (rect.bottom > window.innerHeight) {
            menu.style.top = `${y - rect.height}px`;
        }

        // Add event listeners
        menu.addEventListener('click', (e) => {
            const item = e.target.closest('.context-menu-item');
            if (item) {
                const action = item.dataset.action;
                this.emit('context-menu-action', { action, context });
                this.hideContextMenu();
            }
        });

        setTimeout(() => menu.classList.add('show'), 10);
    }

    hideContextMenu() {
        const menu = document.getElementById('active-context-menu');
        if (menu) {
            menu.remove();
        }
    }

    // Keyboard shortcuts
    registerShortcut(combination, handler) {
        this.shortcuts.set(combination.toLowerCase(), handler);
    }

    unregisterShortcut(combination) {
        this.shortcuts.delete(combination.toLowerCase());
    }

    // Theme management
    setTheme(theme) {
        if (!this.themes.includes(theme)) return;

        this.currentTheme = theme;
        localStorage.setItem('theme', theme);
        this.applyTheme();
        this.emit('theme-changed', { theme });
    }

    applyTheme() {
        const body = document.body;
        
        // Remove existing theme classes
        this.themes.forEach(theme => {
            body.classList.remove(`theme-${theme}`);
        });

        // Apply current theme
        if (this.currentTheme === 'auto') {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            body.classList.add(prefersDark ? 'theme-dark' : 'theme-light');
        } else {
            body.classList.add(`theme-${this.currentTheme}`);
        }

        // Update theme toggle button
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            if (icon) {
                icon.className = this.currentTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
            }
        }
    }

    toggleTheme() {
        const nextTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.setTheme(nextTheme);
    }

    // Layout management
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (!sidebar) return;

        this.sidebarCollapsed = !this.sidebarCollapsed;
        
        if (this.sidebarCollapsed) {
            sidebar.classList.add('collapsed');
        } else {
            sidebar.classList.remove('collapsed');
        }

        localStorage.setItem('sidebar-collapsed', this.sidebarCollapsed);
        this.emit('sidebar-toggle', { collapsed: this.sidebarCollapsed });
    }

    toggleRightPanel() {
        const panel = document.getElementById('right-panel');
        if (!panel) return;

        this.rightPanelOpen = !this.rightPanelOpen;
        
        if (this.rightPanelOpen) {
            panel.classList.remove('hidden');
        } else {
            panel.classList.add('hidden');
        }

        this.emit('right-panel-toggle', { open: this.rightPanelOpen });
    }

    // State management
    saveUIState() {
        const state = {
            theme: this.currentTheme,
            sidebarCollapsed: this.sidebarCollapsed,
            rightPanelOpen: this.rightPanelOpen,
            timestamp: Date.now()
        };
        
        localStorage.setItem('ui-state', JSON.stringify(state));
    }

    restoreUIState() {
        const saved = localStorage.getItem('ui-state');
        if (!saved) return;

        try {
            const state = JSON.parse(saved);
            
            if (state.theme) {
                this.setTheme(state.theme);
            }
            
            if (state.sidebarCollapsed !== undefined) {
                this.sidebarCollapsed = state.sidebarCollapsed;
                const sidebar = document.getElementById('sidebar');
                if (sidebar) {
                    sidebar.classList.toggle('collapsed', this.sidebarCollapsed);
                }
            }
            
            if (state.rightPanelOpen !== undefined) {
                this.rightPanelOpen = state.rightPanelOpen;
                const panel = document.getElementById('right-panel');
                if (panel) {
                    panel.classList.toggle('hidden', !this.rightPanelOpen);
                }
            }
        } catch (error) {
            console.warn('Failed to restore UI state:', error);
        }
    }

    // Event handlers
    handleResize() {
        // Handle responsive layout changes
        const isMobile = window.innerWidth < 768;
        document.body.classList.toggle('mobile', isMobile);
        
        if (isMobile && !this.sidebarCollapsed) {
            this.toggleSidebar();
        }
    }

    handleDocumentClick(e) {
        // Close context menu on outside click
        if (!e.target.closest('.context-menu')) {
            this.hideContextMenu();
        }
    }

    handleKeyDown(e) {
        const combination = this.getKeyCombination(e);
        const handler = this.shortcuts.get(combination);
        
        if (handler) {
            e.preventDefault();
            handler(e);
        }
    }

    handleContextMenu(e) {
        // Prevent default context menu in certain areas
        if (e.target.closest('.file-explorer, .code-editor')) {
            e.preventDefault();
        }
    }

    handleThemeChange(e) {
        this.applyTheme();
    }

    handleNotification(e) {
        const { message, type, duration, actions } = e.detail;
        this.showNotification(message, type, duration, actions);
    }

    // Utility methods
    getKeyCombination(e) {
        const parts = [];
        
        if (e.ctrlKey) parts.push('ctrl');
        if (e.altKey) parts.push('alt');
        if (e.shiftKey) parts.push('shift');
        if (e.metaKey) parts.push('meta');
        
        parts.push(e.key.toLowerCase());
        
        return parts.join('+');
    }

    emit(eventName, detail = {}) {
        document.dispatchEvent(new CustomEvent(eventName, { detail }));
    }

    // Public API methods
    showCommandPalette() {
        this.showModal('command-palette');
    }

    toggleTerminal() {
        const terminal = document.getElementById('terminal');
        if (terminal) {
            terminal.classList.toggle('hidden');
        }
    }

    saveCurrentFile() {
        this.emit('save-file');
    }

    // Utility functions for other components
    updateRecentSessions(sessions) {
        const container = document.getElementById('recent-sessions');
        if (!container) return;

        container.innerHTML = sessions.map(session => `
            <div class="recent-session" data-session-id="${session.id}">
                <div class="session-info">
                    <div class="session-name">${session.name || 'Unnamed Session'}</div>
                    <div class="session-time">${this.formatTime(session.last_activity)}</div>
                </div>
                <div class="session-stats">
                    <span class="message-count">${session.message_count} messages</span>
                </div>
            </div>
        `).join('');
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return date.toLocaleDateString();
    }

    showTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.classList.remove('hidden');
        }
    }

    hideTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.classList.add('hidden');
        }
    }
}

// Export for use in other modules
window.UIManager = UIManager;
