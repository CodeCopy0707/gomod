/**
 * AI Coding Agent - Main Application
 * 
 * This is the main application entry point that initializes all components
 * and manages the overall application state.
 */

class AICodeAgent {
    constructor() {
        this.config = window.AgentConfig || {};
        this.socket = null;
        this.api = null;
        this.ui = null;
        this.chat = null;
        this.editor = null;
        this.fileManager = null;
        this.notifications = null;
        
        this.state = {
            connected: false,
            currentSession: null,
            currentModel: 'gemini-pro',
            theme: 'dark',
            sidebarOpen: true,
            rightPanelOpen: false,
            loading: true
        };
        
        this.init();
    }
    
    async init() {
        try {
            console.log('🤖 Initializing AI Coding Agent...');
            
            // Show loading screen
            this.showLoading();
            
            // Initialize core components
            await this.initializeComponents();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Connect to server
            await this.connect();
            
            // Initialize UI
            await this.initializeUI();
            
            // Hide loading screen
            this.hideLoading();
            
            console.log('✅ AI Coding Agent initialized successfully');
            
        } catch (error) {
            console.error('❌ Failed to initialize AI Coding Agent:', error);
            this.showError('Failed to initialize application', error.message);
        }
    }
    
    async initializeComponents() {
        // Initialize API client
        this.api = new APIClient(this.config.apiUrl || '/api');
        
        // Initialize Socket.IO connection
        this.socket = new SocketManager(this.config.socketUrl || '/');
        
        // Initialize UI manager
        this.ui = new UIManager();
        
        // Initialize chat manager
        this.chat = new ChatManager(this.socket, this.api);
        
        // Initialize code editor
        this.editor = new CodeEditor();
        
        // Initialize file manager
        this.fileManager = new FileManager(this.api);
        
        // Initialize notifications
        this.notifications = new NotificationManager();
        
        // Initialize theme manager
        this.themeManager = new ThemeManager();
        
        // Initialize shortcuts
        this.shortcuts = new ShortcutManager();
    }
    
    setupEventListeners() {
        // Socket events
        this.socket.on('connect', () => {
            this.setState({ connected: true });
            this.updateConnectionStatus('connected');
            this.notifications.show('Connected to server', 'success');
        });
        
        this.socket.on('disconnect', () => {
            this.setState({ connected: false });
            this.updateConnectionStatus('disconnected');
            this.notifications.show('Disconnected from server', 'warning');
        });
        
        this.socket.on('reconnecting', () => {
            this.updateConnectionStatus('connecting');
        });
        
        // Chat events
        this.chat.on('messageReceived', (message) => {
            this.handleMessageReceived(message);
        });
        
        this.chat.on('typingStart', () => {
            this.ui.showTypingIndicator();
        });
        
        this.chat.on('typingStop', () => {
            this.ui.hideTypingIndicator();
        });
        
        // UI events
        document.addEventListener('DOMContentLoaded', () => {
            this.setupUIEventListeners();
        });
        
        // Window events
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
        
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.shortcuts.handleKeydown(e);
        });
    }
    
    setupUIEventListeners() {
        // Header buttons
        const themeToggle = document.getElementById('theme-toggle');
        const settingsBtn = document.getElementById('settings-btn');
        const helpBtn = document.getElementById('help-btn');
        const sidebarToggle = document.getElementById('sidebar-toggle');
        
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.themeManager.toggle();
            });
        }
        
        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                this.ui.showModal('settings-modal');
            });
        }
        
        if (helpBtn) {
            helpBtn.addEventListener('click', () => {
                this.ui.showModal('help-modal');
            });
        }
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }
        
        // Chat input
        const messageInput = document.getElementById('message-input');
        const sendButton = document.getElementById('send-message');
        const attachFile = document.getElementById('attach-file');
        const voiceInput = document.getElementById('voice-input');
        
        if (messageInput) {
            messageInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            messageInput.addEventListener('input', () => {
                this.updateCharCount();
                this.autoResize(messageInput);
            });
        }
        
        if (sendButton) {
            sendButton.addEventListener('click', () => {
                this.sendMessage();
            });
        }
        
        if (attachFile) {
            attachFile.addEventListener('click', () => {
                this.ui.showModal('file-upload-modal');
            });
        }
        
        if (voiceInput) {
            voiceInput.addEventListener('click', () => {
                this.toggleVoiceInput();
            });
        }
        
        // Quick actions
        const quickActions = document.querySelectorAll('.quick-action');
        quickActions.forEach(action => {
            action.addEventListener('click', () => {
                const actionType = action.dataset.action;
                this.handleQuickAction(actionType);
            });
        });
        
        // Modal close buttons
        const modalCloseButtons = document.querySelectorAll('.modal-close');
        modalCloseButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.ui.hideModal(modal.id);
                }
            });
        });
        
        // File upload
        const fileInput = document.getElementById('file-input');
        const fileUploadArea = document.getElementById('file-upload-area');
        
        if (fileInput && fileUploadArea) {
            fileUploadArea.addEventListener('click', () => {
                fileInput.click();
            });
            
            fileUploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                fileUploadArea.classList.add('drag-over');
            });
            
            fileUploadArea.addEventListener('dragleave', () => {
                fileUploadArea.classList.remove('drag-over');
            });
            
            fileUploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                fileUploadArea.classList.remove('drag-over');
                this.handleFileUpload(e.dataTransfer.files);
            });
            
            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target.files);
            });
        }
    }
    
    async connect() {
        try {
            await this.socket.connect();
            
            // Get initial session info
            const sessionInfo = await this.api.get('/session');
            this.setState({ currentSession: sessionInfo.id });
            
        } catch (error) {
            console.error('Failed to connect:', error);
            throw error;
        }
    }
    
    async initializeUI() {
        // Load recent sessions
        await this.loadRecentSessions();
        
        // Load file tree
        await this.loadFileTree();
        
        // Initialize theme
        this.themeManager.init();
        
        // Set initial UI state
        this.updateUI();
    }
    
    async sendMessage() {
        const messageInput = document.getElementById('message-input');
        const message = messageInput.value.trim();
        
        if (!message) return;
        
        try {
            // Clear input
            messageInput.value = '';
            this.updateCharCount();
            this.autoResize(messageInput);
            
            // Add user message to chat
            this.chat.addMessage({
                role: 'user',
                content: message,
                timestamp: new Date()
            });
            
            // Send to server
            await this.chat.sendMessage(message);
            
        } catch (error) {
            console.error('Failed to send message:', error);
            this.notifications.show('Failed to send message', 'error');
        }
    }
    
    handleMessageReceived(message) {
        // Add assistant message to chat
        this.chat.addMessage(message);
        
        // Handle special message types
        if (message.type === 'code') {
            this.handleCodeMessage(message);
        } else if (message.type === 'file') {
            this.handleFileMessage(message);
        }
    }
    
    handleCodeMessage(message) {
        // Show code in right panel
        this.showRightPanel('Code', message.content);
    }
    
    handleFileMessage(message) {
        // Update file tree
        this.fileManager.refresh();
    }
    
    handleQuickAction(actionType) {
        const actions = {
            'generate-code': 'Generate a function that...',
            'debug-code': 'Help me debug this code...',
            'explain-code': 'Explain this code to me...',
            'create-tests': 'Create unit tests for...'
        };
        
        const prompt = actions[actionType];
        if (prompt) {
            const messageInput = document.getElementById('message-input');
            messageInput.value = prompt;
            messageInput.focus();
        }
    }
    
    async handleFileUpload(files) {
        try {
            for (const file of files) {
                await this.fileManager.uploadFile(file);
            }
            
            this.ui.hideModal('file-upload-modal');
            this.notifications.show(`Uploaded ${files.length} file(s)`, 'success');
            
        } catch (error) {
            console.error('File upload failed:', error);
            this.notifications.show('File upload failed', 'error');
        }
    }
    
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const isOpen = !sidebar.classList.contains('hidden');
        
        if (isOpen) {
            sidebar.classList.add('hidden');
        } else {
            sidebar.classList.remove('hidden');
        }
        
        this.setState({ sidebarOpen: !isOpen });
    }
    
    showRightPanel(title, content) {
        const rightPanel = document.getElementById('right-panel');
        const panelTitle = document.getElementById('panel-title');
        const panelContent = document.getElementById('panel-content');
        
        panelTitle.textContent = title;
        panelContent.innerHTML = content;
        
        rightPanel.classList.remove('hidden');
        this.setState({ rightPanelOpen: true });
    }
    
    hideRightPanel() {
        const rightPanel = document.getElementById('right-panel');
        rightPanel.classList.add('hidden');
        this.setState({ rightPanelOpen: false });
    }
    
    toggleVoiceInput() {
        // Voice input implementation would go here
        this.notifications.show('Voice input not yet implemented', 'info');
    }
    
    updateCharCount() {
        const messageInput = document.getElementById('message-input');
        const charCount = document.querySelector('.char-count');
        
        if (messageInput && charCount) {
            const count = messageInput.value.length;
            const max = messageInput.maxLength;
            charCount.textContent = `${count} / ${max}`;
        }
    }
    
    autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }
    
    updateConnectionStatus(status) {
        const statusDot = document.getElementById('connection-status');
        const statusText = document.getElementById('status-text');
        
        if (statusDot && statusText) {
            statusDot.className = `status-dot status-${status}`;
            
            const statusMessages = {
                connected: 'Connected',
                connecting: 'Connecting...',
                disconnected: 'Disconnected'
            };
            
            statusText.textContent = statusMessages[status] || 'Unknown';
        }
    }
    
    async loadRecentSessions() {
        try {
            const sessions = await this.api.get('/sessions');
            this.ui.updateRecentSessions(sessions);
        } catch (error) {
            console.error('Failed to load recent sessions:', error);
        }
    }
    
    async loadFileTree() {
        try {
            const files = await this.api.get('/files');
            this.fileManager.updateFileTree(files);
        } catch (error) {
            console.error('Failed to load file tree:', error);
        }
    }
    
    showLoading() {
        const loadingScreen = document.getElementById('loading-screen');
        const app = document.getElementById('app');
        
        if (loadingScreen) loadingScreen.classList.remove('hidden');
        if (app) app.classList.add('hidden');
    }
    
    hideLoading() {
        const loadingScreen = document.getElementById('loading-screen');
        const app = document.getElementById('app');
        
        if (loadingScreen) loadingScreen.classList.add('hidden');
        if (app) app.classList.remove('hidden');
        
        this.setState({ loading: false });
    }
    
    showError(title, message) {
        this.notifications.show(`${title}: ${message}`, 'error');
    }
    
    handleResize() {
        // Handle window resize
        if (window.innerWidth < 768) {
            // Mobile view
            const sidebar = document.getElementById('sidebar');
            if (sidebar && this.state.sidebarOpen) {
                sidebar.classList.add('hidden');
                this.setState({ sidebarOpen: false });
            }
        }
    }
    
    setState(newState) {
        this.state = { ...this.state, ...newState };
        this.updateUI();
    }
    
    updateUI() {
        // Update UI based on current state
        const currentModel = document.getElementById('current-model');
        if (currentModel) {
            currentModel.textContent = this.state.currentModel;
        }
    }
    
    cleanup() {
        // Cleanup when page is unloaded
        if (this.socket) {
            this.socket.disconnect();
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.aiAgent = new AICodeAgent();
});

// Export for use in other modules
window.AICodeAgent = AICodeAgent;
