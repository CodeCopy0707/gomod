/**
 * Code Editor for AI Coding Agent
 * Handles code editing with syntax highlighting and intelligent features
 */

class CodeEditor extends EventTarget {
    constructor(containerId = 'code-editor') {
        super();
        this.containerId = containerId;
        this.editor = null;
        this.currentFile = null;
        this.currentLanguage = 'javascript';
        this.isModified = false;
        this.autoSaveEnabled = true;
        this.autoSaveDelay = 2000;
        this.autoSaveTimer = null;
        this.suggestions = [];
        this.completionProvider = null;
        
        this.init();
    }

    // Initialize the code editor
    async init() {
        try {
            await this.loadMonaco();
            this.setupEditor();
            this.setupEventListeners();
            this.setupAutoCompletion();
            this.setupKeyBindings();
            
            console.log('Code Editor initialized');
        } catch (error) {
            console.error('Failed to initialize code editor:', error);
            this.fallbackToTextarea();
        }
    }

    // Load Monaco Editor
    async loadMonaco() {
        if (window.monaco) return;

        return new Promise((resolve, reject) => {
            // Load Monaco Editor from CDN
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.41.0/min/vs/loader.js';
            script.onload = () => {
                require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.41.0/min/vs' } });
                require(['vs/editor/editor.main'], () => {
                    resolve();
                });
            };
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Setup Monaco Editor
    setupEditor() {
        const container = document.getElementById(this.containerId);
        if (!container) {
            throw new Error(`Editor container ${this.containerId} not found`);
        }

        // Configure Monaco themes
        monaco.editor.defineTheme('ai-dark', {
            base: 'vs-dark',
            inherit: true,
            rules: [
                { token: 'comment', foreground: '6A9955' },
                { token: 'keyword', foreground: '569CD6' },
                { token: 'string', foreground: 'CE9178' },
                { token: 'number', foreground: 'B5CEA8' },
                { token: 'type', foreground: '4EC9B0' },
                { token: 'function', foreground: 'DCDCAA' }
            ],
            colors: {
                'editor.background': '#1e1e1e',
                'editor.foreground': '#d4d4d4',
                'editor.lineHighlightBackground': '#2d2d30',
                'editor.selectionBackground': '#264f78',
                'editorCursor.foreground': '#ffffff'
            }
        });

        // Create editor instance
        this.editor = monaco.editor.create(container, {
            value: '// Welcome to AI Coding Agent\n// Start typing or paste your code here\n',
            language: this.currentLanguage,
            theme: 'ai-dark',
            automaticLayout: true,
            fontSize: 14,
            lineNumbers: 'on',
            roundedSelection: false,
            scrollBeyondLastLine: false,
            minimap: { enabled: true },
            wordWrap: 'on',
            tabSize: 2,
            insertSpaces: true,
            folding: true,
            foldingStrategy: 'indentation',
            showFoldingControls: 'always',
            bracketPairColorization: { enabled: true },
            guides: {
                bracketPairs: true,
                indentation: true
            },
            suggest: {
                showKeywords: true,
                showSnippets: true,
                showFunctions: true,
                showConstructors: true,
                showFields: true,
                showVariables: true,
                showClasses: true,
                showStructs: true,
                showInterfaces: true,
                showModules: true,
                showProperties: true,
                showEvents: true,
                showOperators: true,
                showUnits: true,
                showValues: true,
                showConstants: true,
                showEnums: true,
                showEnumMembers: true,
                showColors: true,
                showFiles: true,
                showReferences: true,
                showFolders: true,
                showTypeParameters: true
            }
        });

        // Setup editor event handlers
        this.editor.onDidChangeModelContent(() => {
            this.handleContentChange();
        });

        this.editor.onDidChangeCursorPosition(() => {
            this.updateCursorInfo();
        });

        this.editor.onDidChangeModelLanguage(() => {
            this.handleLanguageChange();
        });
    }

    // Setup event listeners
    setupEventListeners() {
        // File operations
        document.addEventListener('open-file', this.handleOpenFile.bind(this));
        document.addEventListener('save-file', this.handleSaveFile.bind(this));
        document.addEventListener('new-file', this.handleNewFile.bind(this));
        
        // Editor actions
        document.addEventListener('format-code', this.handleFormatCode.bind(this));
        document.addEventListener('analyze-code', this.handleAnalyzeCode.bind(this));
        document.addEventListener('generate-code', this.handleGenerateCode.bind(this));
        
        // Theme changes
        document.addEventListener('theme-changed', this.handleThemeChange.bind(this));
        
        // Window events
        window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));
    }

    // Setup auto-completion
    setupAutoCompletion() {
        // Register AI-powered completion provider
        this.completionProvider = monaco.languages.registerCompletionItemProvider('*', {
            provideCompletionItems: async (model, position) => {
                const suggestions = await this.getAISuggestions(model, position);
                return { suggestions };
            }
        });

        // Register hover provider for documentation
        monaco.languages.registerHoverProvider('*', {
            provideHover: async (model, position) => {
                return this.getHoverInfo(model, position);
            }
        });

        // Register code action provider
        monaco.languages.registerCodeActionProvider('*', {
            provideCodeActions: async (model, range, context) => {
                return this.getCodeActions(model, range, context);
            }
        });
    }

    // Setup key bindings
    setupKeyBindings() {
        // Custom key bindings
        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
            this.saveFile();
        });

        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyO, () => {
            document.dispatchEvent(new CustomEvent('open-file-dialog'));
        });

        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyP, () => {
            this.showCommandPalette();
        });

        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyG, () => {
            this.generateCodeAtCursor();
        });

        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF, () => {
            this.formatCode();
        });

        this.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyA, () => {
            this.analyzeCode();
        });
    }

    // Handle content changes
    handleContentChange() {
        this.isModified = true;
        this.updateFileStatus();
        
        // Auto-save
        if (this.autoSaveEnabled) {
            clearTimeout(this.autoSaveTimer);
            this.autoSaveTimer = setTimeout(() => {
                this.autoSave();
            }, this.autoSaveDelay);
        }

        // Emit change event
        this.dispatchEvent(new CustomEvent('contentChanged', {
            detail: {
                content: this.editor.getValue(),
                file: this.currentFile,
                isModified: this.isModified
            }
        }));
    }

    // Update cursor information
    updateCursorInfo() {
        const position = this.editor.getPosition();
        const selection = this.editor.getSelection();
        
        const cursorInfo = document.getElementById('cursor-info');
        if (cursorInfo) {
            const line = position.lineNumber;
            const column = position.column;
            const selected = selection.isEmpty() ? '' : ` (${this.getSelectionLength()} selected)`;
            cursorInfo.textContent = `Ln ${line}, Col ${column}${selected}`;
        }
    }

    // Get AI-powered suggestions
    async getAISuggestions(model, position) {
        try {
            const textUntilPosition = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column
            });

            const word = model.getWordUntilPosition(position);
            const range = {
                startLineNumber: position.lineNumber,
                endLineNumber: position.lineNumber,
                startColumn: word.startColumn,
                endColumn: word.endColumn
            };

            // Get suggestions from AI
            const response = await window.api.post('/ai/suggestions', {
                code: textUntilPosition,
                language: this.currentLanguage,
                position: { line: position.lineNumber, column: position.column }
            });

            return response.suggestions.map(suggestion => ({
                label: suggestion.label,
                kind: this.getCompletionKind(suggestion.type),
                insertText: suggestion.text,
                detail: suggestion.detail,
                documentation: suggestion.documentation,
                range: range
            }));

        } catch (error) {
            console.warn('Failed to get AI suggestions:', error);
            return [];
        }
    }

    // Get completion item kind
    getCompletionKind(type) {
        const kinds = {
            function: monaco.languages.CompletionItemKind.Function,
            method: monaco.languages.CompletionItemKind.Method,
            variable: monaco.languages.CompletionItemKind.Variable,
            class: monaco.languages.CompletionItemKind.Class,
            interface: monaco.languages.CompletionItemKind.Interface,
            keyword: monaco.languages.CompletionItemKind.Keyword,
            snippet: monaco.languages.CompletionItemKind.Snippet
        };
        return kinds[type] || monaco.languages.CompletionItemKind.Text;
    }

    // Get hover information
    async getHoverInfo(model, position) {
        try {
            const word = model.getWordAtPosition(position);
            if (!word) return null;

            const response = await window.api.post('/ai/hover', {
                code: model.getValue(),
                language: this.currentLanguage,
                word: word.word,
                position: { line: position.lineNumber, column: position.column }
            });

            if (response.documentation) {
                return {
                    range: new monaco.Range(
                        position.lineNumber,
                        word.startColumn,
                        position.lineNumber,
                        word.endColumn
                    ),
                    contents: [
                        { value: `**${word.word}**` },
                        { value: response.documentation }
                    ]
                };
            }

        } catch (error) {
            console.warn('Failed to get hover info:', error);
        }

        return null;
    }

    // Get code actions
    async getCodeActions(model, range, context) {
        const actions = [];

        // Quick fix actions
        if (context.markers && context.markers.length > 0) {
            actions.push({
                title: 'Fix with AI',
                kind: 'quickfix',
                edit: {
                    edits: [{
                        resource: model.uri,
                        edit: {
                            range: range,
                            text: '// AI fix would go here'
                        }
                    }]
                }
            });
        }

        // Refactor actions
        actions.push({
            title: 'Refactor with AI',
            kind: 'refactor',
            command: {
                id: 'ai.refactor',
                title: 'Refactor with AI',
                arguments: [model, range]
            }
        });

        return { actions };
    }

    // File operations
    async openFile(filePath) {
        try {
            const response = await window.api.getFile(filePath);
            
            this.currentFile = {
                path: filePath,
                name: filePath.split('/').pop(),
                content: response.content,
                language: response.language || this.detectLanguage(filePath)
            };

            this.editor.setValue(response.content);
            this.setLanguage(this.currentFile.language);
            this.isModified = false;
            this.updateFileStatus();

            this.dispatchEvent(new CustomEvent('fileOpened', {
                detail: this.currentFile
            }));

        } catch (error) {
            console.error('Failed to open file:', error);
            this.showError(`Failed to open file: ${error.message}`);
        }
    }

    async saveFile() {
        if (!this.currentFile) {
            this.showSaveAsDialog();
            return;
        }

        try {
            const content = this.editor.getValue();
            
            await window.api.saveFile(this.currentFile.path, content);
            
            this.currentFile.content = content;
            this.isModified = false;
            this.updateFileStatus();

            this.dispatchEvent(new CustomEvent('fileSaved', {
                detail: this.currentFile
            }));

            this.showSuccess('File saved successfully');

        } catch (error) {
            console.error('Failed to save file:', error);
            this.showError(`Failed to save file: ${error.message}`);
        }
    }

    async autoSave() {
        if (this.isModified && this.currentFile) {
            try {
                const content = this.editor.getValue();
                await window.api.saveFile(this.currentFile.path, content);
                
                this.currentFile.content = content;
                this.isModified = false;
                this.updateFileStatus();

                console.log('Auto-saved file:', this.currentFile.path);

            } catch (error) {
                console.warn('Auto-save failed:', error);
            }
        }
    }

    newFile() {
        this.currentFile = null;
        this.editor.setValue('');
        this.isModified = false;
        this.updateFileStatus();

        this.dispatchEvent(new CustomEvent('newFile'));
    }

    // Code operations
    async formatCode() {
        try {
            const content = this.editor.getValue();
            const response = await window.api.post('/format', {
                code: content,
                language: this.currentLanguage
            });

            if (response.formatted_code) {
                this.editor.setValue(response.formatted_code);
                this.showSuccess('Code formatted successfully');
            }

        } catch (error) {
            console.error('Failed to format code:', error);
            this.showError('Failed to format code');
        }
    }

    async analyzeCode() {
        try {
            const content = this.editor.getValue();
            const response = await window.api.analyzeCode({
                code: content,
                language: this.currentLanguage
            });

            this.showAnalysisResults(response);

        } catch (error) {
            console.error('Failed to analyze code:', error);
            this.showError('Failed to analyze code');
        }
    }

    async generateCodeAtCursor() {
        const position = this.editor.getPosition();
        const selection = this.editor.getSelection();
        
        let prompt = '';
        if (!selection.isEmpty()) {
            prompt = this.editor.getModel().getValueInRange(selection);
        } else {
            // Get current line as context
            const line = this.editor.getModel().getLineContent(position.lineNumber);
            prompt = line.trim();
        }

        if (!prompt) {
            prompt = 'Generate code here';
        }

        try {
            const response = await window.api.generateCode({
                prompt: prompt,
                language: this.currentLanguage,
                context: {
                    existing_code: this.editor.getValue(),
                    cursor_position: position
                }
            });

            if (response.code) {
                this.insertCodeAtCursor(response.code);
            }

        } catch (error) {
            console.error('Failed to generate code:', error);
            this.showError('Failed to generate code');
        }
    }

    // Utility methods
    insertCodeAtCursor(code) {
        const position = this.editor.getPosition();
        this.editor.executeEdits('ai-insert', [{
            range: new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column),
            text: code
        }]);
    }

    setLanguage(language) {
        this.currentLanguage = language;
        monaco.editor.setModelLanguage(this.editor.getModel(), language);
        this.updateLanguageStatus();
    }

    detectLanguage(filePath) {
        const ext = filePath.split('.').pop().toLowerCase();
        const languageMap = {
            js: 'javascript',
            ts: 'typescript',
            py: 'python',
            go: 'go',
            java: 'java',
            cpp: 'cpp',
            c: 'c',
            cs: 'csharp',
            php: 'php',
            rb: 'ruby',
            rs: 'rust',
            swift: 'swift',
            kt: 'kotlin',
            scala: 'scala',
            html: 'html',
            css: 'css',
            json: 'json',
            xml: 'xml',
            yaml: 'yaml',
            yml: 'yaml',
            md: 'markdown',
            sql: 'sql'
        };
        return languageMap[ext] || 'text';
    }

    getSelectionLength() {
        const selection = this.editor.getSelection();
        if (selection.isEmpty()) return 0;
        
        const model = this.editor.getModel();
        return model.getValueInRange(selection).length;
    }

    updateFileStatus() {
        const fileStatus = document.getElementById('file-status');
        if (fileStatus) {
            const fileName = this.currentFile ? this.currentFile.name : 'Untitled';
            const modified = this.isModified ? ' •' : '';
            fileStatus.textContent = `${fileName}${modified}`;
        }
    }

    updateLanguageStatus() {
        const languageStatus = document.getElementById('language-status');
        if (languageStatus) {
            languageStatus.textContent = this.currentLanguage.toUpperCase();
        }
    }

    showAnalysisResults(results) {
        // Show analysis results in a panel or modal
        document.dispatchEvent(new CustomEvent('show-analysis', {
            detail: results
        }));
    }

    showSaveAsDialog() {
        document.dispatchEvent(new CustomEvent('show-save-dialog'));
    }

    showCommandPalette() {
        document.dispatchEvent(new CustomEvent('show-command-palette'));
    }

    showSuccess(message) {
        document.dispatchEvent(new CustomEvent('notification', {
            detail: { message, type: 'success', duration: 3000 }
        }));
    }

    showError(message) {
        document.dispatchEvent(new CustomEvent('notification', {
            detail: { message, type: 'error', duration: 5000 }
        }));
    }

    // Event handlers
    handleOpenFile(event) {
        const { filePath } = event.detail;
        this.openFile(filePath);
    }

    handleSaveFile(event) {
        this.saveFile();
    }

    handleNewFile(event) {
        this.newFile();
    }

    handleFormatCode(event) {
        this.formatCode();
    }

    handleAnalyzeCode(event) {
        this.analyzeCode();
    }

    handleGenerateCode(event) {
        this.generateCodeAtCursor();
    }

    handleThemeChange(event) {
        const { theme } = event.detail;
        const monacoTheme = theme === 'dark' ? 'ai-dark' : 'vs';
        monaco.editor.setTheme(monacoTheme);
    }

    handleLanguageChange() {
        this.currentLanguage = this.editor.getModel().getLanguageId();
        this.updateLanguageStatus();
    }

    handleBeforeUnload(event) {
        if (this.isModified) {
            event.preventDefault();
            event.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
        }
    }

    // Fallback to textarea if Monaco fails
    fallbackToTextarea() {
        const container = document.getElementById(this.containerId);
        container.innerHTML = `
            <textarea id="fallback-editor" 
                      placeholder="Code editor failed to load. Using fallback textarea..."
                      style="width: 100%; height: 100%; font-family: monospace; font-size: 14px; border: none; outline: none; resize: none; background: #1e1e1e; color: #d4d4d4; padding: 10px;">
            </textarea>
        `;

        const textarea = document.getElementById('fallback-editor');
        textarea.addEventListener('input', () => {
            this.handleContentChange();
        });

        this.editor = {
            getValue: () => textarea.value,
            setValue: (value) => { textarea.value = value; },
            getPosition: () => ({ lineNumber: 1, column: 1 }),
            getSelection: () => ({ isEmpty: () => true })
        };
    }

    // Public API
    getValue() {
        return this.editor.getValue();
    }

    setValue(value) {
        this.editor.setValue(value);
    }

    focus() {
        this.editor.focus();
    }

    dispose() {
        if (this.completionProvider) {
            this.completionProvider.dispose();
        }
        if (this.editor && this.editor.dispose) {
            this.editor.dispose();
        }
    }
}

// Export for use in other modules
window.CodeEditor = CodeEditor;
