/**
 * Chat Manager for AI Coding Agent
 * Handles chat interface and message management
 */

class ChatManager extends EventTarget {
    constructor(socket, api) {
        super();
        this.socket = socket;
        this.api = api;
        this.currentSessionId = null;
        this.messages = [];
        this.isTyping = false;
        this.messageHistory = [];
        this.historyIndex = -1;
        this.maxHistorySize = 100;
        this.autoScroll = true;
        this.messageQueue = [];
        this.isProcessing = false;
        
        this.init();
    }

    // Initialize chat manager
    init() {
        this.setupEventListeners();
        this.setupMessageInput();
        this.setupAutoComplete();
        this.loadChatHistory();
        
        console.log('Chat Manager initialized');
    }

    // Setup event listeners
    setupEventListeners() {
        // Socket events
        this.socket.addEventListener('chat_message', this.handleIncomingMessage.bind(this));
        this.socket.addEventListener('typing_start', this.handleTypingStart.bind(this));
        this.socket.addEventListener('typing_stop', this.handleTypingStop.bind(this));
        this.socket.addEventListener('message_status', this.handleMessageStatus.bind(this));
        
        // UI events
        document.addEventListener('send-message', this.handleSendMessage.bind(this));
        document.addEventListener('clear-chat', this.handleClearChat.bind(this));
        document.addEventListener('export-chat', this.handleExportChat.bind(this));
    }

    // Setup message input
    setupMessageInput() {
        const messageInput = document.getElementById('message-input');
        const sendButton = document.getElementById('send-message');
        
        if (!messageInput || !sendButton) return;

        // Input event handlers
        messageInput.addEventListener('keydown', this.handleInputKeyDown.bind(this));
        messageInput.addEventListener('input', this.handleInputChange.bind(this));
        messageInput.addEventListener('paste', this.handleInputPaste.bind(this));
        
        // Send button
        sendButton.addEventListener('click', this.sendCurrentMessage.bind(this));
        
        // Auto-resize textarea
        this.setupAutoResize(messageInput);
    }

    // Setup auto-complete functionality
    setupAutoComplete() {
        const messageInput = document.getElementById('message-input');
        if (!messageInput) return;

        // Common AI coding prompts
        this.autoCompleteOptions = [
            'Generate a function that',
            'Create a class for',
            'Write unit tests for',
            'Explain this code:',
            'Refactor this code:',
            'Debug this error:',
            'Optimize this function:',
            'Add documentation for',
            'Convert this code to',
            'Create an API endpoint for',
            'Write a SQL query to',
            'Generate a regex pattern for',
            'Create a React component for',
            'Write a Python script to',
            'Generate TypeScript interfaces for'
        ];

        // Setup autocomplete dropdown
        this.setupAutoCompleteDropdown(messageInput);
    }

    // Handle input keydown events
    handleInputKeyDown(e) {
        const messageInput = e.target;
        
        switch (e.key) {
            case 'Enter':
                if (!e.shiftKey) {
                    e.preventDefault();
                    this.sendCurrentMessage();
                }
                break;
                
            case 'ArrowUp':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.navigateHistory(-1);
                }
                break;
                
            case 'ArrowDown':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.navigateHistory(1);
                }
                break;
                
            case 'Tab':
                if (this.autoCompleteVisible) {
                    e.preventDefault();
                    this.selectAutoComplete();
                }
                break;
                
            case 'Escape':
                this.hideAutoComplete();
                break;
        }
    }

    // Handle input changes
    handleInputChange(e) {
        const messageInput = e.target;
        const value = messageInput.value;
        
        // Update character count
        this.updateCharacterCount(value.length);
        
        // Auto-resize
        this.autoResize(messageInput);
        
        // Show/hide autocomplete
        this.updateAutoComplete(value);
        
        // Send typing indicator
        this.sendTypingIndicator();
    }

    // Handle paste events
    handleInputPaste(e) {
        const items = e.clipboardData.items;
        
        for (let item of items) {
            if (item.type.indexOf('image') !== -1) {
                e.preventDefault();
                const file = item.getAsFile();
                this.handleImagePaste(file);
                break;
            }
        }
    }

    // Send current message
    async sendCurrentMessage() {
        const messageInput = document.getElementById('message-input');
        const message = messageInput.value.trim();
        
        if (!message || this.isProcessing) return;

        try {
            this.isProcessing = true;
            
            // Clear input
            messageInput.value = '';
            this.autoResize(messageInput);
            this.updateCharacterCount(0);
            
            // Add to history
            this.addToHistory(message);
            
            // Create user message
            const userMessage = {
                id: this.generateMessageId(),
                role: 'user',
                content: message,
                timestamp: new Date(),
                status: 'sending'
            };
            
            // Add to UI
            this.addMessage(userMessage);
            
            // Send to server
            if (this.socket.isReady()) {
                const response = await this.socket.sendChatMessage(message, this.currentSessionId);
                userMessage.status = 'sent';
                this.updateMessageStatus(userMessage.id, 'sent');
            } else {
                // Fallback to API
                const response = await this.api.sendMessage(this.currentSessionId, message);
                userMessage.status = 'sent';
                this.updateMessageStatus(userMessage.id, 'sent');
                
                // Add AI response
                if (response.reply) {
                    this.handleIncomingMessage({ detail: response.reply });
                }
            }
            
        } catch (error) {
            console.error('Failed to send message:', error);
            this.showError('Failed to send message. Please try again.');
        } finally {
            this.isProcessing = false;
        }
    }

    // Handle incoming messages
    handleIncomingMessage(event) {
        const messageData = event.detail;
        
        const message = {
            id: messageData.id || this.generateMessageId(),
            role: 'assistant',
            content: messageData.content || messageData.message,
            timestamp: new Date(messageData.timestamp || Date.now()),
            status: 'received',
            metadata: messageData.metadata || {}
        };
        
        this.addMessage(message);
        this.dispatchEvent(new CustomEvent('messageReceived', { detail: message }));
    }

    // Add message to chat
    addMessage(message) {
        this.messages.push(message);
        this.renderMessage(message);
        
        if (this.autoScroll) {
            this.scrollToBottom();
        }
        
        // Save to local storage
        this.saveChatHistory();
    }

    // Render message in UI
    renderMessage(message) {
        const chatContainer = document.getElementById('chat-messages');
        if (!chatContainer) return;

        const messageElement = document.createElement('div');
        messageElement.className = `message message-${message.role}`;
        messageElement.dataset.messageId = message.id;
        
        messageElement.innerHTML = `
            <div class="message-header">
                <div class="message-avatar">
                    <i class="fas ${message.role === 'user' ? 'fa-user' : 'fa-robot'}"></i>
                </div>
                <div class="message-info">
                    <span class="message-sender">${message.role === 'user' ? 'You' : 'AI Assistant'}</span>
                    <span class="message-time">${this.formatTime(message.timestamp)}</span>
                    <span class="message-status ${message.status}">${this.getStatusIcon(message.status)}</span>
                </div>
                <div class="message-actions">
                    <button class="btn-icon" onclick="chat.copyMessage('${message.id}')" title="Copy">
                        <i class="fas fa-copy"></i>
                    </button>
                    ${message.role === 'assistant' ? `
                        <button class="btn-icon" onclick="chat.regenerateMessage('${message.id}')" title="Regenerate">
                            <i class="fas fa-redo"></i>
                        </button>
                    ` : ''}
                    <button class="btn-icon" onclick="chat.deleteMessage('${message.id}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="message-content">
                ${this.renderMessageContent(message.content, message.metadata)}
            </div>
        `;

        chatContainer.appendChild(messageElement);
        
        // Animate in
        setTimeout(() => messageElement.classList.add('show'), 10);
    }

    // Render message content with syntax highlighting
    renderMessageContent(content, metadata = {}) {
        // Check if content contains code blocks
        const codeBlockRegex = /```(\w+)?\n([\s\S]*?)\n```/g;
        
        let renderedContent = content;
        
        // Replace code blocks with highlighted versions
        renderedContent = renderedContent.replace(codeBlockRegex, (match, language, code) => {
            const lang = language || 'text';
            const highlightedCode = this.highlightCode(code, lang);
            
            return `
                <div class="code-block">
                    <div class="code-header">
                        <span class="code-language">${lang}</span>
                        <button class="btn-icon" onclick="chat.copyCode(this)" title="Copy Code">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                    <pre><code class="language-${lang}">${highlightedCode}</code></pre>
                </div>
            `;
        });
        
        // Replace inline code
        renderedContent = renderedContent.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
        
        // Convert URLs to links
        renderedContent = renderedContent.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
        
        // Convert newlines to <br>
        renderedContent = renderedContent.replace(/\n/g, '<br>');
        
        return renderedContent;
    }

    // Highlight code using a simple syntax highlighter
    highlightCode(code, language) {
        // This is a simplified highlighter - in production, use Prism.js or similar
        const keywords = {
            javascript: ['function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return'],
            python: ['def', 'class', 'if', 'elif', 'else', 'for', 'while', 'return', 'import'],
            go: ['func', 'var', 'const', 'if', 'else', 'for', 'range', 'return', 'package'],
            java: ['public', 'private', 'class', 'interface', 'if', 'else', 'for', 'while', 'return']
        };
        
        let highlighted = code;
        
        if (keywords[language]) {
            keywords[language].forEach(keyword => {
                const regex = new RegExp(`\\b${keyword}\\b`, 'g');
                highlighted = highlighted.replace(regex, `<span class="keyword">${keyword}</span>`);
            });
        }
        
        return highlighted;
    }

    // Message actions
    copyMessage(messageId) {
        const message = this.messages.find(m => m.id === messageId);
        if (message) {
            navigator.clipboard.writeText(message.content);
            this.showSuccess('Message copied to clipboard');
        }
    }

    copyCode(button) {
        const codeBlock = button.closest('.code-block');
        const code = codeBlock.querySelector('code').textContent;
        navigator.clipboard.writeText(code);
        this.showSuccess('Code copied to clipboard');
    }

    async regenerateMessage(messageId) {
        const messageIndex = this.messages.findIndex(m => m.id === messageId);
        if (messageIndex === -1) return;
        
        // Find the user message that prompted this response
        const userMessage = this.messages[messageIndex - 1];
        if (!userMessage || userMessage.role !== 'user') return;
        
        try {
            // Remove the AI message
            this.deleteMessage(messageId);
            
            // Resend the user message
            const response = await this.socket.sendChatMessage(userMessage.content, this.currentSessionId);
            
        } catch (error) {
            console.error('Failed to regenerate message:', error);
            this.showError('Failed to regenerate message');
        }
    }

    deleteMessage(messageId) {
        const messageIndex = this.messages.findIndex(m => m.id === messageId);
        if (messageIndex !== -1) {
            this.messages.splice(messageIndex, 1);
            
            const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
            if (messageElement) {
                messageElement.remove();
            }
            
            this.saveChatHistory();
        }
    }

    // History management
    addToHistory(message) {
        this.messageHistory.unshift(message);
        if (this.messageHistory.length > this.maxHistorySize) {
            this.messageHistory.pop();
        }
        this.historyIndex = -1;
    }

    navigateHistory(direction) {
        const messageInput = document.getElementById('message-input');
        if (!messageInput) return;

        this.historyIndex += direction;
        
        if (this.historyIndex < -1) {
            this.historyIndex = -1;
        } else if (this.historyIndex >= this.messageHistory.length) {
            this.historyIndex = this.messageHistory.length - 1;
        }
        
        if (this.historyIndex === -1) {
            messageInput.value = '';
        } else {
            messageInput.value = this.messageHistory[this.historyIndex];
        }
        
        this.autoResize(messageInput);
    }

    // Auto-complete functionality
    setupAutoCompleteDropdown(input) {
        const dropdown = document.createElement('div');
        dropdown.className = 'autocomplete-dropdown hidden';
        dropdown.id = 'autocomplete-dropdown';
        input.parentNode.appendChild(dropdown);
        
        this.autoCompleteDropdown = dropdown;
        this.autoCompleteVisible = false;
    }

    updateAutoComplete(value) {
        if (value.length < 2) {
            this.hideAutoComplete();
            return;
        }
        
        const matches = this.autoCompleteOptions.filter(option =>
            option.toLowerCase().includes(value.toLowerCase())
        );
        
        if (matches.length === 0) {
            this.hideAutoComplete();
            return;
        }
        
        this.showAutoComplete(matches);
    }

    showAutoComplete(options) {
        const dropdown = this.autoCompleteDropdown;
        
        dropdown.innerHTML = options.map((option, index) => `
            <div class="autocomplete-option ${index === 0 ? 'selected' : ''}" data-option="${option}">
                ${option}
            </div>
        `).join('');
        
        dropdown.classList.remove('hidden');
        this.autoCompleteVisible = true;
        
        // Add click handlers
        dropdown.addEventListener('click', (e) => {
            const option = e.target.closest('.autocomplete-option');
            if (option) {
                this.selectAutoCompleteOption(option.dataset.option);
            }
        });
    }

    hideAutoComplete() {
        if (this.autoCompleteDropdown) {
            this.autoCompleteDropdown.classList.add('hidden');
            this.autoCompleteVisible = false;
        }
    }

    selectAutoComplete() {
        const selected = this.autoCompleteDropdown.querySelector('.autocomplete-option.selected');
        if (selected) {
            this.selectAutoCompleteOption(selected.dataset.option);
        }
    }

    selectAutoCompleteOption(option) {
        const messageInput = document.getElementById('message-input');
        messageInput.value = option;
        messageInput.focus();
        this.hideAutoComplete();
        this.autoResize(messageInput);
    }

    // Utility methods
    generateMessageId() {
        return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    getStatusIcon(status) {
        const icons = {
            sending: '<i class="fas fa-clock"></i>',
            sent: '<i class="fas fa-check"></i>',
            received: '<i class="fas fa-check-double"></i>',
            error: '<i class="fas fa-exclamation-triangle"></i>'
        };
        return icons[status] || '';
    }

    updateCharacterCount(count) {
        const counter = document.getElementById('char-count');
        if (counter) {
            counter.textContent = `${count} / 4000`;
        }
    }

    autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }

    setupAutoResize(textarea) {
        textarea.addEventListener('input', () => this.autoResize(textarea));
    }

    scrollToBottom() {
        const chatContainer = document.getElementById('chat-messages');
        if (chatContainer) {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    }

    updateMessageStatus(messageId, status) {
        const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
        if (messageElement) {
            const statusElement = messageElement.querySelector('.message-status');
            statusElement.innerHTML = this.getStatusIcon(status);
            statusElement.className = `message-status ${status}`;
        }
    }

    sendTypingIndicator() {
        if (!this.isTyping) {
            this.isTyping = true;
            this.socket.send('typing_start', { session_id: this.currentSessionId });
            
            // Stop typing after 3 seconds of inactivity
            clearTimeout(this.typingTimeout);
            this.typingTimeout = setTimeout(() => {
                this.isTyping = false;
                this.socket.send('typing_stop', { session_id: this.currentSessionId });
            }, 3000);
        }
    }

    handleTypingStart(event) {
        this.dispatchEvent(new CustomEvent('typingStart'));
    }

    handleTypingStop(event) {
        this.dispatchEvent(new CustomEvent('typingStop'));
    }

    handleMessageStatus(event) {
        const { messageId, status } = event.detail;
        this.updateMessageStatus(messageId, status);
    }

    handleImagePaste(file) {
        // Handle image paste - upload and include in message
        console.log('Image pasted:', file);
        // Implementation would upload image and include reference
    }

    // Chat management
    clearChat() {
        this.messages = [];
        const chatContainer = document.getElementById('chat-messages');
        if (chatContainer) {
            chatContainer.innerHTML = '';
        }
        this.saveChatHistory();
    }

    exportChat() {
        const chatData = {
            sessionId: this.currentSessionId,
            messages: this.messages,
            exportedAt: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `chat-export-${Date.now()}.json`;
        a.click();
        
        URL.revokeObjectURL(url);
    }

    saveChatHistory() {
        localStorage.setItem(`chat-${this.currentSessionId}`, JSON.stringify(this.messages));
    }

    loadChatHistory() {
        if (this.currentSessionId) {
            const saved = localStorage.getItem(`chat-${this.currentSessionId}`);
            if (saved) {
                try {
                    this.messages = JSON.parse(saved);
                    this.renderAllMessages();
                } catch (error) {
                    console.warn('Failed to load chat history:', error);
                }
            }
        }
    }

    renderAllMessages() {
        const chatContainer = document.getElementById('chat-messages');
        if (chatContainer) {
            chatContainer.innerHTML = '';
            this.messages.forEach(message => this.renderMessage(message));
            this.scrollToBottom();
        }
    }

    setSession(sessionId) {
        this.currentSessionId = sessionId;
        this.loadChatHistory();
    }

    showSuccess(message) {
        document.dispatchEvent(new CustomEvent('notification', {
            detail: { message, type: 'success', duration: 3000 }
        }));
    }

    showError(message) {
        document.dispatchEvent(new CustomEvent('notification', {
            detail: { message, type: 'error', duration: 5000 }
        }));
    }

    // Event handlers
    handleSendMessage(event) {
        this.sendCurrentMessage();
    }

    handleClearChat(event) {
        this.clearChat();
    }

    handleExportChat(event) {
        this.exportChat();
    }
}

// Export for use in other modules
window.ChatManager = ChatManager;
