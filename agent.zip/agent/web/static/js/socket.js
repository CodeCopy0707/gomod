/**
 * WebSocket Manager for AI Coding Agent
 * Handles real-time communication with the backend
 */

class SocketManager extends EventTarget {
    constructor(url = '/ws') {
        super();
        this.url = url;
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.heartbeatInterval = 30000;
        this.heartbeatTimer = null;
        this.isConnecting = false;
        this.isConnected = false;
        this.messageQueue = [];
        this.subscriptions = new Map();
        this.requestCallbacks = new Map();
        this.requestId = 0;
    }

    // Connect to WebSocket
    async connect() {
        if (this.isConnecting || this.isConnected) {
            return;
        }

        this.isConnecting = true;
        
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}${this.url}`;
            
            this.socket = new WebSocket(wsUrl);
            this.setupEventListeners();
            
            // Wait for connection to open
            await new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('Connection timeout'));
                }, 10000);

                this.socket.addEventListener('open', () => {
                    clearTimeout(timeout);
                    resolve();
                });

                this.socket.addEventListener('error', (error) => {
                    clearTimeout(timeout);
                    reject(error);
                });
            });

        } catch (error) {
            this.isConnecting = false;
            throw error;
        }
    }

    // Setup WebSocket event listeners
    setupEventListeners() {
        this.socket.addEventListener('open', this.handleOpen.bind(this));
        this.socket.addEventListener('message', this.handleMessage.bind(this));
        this.socket.addEventListener('close', this.handleClose.bind(this));
        this.socket.addEventListener('error', this.handleError.bind(this));
    }

    // Handle connection open
    handleOpen() {
        console.log('WebSocket connected');
        this.isConnecting = false;
        this.isConnected = true;
        this.reconnectAttempts = 0;
        
        // Start heartbeat
        this.startHeartbeat();
        
        // Send queued messages
        this.flushMessageQueue();
        
        // Emit connect event
        this.dispatchEvent(new CustomEvent('connect'));
    }

    // Handle incoming messages
    handleMessage(event) {
        try {
            const data = JSON.parse(event.data);
            this.processMessage(data);
        } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
        }
    }

    // Process incoming message
    processMessage(data) {
        const { type, id, payload, error } = data;

        // Handle response to request
        if (id && this.requestCallbacks.has(id)) {
            const callback = this.requestCallbacks.get(id);
            this.requestCallbacks.delete(id);
            
            if (error) {
                callback.reject(new Error(error));
            } else {
                callback.resolve(payload);
            }
            return;
        }

        // Handle subscription messages
        if (this.subscriptions.has(type)) {
            const handlers = this.subscriptions.get(type);
            handlers.forEach(handler => {
                try {
                    handler(payload);
                } catch (error) {
                    console.error(`Error in subscription handler for ${type}:`, error);
                }
            });
        }

        // Emit generic message event
        this.dispatchEvent(new CustomEvent('message', { detail: data }));

        // Handle specific message types
        switch (type) {
            case 'heartbeat':
                this.handleHeartbeat(payload);
                break;
            case 'chat_message':
                this.handleChatMessage(payload);
                break;
            case 'code_generation':
                this.handleCodeGeneration(payload);
                break;
            case 'file_change':
                this.handleFileChange(payload);
                break;
            case 'system_notification':
                this.handleSystemNotification(payload);
                break;
            case 'error':
                this.handleServerError(payload);
                break;
        }
    }

    // Handle connection close
    handleClose(event) {
        console.log('WebSocket disconnected:', event.code, event.reason);
        this.isConnected = false;
        this.stopHeartbeat();
        
        // Emit disconnect event
        this.dispatchEvent(new CustomEvent('disconnect', { 
            detail: { code: event.code, reason: event.reason }
        }));

        // Attempt reconnection if not intentional
        if (event.code !== 1000 && this.reconnectAttempts < this.maxReconnectAttempts) {
            this.scheduleReconnect();
        }
    }

    // Handle connection error
    handleError(error) {
        console.error('WebSocket error:', error);
        this.dispatchEvent(new CustomEvent('error', { detail: error }));
    }

    // Schedule reconnection
    scheduleReconnect() {
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);
        
        setTimeout(() => {
            if (!this.isConnected) {
                this.connect().catch(error => {
                    console.error('Reconnection failed:', error);
                });
            }
        }, delay);
    }

    // Start heartbeat
    startHeartbeat() {
        this.heartbeatTimer = setInterval(() => {
            this.send('heartbeat', { timestamp: Date.now() });
        }, this.heartbeatInterval);
    }

    // Stop heartbeat
    stopHeartbeat() {
        if (this.heartbeatTimer) {
            clearInterval(this.heartbeatTimer);
            this.heartbeatTimer = null;
        }
    }

    // Send message
    send(type, payload = {}, requestResponse = false) {
        const message = {
            type,
            payload,
            timestamp: Date.now()
        };

        if (requestResponse) {
            message.id = ++this.requestId;
            
            return new Promise((resolve, reject) => {
                this.requestCallbacks.set(message.id, { resolve, reject });
                
                // Set timeout for request
                setTimeout(() => {
                    if (this.requestCallbacks.has(message.id)) {
                        this.requestCallbacks.delete(message.id);
                        reject(new Error('Request timeout'));
                    }
                }, 30000);
                
                this.sendMessage(message);
            });
        } else {
            this.sendMessage(message);
        }
    }

    // Send message to WebSocket
    sendMessage(message) {
        if (this.isConnected && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(message));
        } else {
            // Queue message for later
            this.messageQueue.push(message);
        }
    }

    // Flush queued messages
    flushMessageQueue() {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            this.sendMessage(message);
        }
    }

    // Subscribe to message type
    subscribe(type, handler) {
        if (!this.subscriptions.has(type)) {
            this.subscriptions.set(type, new Set());
        }
        this.subscriptions.get(type).add(handler);

        // Return unsubscribe function
        return () => {
            const handlers = this.subscriptions.get(type);
            if (handlers) {
                handlers.delete(handler);
                if (handlers.size === 0) {
                    this.subscriptions.delete(type);
                }
            }
        };
    }

    // Unsubscribe from message type
    unsubscribe(type, handler) {
        const handlers = this.subscriptions.get(type);
        if (handlers) {
            handlers.delete(handler);
            if (handlers.size === 0) {
                this.subscriptions.delete(type);
            }
        }
    }

    // Disconnect WebSocket
    disconnect() {
        if (this.socket) {
            this.socket.close(1000, 'Client disconnect');
        }
        this.stopHeartbeat();
        this.isConnected = false;
        this.isConnecting = false;
    }

    // Message handlers
    handleHeartbeat(payload) {
        // Respond to server heartbeat
        this.send('heartbeat_response', { timestamp: Date.now() });
    }

    handleChatMessage(payload) {
        this.dispatchEvent(new CustomEvent('chat_message', { detail: payload }));
    }

    handleCodeGeneration(payload) {
        this.dispatchEvent(new CustomEvent('code_generation', { detail: payload }));
    }

    handleFileChange(payload) {
        this.dispatchEvent(new CustomEvent('file_change', { detail: payload }));
    }

    handleSystemNotification(payload) {
        this.dispatchEvent(new CustomEvent('system_notification', { detail: payload }));
    }

    handleServerError(payload) {
        this.dispatchEvent(new CustomEvent('server_error', { detail: payload }));
    }

    // High-level API methods
    async sendChatMessage(message, sessionId) {
        return this.send('chat_message', { message, session_id: sessionId }, true);
    }

    async requestCodeGeneration(prompt, language, context = {}) {
        return this.send('code_generation', { prompt, language, context }, true);
    }

    async requestCodeAnalysis(code, language) {
        return this.send('code_analysis', { code, language }, true);
    }

    async requestFileOperation(operation, path, data = {}) {
        return this.send('file_operation', { operation, path, ...data }, true);
    }

    // Utility methods
    getConnectionState() {
        if (!this.socket) return 'disconnected';
        
        switch (this.socket.readyState) {
            case WebSocket.CONNECTING:
                return 'connecting';
            case WebSocket.OPEN:
                return 'connected';
            case WebSocket.CLOSING:
                return 'closing';
            case WebSocket.CLOSED:
                return 'disconnected';
            default:
                return 'unknown';
        }
    }

    isReady() {
        return this.isConnected && this.socket.readyState === WebSocket.OPEN;
    }

    getQueuedMessageCount() {
        return this.messageQueue.length;
    }

    getActiveSubscriptions() {
        return Array.from(this.subscriptions.keys());
    }

    // Event listener helpers
    on(event, handler) {
        this.addEventListener(event, handler);
        return () => this.removeEventListener(event, handler);
    }

    once(event, handler) {
        const wrapper = (e) => {
            handler(e);
            this.removeEventListener(event, wrapper);
        };
        this.addEventListener(event, wrapper);
    }

    off(event, handler) {
        this.removeEventListener(event, handler);
    }
}

// Export for use in other modules
window.SocketManager = SocketManager;
