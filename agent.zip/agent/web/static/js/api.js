/**
 * API Client for AI Coding Agent
 * Handles all HTTP requests to the backend API
 */

class APIClient {
    constructor(baseUrl = '/api') {
        this.baseUrl = baseUrl;
        this.token = localStorage.getItem('auth_token');
        this.requestId = 0;
    }

    // Set authentication token
    setToken(token) {
        this.token = token;
        localStorage.setItem('auth_token', token);
    }

    // Clear authentication token
    clearToken() {
        this.token = null;
        localStorage.removeItem('auth_token');
    }

    // Generate request headers
    getHeaders(contentType = 'application/json') {
        const headers = {
            'Content-Type': contentType,
            'X-Request-ID': `req_${++this.requestId}_${Date.now()}`
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        return headers;
    }

    // Generic request method
    async request(method, endpoint, data = null, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const config = {
            method,
            headers: this.getHeaders(options.contentType),
            ...options
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            if (config.headers['Content-Type'] === 'application/json') {
                config.body = JSON.stringify(data);
            } else {
                config.body = data;
            }
        }

        try {
            const response = await fetch(url, config);
            
            // Handle rate limiting
            if (response.status === 429) {
                const retryAfter = response.headers.get('Retry-After') || 60;
                throw new APIError('Rate limit exceeded', 429, { retryAfter });
            }

            // Handle authentication errors
            if (response.status === 401) {
                this.clearToken();
                throw new APIError('Authentication required', 401);
            }

            const responseData = await response.json();

            if (!response.ok) {
                throw new APIError(
                    responseData.error?.message || 'Request failed',
                    response.status,
                    responseData.error
                );
            }

            return responseData;
        } catch (error) {
            if (error instanceof APIError) {
                throw error;
            }
            throw new APIError('Network error', 0, { originalError: error });
        }
    }

    // GET request
    async get(endpoint, params = {}) {
        const url = new URL(`${this.baseUrl}${endpoint}`, window.location.origin);
        Object.keys(params).forEach(key => {
            if (params[key] !== undefined && params[key] !== null) {
                url.searchParams.append(key, params[key]);
            }
        });
        
        return this.request('GET', url.pathname + url.search);
    }

    // POST request
    async post(endpoint, data) {
        return this.request('POST', endpoint, data);
    }

    // PUT request
    async put(endpoint, data) {
        return this.request('PUT', endpoint, data);
    }

    // DELETE request
    async delete(endpoint) {
        return this.request('DELETE', endpoint);
    }

    // Health check
    async health() {
        return this.get('/health');
    }

    // Code generation
    async generateCode(request) {
        return this.post('/generate', request);
    }

    // Code analysis
    async analyzeCode(request) {
        return this.post('/analyze', request);
    }

    // Code refactoring
    async refactorCode(request) {
        return this.post('/refactor', request);
    }

    // Test generation
    async generateTests(request) {
        return this.post('/generate-tests', request);
    }

    // Documentation generation
    async generateDocs(request) {
        return this.post('/generate-docs', request);
    }

    // File operations
    async listFiles(path = '', recursive = false, filter = '') {
        return this.get('/files', { path, recursive, filter });
    }

    async getFile(path) {
        return this.get(`/files/${encodeURIComponent(path)}`);
    }

    async saveFile(path, content, encoding = 'utf-8') {
        return this.post(`/files/${encodeURIComponent(path)}`, { content, encoding });
    }

    async deleteFile(path) {
        return this.delete(`/files/${encodeURIComponent(path)}`);
    }

    // Terminal operations
    async executeCommand(command, args = [], workingDir = '', timeout = 30) {
        return this.post('/terminal/execute', {
            command,
            args,
            working_dir: workingDir,
            timeout
        });
    }

    // AI provider management
    async getProviders() {
        return this.get('/providers');
    }

    async switchProvider(provider, model) {
        return this.post('/providers/switch', { provider, model });
    }

    // Session management
    async getSessions() {
        return this.get('/sessions');
    }

    async createSession(userId, context = {}) {
        return this.post('/sessions', { user_id: userId, context });
    }

    async getSessionMessages(sessionId) {
        return this.get(`/sessions/${sessionId}/messages`);
    }

    async sendMessage(sessionId, message, context = {}) {
        return this.post(`/sessions/${sessionId}/messages`, { message, context });
    }

    // Analytics
    async getMetrics() {
        return this.get('/analytics/metrics');
    }

    async getUsage(period = 'day', startDate = null, endDate = null) {
        const params = { period };
        if (startDate) params.start_date = startDate;
        if (endDate) params.end_date = endDate;
        return this.get('/analytics/usage', params);
    }

    // Language operations
    async getSupportedLanguages() {
        return this.get('/languages');
    }

    async translateCode(request) {
        return this.post('/languages/translate', request);
    }

    async detectLanguage(filename, content) {
        return this.post('/languages/detect', { filename, content });
    }

    // Search operations
    async searchWeb(query, language = '') {
        return this.post('/search/web', { query, language });
    }

    async lookupDocumentation(library, function_name, language) {
        return this.post('/search/docs', { library, function: function_name, language });
    }

    // Upload file
    async uploadFile(file, onProgress = null) {
        const formData = new FormData();
        formData.append('file', file);

        const config = {
            contentType: null, // Let browser set content type for FormData
        };

        if (onProgress) {
            config.onUploadProgress = onProgress;
        }

        return this.request('POST', '/files/upload', formData, config);
    }

    // Batch operations
    async batchRequest(requests) {
        return this.post('/batch', { requests });
    }

    // Streaming requests (for real-time responses)
    async streamRequest(endpoint, data, onChunk, onComplete, onError) {
        const url = `${this.baseUrl}${endpoint}`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify({ ...data, stream: true })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();

            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    onComplete?.();
                    break;
                }

                const chunk = decoder.decode(value, { stream: true });
                const lines = chunk.split('\n').filter(line => line.trim());

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            onChunk?.(data);
                        } catch (e) {
                            console.warn('Failed to parse streaming data:', line);
                        }
                    }
                }
            }
        } catch (error) {
            onError?.(error);
        }
    }

    // WebSocket connection helper
    createWebSocket(endpoint = '/ws') {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}${endpoint}`;
        
        const ws = new WebSocket(wsUrl);
        
        // Add authentication if token exists
        ws.addEventListener('open', () => {
            if (this.token) {
                ws.send(JSON.stringify({
                    type: 'auth',
                    token: this.token
                }));
            }
        });

        return ws;
    }
}

// Custom error class for API errors
class APIError extends Error {
    constructor(message, status, details = {}) {
        super(message);
        this.name = 'APIError';
        this.status = status;
        this.details = details;
    }

    get isNetworkError() {
        return this.status === 0;
    }

    get isAuthError() {
        return this.status === 401 || this.status === 403;
    }

    get isRateLimited() {
        return this.status === 429;
    }

    get isServerError() {
        return this.status >= 500;
    }
}

// Request interceptor for adding common headers or handling responses
class RequestInterceptor {
    constructor(apiClient) {
        this.apiClient = apiClient;
        this.requestInterceptors = [];
        this.responseInterceptors = [];
    }

    addRequestInterceptor(interceptor) {
        this.requestInterceptors.push(interceptor);
    }

    addResponseInterceptor(interceptor) {
        this.responseInterceptors.push(interceptor);
    }

    async processRequest(config) {
        for (const interceptor of this.requestInterceptors) {
            config = await interceptor(config);
        }
        return config;
    }

    async processResponse(response) {
        for (const interceptor of this.responseInterceptors) {
            response = await interceptor(response);
        }
        return response;
    }
}

// Cache for API responses
class APICache {
    constructor(maxSize = 100, ttl = 5 * 60 * 1000) { // 5 minutes default TTL
        this.cache = new Map();
        this.maxSize = maxSize;
        this.ttl = ttl;
    }

    get(key) {
        const item = this.cache.get(key);
        if (!item) return null;

        if (Date.now() > item.expiry) {
            this.cache.delete(key);
            return null;
        }

        return item.data;
    }

    set(key, data) {
        if (this.cache.size >= this.maxSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
        }

        this.cache.set(key, {
            data,
            expiry: Date.now() + this.ttl
        });
    }

    clear() {
        this.cache.clear();
    }

    delete(key) {
        this.cache.delete(key);
    }
}

// Export for use in other modules
window.APIClient = APIClient;
window.APIError = APIError;
window.RequestInterceptor = RequestInterceptor;
window.APICache = APICache;
