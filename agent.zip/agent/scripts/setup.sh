#!/bin/bash

# AI Coding Agent Setup Script
# This script sets up the development environment and installs dependencies

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check version
check_version() {
    local cmd=$1
    local min_version=$2
    local current_version=$($cmd --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1)
    
    if [ -z "$current_version" ]; then
        return 1
    fi
    
    # Simple version comparison (works for most cases)
    if [ "$(printf '%s\n' "$min_version" "$current_version" | sort -V | head -n1)" = "$min_version" ]; then
        return 0
    else
        return 1
    fi
}

print_status "Starting AI Coding Agent setup..."

# Check operating system
OS="$(uname -s)"
case "${OS}" in
    Linux*)     MACHINE=Linux;;
    Darwin*)    MACHINE=Mac;;
    CYGWIN*)    MACHINE=Cygwin;;
    MINGW*)     MACHINE=MinGw;;
    *)          MACHINE="UNKNOWN:${OS}"
esac

print_status "Detected operating system: $MACHINE"

# Check and install Go
print_status "Checking Go installation..."
if command_exists go; then
    if check_version "go version" "1.21"; then
        print_success "Go $(go version | grep -oE 'go[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1) is installed"
    else
        print_warning "Go version is too old. Please upgrade to Go 1.21 or later"
        exit 1
    fi
else
    print_error "Go is not installed. Please install Go 1.21 or later from https://golang.org/dl/"
    exit 1
fi

# Check and install Node.js
print_status "Checking Node.js installation..."
if command_exists node; then
    if check_version "node" "18.0.0"; then
        print_success "Node.js $(node --version) is installed"
    else
        print_warning "Node.js version is too old. Please upgrade to Node.js 18 or later"
        exit 1
    fi
else
    print_error "Node.js is not installed. Please install Node.js 18 or later from https://nodejs.org/"
    exit 1
fi

# Check and install Python
print_status "Checking Python installation..."
if command_exists python3; then
    if check_version "python3" "3.9.0"; then
        print_success "Python $(python3 --version | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?') is installed"
    else
        print_warning "Python version is too old. Please upgrade to Python 3.9 or later"
        exit 1
    fi
else
    print_error "Python 3 is not installed. Please install Python 3.9 or later"
    exit 1
fi

# Create necessary directories
print_status "Creating project directories..."
mkdir -p data
mkdir -p logs
mkdir -p backups
mkdir -p temp
mkdir -p cache
print_success "Directories created"

# Copy environment file
print_status "Setting up environment configuration..."
if [ ! -f .env ]; then
    cp .env.example .env
    print_success "Environment file created from template"
    print_warning "Please edit .env file with your API keys and configuration"
else
    print_warning ".env file already exists, skipping..."
fi

# Install Go dependencies
print_status "Installing Go dependencies..."
if go mod download; then
    print_success "Go dependencies installed"
else
    print_error "Failed to install Go dependencies"
    exit 1
fi

# Install Node.js dependencies
print_status "Installing Node.js dependencies..."
if npm install; then
    print_success "Node.js dependencies installed"
else
    print_error "Failed to install Node.js dependencies"
    exit 1
fi

# Install Python dependencies
print_status "Installing Python dependencies..."
if python3 -m pip install -r requirements.txt; then
    print_success "Python dependencies installed"
else
    print_error "Failed to install Python dependencies"
    exit 1
fi

# Build the Go application
print_status "Building Go application..."
if go build -o bin/agent main.go; then
    print_success "Go application built successfully"
else
    print_error "Failed to build Go application"
    exit 1
fi

# Set up Git hooks (if in a Git repository)
if [ -d .git ]; then
    print_status "Setting up Git hooks..."
    if [ -f scripts/git-hooks/pre-commit ]; then
        cp scripts/git-hooks/pre-commit .git/hooks/
        chmod +x .git/hooks/pre-commit
        print_success "Git hooks installed"
    fi
fi

# Install optional tools
print_status "Checking optional tools..."

# Check for code formatters
if command_exists black; then
    print_success "Black (Python formatter) is available"
else
    print_warning "Black (Python formatter) not found. Install with: pip install black"
fi

if command_exists gofmt; then
    print_success "gofmt (Go formatter) is available"
else
    print_warning "gofmt not found (should come with Go installation)"
fi

if command_exists prettier; then
    print_success "Prettier (JavaScript formatter) is available"
else
    print_warning "Prettier not found. Install with: npm install -g prettier"
fi

# Check for linters
if command_exists pylint; then
    print_success "Pylint (Python linter) is available"
else
    print_warning "Pylint not found. Install with: pip install pylint"
fi

if command_exists eslint; then
    print_success "ESLint (JavaScript linter) is available"
else
    print_warning "ESLint not found. Install with: npm install -g eslint"
fi

# Check for Git
if command_exists git; then
    print_success "Git is available"
else
    print_warning "Git not found. Some features may not work properly"
fi

# Check for Docker (optional)
if command_exists docker; then
    print_success "Docker is available"
else
    print_warning "Docker not found. Container features will not be available"
fi

# Run initial tests
print_status "Running initial tests..."
if go test ./...; then
    print_success "Go tests passed"
else
    print_warning "Some Go tests failed"
fi

if npm test; then
    print_success "Node.js tests passed"
else
    print_warning "Some Node.js tests failed"
fi

# Create startup script
print_status "Creating startup script..."
cat > start.sh << 'EOF'
#!/bin/bash
# AI Coding Agent Startup Script

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Start the agent
./bin/agent "$@"
EOF

chmod +x start.sh
print_success "Startup script created"

# Final setup verification
print_status "Verifying setup..."
if [ -f bin/agent ] && [ -f .env ] && [ -d data ]; then
    print_success "Setup verification passed"
else
    print_error "Setup verification failed"
    exit 1
fi

print_success "Setup completed successfully!"
echo
print_status "Next steps:"
echo "1. Edit the .env file with your API keys"
echo "2. Review and modify config/agent.yaml if needed"
echo "3. Run './start.sh' to start the agent"
echo "4. Run './start.sh --web' to start with web interface"
echo "5. Run './start.sh --help' to see all options"
echo
print_status "For more information, see the README.md file"
