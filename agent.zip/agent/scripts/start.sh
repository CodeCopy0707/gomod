#!/bin/bash

# AI Coding Agent Start Script
# This script starts the AI coding agent with proper environment setup

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
show_usage() {
    echo "AI Coding Agent - Advanced AI-powered coding assistant"
    echo
    echo "Usage: $0 [OPTIONS] [COMMAND]"
    echo
    echo "Options:"
    echo "  -h, --help              Show this help message"
    echo "  -v, --version           Show version information"
    echo "  -c, --config FILE       Use custom config file"
    echo "  -w, --web               Start web interface"
    echo "  -p, --port PORT         Set port (default: 3000)"
    echo "  -m, --mode MODE         Set mode (interactive, cli, web, api)"
    echo "  -d, --debug             Enable debug mode"
    echo "  --verbose               Enable verbose logging"
    echo "  --providers PROVIDERS   Comma-separated list of AI providers"
    echo "  --language LANG         Set interface language"
    echo
    echo "Commands:"
    echo "  init                    Initialize a new project"
    echo "  setup                   Setup the agent environment"
    echo "  test                    Run tests"
    echo "  version                 Show version information"
    echo
    echo "Examples:"
    echo "  $0                      Start in interactive mode"
    echo "  $0 --web                Start web interface"
    echo "  $0 --mode cli \"Generate a Python function\""
    echo "  $0 init                 Initialize new project"
    echo "  $0 test                 Run tests"
    echo
    echo "Environment Variables:"
    echo "  GEMINI_API_KEY          Google Gemini API key"
    echo "  MISTRAL_API_KEY         Mistral AI API key"
    echo "  DEEPSEEK_API_KEY        DeepSeek API key"
    echo "  OPENAI_API_KEY          OpenAI API key (optional)"
    echo "  LOG_LEVEL               Logging level (debug, info, warn, error)"
    echo "  CONFIG_FILE             Custom config file path"
}

# Function to check if binary exists
check_binary() {
    if [ ! -f "bin/agent" ]; then
        print_error "Agent binary not found. Please run setup first:"
        echo "  ./scripts/setup.sh"
        exit 1
    fi
}

# Function to load environment variables
load_env() {
    if [ -f .env ]; then
        print_status "Loading environment variables from .env"
        export $(cat .env | grep -v '^#' | grep -v '^$' | xargs)
    else
        print_warning ".env file not found. Using system environment variables only"
    fi
}

# Function to validate environment
validate_env() {
    local missing_keys=()
    
    # Check for at least one AI provider API key
    if [ -z "$GEMINI_API_KEY" ] && [ -z "$MISTRAL_API_KEY" ] && [ -z "$DEEPSEEK_API_KEY" ] && [ -z "$OPENAI_API_KEY" ]; then
        missing_keys+=("At least one AI provider API key (GEMINI_API_KEY, MISTRAL_API_KEY, DEEPSEEK_API_KEY, or OPENAI_API_KEY)")
    fi
    
    if [ ${#missing_keys[@]} -gt 0 ]; then
        print_error "Missing required environment variables:"
        for key in "${missing_keys[@]}"; do
            echo "  - $key"
        done
        echo
        print_status "Please set these variables in your .env file or environment"
        exit 1
    fi
    
    print_success "Environment validation passed"
}

# Function to create necessary directories
create_directories() {
    local dirs=("data" "logs" "backups" "temp" "cache")
    
    for dir in "${dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_status "Created directory: $dir"
        fi
    done
}

# Function to check system resources
check_resources() {
    # Check available memory (Linux/Mac)
    if command -v free >/dev/null 2>&1; then
        local available_mem=$(free -m | awk 'NR==2{printf "%.0f", $7}')
        if [ "$available_mem" -lt 512 ]; then
            print_warning "Low available memory: ${available_mem}MB. Agent may run slowly"
        fi
    elif command -v vm_stat >/dev/null 2>&1; then
        # macOS memory check
        local free_pages=$(vm_stat | grep "Pages free" | awk '{print $3}' | sed 's/\.//')
        local available_mem=$((free_pages * 4096 / 1024 / 1024))
        if [ "$available_mem" -lt 512 ]; then
            print_warning "Low available memory: ${available_mem}MB. Agent may run slowly"
        fi
    fi
    
    # Check disk space
    local available_disk=$(df . | tail -1 | awk '{print $4}')
    if [ "$available_disk" -lt 1048576 ]; then  # Less than 1GB
        print_warning "Low disk space available. Consider cleaning up"
    fi
}

# Function to start the agent
start_agent() {
    local args=("$@")
    
    print_status "Starting AI Coding Agent..."
    print_status "Process ID: $$"
    print_status "Working directory: $(pwd)"
    print_status "Arguments: ${args[*]}"
    
    # Set up signal handlers for graceful shutdown
    trap 'print_status "Received interrupt signal, shutting down..."; exit 0' INT TERM
    
    # Start the agent
    exec ./bin/agent "${args[@]}"
}

# Function to show system information
show_system_info() {
    echo "System Information:"
    echo "  OS: $(uname -s) $(uname -r)"
    echo "  Architecture: $(uname -m)"
    echo "  Go version: $(go version 2>/dev/null | awk '{print $3}' || echo 'Not found')"
    echo "  Node.js version: $(node --version 2>/dev/null || echo 'Not found')"
    echo "  Python version: $(python3 --version 2>/dev/null | awk '{print $2}' || echo 'Not found')"
    echo "  Working directory: $(pwd)"
    echo "  Agent binary: $([ -f bin/agent ] && echo 'Found' || echo 'Not found')"
    echo
}

# Main execution
main() {
    # Parse command line arguments
    local web_mode=false
    local debug_mode=false
    local verbose=false
    local port=""
    local mode=""
    local config_file=""
    local providers=""
    local language=""
    local show_info=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_usage
                exit 0
                ;;
            -v|--version)
                check_binary
                ./bin/agent version
                exit 0
                ;;
            --info)
                show_info=true
                shift
                ;;
            -w|--web)
                web_mode=true
                shift
                ;;
            -p|--port)
                port="$2"
                shift 2
                ;;
            -m|--mode)
                mode="$2"
                shift 2
                ;;
            -c|--config)
                config_file="$2"
                shift 2
                ;;
            -d|--debug)
                debug_mode=true
                shift
                ;;
            --verbose)
                verbose=true
                shift
                ;;
            --providers)
                providers="$2"
                shift 2
                ;;
            --language)
                language="$2"
                shift 2
                ;;
            *)
                # Pass remaining arguments to the agent
                break
                ;;
        esac
    done
    
    # Show system information if requested
    if [ "$show_info" = true ]; then
        show_system_info
        exit 0
    fi
    
    # Check if binary exists
    check_binary
    
    # Load environment variables
    load_env
    
    # Validate environment
    validate_env
    
    # Create necessary directories
    create_directories
    
    # Check system resources
    check_resources
    
    # Build agent arguments
    local agent_args=()
    
    if [ "$web_mode" = true ]; then
        agent_args+=("--web")
    fi
    
    if [ -n "$port" ]; then
        agent_args+=("--port" "$port")
    fi
    
    if [ -n "$mode" ]; then
        agent_args+=("--mode" "$mode")
    fi
    
    if [ -n "$config_file" ]; then
        agent_args+=("--config" "$config_file")
    fi
    
    if [ "$debug_mode" = true ]; then
        agent_args+=("--debug")
    fi
    
    if [ "$verbose" = true ]; then
        agent_args+=("--verbose")
    fi
    
    if [ -n "$providers" ]; then
        agent_args+=("--providers" "$providers")
    fi
    
    if [ -n "$language" ]; then
        agent_args+=("--language" "$language")
    fi
    
    # Add remaining arguments
    agent_args+=("$@")
    
    # Start the agent
    start_agent "${agent_args[@]}"
}

# Run main function with all arguments
main "$@"
