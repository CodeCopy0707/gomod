#!/usr/bin/env node

/**
 * AI Coding Agent - Node.js Integration Layer
 * 
 * This module provides Node.js integration for the AI coding agent,
 * including web interface, API endpoints, and JavaScript ecosystem tools.
 */

import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import morgan from 'morgan';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';
import chalk from 'chalk';
import figlet from 'figlet';
import { Command } from 'commander';

import { WebInterface } from './web/interface.js';
import { APIRouter } from './api/router.js';
import { ToolsManager } from './tools/manager.js';
import { FileWatcher } from './utils/file-watcher.js';
import { Logger } from './utils/logger.js';
import { Config } from './config/config.js';
import { AgentBridge } from './bridge/agent-bridge.js';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class AICodeAgent {
    constructor(options = {}) {
        this.options = {
            port: options.port || process.env.PORT || 3000,
            host: options.host || process.env.HOST || 'localhost',
            mode: options.mode || 'web',
            debug: options.debug || false,
            ...options
        };

        this.logger = new Logger({
            level: this.options.debug ? 'debug' : 'info',
            format: 'pretty'
        });

        this.config = new Config();
        this.app = express();
        this.server = createServer(this.app);
        this.io = new SocketIOServer(this.server, {
            cors: {
                origin: "*",
                methods: ["GET", "POST"]
            }
        });

        this.agentBridge = new AgentBridge(this.logger);
        this.toolsManager = new ToolsManager(this.logger);
        this.webInterface = new WebInterface(this.io, this.logger);
        this.apiRouter = new APIRouter(this.agentBridge, this.logger);
        this.fileWatcher = new FileWatcher(this.logger);

        this.setupMiddleware();
        this.setupRoutes();
        this.setupSocketHandlers();
        this.setupErrorHandlers();
    }

    setupMiddleware() {
        // Security middleware
        this.app.use(helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
                    fontSrc: ["'self'", "https://fonts.gstatic.com"],
                    scriptSrc: ["'self'", "'unsafe-inline'"],
                    imgSrc: ["'self'", "data:", "https:"],
                    connectSrc: ["'self'", "ws:", "wss:"]
                }
            }
        }));

        // CORS
        this.app.use(cors({
            origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
            credentials: true
        }));

        // Rate limiting
        const limiter = rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutes
            max: 100, // limit each IP to 100 requests per windowMs
            message: 'Too many requests from this IP, please try again later.'
        });
        this.app.use('/api/', limiter);

        // Compression
        this.app.use(compression());

        // Logging
        this.app.use(morgan('combined', {
            stream: {
                write: (message) => this.logger.info(message.trim())
            }
        }));

        // Body parsing
        this.app.use(express.json({ limit: '50mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));

        // Static files
        this.app.use('/static', express.static(join(__dirname, 'web', 'static')));
        this.app.use('/assets', express.static(join(__dirname, 'web', 'assets')));
    }

    setupRoutes() {
        // Health check
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                timestamp: new Date().toISOString(),
                version: process.env.npm_package_version || '1.0.0',
                uptime: process.uptime(),
                memory: process.memoryUsage(),
                node_version: process.version
            });
        });

        // API routes
        this.app.use('/api', this.apiRouter.getRouter());

        // Web interface routes
        this.app.use('/', this.webInterface.getRouter());

        // Catch-all route for SPA
        this.app.get('*', (req, res) => {
            res.sendFile(join(__dirname, 'web', 'index.html'));
        });
    }

    setupSocketHandlers() {
        this.io.on('connection', (socket) => {
            this.logger.info(`Client connected: ${socket.id}`);

            // Handle agent requests
            socket.on('agent:request', async (data) => {
                try {
                    const response = await this.agentBridge.processRequest(data);
                    socket.emit('agent:response', response);
                } catch (error) {
                    this.logger.error('Agent request failed:', error);
                    socket.emit('agent:error', { error: error.message });
                }
            });

            // Handle tool execution
            socket.on('tool:execute', async (data) => {
                try {
                    const result = await this.toolsManager.execute(data.tool, data.params);
                    socket.emit('tool:result', result);
                } catch (error) {
                    this.logger.error('Tool execution failed:', error);
                    socket.emit('tool:error', { error: error.message });
                }
            });

            // Handle file operations
            socket.on('file:watch', (path) => {
                this.fileWatcher.watch(path, (event, filename) => {
                    socket.emit('file:changed', { event, filename, path });
                });
            });

            socket.on('file:unwatch', (path) => {
                this.fileWatcher.unwatch(path);
            });

            socket.on('disconnect', () => {
                this.logger.info(`Client disconnected: ${socket.id}`);
            });
        });
    }

    setupErrorHandlers() {
        // 404 handler
        this.app.use((req, res) => {
            res.status(404).json({
                error: 'Not Found',
                message: `Route ${req.originalUrl} not found`,
                timestamp: new Date().toISOString()
            });
        });

        // Global error handler
        this.app.use((err, req, res, next) => {
            this.logger.error('Unhandled error:', err);
            
            res.status(err.status || 500).json({
                error: err.name || 'Internal Server Error',
                message: err.message || 'An unexpected error occurred',
                timestamp: new Date().toISOString(),
                ...(this.options.debug && { stack: err.stack })
            });
        });

        // Handle uncaught exceptions
        process.on('uncaughtException', (err) => {
            this.logger.error('Uncaught Exception:', err);
            this.gracefulShutdown(1);
        });

        // Handle unhandled promise rejections
        process.on('unhandledRejection', (reason, promise) => {
            this.logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
            this.gracefulShutdown(1);
        });

        // Handle SIGTERM and SIGINT
        process.on('SIGTERM', () => {
            this.logger.info('Received SIGTERM, shutting down gracefully');
            this.gracefulShutdown(0);
        });

        process.on('SIGINT', () => {
            this.logger.info('Received SIGINT, shutting down gracefully');
            this.gracefulShutdown(0);
        });
    }

    async start() {
        try {
            // Initialize components
            await this.agentBridge.initialize();
            await this.toolsManager.initialize();
            await this.webInterface.initialize();

            // Start server
            this.server.listen(this.options.port, this.options.host, () => {
                this.printBanner();
                this.logger.info(`🚀 AI Coding Agent started successfully`);
                this.logger.info(`📡 Server running on http://${this.options.host}:${this.options.port}`);
                this.logger.info(`🌐 Web interface: http://${this.options.host}:${this.options.port}`);
                this.logger.info(`🔧 API endpoint: http://${this.options.host}:${this.options.port}/api`);
                this.logger.info(`📊 Health check: http://${this.options.host}:${this.options.port}/health`);
                this.logger.info(`🎯 Mode: ${this.options.mode}`);
                this.logger.info(`📝 Debug: ${this.options.debug ? 'enabled' : 'disabled'}`);
            });

        } catch (error) {
            this.logger.error('Failed to start server:', error);
            process.exit(1);
        }
    }

    printBanner() {
        const banner = figlet.textSync('AI Agent', {
            font: 'Small',
            horizontalLayout: 'default',
            verticalLayout: 'default'
        });

        console.log(chalk.cyan(banner));
        console.log(chalk.yellow('🤖 Advanced AI Coding Assistant'));
        console.log(chalk.gray('━'.repeat(50)));
    }

    async gracefulShutdown(exitCode = 0) {
        this.logger.info('Starting graceful shutdown...');

        try {
            // Close server
            if (this.server) {
                await new Promise((resolve) => {
                    this.server.close(resolve);
                });
                this.logger.info('HTTP server closed');
            }

            // Close Socket.IO
            if (this.io) {
                this.io.close();
                this.logger.info('Socket.IO server closed');
            }

            // Cleanup components
            await this.fileWatcher.close();
            await this.toolsManager.close();
            await this.agentBridge.close();

            this.logger.info('Graceful shutdown completed');
            process.exit(exitCode);

        } catch (error) {
            this.logger.error('Error during shutdown:', error);
            process.exit(1);
        }
    }

    // CLI interface
    static createCLI() {
        const program = new Command();

        program
            .name('ai-agent')
            .description('Advanced AI Coding Agent')
            .version(process.env.npm_package_version || '1.0.0');

        program
            .option('-p, --port <port>', 'port to run on', '3000')
            .option('-h, --host <host>', 'host to bind to', 'localhost')
            .option('-m, --mode <mode>', 'mode to run in', 'web')
            .option('-d, --debug', 'enable debug mode', false)
            .option('-c, --config <file>', 'config file path')
            .action(async (options) => {
                const agent = new AICodeAgent(options);
                await agent.start();
            });

        program
            .command('test')
            .description('run tests')
            .action(async () => {
                console.log('Running tests...');
                // Test implementation would go here
            });

        program
            .command('setup')
            .description('setup the agent')
            .action(async () => {
                console.log('Setting up agent...');
                // Setup implementation would go here
            });

        return program;
    }
}

// Export for use as module
export { AICodeAgent };

// CLI execution
if (import.meta.url === `file://${process.argv[1]}`) {
    const cli = AICodeAgent.createCLI();
    cli.parse(process.argv);
}
 