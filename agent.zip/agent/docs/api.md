# AI Coding Agent API Documentation

## Overview

The AI Coding Agent provides a comprehensive REST API for integrating with external tools and services. The API supports multiple AI providers, advanced code analysis, and intelligent automation features.

## Base URL

```
http://localhost:9000/api
```

## Authentication

The API uses JWT tokens for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## Rate Limiting

- **Rate Limit**: 1000 requests per hour per user
- **Burst Limit**: 100 requests per minute
- **Headers**: Rate limit information is included in response headers

## Content Types

- **Request**: `application/json`
- **Response**: `application/json`

## Error Handling

All errors follow a consistent format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable error message",
    "details": "Additional error details",
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

### HTTP Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `429` - Too Many Requests
- `500` - Internal Server Error

## Endpoints

### Health Check

#### GET /health

Check the health status of the API.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00Z",
  "version": "1.0.0",
  "uptime": 3600,
  "services": {
    "ai_providers": "healthy",
    "database": "healthy",
    "cache": "healthy"
  }
}
```

### Code Generation

#### POST /generate

Generate code based on a natural language prompt.

**Request:**
```json
{
  "prompt": "Create a REST API endpoint for user authentication",
  "language": "go",
  "context": {
    "framework": "gin",
    "database": "postgresql"
  },
  "options": {
    "include_tests": true,
    "include_docs": true,
    "style": "clean_architecture"
  }
}
```

**Response:**
```json
{
  "code": "package main\n\n// Generated code here...",
  "language": "go",
  "explanation": "This code creates a REST API endpoint...",
  "files": [
    {
      "name": "auth.go",
      "content": "// Main authentication logic",
      "type": "implementation"
    },
    {
      "name": "auth_test.go",
      "content": "// Unit tests",
      "type": "test"
    }
  ],
  "metadata": {
    "lines_of_code": 150,
    "complexity": "medium",
    "estimated_time": "30 minutes"
  }
}
```

### Code Analysis

#### POST /analyze

Analyze code for bugs, performance issues, and improvements.

**Request:**
```json
{
  "code": "func main() {\n  // Your code here\n}",
  "language": "go",
  "analysis_types": ["bugs", "performance", "security", "style"]
}
```

**Response:**
```json
{
  "issues": [
    {
      "type": "bug",
      "severity": "high",
      "line": 5,
      "column": 10,
      "message": "Potential null pointer dereference",
      "suggestion": "Add null check before accessing the variable"
    }
  ],
  "metrics": {
    "complexity": 8,
    "maintainability": 75,
    "test_coverage": 85
  },
  "suggestions": [
    "Consider extracting this function into a separate module",
    "Add error handling for database operations"
  ]
}
```

### Code Refactoring

#### POST /refactor

Refactor code to improve quality and maintainability.

**Request:**
```json
{
  "code": "// Original code",
  "language": "python",
  "refactor_type": "extract_method",
  "options": {
    "preserve_behavior": true,
    "add_documentation": true
  }
}
```

**Response:**
```json
{
  "refactored_code": "// Refactored code",
  "changes": [
    {
      "type": "method_extraction",
      "description": "Extracted calculate_total method",
      "line_range": [10, 25]
    }
  ],
  "improvements": [
    "Reduced code duplication by 40%",
    "Improved readability score from 6 to 8"
  ]
}
```

### Test Generation

#### POST /generate-tests

Generate unit tests for the provided code.

**Request:**
```json
{
  "code": "func Add(a, b int) int { return a + b }",
  "language": "go",
  "test_framework": "testing",
  "coverage_target": 90
}
```

**Response:**
```json
{
  "test_code": "func TestAdd(t *testing.T) { ... }",
  "test_cases": [
    {
      "name": "TestAdd_PositiveNumbers",
      "description": "Test addition with positive numbers"
    },
    {
      "name": "TestAdd_NegativeNumbers", 
      "description": "Test addition with negative numbers"
    }
  ],
  "coverage_estimate": 95
}
```

### Documentation Generation

#### POST /generate-docs

Generate documentation for code.

**Request:**
```json
{
  "code": "// Your code here",
  "language": "go",
  "doc_format": "godoc",
  "include_examples": true
}
```

**Response:**
```json
{
  "documentation": "// Package documentation...",
  "format": "godoc",
  "sections": [
    {
      "type": "overview",
      "content": "Package overview..."
    },
    {
      "type": "examples",
      "content": "Usage examples..."
    }
  ]
}
```

### File Operations

#### GET /files

List files in the workspace.

**Query Parameters:**
- `path` - Directory path (optional)
- `recursive` - Include subdirectories (default: false)
- `filter` - File extension filter (optional)

**Response:**
```json
{
  "files": [
    {
      "name": "main.go",
      "path": "/workspace/main.go",
      "size": 1024,
      "modified": "2024-01-01T00:00:00Z",
      "type": "file",
      "language": "go"
    }
  ],
  "total": 1
}
```

#### GET /files/{path}

Get file content.

**Response:**
```json
{
  "content": "package main\n\nfunc main() { ... }",
  "language": "go",
  "size": 1024,
  "lines": 50,
  "encoding": "utf-8"
}
```

#### POST /files/{path}

Create or update a file.

**Request:**
```json
{
  "content": "package main\n\nfunc main() { ... }",
  "encoding": "utf-8"
}
```

#### DELETE /files/{path}

Delete a file.

### Terminal Operations

#### POST /terminal/execute

Execute a command in the terminal.

**Request:**
```json
{
  "command": "go build",
  "args": ["-o", "app"],
  "working_dir": "/workspace",
  "timeout": 30
}
```

**Response:**
```json
{
  "output": "Build successful",
  "error": "",
  "exit_code": 0,
  "duration": 2.5
}
```

### AI Provider Management

#### GET /providers

List available AI providers.

**Response:**
```json
{
  "providers": [
    {
      "name": "gemini",
      "status": "healthy",
      "model": "gemini-pro",
      "capabilities": ["code_generation", "analysis", "chat"]
    },
    {
      "name": "mistral",
      "status": "healthy", 
      "model": "mistral-large-latest",
      "capabilities": ["code_generation", "analysis"]
    }
  ]
}
```

#### POST /providers/switch

Switch the active AI provider.

**Request:**
```json
{
  "provider": "mistral",
  "model": "mistral-large-latest"
}
```

### Session Management

#### GET /sessions

List active sessions.

**Response:**
```json
{
  "sessions": [
    {
      "id": "session-123",
      "user_id": "user-456",
      "created_at": "2024-01-01T00:00:00Z",
      "last_activity": "2024-01-01T01:00:00Z",
      "message_count": 25
    }
  ]
}
```

#### POST /sessions

Create a new session.

**Request:**
```json
{
  "user_id": "user-456",
  "context": {
    "project": "my-app",
    "language": "go"
  }
}
```

#### GET /sessions/{id}/messages

Get session messages.

**Response:**
```json
{
  "messages": [
    {
      "id": "msg-123",
      "role": "user",
      "content": "Generate a function to sort an array",
      "timestamp": "2024-01-01T00:00:00Z"
    },
    {
      "id": "msg-124",
      "role": "assistant", 
      "content": "Here's a sorting function...",
      "timestamp": "2024-01-01T00:01:00Z"
    }
  ]
}
```

### Analytics

#### GET /analytics/metrics

Get system metrics.

**Response:**
```json
{
  "metrics": {
    "requests_per_minute": 45,
    "average_response_time": 250,
    "error_rate": 0.02,
    "active_sessions": 12
  },
  "timestamp": "2024-01-01T00:00:00Z"
}
```

#### GET /analytics/usage

Get usage analytics.

**Query Parameters:**
- `period` - Time period (hour, day, week, month)
- `start_date` - Start date (ISO 8601)
- `end_date` - End date (ISO 8601)

**Response:**
```json
{
  "period": "day",
  "data": [
    {
      "timestamp": "2024-01-01T00:00:00Z",
      "requests": 1250,
      "users": 45,
      "code_generated": 125
    }
  ]
}
```

## WebSocket API

### Connection

Connect to the WebSocket endpoint for real-time communication:

```
ws://localhost:9000/ws
```

### Message Format

All WebSocket messages follow this format:

```json
{
  "type": "message_type",
  "data": { ... },
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### Message Types

#### chat_message

Send a chat message to the AI.

```json
{
  "type": "chat_message",
  "data": {
    "message": "Generate a Python function",
    "session_id": "session-123"
  }
}
```

#### code_generation

Request code generation.

```json
{
  "type": "code_generation",
  "data": {
    "prompt": "Create a REST API",
    "language": "go",
    "context": { ... }
  }
}
```

#### file_change

Notify about file changes.

```json
{
  "type": "file_change",
  "data": {
    "path": "/workspace/main.go",
    "action": "modified"
  }
}
```

## SDKs and Libraries

### JavaScript/TypeScript

```bash
npm install ai-coding-agent-sdk
```

```javascript
import { AICodeAgent } from 'ai-coding-agent-sdk';

const agent = new AICodeAgent({
  baseUrl: 'http://localhost:9000/api',
  apiKey: 'your-api-key'
});

const result = await agent.generateCode({
  prompt: 'Create a REST API',
  language: 'go'
});
```

### Python

```bash
pip install ai-coding-agent
```

```python
from ai_coding_agent import AICodeAgent

agent = AICodeAgent(
    base_url='http://localhost:9000/api',
    api_key='your-api-key'
)

result = agent.generate_code(
    prompt='Create a REST API',
    language='python'
)
```

### Go

```bash
go get github.com/ai-coding-agent/go-sdk
```

```go
import "github.com/ai-coding-agent/go-sdk"

client := sdk.NewClient("http://localhost:9000/api", "your-api-key")

result, err := client.GenerateCode(ctx, &sdk.GenerateRequest{
    Prompt:   "Create a REST API",
    Language: "go",
})
```

## Examples

### Complete Workflow Example

```bash
# 1. Generate code
curl -X POST http://localhost:9000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Create a user authentication system",
    "language": "go",
    "context": {"framework": "gin"}
  }'

# 2. Analyze the generated code
curl -X POST http://localhost:9000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "code": "...",
    "language": "go",
    "analysis_types": ["security", "performance"]
  }'

# 3. Generate tests
curl -X POST http://localhost:9000/api/generate-tests \
  -H "Content-Type: application/json" \
  -d '{
    "code": "...",
    "language": "go",
    "test_framework": "testing"
  }'

# 4. Execute tests
curl -X POST http://localhost:9000/api/terminal/execute \
  -H "Content-Type: application/json" \
  -d '{
    "command": "go test",
    "args": ["-v", "./..."]
  }'
```

## Support

- **Documentation**: [https://docs.ai-coding-agent.com](https://docs.ai-coding-agent.com)
- **GitHub**: [https://github.com/ai-coding-agent/api](https://github.com/ai-coding-agent/api)
- **Discord**: [https://discord.gg/ai-coding-agent](https://discord.gg/ai-coding-agent)
- **Email**: support@ai-coding-agent.com
