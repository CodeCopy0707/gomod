# AI Coding Agent - Deployment Guide

This guide covers deploying the AI Coding Agent in various environments, from development to production.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Environment Setup](#environment-setup)
- [Configuration](#configuration)
- [Deployment Options](#deployment-options)
- [Monitoring](#monitoring)
- [Troubleshooting](#troubleshooting)
- [Security](#security)

## Prerequisites

### System Requirements

- **CPU**: 2+ cores (4+ recommended for production)
- **Memory**: 4GB RAM minimum (8GB+ recommended)
- **Storage**: 10GB available space
- **Network**: Internet access for AI API calls

### Software Dependencies

- **Go**: 1.21 or later
- **Node.js**: 18 or later
- **Python**: 3.11 or later
- **Database**: SQLite (default) or PostgreSQL
- **Cache**: Redis (optional but recommended)
- **Web Server**: Nginx (for production)

## Environment Setup

### Development Environment

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-org/ai-coding-agent.git
   cd ai-coding-agent
   ```

2. **Run setup script**:
   ```bash
   chmod +x scripts/setup.sh
   ./scripts/setup.sh
   ```

3. **Configure environment**:
   ```bash
   cp .env.example .env
   # Edit .env with your API keys and configuration
   ```

4. **Start development server**:
   ```bash
   ./scripts/start.sh dev
   ```

### Production Environment

1. **System preparation**:
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install dependencies
   sudo apt install -y nginx redis-server postgresql supervisor
   ```

2. **Create application user**:
   ```bash
   sudo useradd -r -s /bin/false ai-agent
   sudo mkdir -p /opt/ai-coding-agent
   sudo chown ai-agent:ai-agent /opt/ai-coding-agent
   ```

3. **Deploy application**:
   ```bash
   # Copy application files
   sudo cp -r . /opt/ai-coding-agent/
   sudo chown -R ai-agent:ai-agent /opt/ai-coding-agent
   
   # Run setup as ai-agent user
   sudo -u ai-agent ./scripts/setup.sh
   ```

## Configuration

### Environment Variables

Create a `.env` file with the following variables:

```bash
# AI Provider API Keys
GEMINI_API_KEY=your_gemini_api_key
MISTRAL_API_KEY=your_mistral_api_key
DEEPSEEK_API_KEY=your_deepseek_api_key
OPENAI_API_KEY=your_openai_api_key

# Application Settings
ENVIRONMENT=production
HOST=0.0.0.0
PORT=9000
LOG_LEVEL=info

# Security
JWT_SECRET=your_secure_jwt_secret_here
CORS_ORIGINS=https://yourdomain.com

# Database
DATABASE_URL=postgresql://user:password@localhost/ai_agent
# Or for SQLite: sqlite:///data/agent.db

# Cache
REDIS_URL=redis://localhost:6379

# Performance
MAX_WORKERS=8
CACHE_SIZE=100MB
OPTIMIZATION_LEVEL=basic
```

### Configuration File

Edit `config/config.yaml`:

```yaml
server:
  host: "0.0.0.0"
  port: 9000
  mode: "production"
  read_timeout: "30s"
  write_timeout: "30s"
  idle_timeout: "120s"

database:
  type: "postgresql"
  url: "${DATABASE_URL}"
  max_connections: 25
  max_idle: 5
  max_lifetime: "1h"

cache:
  type: "redis"
  url: "${REDIS_URL}"
  ttl: 3600
  max_connections: 10

ai:
  providers:
    gemini:
      enabled: true
      api_key: "${GEMINI_API_KEY}"
      model: "gemini-pro"
      rate_limit: 60
    mistral:
      enabled: true
      api_key: "${MISTRAL_API_KEY}"
      model: "mistral-large-latest"
      rate_limit: 60

logging:
  level: "info"
  format: "json"
  output: "/var/log/ai-agent/agent.log"

security:
  jwt_secret: "${JWT_SECRET}"
  rate_limit: 1000
  cors_origins: ["${CORS_ORIGINS}"]
  enable_https: true

performance:
  max_workers: 8
  cache_size: "100MB"
  optimization_level: "basic"
  enable_profiling: false
```

## Deployment Options

### Option 1: Systemd Service (Recommended)

1. **Create systemd service**:
   ```bash
   sudo tee /etc/systemd/system/ai-coding-agent.service > /dev/null << EOF
   [Unit]
   Description=AI Coding Agent
   After=network.target postgresql.service redis.service
   Wants=postgresql.service redis.service

   [Service]
   Type=simple
   User=ai-agent
   Group=ai-agent
   WorkingDirectory=/opt/ai-coding-agent
   ExecStart=/opt/ai-coding-agent/bin/agent
   ExecReload=/bin/kill -HUP \$MAINPID
   Restart=always
   RestartSec=5
   Environment=PATH=/usr/local/go/bin:/usr/bin:/bin
   EnvironmentFile=/opt/ai-coding-agent/.env

   # Security settings
   NoNewPrivileges=true
   PrivateTmp=true
   ProtectSystem=strict
   ProtectHome=true
   ReadWritePaths=/opt/ai-coding-agent/data /opt/ai-coding-agent/logs

   [Install]
   WantedBy=multi-user.target
   EOF
   ```

2. **Enable and start service**:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable ai-coding-agent
   sudo systemctl start ai-coding-agent
   ```

### Option 2: Docker Deployment

1. **Create Dockerfile**:
   ```dockerfile
   FROM golang:1.21-alpine AS builder
   
   WORKDIR /app
   COPY go.mod go.sum ./
   RUN go mod download
   
   COPY . .
   RUN go build -o bin/agent cmd/agent/main.go
   
   FROM alpine:latest
   RUN apk --no-cache add ca-certificates
   WORKDIR /root/
   
   COPY --from=builder /app/bin/agent .
   COPY --from=builder /app/config ./config
   COPY --from=builder /app/web ./web
   
   EXPOSE 9000
   CMD ["./agent"]
   ```

2. **Create docker-compose.yml**:
   ```yaml
   version: '3.8'
   
   services:
     ai-agent:
       build: .
       ports:
         - "9000:9000"
       environment:
         - DATABASE_URL=postgresql://postgres:password@db:5432/ai_agent
         - REDIS_URL=redis://redis:6379
       depends_on:
         - db
         - redis
       volumes:
         - ./data:/app/data
         - ./logs:/app/logs
   
     db:
       image: postgres:15
       environment:
         POSTGRES_DB: ai_agent
         POSTGRES_USER: postgres
         POSTGRES_PASSWORD: password
       volumes:
         - postgres_data:/var/lib/postgresql/data
   
     redis:
       image: redis:7-alpine
       volumes:
         - redis_data:/data
   
     nginx:
       image: nginx:alpine
       ports:
         - "80:80"
         - "443:443"
       volumes:
         - ./nginx.conf:/etc/nginx/nginx.conf
         - ./ssl:/etc/nginx/ssl
       depends_on:
         - ai-agent
   
   volumes:
     postgres_data:
     redis_data:
   ```

3. **Deploy with Docker**:
   ```bash
   docker-compose up -d
   ```

### Option 3: Kubernetes Deployment

1. **Create namespace**:
   ```yaml
   apiVersion: v1
   kind: Namespace
   metadata:
     name: ai-coding-agent
   ```

2. **Create deployment**:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: ai-coding-agent
     namespace: ai-coding-agent
   spec:
     replicas: 3
     selector:
       matchLabels:
         app: ai-coding-agent
     template:
       metadata:
         labels:
           app: ai-coding-agent
       spec:
         containers:
         - name: ai-agent
           image: ai-coding-agent:latest
           ports:
           - containerPort: 9000
           env:
           - name: DATABASE_URL
             valueFrom:
               secretKeyRef:
                 name: ai-agent-secrets
                 key: database-url
           resources:
             requests:
               memory: "512Mi"
               cpu: "250m"
             limits:
               memory: "2Gi"
               cpu: "1000m"
   ```

## Nginx Configuration

Create `/etc/nginx/sites-available/ai-coding-agent`:

```nginx
upstream ai_agent {
    server 127.0.0.1:9000;
}

server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/ssl/certs/yourdomain.com.crt;
    ssl_certificate_key /etc/ssl/private/yourdomain.com.key;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    location / {
        proxy_pass http://ai_agent;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /ws {
        proxy_pass http://ai_agent;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /static/ {
        alias /opt/ai-coding-agent/web/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## Monitoring

### Health Checks

The application provides health check endpoints:

- `GET /api/health` - Basic health check
- `GET /api/health/detailed` - Detailed health information

### Logging

Configure log rotation:

```bash
sudo tee /etc/logrotate.d/ai-coding-agent > /dev/null << EOF
/var/log/ai-agent/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ai-agent ai-agent
    postrotate
        systemctl reload ai-coding-agent
    endscript
}
EOF
```

### Metrics

The application exposes metrics at `/api/metrics` in Prometheus format.

Example Prometheus configuration:

```yaml
scrape_configs:
  - job_name: 'ai-coding-agent'
    static_configs:
      - targets: ['localhost:9000']
    metrics_path: '/api/metrics'
    scrape_interval: 30s
```

## Security

### SSL/TLS Configuration

1. **Obtain SSL certificate**:
   ```bash
   # Using Let's Encrypt
   sudo certbot --nginx -d yourdomain.com
   ```

2. **Configure strong SSL**:
   ```nginx
   ssl_protocols TLSv1.2 TLSv1.3;
   ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
   ssl_prefer_server_ciphers off;
   ssl_session_cache shared:SSL:10m;
   ```

### Firewall Configuration

```bash
# Allow SSH, HTTP, and HTTPS
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443

# Deny direct access to application port
sudo ufw deny 9000

# Enable firewall
sudo ufw enable
```

### Database Security

1. **PostgreSQL security**:
   ```sql
   -- Create dedicated user
   CREATE USER ai_agent WITH PASSWORD 'secure_password';
   CREATE DATABASE ai_agent OWNER ai_agent;
   GRANT ALL PRIVILEGES ON DATABASE ai_agent TO ai_agent;
   ```

2. **Configure pg_hba.conf**:
   ```
   local   ai_agent    ai_agent                    md5
   host    ai_agent    ai_agent    127.0.0.1/32    md5
   ```

## Troubleshooting

### Common Issues

1. **Application won't start**:
   ```bash
   # Check logs
   sudo journalctl -u ai-coding-agent -f
   
   # Check configuration
   ./bin/agent --config-check
   ```

2. **Database connection issues**:
   ```bash
   # Test database connection
   psql $DATABASE_URL -c "SELECT 1;"
   ```

3. **High memory usage**:
   ```bash
   # Check memory usage
   ps aux | grep agent
   
   # Adjust configuration
   # Reduce MAX_WORKERS or CACHE_SIZE in .env
   ```

4. **Performance issues**:
   ```bash
   # Enable profiling
   export ENABLE_PROFILING=true
   
   # Access profiling data
   curl http://localhost:9000/debug/pprof/
   ```

### Log Analysis

```bash
# View recent errors
sudo journalctl -u ai-coding-agent --since "1 hour ago" | grep ERROR

# Monitor real-time logs
sudo tail -f /var/log/ai-agent/agent.log | jq '.'

# Check specific component logs
grep "component=ai" /var/log/ai-agent/agent.log
```

## Backup and Recovery

### Database Backup

```bash
# PostgreSQL backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# SQLite backup
cp data/agent.db backup/agent_$(date +%Y%m%d_%H%M%S).db
```

### Configuration Backup

```bash
# Backup configuration
tar -czf config_backup_$(date +%Y%m%d).tar.gz config/ .env
```

### Automated Backup Script

```bash
#!/bin/bash
# /opt/ai-coding-agent/scripts/backup.sh

BACKUP_DIR="/opt/backups/ai-coding-agent"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Database backup
pg_dump $DATABASE_URL > $BACKUP_DIR/db_$DATE.sql

# Configuration backup
tar -czf $BACKUP_DIR/config_$DATE.tar.gz config/ .env

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```

Add to crontab:
```bash
0 2 * * * /opt/ai-coding-agent/scripts/backup.sh
```

## Performance Tuning

### Application Tuning

1. **Adjust worker count**:
   ```bash
   # Set to number of CPU cores
   export MAX_WORKERS=$(nproc)
   ```

2. **Optimize cache settings**:
   ```bash
   # Increase cache size for better performance
   export CACHE_SIZE=500MB
   ```

3. **Enable optimization**:
   ```bash
   export OPTIMIZATION_LEVEL=aggressive
   ```

### System Tuning

1. **Increase file limits**:
   ```bash
   echo "ai-agent soft nofile 65536" >> /etc/security/limits.conf
   echo "ai-agent hard nofile 65536" >> /etc/security/limits.conf
   ```

2. **Optimize kernel parameters**:
   ```bash
   echo "net.core.somaxconn = 65536" >> /etc/sysctl.conf
   echo "net.ipv4.tcp_max_syn_backlog = 65536" >> /etc/sysctl.conf
   sysctl -p
   ```

This deployment guide provides comprehensive instructions for deploying the AI Coding Agent in various environments. Follow the appropriate sections based on your deployment needs and environment.
