package tests

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"ai-coding-agent/internal/agent"
	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
)

// IntegrationTestSuite contains integration tests
type IntegrationTestSuite struct {
	suite.Suite
	agent    *agent.Agent
	server   *httptest.Server
	client   *http.Client
	logger   logger.Logger
	database database.Database
	cache    cache.Cache
}

// SetupSuite sets up the test suite
func (suite *IntegrationTestSuite) SetupSuite() {
	// Set test environment
	os.Setenv("ENVIRONMENT", "test")
	os.Setenv("LOG_LEVEL", "debug")

	// Initialize logger
	suite.logger = logger.New(&logger.Config{
		Level:  "debug",
		Format: "json",
		Output: "stdout",
	})

	// Initialize test database
	suite.database = database.NewSQLite(":memory:")
	err := suite.database.Migrate()
	require.NoError(suite.T(), err)

	// Initialize test cache
	suite.cache = cache.NewMemory()

	// Load test configuration
	cfg := &config.Config{
		Server: config.ServerConfig{
			Host: "localhost",
			Port: 0, // Use random port
		},
		AI: config.AIConfig{
			Providers: map[string]config.ProviderConfig{
				"test": {
					Enabled: true,
					Model:   "test-model",
				},
			},
		},
		Database: config.DatabaseConfig{
			URL: ":memory:",
		},
		Cache: config.CacheConfig{
			Type: "memory",
		},
	}

	// Create agent
	suite.agent, err = agent.New(cfg, suite.logger)
	require.NoError(suite.T(), err)

	// Start test server
	suite.server = httptest.NewServer(suite.agent.GetHTTPHandler())
	suite.client = suite.server.Client()

	suite.logger.Info("Integration test suite setup complete")
}

// TearDownSuite tears down the test suite
func (suite *IntegrationTestSuite) TearDownSuite() {
	if suite.server != nil {
		suite.server.Close()
	}
	if suite.agent != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		suite.agent.Shutdown(ctx)
	}
	if suite.database != nil {
		suite.database.Close()
	}
}

// TestHealthCheck tests the health check endpoint
func (suite *IntegrationTestSuite) TestHealthCheck() {
	resp, err := suite.client.Get(suite.server.URL + "/api/health")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var health map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&health)
	require.NoError(suite.T(), err)

	assert.Equal(suite.T(), "healthy", health["status"])
	assert.Contains(suite.T(), health, "timestamp")
	assert.Contains(suite.T(), health, "version")
}

// TestCodeGeneration tests code generation functionality
func (suite *IntegrationTestSuite) TestCodeGeneration() {
	request := map[string]interface{}{
		"prompt":   "Create a simple Hello World function in Go",
		"language": "go",
		"context": map[string]interface{}{
			"style": "clean",
		},
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/generate",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var response map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&response)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), response, "code")
	assert.Contains(suite.T(), response, "language")
	assert.Equal(suite.T(), "go", response["language"])
}

// TestCodeAnalysis tests code analysis functionality
func (suite *IntegrationTestSuite) TestCodeAnalysis() {
	request := map[string]interface{}{
		"code":           "func main() {\n\tfmt.Println(\"Hello, World!\")\n}",
		"language":       "go",
		"analysis_types": []string{"bugs", "style", "performance"},
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/analyze",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var response map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&response)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), response, "issues")
	assert.Contains(suite.T(), response, "metrics")
}

// TestFileOperations tests file operations
func (suite *IntegrationTestSuite) TestFileOperations() {
	// Test file listing
	resp, err := suite.client.Get(suite.server.URL + "/api/files")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var fileList map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&fileList)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), fileList, "files")
	assert.Contains(suite.T(), fileList, "total")
}

// TestTerminalExecution tests terminal command execution
func (suite *IntegrationTestSuite) TestTerminalExecution() {
	request := map[string]interface{}{
		"command":     "echo",
		"args":        []string{"Hello, World!"},
		"working_dir": "/tmp",
		"timeout":     10,
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/terminal/execute",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var response map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&response)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), response, "output")
	assert.Contains(suite.T(), response, "exit_code")
	assert.Equal(suite.T(), float64(0), response["exit_code"])
}

// TestAIProviders tests AI provider management
func (suite *IntegrationTestSuite) TestAIProviders() {
	// Test listing providers
	resp, err := suite.client.Get(suite.server.URL + "/api/providers")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var providers map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&providers)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), providers, "providers")
}

// TestSessionManagement tests session management
func (suite *IntegrationTestSuite) TestSessionManagement() {
	// Create a new session
	request := map[string]interface{}{
		"user_id": "test-user",
		"context": map[string]interface{}{
			"project":  "test-project",
			"language": "go",
		},
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/sessions",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusCreated, resp.StatusCode)

	var session map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&session)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), session, "id")
	assert.Contains(suite.T(), session, "user_id")
	assert.Equal(suite.T(), "test-user", session["user_id"])

	// Test listing sessions
	resp, err = suite.client.Get(suite.server.URL + "/api/sessions")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)
}

// TestRateLimiting tests rate limiting functionality
func (suite *IntegrationTestSuite) TestRateLimiting() {
	// Make multiple rapid requests to trigger rate limiting
	for i := 0; i < 10; i++ {
		resp, err := suite.client.Get(suite.server.URL + "/api/health")
		require.NoError(suite.T(), err)
		resp.Body.Close()

		// Check rate limit headers
		assert.Contains(suite.T(), resp.Header, "X-Ratelimit-Limit")
		assert.Contains(suite.T(), resp.Header, "X-Ratelimit-Remaining")
	}
}

// TestErrorHandling tests error handling
func (suite *IntegrationTestSuite) TestErrorHandling() {
	// Test invalid endpoint
	resp, err := suite.client.Get(suite.server.URL + "/api/invalid")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusNotFound, resp.StatusCode)

	// Test invalid JSON
	resp, err = suite.client.Post(
		suite.server.URL+"/api/generate",
		"application/json",
		bytes.NewBufferString("invalid json"),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusBadRequest, resp.StatusCode)
}

// TestConcurrency tests concurrent operations
func (suite *IntegrationTestSuite) TestConcurrency() {
	const numRequests = 10
	results := make(chan error, numRequests)

	// Make concurrent requests
	for i := 0; i < numRequests; i++ {
		go func(id int) {
			request := map[string]interface{}{
				"prompt":   fmt.Sprintf("Create function %d", id),
				"language": "go",
			}

			body, err := json.Marshal(request)
			if err != nil {
				results <- err
				return
			}

			resp, err := suite.client.Post(
				suite.server.URL+"/api/generate",
				"application/json",
				bytes.NewBuffer(body),
			)
			if err != nil {
				results <- err
				return
			}
			defer resp.Body.Close()

			if resp.StatusCode != http.StatusOK {
				results <- fmt.Errorf("unexpected status code: %d", resp.StatusCode)
				return
			}

			results <- nil
		}(i)
	}

	// Wait for all requests to complete
	for i := 0; i < numRequests; i++ {
		err := <-results
		assert.NoError(suite.T(), err)
	}
}

// TestWebSocketConnection tests WebSocket functionality
func (suite *IntegrationTestSuite) TestWebSocketConnection() {
	// This would test WebSocket connections
	// Implementation depends on WebSocket library used
	suite.T().Skip("WebSocket testing requires additional setup")
}

// TestMetrics tests metrics collection
func (suite *IntegrationTestSuite) TestMetrics() {
	resp, err := suite.client.Get(suite.server.URL + "/api/analytics/metrics")
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)

	var metrics map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&metrics)
	require.NoError(suite.T(), err)

	assert.Contains(suite.T(), metrics, "metrics")
	assert.Contains(suite.T(), metrics, "timestamp")
}

// TestSecurity tests security features
func (suite *IntegrationTestSuite) TestSecurity() {
	// Test input validation
	request := map[string]interface{}{
		"prompt":   "<script>alert('xss')</script>",
		"language": "go",
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/generate",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	// Should handle malicious input gracefully
	assert.True(suite.T(), resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusBadRequest)
}

// TestPerformance tests performance characteristics
func (suite *IntegrationTestSuite) TestPerformance() {
	start := time.Now()

	request := map[string]interface{}{
		"prompt":   "Create a simple function",
		"language": "go",
	}

	body, err := json.Marshal(request)
	require.NoError(suite.T(), err)

	resp, err := suite.client.Post(
		suite.server.URL+"/api/generate",
		"application/json",
		bytes.NewBuffer(body),
	)
	require.NoError(suite.T(), err)
	defer resp.Body.Close()

	duration := time.Since(start)

	assert.Equal(suite.T(), http.StatusOK, resp.StatusCode)
	assert.Less(suite.T(), duration, 30*time.Second, "Request should complete within 30 seconds")
}

// BenchmarkCodeGeneration benchmarks code generation
func BenchmarkCodeGeneration(b *testing.B) {
	// Setup benchmark environment
	suite := &IntegrationTestSuite{}
	suite.SetupSuite()
	defer suite.TearDownSuite()

	request := map[string]interface{}{
		"prompt":   "Create a simple function",
		"language": "go",
	}

	body, _ := json.Marshal(request)

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			resp, err := suite.client.Post(
				suite.server.URL+"/api/generate",
				"application/json",
				bytes.NewBuffer(body),
			)
			if err != nil {
				b.Fatal(err)
			}
			resp.Body.Close()
		}
	})
}

// TestRunner runs all integration tests
func TestIntegrationSuite(t *testing.T) {
	// Skip integration tests if not in integration test mode
	if testing.Short() {
		t.Skip("Skipping integration tests in short mode")
	}

	suite.Run(t, new(IntegrationTestSuite))
}

// Helper functions for testing

// createTestFile creates a temporary test file
func createTestFile(t *testing.T, content string) string {
	file, err := os.CreateTemp("", "test-*.go")
	require.NoError(t, err)

	_, err = file.WriteString(content)
	require.NoError(t, err)

	err = file.Close()
	require.NoError(t, err)

	return file.Name()
}

// cleanupTestFile removes a test file
func cleanupTestFile(path string) {
	os.Remove(path)
}

// assertJSONResponse asserts that a response contains valid JSON
func assertJSONResponse(t *testing.T, resp *http.Response) map[string]interface{} {
	var result map[string]interface{}
	err := json.NewDecoder(resp.Body).Decode(&result)
	require.NoError(t, err)
	return result
}

// assertErrorResponse asserts that a response contains an error
func assertErrorResponse(t *testing.T, resp *http.Response) {
	assert.True(t, resp.StatusCode >= 400)
	
	var errorResp map[string]interface{}
	err := json.NewDecoder(resp.Body).Decode(&errorResp)
	require.NoError(t, err)
	
	assert.Contains(t, errorResp, "error")
}
