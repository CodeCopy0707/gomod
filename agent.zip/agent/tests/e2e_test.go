package tests

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"ai-coding-agent/internal/agent"
	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
)

// E2ETestSuite contains end-to-end tests
type E2ETestSuite struct {
	suite.Suite
	agent    *agent.Agent
	server   *httptest.Server
	client   *http.Client
	logger   logger.Logger
	baseURL  string
}

// SetupSuite sets up the test suite
func (suite *E2ETestSuite) SetupSuite() {
	// Set test environment
	os.Setenv("ENVIRONMENT", "test")
	os.Setenv("LOG_LEVEL", "error") // Reduce log noise in tests

	// Initialize logger
	suite.logger = logger.New(&logger.Config{
		Level:  "error",
		Format: "json",
		Output: "stdout",
	})

	// Load test configuration
	cfg := &config.Config{
		Server: config.ServerConfig{
			Host: "localhost",
			Port: 0, // Use random port
		},
		AI: config.AIConfig{
			Providers: map[string]config.ProviderConfig{
				"test": {
					Enabled: true,
					Model:   "test-model",
				},
			},
		},
		Database: config.DatabaseConfig{
			URL: ":memory:",
		},
		Cache: config.CacheConfig{
			Type: "memory",
		},
	}

	// Create agent
	var err error
	suite.agent, err = agent.New(cfg, suite.logger)
	require.NoError(suite.T(), err)

	// Start test server
	suite.server = httptest.NewServer(suite.agent.GetHTTPHandler())
	suite.client = suite.server.Client()
	suite.baseURL = suite.server.URL

	suite.logger.Info("E2E test suite setup complete")
}

// TearDownSuite tears down the test suite
func (suite *E2ETestSuite) TearDownSuite() {
	if suite.server != nil {
		suite.server.Close()
	}
	if suite.agent != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		suite.agent.Shutdown(ctx)
	}
}

// TestCompleteWorkflow tests a complete user workflow
func (suite *E2ETestSuite) TestCompleteWorkflow() {
	// 1. Health check
	suite.T().Run("HealthCheck", func(t *testing.T) {
		resp, err := suite.client.Get(suite.baseURL + "/api/health")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var health map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&health)
		require.NoError(t, err)

		assert.Equal(t, "healthy", health["status"])
	})

	// 2. Create a new session
	var sessionID string
	suite.T().Run("CreateSession", func(t *testing.T) {
		request := map[string]interface{}{
			"user_id": "test-user",
			"context": map[string]interface{}{
				"project":  "test-project",
				"language": "go",
			},
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/sessions",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusCreated, resp.StatusCode)

		var session map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&session)
		require.NoError(t, err)

		sessionID = session["id"].(string)
		assert.NotEmpty(t, sessionID)
	})

	// 3. Generate code
	suite.T().Run("GenerateCode", func(t *testing.T) {
		request := map[string]interface{}{
			"prompt":   "Create a simple Hello World function in Go",
			"language": "go",
			"context": map[string]interface{}{
				"session_id": sessionID,
			},
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var response map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&response)
		require.NoError(t, err)

		assert.Contains(t, response, "code")
		assert.Equal(t, "go", response["language"])
		
		// Store generated code for next steps
		generatedCode := response["code"].(string)
		assert.NotEmpty(t, generatedCode)
	})

	// 4. Analyze the generated code
	suite.T().Run("AnalyzeCode", func(t *testing.T) {
		request := map[string]interface{}{
			"code":           "func main() {\n\tfmt.Println(\"Hello, World!\")\n}",
			"language":       "go",
			"analysis_types": []string{"bugs", "style", "performance"},
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/analyze",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var response map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&response)
		require.NoError(t, err)

		assert.Contains(t, response, "issues")
		assert.Contains(t, response, "metrics")
	})

	// 5. Generate tests for the code
	suite.T().Run("GenerateTests", func(t *testing.T) {
		request := map[string]interface{}{
			"code":            "func Add(a, b int) int { return a + b }",
			"language":        "go",
			"test_framework":  "testing",
			"coverage_target": 90,
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate-tests",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var response map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&response)
		require.NoError(t, err)

		assert.Contains(t, response, "test_code")
		assert.Contains(t, response, "test_cases")
	})

	// 6. File operations
	suite.T().Run("FileOperations", func(t *testing.T) {
		// List files
		resp, err := suite.client.Get(suite.baseURL + "/api/files")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var fileList map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&fileList)
		require.NoError(t, err)

		assert.Contains(t, fileList, "files")
		assert.Contains(t, fileList, "total")
	})

	// 7. Execute terminal command
	suite.T().Run("TerminalExecution", func(t *testing.T) {
		request := map[string]interface{}{
			"command":     "echo",
			"args":        []string{"Hello from terminal"},
			"working_dir": "/tmp",
			"timeout":     10,
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/terminal/execute",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var response map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&response)
		require.NoError(t, err)

		assert.Contains(t, response, "output")
		assert.Contains(t, response, "exit_code")
		assert.Equal(t, float64(0), response["exit_code"])
	})

	// 8. Get analytics
	suite.T().Run("Analytics", func(t *testing.T) {
		resp, err := suite.client.Get(suite.baseURL + "/api/analytics/metrics")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var metrics map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&metrics)
		require.NoError(t, err)

		assert.Contains(t, metrics, "metrics")
		assert.Contains(t, metrics, "timestamp")
	})
}

// TestLanguageSupport tests multi-language support
func (suite *E2ETestSuite) TestLanguageSupport() {
	languages := []string{"go", "python", "javascript", "java", "rust"}

	for _, lang := range languages {
		suite.T().Run(fmt.Sprintf("Language_%s", lang), func(t *testing.T) {
			request := map[string]interface{}{
				"prompt":   fmt.Sprintf("Create a simple function in %s", lang),
				"language": lang,
			}

			body, err := json.Marshal(request)
			require.NoError(t, err)

			resp, err := suite.client.Post(
				suite.baseURL+"/api/generate",
				"application/json",
				bytes.NewBuffer(body),
			)
			require.NoError(t, err)
			defer resp.Body.Close()

			assert.Equal(t, http.StatusOK, resp.StatusCode)

			var response map[string]interface{}
			err = json.NewDecoder(resp.Body).Decode(&response)
			require.NoError(t, err)

			assert.Contains(t, response, "code")
			assert.Equal(t, lang, response["language"])
		})
	}
}

// TestErrorHandling tests error handling scenarios
func (suite *E2ETestSuite) TestErrorHandling() {
	// Test invalid endpoint
	suite.T().Run("InvalidEndpoint", func(t *testing.T) {
		resp, err := suite.client.Get(suite.baseURL + "/api/invalid")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusNotFound, resp.StatusCode)
	})

	// Test invalid JSON
	suite.T().Run("InvalidJSON", func(t *testing.T) {
		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBufferString("invalid json"),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusBadRequest, resp.StatusCode)
	})

	// Test missing required fields
	suite.T().Run("MissingFields", func(t *testing.T) {
		request := map[string]interface{}{
			"language": "go",
			// Missing prompt
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusBadRequest, resp.StatusCode)
	})
}

// TestPerformance tests performance characteristics
func (suite *E2ETestSuite) TestPerformance() {
	suite.T().Run("ResponseTime", func(t *testing.T) {
		start := time.Now()

		request := map[string]interface{}{
			"prompt":   "Create a simple function",
			"language": "go",
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		duration := time.Since(start)

		assert.Equal(t, http.StatusOK, resp.StatusCode)
		assert.Less(t, duration, 30*time.Second, "Request should complete within 30 seconds")
	})

	suite.T().Run("ConcurrentRequests", func(t *testing.T) {
		const numRequests = 5
		results := make(chan error, numRequests)

		for i := 0; i < numRequests; i++ {
			go func(id int) {
				request := map[string]interface{}{
					"prompt":   fmt.Sprintf("Create function %d", id),
					"language": "go",
				}

				body, err := json.Marshal(request)
				if err != nil {
					results <- err
					return
				}

				resp, err := suite.client.Post(
					suite.baseURL+"/api/generate",
					"application/json",
					bytes.NewBuffer(body),
				)
				if err != nil {
					results <- err
					return
				}
				defer resp.Body.Close()

				if resp.StatusCode != http.StatusOK {
					results <- fmt.Errorf("unexpected status code: %d", resp.StatusCode)
					return
				}

				results <- nil
			}(i)
		}

		// Wait for all requests to complete
		for i := 0; i < numRequests; i++ {
			err := <-results
			assert.NoError(t, err)
		}
	})
}

// TestSecurity tests security features
func (suite *E2ETestSuite) TestSecurity() {
	suite.T().Run("InputValidation", func(t *testing.T) {
		// Test with potentially malicious input
		request := map[string]interface{}{
			"prompt":   "<script>alert('xss')</script>",
			"language": "go",
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		// Should handle malicious input gracefully
		assert.True(t, resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusBadRequest)
	})

	suite.T().Run("RateLimiting", func(t *testing.T) {
		// Make multiple rapid requests to test rate limiting
		// This is a simplified test - in practice, you'd need more requests
		for i := 0; i < 10; i++ {
			resp, err := suite.client.Get(suite.baseURL + "/api/health")
			require.NoError(t, err)
			resp.Body.Close()

			// Check rate limit headers
			assert.Contains(t, resp.Header, "X-Ratelimit-Limit")
		}
	})
}

// TestIntegration tests integration between components
func (suite *E2ETestSuite) TestIntegration() {
	suite.T().Run("AIProviderIntegration", func(t *testing.T) {
		// Test AI provider switching
		resp, err := suite.client.Get(suite.baseURL + "/api/providers")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var providers map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&providers)
		require.NoError(t, err)

		assert.Contains(t, providers, "providers")
	})

	suite.T().Run("DatabaseIntegration", func(t *testing.T) {
		// Test that database operations work
		// This is tested implicitly through session creation
		request := map[string]interface{}{
			"user_id": "integration-test-user",
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		resp, err := suite.client.Post(
			suite.baseURL+"/api/sessions",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusCreated, resp.StatusCode)
	})

	suite.T().Run("CacheIntegration", func(t *testing.T) {
		// Test caching by making the same request twice
		request := map[string]interface{}{
			"prompt":   "Create a cached function",
			"language": "go",
		}

		body, err := json.Marshal(request)
		require.NoError(t, err)

		// First request
		start1 := time.Now()
		resp1, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		resp1.Body.Close()
		duration1 := time.Since(start1)

		// Second request (should be faster due to caching)
		start2 := time.Now()
		resp2, err := suite.client.Post(
			suite.baseURL+"/api/generate",
			"application/json",
			bytes.NewBuffer(body),
		)
		require.NoError(t, err)
		resp2.Body.Close()
		duration2 := time.Since(start2)

		assert.Equal(t, http.StatusOK, resp1.StatusCode)
		assert.Equal(t, http.StatusOK, resp2.StatusCode)
		
		// Note: This test might not always pass due to various factors
		// In a real implementation, you'd have more sophisticated cache testing
		suite.logger.Info("Cache test durations", "first", duration1, "second", duration2)
	})
}

// TestRunner runs all E2E tests
func TestE2ESuite(t *testing.T) {
	// Skip E2E tests if not in E2E test mode
	if testing.Short() {
		t.Skip("Skipping E2E tests in short mode")
	}

	suite.Run(t, new(E2ETestSuite))
}

// BenchmarkE2E benchmarks the complete workflow
func BenchmarkE2E(b *testing.B) {
	// Setup benchmark environment
	suite := &E2ETestSuite{}
	suite.SetupSuite()
	defer suite.TearDownSuite()

	request := map[string]interface{}{
		"prompt":   "Create a simple function",
		"language": "go",
	}

	body, _ := json.Marshal(request)

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			resp, err := suite.client.Post(
				suite.baseURL+"/api/generate",
				"application/json",
				bytes.NewBuffer(body),
			)
			if err != nil {
				b.Fatal(err)
			}
			resp.Body.Close()
		}
	})
}
