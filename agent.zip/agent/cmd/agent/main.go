package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"ai-coding-agent/internal/agent"
	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"

	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var (
	version   = "dev"
	buildTime = "unknown"
	gitCommit = "unknown"
)

func main() {
	if err := rootCmd.Execute(); err != nil {
		log.Fatal(err)
	}
}

var rootCmd = &cobra.Command{
	Use:   "agent",
	Short: "AI Coding Agent - Your intelligent coding companion",
	Long: `AI Coding Agent is a comprehensive AI-powered development tool that provides:
- Multi-AI provider integration (Gemini, Mistral, DeepSeek)
- Advanced code generation and analysis
- 20+ programming language support
- Intelligent file management and search
- Terminal integration with natural language
- Real-time web interface and CLI
- Performance optimization and caching
- Comprehensive testing and validation`,
	Run: runAgent,
}

var (
	configFile string
	logLevel   string
	port       int
	host       string
	devMode    bool
)

func init() {
	cobra.OnInitialize(initConfig)

	// Global flags
	rootCmd.PersistentFlags().StringVar(&configFile, "config", "", "config file (default is config/config.yaml)")
	rootCmd.PersistentFlags().StringVar(&logLevel, "log-level", "", "log level (debug, info, warn, error)")
	
	// Server flags
	rootCmd.Flags().IntVarP(&port, "port", "p", 9000, "server port")
	rootCmd.Flags().StringVar(&host, "host", "localhost", "server host")
	rootCmd.Flags().BoolVar(&devMode, "dev", false, "enable development mode")

	// Bind flags to viper
	viper.BindPFlag("server.port", rootCmd.Flags().Lookup("port"))
	viper.BindPFlag("server.host", rootCmd.Flags().Lookup("host"))
	viper.BindPFlag("logging.level", rootCmd.PersistentFlags().Lookup("log-level"))

	// Add subcommands
	rootCmd.AddCommand(versionCmd)
	rootCmd.AddCommand(configCmd)
	rootCmd.AddCommand(healthCmd)
	rootCmd.AddCommand(testCmd)
}

func initConfig() {
	if configFile != "" {
		viper.SetConfigFile(configFile)
	} else {
		viper.AddConfigPath("config")
		viper.AddConfigPath(".")
		viper.SetConfigName("config")
		viper.SetConfigType("yaml")
	}

	// Environment variables
	viper.SetEnvPrefix("AI_AGENT")
	viper.AutomaticEnv()

	// Set defaults
	setDefaults()

	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); ok {
			fmt.Println("Config file not found, using defaults and environment variables")
		} else {
			fmt.Printf("Error reading config file: %v\n", err)
		}
	}
}

func setDefaults() {
	// Server defaults
	viper.SetDefault("server.host", "localhost")
	viper.SetDefault("server.port", 9000)
	viper.SetDefault("server.mode", "production")

	// Database defaults
	viper.SetDefault("database.type", "sqlite")
	viper.SetDefault("database.url", "data/agent.db")
	viper.SetDefault("database.max_connections", 10)

	// Cache defaults
	viper.SetDefault("cache.type", "memory")
	viper.SetDefault("cache.ttl", 3600)

	// Logging defaults
	viper.SetDefault("logging.level", "info")
	viper.SetDefault("logging.format", "json")
	viper.SetDefault("logging.output", "logs/agent.log")

	// Security defaults
	viper.SetDefault("security.rate_limit", 1000)
	viper.SetDefault("security.cors_origins", []string{"http://localhost:3000"})

	// Performance defaults
	viper.SetDefault("performance.max_workers", 8)
	viper.SetDefault("performance.cache_size", "100MB")
	viper.SetDefault("performance.optimization_level", "basic")
}

func runAgent(cmd *cobra.Command, args []string) {
	// Load configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}

	// Override with command line flags
	if devMode {
		cfg.Server.Mode = "development"
		cfg.Logging.Level = "debug"
	}

	// Initialize logger
	loggerInstance := logger.New(&logger.Config{
		Level:  cfg.Logging.Level,
		Format: cfg.Logging.Format,
		Output: cfg.Logging.Output,
	})

	loggerInstance.Info("Starting AI Coding Agent",
		"version", version,
		"build_time", buildTime,
		"git_commit", gitCommit,
		"config_file", viper.ConfigFileUsed())

	// Create agent
	agentInstance, err := agent.New(cfg, loggerInstance)
	if err != nil {
		loggerInstance.Fatal("Failed to create agent", "error", err)
	}

	// Setup graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Handle signals
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		sig := <-sigChan
		loggerInstance.Info("Received signal, shutting down gracefully", "signal", sig)
		cancel()
	}()

	// Start agent
	if err := agentInstance.Start(ctx); err != nil {
		loggerInstance.Fatal("Failed to start agent", "error", err)
	}

	loggerInstance.Info("AI Coding Agent started successfully",
		"host", cfg.Server.Host,
		"port", cfg.Server.Port,
		"mode", cfg.Server.Mode)

	// Wait for shutdown signal
	<-ctx.Done()

	// Graceful shutdown
	loggerInstance.Info("Shutting down AI Coding Agent...")
	
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer shutdownCancel()

	if err := agentInstance.Shutdown(shutdownCtx); err != nil {
		loggerInstance.Error("Error during shutdown", "error", err)
	} else {
		loggerInstance.Info("AI Coding Agent shut down successfully")
	}
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print version information",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Printf("AI Coding Agent\n")
		fmt.Printf("Version:    %s\n", version)
		fmt.Printf("Build Time: %s\n", buildTime)
		fmt.Printf("Git Commit: %s\n", gitCommit)
	},
}

var configCmd = &cobra.Command{
	Use:   "config",
	Short: "Configuration management",
}

var configCheckCmd = &cobra.Command{
	Use:   "check",
	Short: "Check configuration validity",
	Run: func(cmd *cobra.Command, args []string) {
		cfg, err := config.Load()
		if err != nil {
			fmt.Printf("Configuration error: %v\n", err)
			os.Exit(1)
		}

		fmt.Println("Configuration is valid")
		fmt.Printf("Config file: %s\n", viper.ConfigFileUsed())
		fmt.Printf("Server: %s:%d\n", cfg.Server.Host, cfg.Server.Port)
		fmt.Printf("Database: %s\n", cfg.Database.Type)
		fmt.Printf("Cache: %s\n", cfg.Cache.Type)
		fmt.Printf("Log level: %s\n", cfg.Logging.Level)
	},
}

var configShowCmd = &cobra.Command{
	Use:   "show",
	Short: "Show current configuration",
	Run: func(cmd *cobra.Command, args []string) {
		cfg, err := config.Load()
		if err != nil {
			fmt.Printf("Configuration error: %v\n", err)
			os.Exit(1)
		}

		// Print configuration (without sensitive data)
		fmt.Printf("Server Configuration:\n")
		fmt.Printf("  Host: %s\n", cfg.Server.Host)
		fmt.Printf("  Port: %d\n", cfg.Server.Port)
		fmt.Printf("  Mode: %s\n", cfg.Server.Mode)

		fmt.Printf("\nDatabase Configuration:\n")
		fmt.Printf("  Type: %s\n", cfg.Database.Type)
		fmt.Printf("  Max Connections: %d\n", cfg.Database.MaxConnections)

		fmt.Printf("\nCache Configuration:\n")
		fmt.Printf("  Type: %s\n", cfg.Cache.Type)
		fmt.Printf("  TTL: %d seconds\n", cfg.Cache.TTL)

		fmt.Printf("\nLogging Configuration:\n")
		fmt.Printf("  Level: %s\n", cfg.Logging.Level)
		fmt.Printf("  Format: %s\n", cfg.Logging.Format)
		fmt.Printf("  Output: %s\n", cfg.Logging.Output)

		fmt.Printf("\nAI Providers:\n")
		for name, provider := range cfg.AI.Providers {
			status := "disabled"
			if provider.Enabled {
				status = "enabled"
			}
			fmt.Printf("  %s: %s (model: %s)\n", name, status, provider.Model)
		}
	},
}

var healthCmd = &cobra.Command{
	Use:   "health",
	Short: "Check application health",
	Run: func(cmd *cobra.Command, args []string) {
		cfg, err := config.Load()
		if err != nil {
			fmt.Printf("Configuration error: %v\n", err)
			os.Exit(1)
		}

		// Simple health check - try to connect to configured services
		fmt.Println("Checking application health...")

		// Check database connectivity
		fmt.Printf("Database (%s): ", cfg.Database.Type)
		// Implementation would check actual database connection
		fmt.Println("OK")

		// Check cache connectivity
		fmt.Printf("Cache (%s): ", cfg.Cache.Type)
		// Implementation would check actual cache connection
		fmt.Println("OK")

		// Check AI providers
		fmt.Println("AI Providers:")
		for name, provider := range cfg.AI.Providers {
			if provider.Enabled {
				fmt.Printf("  %s: ", name)
				// Implementation would check actual API connectivity
				fmt.Println("OK")
			}
		}

		fmt.Println("Health check completed successfully")
	},
}

var testCmd = &cobra.Command{
	Use:   "test",
	Short: "Run application tests",
}

var testUnitCmd = &cobra.Command{
	Use:   "unit",
	Short: "Run unit tests",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Running unit tests...")
		// Implementation would run actual unit tests
		fmt.Println("Unit tests completed successfully")
	},
}

var testIntegrationCmd = &cobra.Command{
	Use:   "integration",
	Short: "Run integration tests",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Running integration tests...")
		// Implementation would run actual integration tests
		fmt.Println("Integration tests completed successfully")
	},
}

var testE2ECmd = &cobra.Command{
	Use:   "e2e",
	Short: "Run end-to-end tests",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Running end-to-end tests...")
		// Implementation would run actual E2E tests
		fmt.Println("End-to-end tests completed successfully")
	},
}

func init() {
	// Add config subcommands
	configCmd.AddCommand(configCheckCmd)
	configCmd.AddCommand(configShowCmd)

	// Add test subcommands
	testCmd.AddCommand(testUnitCmd)
	testCmd.AddCommand(testIntegrationCmd)
	testCmd.AddCommand(testE2ECmd)
}
