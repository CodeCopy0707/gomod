package config

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/joho/godotenv"
	"github.com/spf13/viper"
)

// Config represents the main configuration structure
type Config struct {
	Server   *ServerConfig   `mapstructure:"server"`
	AI       *AIConfig       `mapstructure:"ai"`
	Database *DatabaseConfig `mapstructure:"database"`
	Cache    *CacheConfig    `mapstructure:"cache"`
	Logging  *LoggingConfig  `mapstructure:"logging"`
	Tools    *ToolsConfig    `mapstructure:"tools"`
	Security *SecurityConfig `mapstructure:"security"`
	Features *FeaturesConfig `mapstructure:"features"`
}

// ServerConfig holds server configuration
type ServerConfig struct {
	Host    string `mapstructure:"host"`
	Port    int    `mapstructure:"port"`
	WebPort int    `mapstructure:"web_port"`
	APIPort int    `mapstructure:"api_port"`
	Mode    string `mapstructure:"mode"` // development, production
}

// AIConfig holds AI provider configurations
type AIConfig struct {
	PrimaryProvider       string           `mapstructure:"primary_provider"`
	FallbackProviders     []string         `mapstructure:"fallback_providers"`
	LoadBalancingStrategy string           `mapstructure:"load_balancing_strategy"`
	MaxContextTokens      int              `mapstructure:"max_context_tokens"`
	DefaultTemperature    float64          `mapstructure:"default_temperature"`
	MaxTokens             int              `mapstructure:"max_tokens"`
	Gemini                *GeminiConfig    `mapstructure:"gemini"`
	Mistral               *MistralConfig   `mapstructure:"mistral"`
	DeepSeek              *DeepSeekConfig  `mapstructure:"deepseek"`
	OpenAI                *OpenAIConfig    `mapstructure:"openai"`
}

// GeminiConfig holds Gemini-specific configuration
type GeminiConfig struct {
	Enabled     bool    `mapstructure:"enabled"`
	APIKey      string  `mapstructure:"api_key"`
	Model       string  `mapstructure:"model"`
	Temperature float64 `mapstructure:"temperature"`
	MaxTokens   int     `mapstructure:"max_tokens"`
	TopP        float64 `mapstructure:"top_p"`
	TopK        int     `mapstructure:"top_k"`
	Timeout     int     `mapstructure:"timeout"`
}

// MistralConfig holds Mistral-specific configuration
type MistralConfig struct {
	Enabled     bool    `mapstructure:"enabled"`
	APIKey      string  `mapstructure:"api_key"`
	BaseURL     string  `mapstructure:"base_url"`
	Model       string  `mapstructure:"model"`
	Temperature float64 `mapstructure:"temperature"`
	MaxTokens   int     `mapstructure:"max_tokens"`
	TopP        float64 `mapstructure:"top_p"`
	Timeout     int     `mapstructure:"timeout"`
}

// DeepSeekConfig holds DeepSeek-specific configuration
type DeepSeekConfig struct {
	Enabled     bool    `mapstructure:"enabled"`
	APIKey      string  `mapstructure:"api_key"`
	BaseURL     string  `mapstructure:"base_url"`
	Model       string  `mapstructure:"model"`
	Temperature float64 `mapstructure:"temperature"`
	MaxTokens   int     `mapstructure:"max_tokens"`
	TopP        float64 `mapstructure:"top_p"`
	Timeout     int     `mapstructure:"timeout"`
}

// OpenAIConfig holds OpenAI-specific configuration
type OpenAIConfig struct {
	Enabled     bool    `mapstructure:"enabled"`
	APIKey      string  `mapstructure:"api_key"`
	Model       string  `mapstructure:"model"`
	Temperature float64 `mapstructure:"temperature"`
	MaxTokens   int     `mapstructure:"max_tokens"`
	TopP        float64 `mapstructure:"top_p"`
	Timeout     int     `mapstructure:"timeout"`
}

// DatabaseConfig holds database configuration
type DatabaseConfig struct {
	Type     string `mapstructure:"type"`
	URL      string `mapstructure:"url"`
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Database string `mapstructure:"database"`
	Username string `mapstructure:"username"`
	Password string `mapstructure:"password"`
	SSLMode  string `mapstructure:"ssl_mode"`
	Timeout  int    `mapstructure:"timeout"`
}

// CacheConfig holds cache configuration
type CacheConfig struct {
	Type     string `mapstructure:"type"`
	URL      string `mapstructure:"url"`
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
	TTL      int    `mapstructure:"ttl"`
	Size     string `mapstructure:"size"`
}

// LoggingConfig holds logging configuration
type LoggingConfig struct {
	Level      string `mapstructure:"level"`
	Format     string `mapstructure:"format"`
	Output     string `mapstructure:"output"`
	File       string `mapstructure:"file"`
	MaxSize    int    `mapstructure:"max_size"`
	MaxBackups int    `mapstructure:"max_backups"`
	MaxAge     int    `mapstructure:"max_age"`
	Compress   bool   `mapstructure:"compress"`
}

// ToolsConfig holds tools configuration
type ToolsConfig struct {
	EnableWebSearch      bool     `mapstructure:"enable_web_search"`
	EnableCodeExecution  bool     `mapstructure:"enable_code_execution"`
	EnableFileOperations bool     `mapstructure:"enable_file_operations"`
	EnableTerminalAccess bool     `mapstructure:"enable_terminal_access"`
	EnableGitOperations  bool     `mapstructure:"enable_git_operations"`
	MaxFileSize          int64    `mapstructure:"max_file_size"`
	AllowedExtensions    []string `mapstructure:"allowed_extensions"`
	ExcludedDirectories  []string `mapstructure:"excluded_directories"`
	TerminalTimeout      int      `mapstructure:"terminal_timeout"`
	MaxCommandLength     int      `mapstructure:"max_command_length"`
}

// SecurityConfig holds security configuration
type SecurityConfig struct {
	JWTSecret           string `mapstructure:"jwt_secret"`
	EncryptionKey       string `mapstructure:"encryption_key"`
	SessionSecret       string `mapstructure:"session_secret"`
	RateLimitEnabled    bool   `mapstructure:"rate_limit_enabled"`
	RateLimitRequests   int    `mapstructure:"rate_limit_requests"`
	RateLimitWindow     int    `mapstructure:"rate_limit_window"`
	RequireAuth         bool   `mapstructure:"require_auth"`
	AllowedOrigins      []string `mapstructure:"allowed_origins"`
}

// FeaturesConfig holds feature flags
type FeaturesConfig struct {
	EnableExperimentalFeatures    bool `mapstructure:"enable_experimental_features"`
	EnableBetaFeatures           bool `mapstructure:"enable_beta_features"`
	EnableAdvancedDebugging      bool `mapstructure:"enable_advanced_debugging"`
	EnablePredictivePrefetching  bool `mapstructure:"enable_predictive_prefetching"`
	EnableSmartSuggestions       bool `mapstructure:"enable_smart_suggestions"`
	EnableAutoRefactoring        bool `mapstructure:"enable_auto_refactoring"`
	EnableCrossLanguageTranslation bool `mapstructure:"enable_cross_language_translation"`
	EnableMultilingual           bool `mapstructure:"enable_multilingual"`
}

// Load loads the configuration from various sources
func Load() (*Config, error) {
	// Load .env file if it exists
	if err := godotenv.Load(); err != nil {
		// .env file is optional, so we don't return an error
	}

	// Set up viper
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(".")
	viper.AddConfigPath("./config")
	viper.AddConfigPath("$HOME/.ai-coding-agent")
	viper.AddConfigPath("/etc/ai-coding-agent")

	// Set environment variable prefix
	viper.SetEnvPrefix("AGENT")
	viper.AutomaticEnv()
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))

	// Set defaults
	setDefaults()

	// Read config file
	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("error reading config file: %w", err)
		}
		// Config file not found, use defaults and environment variables
	}

	// Override with environment variables
	bindEnvironmentVariables()

	// Unmarshal config
	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		return nil, fmt.Errorf("error unmarshaling config: %w", err)
	}

	// Validate config
	if err := validateConfig(&config); err != nil {
		return nil, fmt.Errorf("config validation failed: %w", err)
	}

	return &config, nil
}

// setDefaults sets default configuration values
func setDefaults() {
	// Server defaults
	viper.SetDefault("server.host", "localhost")
	viper.SetDefault("server.port", 3000)
	viper.SetDefault("server.web_port", 8080)
	viper.SetDefault("server.api_port", 9000)
	viper.SetDefault("server.mode", "development")

	// AI defaults
	viper.SetDefault("ai.primary_provider", "gemini")
	viper.SetDefault("ai.fallback_providers", []string{"mistral", "deepseek"})
	viper.SetDefault("ai.load_balancing_strategy", "round_robin")
	viper.SetDefault("ai.max_context_tokens", 128000)
	viper.SetDefault("ai.default_temperature", 0.7)
	viper.SetDefault("ai.max_tokens", 4096)

	// Gemini defaults
	viper.SetDefault("ai.gemini.enabled", true)
	viper.SetDefault("ai.gemini.model", "gemini-pro")
	viper.SetDefault("ai.gemini.temperature", 0.7)
	viper.SetDefault("ai.gemini.max_tokens", 4096)
	viper.SetDefault("ai.gemini.top_p", 0.9)
	viper.SetDefault("ai.gemini.top_k", 40)
	viper.SetDefault("ai.gemini.timeout", 30)

	// Mistral defaults
	viper.SetDefault("ai.mistral.enabled", true)
	viper.SetDefault("ai.mistral.base_url", "https://api.mistral.ai/v1")
	viper.SetDefault("ai.mistral.model", "mistral-large-latest")
	viper.SetDefault("ai.mistral.temperature", 0.7)
	viper.SetDefault("ai.mistral.max_tokens", 4096)
	viper.SetDefault("ai.mistral.top_p", 0.9)
	viper.SetDefault("ai.mistral.timeout", 30)

	// DeepSeek defaults
	viper.SetDefault("ai.deepseek.enabled", true)
	viper.SetDefault("ai.deepseek.base_url", "https://api.deepseek.com")
	viper.SetDefault("ai.deepseek.model", "deepseek-chat")
	viper.SetDefault("ai.deepseek.temperature", 0.7)
	viper.SetDefault("ai.deepseek.max_tokens", 4096)
	viper.SetDefault("ai.deepseek.top_p", 0.9)
	viper.SetDefault("ai.deepseek.timeout", 30)

	// OpenAI defaults
	viper.SetDefault("ai.openai.enabled", false)
	viper.SetDefault("ai.openai.model", "gpt-4")
	viper.SetDefault("ai.openai.temperature", 0.7)
	viper.SetDefault("ai.openai.max_tokens", 4096)
	viper.SetDefault("ai.openai.top_p", 0.9)
	viper.SetDefault("ai.openai.timeout", 30)

	// Database defaults
	viper.SetDefault("database.type", "sqlite")
	viper.SetDefault("database.url", "sqlite:///data/agent.db")
	viper.SetDefault("database.timeout", 10)

	// Cache defaults
	viper.SetDefault("cache.type", "memory")
	viper.SetDefault("cache.ttl", 3600)
	viper.SetDefault("cache.size", "1GB")

	// Logging defaults
	viper.SetDefault("logging.level", "info")
	viper.SetDefault("logging.format", "json")
	viper.SetDefault("logging.output", "stdout")
	viper.SetDefault("logging.max_size", 100)
	viper.SetDefault("logging.max_backups", 3)
	viper.SetDefault("logging.max_age", 28)
	viper.SetDefault("logging.compress", true)

	// Tools defaults
	viper.SetDefault("tools.enable_web_search", true)
	viper.SetDefault("tools.enable_code_execution", true)
	viper.SetDefault("tools.enable_file_operations", true)
	viper.SetDefault("tools.enable_terminal_access", true)
	viper.SetDefault("tools.enable_git_operations", true)
	viper.SetDefault("tools.max_file_size", 10485760) // 10MB
	viper.SetDefault("tools.terminal_timeout", 30)
	viper.SetDefault("tools.max_command_length", 1000)

	// Security defaults
	viper.SetDefault("security.rate_limit_enabled", true)
	viper.SetDefault("security.rate_limit_requests", 1000)
	viper.SetDefault("security.rate_limit_window", 3600)
	viper.SetDefault("security.require_auth", false)

	// Features defaults
	viper.SetDefault("features.enable_experimental_features", false)
	viper.SetDefault("features.enable_beta_features", false)
	viper.SetDefault("features.enable_advanced_debugging", false)
	viper.SetDefault("features.enable_predictive_prefetching", true)
	viper.SetDefault("features.enable_smart_suggestions", true)
	viper.SetDefault("features.enable_auto_refactoring", true)
	viper.SetDefault("features.enable_cross_language_translation", true)
	viper.SetDefault("features.enable_multilingual", true)
}

// bindEnvironmentVariables binds environment variables to config keys
func bindEnvironmentVariables() {
	// AI provider API keys
	viper.BindEnv("ai.gemini.api_key", "GEMINI_API_KEY")
	viper.BindEnv("ai.mistral.api_key", "MISTRAL_API_KEY")
	viper.BindEnv("ai.deepseek.api_key", "DEEPSEEK_API_KEY")
	viper.BindEnv("ai.openai.api_key", "OPENAI_API_KEY")

	// Database
	viper.BindEnv("database.url", "DATABASE_URL")
	viper.BindEnv("database.host", "DB_HOST")
	viper.BindEnv("database.port", "DB_PORT")
	viper.BindEnv("database.database", "DB_NAME")
	viper.BindEnv("database.username", "DB_USER")
	viper.BindEnv("database.password", "DB_PASSWORD")

	// Cache
	viper.BindEnv("cache.url", "REDIS_URL")
	viper.BindEnv("cache.host", "REDIS_HOST")
	viper.BindEnv("cache.port", "REDIS_PORT")
	viper.BindEnv("cache.password", "REDIS_PASSWORD")
	viper.BindEnv("cache.db", "REDIS_DB")

	// Server
	viper.BindEnv("server.port", "PORT")
	viper.BindEnv("server.host", "HOST")
	viper.BindEnv("server.web_port", "WEB_PORT")
	viper.BindEnv("server.api_port", "API_PORT")

	// Security
	viper.BindEnv("security.jwt_secret", "JWT_SECRET")
	viper.BindEnv("security.encryption_key", "ENCRYPTION_KEY")
	viper.BindEnv("security.session_secret", "SESSION_SECRET")

	// Logging
	viper.BindEnv("logging.level", "LOG_LEVEL")
	viper.BindEnv("logging.file", "LOG_FILE")
}

// validateConfig validates the configuration
func validateConfig(config *Config) error {
	// Validate AI provider configuration
	if config.AI.Gemini.Enabled && config.AI.Gemini.APIKey == "" {
		return fmt.Errorf("Gemini API key is required when Gemini is enabled")
	}
	if config.AI.Mistral.Enabled && config.AI.Mistral.APIKey == "" {
		return fmt.Errorf("Mistral API key is required when Mistral is enabled")
	}
	if config.AI.DeepSeek.Enabled && config.AI.DeepSeek.APIKey == "" {
		return fmt.Errorf("DeepSeek API key is required when DeepSeek is enabled")
	}
	if config.AI.OpenAI.Enabled && config.AI.OpenAI.APIKey == "" {
		return fmt.Errorf("OpenAI API key is required when OpenAI is enabled")
	}

	// Validate that at least one AI provider is enabled
	if !config.AI.Gemini.Enabled && !config.AI.Mistral.Enabled && 
	   !config.AI.DeepSeek.Enabled && !config.AI.OpenAI.Enabled {
		return fmt.Errorf("at least one AI provider must be enabled")
	}

	// Validate server configuration
	if config.Server.Port <= 0 || config.Server.Port > 65535 {
		return fmt.Errorf("invalid server port: %d", config.Server.Port)
	}

	// Create data directory if it doesn't exist
	if config.Database.Type == "sqlite" {
		dataDir := filepath.Dir(strings.TrimPrefix(config.Database.URL, "sqlite://"))
		if err := os.MkdirAll(dataDir, 0755); err != nil {
			return fmt.Errorf("failed to create data directory: %w", err)
		}
	}

	return nil
}
