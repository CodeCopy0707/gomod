package agent

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strings"
	"time"

	"ai-coding-agent/internal/logger"
)

// CLI represents the command-line interface for the agent
type CLI struct {
	agent  *Agent
	logger logger.Logger
	reader *bufio.Reader
	ctx    context.Context
}

// NewCLI creates a new CLI instance
func (a *Agent) NewCLI() *CLI {
	return &CLI{
		agent:  a,
		logger: a.logger,
		reader: bufio.NewReader(os.Stdin),
		ctx:    a.ctx,
	}
}

// Start starts the interactive CLI
func (c *CLI) Start(ctx context.Context) error {
	c.printWelcome()
	c.printHelp()

	for {
		select {
		case <-ctx.Done():
			c.logger.Info("CLI shutting down...")
			return nil
		default:
			if err := c.processCommand(); err != nil {
				if err.Error() == "exit" {
					c.printGoodbye()
					return nil
				}
				c.logger.Error("Command error", "error", err)
			}
		}
	}
}

// printWelcome prints the welcome message
func (c *CLI) printWelcome() {
	fmt.Println()
	fmt.Println("🤖 AI Coding Agent - Interactive Mode")
	fmt.Println("=====================================")
	fmt.Println()
	fmt.Println("Welcome to the AI Coding Agent! I'm here to help you with:")
	fmt.Println("• Code generation and refactoring")
	fmt.Println("• Bug fixing and debugging")
	fmt.Println("• Project management and planning")
	fmt.Println("• Documentation and testing")
	fmt.Println("• And much more!")
	fmt.Println()
}

// printHelp prints the help message
func (c *CLI) printHelp() {
	fmt.Println("Available commands:")
	fmt.Println("  help, h          - Show this help message")
	fmt.Println("  exit, quit, q    - Exit the agent")
	fmt.Println("  clear, cls       - Clear the screen")
	fmt.Println("  status           - Show agent status")
	fmt.Println("  tools            - List available tools")
	fmt.Println("  history          - Show conversation history")
	fmt.Println("  config           - Show configuration")
	fmt.Println("  metrics          - Show performance metrics")
	fmt.Println()
	fmt.Println("Or simply type your request in natural language!")
	fmt.Println("Examples:")
	fmt.Println("  \"Create a REST API in Go\"")
	fmt.Println("  \"Fix the bug in my Python code\"")
	fmt.Println("  \"Generate tests for this function\"")
	fmt.Println("  \"Explain this code to me\"")
	fmt.Println()
}

// processCommand processes a single command
func (c *CLI) processCommand() error {
	fmt.Print("🤖 > ")
	
	input, err := c.reader.ReadString('\n')
	if err != nil {
		return fmt.Errorf("failed to read input: %w", err)
	}

	input = strings.TrimSpace(input)
	if input == "" {
		return nil
	}

	// Handle built-in commands
	switch strings.ToLower(input) {
	case "help", "h":
		c.printHelp()
		return nil

	case "exit", "quit", "q":
		return fmt.Errorf("exit")

	case "clear", "cls":
		c.clearScreen()
		return nil

	case "status":
		c.printStatus()
		return nil

	case "tools":
		c.printTools()
		return nil

	case "history":
		c.printHistory()
		return nil

	case "config":
		c.printConfig()
		return nil

	case "metrics":
		c.printMetrics()
		return nil

	default:
		// Process as natural language input
		return c.processNaturalLanguageInput(input)
	}
}

// processNaturalLanguageInput processes natural language input
func (c *CLI) processNaturalLanguageInput(input string) error {
	fmt.Println()
	fmt.Println("🤔 Processing your request...")
	
	startTime := time.Now()
	
	// Show typing indicator
	done := make(chan bool)
	go c.showTypingIndicator(done)

	// Process the input
	response, err := c.agent.ProcessInput(c.ctx, input)
	
	// Stop typing indicator
	done <- true
	
	if err != nil {
		fmt.Printf("❌ Error: %v\n\n", err)
		return nil
	}

	duration := time.Since(startTime)
	
	fmt.Printf("✅ Response (took %v):\n", duration.Round(time.Millisecond))
	fmt.Println("─────────────────────────────────────")
	fmt.Println(response)
	fmt.Println("─────────────────────────────────────")
	fmt.Println()

	return nil
}

// showTypingIndicator shows a typing indicator
func (c *CLI) showTypingIndicator(done chan bool) {
	chars := []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}
	i := 0
	
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()

	for {
		select {
		case <-done:
			fmt.Print("\r   \r") // Clear the indicator
			return
		case <-ticker.C:
			fmt.Printf("\r%s Thinking...", chars[i%len(chars)])
			i++
		}
	}
}

// clearScreen clears the terminal screen
func (c *CLI) clearScreen() {
	fmt.Print("\033[2J\033[H")
	c.printWelcome()
}

// printStatus prints the agent status
func (c *CLI) printStatus() {
	fmt.Println()
	fmt.Println("📊 Agent Status")
	fmt.Println("===============")
	
	// Get session info
	session := c.agent.getOrCreateSession("default", "default")
	
	fmt.Printf("Status: %s\n", "🟢 Active")
	fmt.Printf("Session ID: %s\n", session.ID)
	fmt.Printf("Messages in history: %d\n", len(session.History))
	fmt.Printf("Working directory: %s\n", session.Context.WorkingDirectory)
	fmt.Printf("AI Provider: %s\n", c.agent.config.AI.PrimaryProvider)
	fmt.Printf("Uptime: %v\n", time.Since(session.CreatedAt).Round(time.Second))
	
	// Show active sessions
	c.agent.sessionsMux.RLock()
	sessionCount := len(c.agent.sessions)
	c.agent.sessionsMux.RUnlock()
	
	fmt.Printf("Active sessions: %d\n", sessionCount)
	fmt.Println()
}

// printTools prints available tools
func (c *CLI) printTools() {
	fmt.Println()
	fmt.Println("🔧 Available Tools")
	fmt.Println("==================")
	
	tools := c.agent.tools.ListTools()
	categories := c.agent.tools.GetToolsByCategory()
	
	for category, toolNames := range categories {
		fmt.Printf("\n📁 %s:\n", strings.Title(strings.ReplaceAll(category, "_", " ")))
		for _, toolName := range toolNames {
			if contains(tools, toolName) {
				if desc, err := c.agent.tools.GetToolDescription(toolName); err == nil {
					fmt.Printf("  • %s - %s\n", toolName, desc)
				} else {
					fmt.Printf("  • %s\n", toolName)
				}
			}
		}
	}
	
	fmt.Printf("\nTotal tools available: %d\n", len(tools))
	fmt.Println()
}

// printHistory prints conversation history
func (c *CLI) printHistory() {
	fmt.Println()
	fmt.Println("📜 Conversation History")
	fmt.Println("=======================")
	
	session := c.agent.getOrCreateSession("default", "default")
	messages := session.GetRecentMessages(10) // Show last 10 messages
	
	if len(messages) == 0 {
		fmt.Println("No conversation history yet.")
		fmt.Println()
		return
	}
	
	for i, msg := range messages {
		icon := "👤"
		if msg.Role == "assistant" {
			icon = "🤖"
		}
		
		fmt.Printf("%d. %s [%s] %s\n", i+1, icon, msg.Timestamp.Format("15:04:05"), 
			truncateString(msg.Content, 80))
	}
	
	if len(session.History) > 10 {
		fmt.Printf("\n... and %d more messages\n", len(session.History)-10)
	}
	
	fmt.Println()
}

// printConfig prints configuration information
func (c *CLI) printConfig() {
	fmt.Println()
	fmt.Println("⚙️  Configuration")
	fmt.Println("=================")
	
	fmt.Printf("Primary AI Provider: %s\n", c.agent.config.AI.PrimaryProvider)
	fmt.Printf("Fallback Providers: %v\n", c.agent.config.AI.FallbackProviders)
	fmt.Printf("Max Context Tokens: %d\n", c.agent.config.AI.MaxContextTokens)
	fmt.Printf("Default Temperature: %.2f\n", c.agent.config.AI.DefaultTemperature)
	fmt.Printf("Database Type: %s\n", c.agent.config.Database.Type)
	fmt.Printf("Cache Type: %s\n", c.agent.config.Cache.Type)
	fmt.Printf("Log Level: %s\n", c.agent.config.Logging.Level)
	
	fmt.Println("\nEnabled Features:")
	fmt.Printf("  • Web Search: %v\n", c.agent.config.Tools.EnableWebSearch)
	fmt.Printf("  • Code Execution: %v\n", c.agent.config.Tools.EnableCodeExecution)
	fmt.Printf("  • File Operations: %v\n", c.agent.config.Tools.EnableFileOperations)
	fmt.Printf("  • Terminal Access: %v\n", c.agent.config.Tools.EnableTerminalAccess)
	fmt.Printf("  • Git Operations: %v\n", c.agent.config.Tools.EnableGitOperations)
	
	fmt.Println()
}

// printMetrics prints performance metrics
func (c *CLI) printMetrics() {
	fmt.Println()
	fmt.Println("📈 Performance Metrics")
	fmt.Println("======================")
	
	metrics := c.agent.metrics
	metrics.mutex.RLock()
	defer metrics.mutex.RUnlock()
	
	fmt.Printf("Requests Processed: %d\n", metrics.RequestsProcessed)
	fmt.Printf("Average Response Time: %v\n", metrics.AverageResponseTime.Round(time.Millisecond))
	fmt.Printf("Error Rate: %.2f%%\n", metrics.ErrorRate)
	fmt.Printf("Cache Hit Rate: %.2f%%\n", metrics.CacheHitRate)
	fmt.Printf("Active Sessions: %d\n", metrics.ActiveSessions)
	fmt.Printf("Total Sessions: %d\n", metrics.TotalSessions)
	
	// AI provider metrics
	aiMetrics := c.agent.ai.GetMetrics()
	if len(aiMetrics) > 0 {
		fmt.Println("\nAI Provider Metrics:")
		for provider, stats := range aiMetrics {
			fmt.Printf("  %s:\n", provider)
			fmt.Printf("    Requests: %d\n", stats.RequestCount)
			fmt.Printf("    Success Rate: %.2f%%\n", 
				float64(stats.SuccessCount)/float64(stats.RequestCount)*100)
			fmt.Printf("    Avg Latency: %v\n", stats.AverageLatency.Round(time.Millisecond))
			fmt.Printf("    Health: %v\n", stats.HealthStatus)
		}
	}
	
	fmt.Println()
}

// printGoodbye prints the goodbye message
func (c *CLI) printGoodbye() {
	fmt.Println()
	fmt.Println("👋 Thank you for using AI Coding Agent!")
	fmt.Println("Have a great day and happy coding! 🚀")
	fmt.Println()
}

// Helper functions

// contains checks if a slice contains a string
func contains(slice []string, item string) bool {
	for _, s := range slice {
		if s == item {
			return true
		}
	}
	return false
}

// truncateString truncates a string to a maximum length
func truncateString(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
