package agent

import (
	"context"
	"fmt"
	"sync"
	"time"

	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"
	"ai-coding-agent/pkg/tools"
	"ai-coding-agent/pkg/memory"
	"ai-coding-agent/pkg/planning"
	"ai-coding-agent/pkg/intelligence"
)

// Agent represents the main AI coding agent
type Agent struct {
	config      *config.Config
	logger      logger.Logger
	ai          *ai.Manager
	database    database.Database
	cache       cache.Cache
	tools       *tools.Manager
	memory      *memory.Manager
	planner     *planning.Manager
	intelligence *intelligence.Manager
	
	// State management
	sessions    map[string]*Session
	sessionsMux sync.RWMutex
	
	// Performance tracking
	metrics     *Metrics
	
	// Shutdown handling
	ctx    context.Context
	cancel context.CancelFunc
}

// Config holds the configuration for the agent
type Config struct {
	AI       *ai.Manager
	Database database.Database
	Cache    cache.Cache
	Logger   logger.Logger
	Config   *config.Config
}

// Session represents a user session with the agent
type Session struct {
	ID          string
	UserID      string
	Context     *SessionContext
	History     []*Message
	State       SessionState
	CreatedAt   time.Time
	UpdatedAt   time.Time
	mutex       sync.RWMutex
}

// SessionContext holds the context for a session
type SessionContext struct {
	WorkingDirectory string
	OpenFiles        []string
	ActiveProject    *Project
	Variables        map[string]interface{}
	Preferences      *UserPreferences
}

// Message represents a message in the conversation
type Message struct {
	ID        string
	Role      string // user, assistant, system, tool
	Content   string
	Metadata  map[string]interface{}
	Timestamp time.Time
}

// SessionState represents the state of a session
type SessionState string

const (
	SessionStateActive    SessionState = "active"
	SessionStateIdle      SessionState = "idle"
	SessionStatePaused    SessionState = "paused"
	SessionStateCompleted SessionState = "completed"
)

// Project represents a project being worked on
type Project struct {
	ID          string
	Name        string
	Path        string
	Language    string
	Framework   string
	Description string
	Goals       []string
	Tasks       []*Task
	Files       []*ProjectFile
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// Task represents a task in the project
type Task struct {
	ID          string
	Title       string
	Description string
	Status      TaskStatus
	Priority    TaskPriority
	Dependencies []string
	Assignee    string
	CreatedAt   time.Time
	UpdatedAt   time.Time
	CompletedAt *time.Time
}

// TaskStatus represents the status of a task
type TaskStatus string

const (
	TaskStatusPending    TaskStatus = "pending"
	TaskStatusInProgress TaskStatus = "in_progress"
	TaskStatusCompleted  TaskStatus = "completed"
	TaskStatusBlocked    TaskStatus = "blocked"
	TaskStatusCancelled  TaskStatus = "cancelled"
)

// TaskPriority represents the priority of a task
type TaskPriority string

const (
	TaskPriorityLow    TaskPriority = "low"
	TaskPriorityMedium TaskPriority = "medium"
	TaskPriorityHigh   TaskPriority = "high"
	TaskPriorityCritical TaskPriority = "critical"
)

// ProjectFile represents a file in the project
type ProjectFile struct {
	Path        string
	Language    string
	Size        int64
	LastModified time.Time
	Checksum    string
}

// UserPreferences represents user preferences
type UserPreferences struct {
	Language           string
	Theme              string
	CodeStyle          string
	PreferredFrameworks []string
	AIProvider         string
	AutoSave           bool
	Notifications      bool
}

// Metrics holds performance metrics
type Metrics struct {
	RequestsProcessed   int64
	AverageResponseTime time.Duration
	ErrorRate          float64
	CacheHitRate       float64
	ActiveSessions     int64
	TotalSessions      int64
	mutex              sync.RWMutex
}

// New creates a new agent instance
func New(cfg *Config) (*Agent, error) {
	ctx, cancel := context.WithCancel(context.Background())
	
	// Initialize tools manager
	toolsManager, err := tools.NewManager(cfg.Logger)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to initialize tools manager: %w", err)
	}
	
	// Initialize memory manager
	memoryManager, err := memory.NewManager(cfg.Database, cfg.Cache, cfg.Logger)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to initialize memory manager: %w", err)
	}
	
	// Initialize planning manager
	planningManager, err := planning.NewManager(cfg.AI, cfg.Logger)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to initialize planning manager: %w", err)
	}
	
	// Initialize intelligence manager
	intelligenceManager, err := intelligence.NewManager(cfg.AI, cfg.Cache, cfg.Logger)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("failed to initialize intelligence manager: %w", err)
	}
	
	agent := &Agent{
		config:       cfg.Config,
		logger:       cfg.Logger,
		ai:           cfg.AI,
		database:     cfg.Database,
		cache:        cfg.Cache,
		tools:        toolsManager,
		memory:       memoryManager,
		planner:      planningManager,
		intelligence: intelligenceManager,
		sessions:     make(map[string]*Session),
		metrics:      &Metrics{},
		ctx:          ctx,
		cancel:       cancel,
	}
	
	// Start background processes
	go agent.startBackgroundProcesses()
	
	cfg.Logger.Info("Agent initialized successfully")
	return agent, nil
}

// ProcessInput processes user input and returns a response
func (a *Agent) ProcessInput(ctx context.Context, input string) (string, error) {
	startTime := time.Now()
	defer func() {
		a.updateMetrics(time.Since(startTime))
	}()
	
	a.logger.Info("Processing input", "input", input)
	
	// Create or get session
	session := a.getOrCreateSession("default", "default")
	
	// Add user message to history
	userMessage := &Message{
		ID:        generateID(),
		Role:      "user",
		Content:   input,
		Timestamp: time.Now(),
	}
	session.AddMessage(userMessage)
	
	// Analyze input and determine intent
	intent, err := a.intelligence.AnalyzeIntent(ctx, input, session.Context)
	if err != nil {
		a.logger.Error("Failed to analyze intent", "error", err)
		return "", fmt.Errorf("failed to analyze intent: %w", err)
	}
	
	// Plan execution based on intent
	plan, err := a.planner.CreatePlan(ctx, intent, session.Context)
	if err != nil {
		a.logger.Error("Failed to create plan", "error", err)
		return "", fmt.Errorf("failed to create plan: %w", err)
	}
	
	// Execute plan
	result, err := a.executePlan(ctx, plan, session)
	if err != nil {
		a.logger.Error("Failed to execute plan", "error", err)
		return "", fmt.Errorf("failed to execute plan: %w", err)
	}
	
	// Generate response
	response, err := a.ai.GenerateResponse(ctx, &ai.GenerateRequest{
		Messages: session.GetRecentMessages(10),
		Context:  session.Context,
		Result:   result,
	})
	if err != nil {
		a.logger.Error("Failed to generate response", "error", err)
		return "", fmt.Errorf("failed to generate response: %w", err)
	}
	
	// Add assistant message to history
	assistantMessage := &Message{
		ID:        generateID(),
		Role:      "assistant",
		Content:   response,
		Timestamp: time.Now(),
	}
	session.AddMessage(assistantMessage)
	
	// Store in memory
	a.memory.Store(ctx, session.ID, userMessage, assistantMessage)
	
	return response, nil
}

// getOrCreateSession gets an existing session or creates a new one
func (a *Agent) getOrCreateSession(sessionID, userID string) *Session {
	a.sessionsMux.Lock()
	defer a.sessionsMux.Unlock()
	
	if session, exists := a.sessions[sessionID]; exists {
		session.UpdatedAt = time.Now()
		return session
	}
	
	session := &Session{
		ID:      sessionID,
		UserID:  userID,
		Context: &SessionContext{
			WorkingDirectory: ".",
			Variables:        make(map[string]interface{}),
			Preferences:      &UserPreferences{
				Language:    "en",
				Theme:       "dark",
				CodeStyle:   "standard",
				AIProvider:  "gemini",
				AutoSave:    true,
				Notifications: true,
			},
		},
		History:   make([]*Message, 0),
		State:     SessionStateActive,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}
	
	a.sessions[sessionID] = session
	a.metrics.TotalSessions++
	a.metrics.ActiveSessions++
	
	return session
}

// AddMessage adds a message to the session history
func (s *Session) AddMessage(message *Message) {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	
	s.History = append(s.History, message)
	s.UpdatedAt = time.Now()
}

// GetRecentMessages gets the most recent messages from the session
func (s *Session) GetRecentMessages(count int) []*Message {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	
	if len(s.History) <= count {
		return s.History
	}
	
	return s.History[len(s.History)-count:]
}

// executePlan executes a plan and returns the result
func (a *Agent) executePlan(ctx context.Context, plan *planning.Plan, session *Session) (*planning.Result, error) {
	a.logger.Info("Executing plan", "plan_id", plan.ID, "steps", len(plan.Steps))
	
	result := &planning.Result{
		PlanID:    plan.ID,
		Steps:     make([]*planning.StepResult, 0, len(plan.Steps)),
		StartTime: time.Now(),
	}
	
	for i, step := range plan.Steps {
		a.logger.Info("Executing step", "step", i+1, "total", len(plan.Steps), "action", step.Action)
		
		stepResult, err := a.executeStep(ctx, step, session)
		if err != nil {
			stepResult = &planning.StepResult{
				StepID:    step.ID,
				Success:   false,
				Error:     err.Error(),
				EndTime:   time.Now(),
			}
		}
		
		result.Steps = append(result.Steps, stepResult)
		
		if !stepResult.Success && step.Required {
			result.Success = false
			result.Error = fmt.Sprintf("Required step failed: %s", stepResult.Error)
			break
		}
	}
	
	result.EndTime = time.Now()
	result.Duration = result.EndTime.Sub(result.StartTime)
	
	if result.Error == "" {
		result.Success = true
	}
	
	return result, nil
}

// executeStep executes a single step in the plan
func (a *Agent) executeStep(ctx context.Context, step *planning.Step, session *Session) (*planning.StepResult, error) {
	startTime := time.Now()
	
	// Execute the step using the appropriate tool
	output, err := a.tools.Execute(ctx, step.Tool, step.Parameters)
	
	result := &planning.StepResult{
		StepID:    step.ID,
		Success:   err == nil,
		Output:    output,
		StartTime: startTime,
		EndTime:   time.Now(),
	}
	
	if err != nil {
		result.Error = err.Error()
	}
	
	return result, err
}

// startBackgroundProcesses starts background processes for the agent
func (a *Agent) startBackgroundProcesses() {
	// Start session cleanup
	go a.sessionCleanup()
	
	// Start metrics collection
	go a.metricsCollection()
	
	// Start predictive prefetching
	go a.intelligence.StartPrefetching(a.ctx)
}

// sessionCleanup cleans up inactive sessions
func (a *Agent) sessionCleanup() {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()
	
	for {
		select {
		case <-a.ctx.Done():
			return
		case <-ticker.C:
			a.cleanupInactiveSessions()
		}
	}
}

// cleanupInactiveSessions removes inactive sessions
func (a *Agent) cleanupInactiveSessions() {
	a.sessionsMux.Lock()
	defer a.sessionsMux.Unlock()
	
	cutoff := time.Now().Add(-30 * time.Minute)
	
	for id, session := range a.sessions {
		if session.UpdatedAt.Before(cutoff) {
			delete(a.sessions, id)
			a.metrics.ActiveSessions--
		}
	}
}

// metricsCollection collects and updates metrics
func (a *Agent) metricsCollection() {
	ticker := time.NewTicker(1 * time.Minute)
	defer ticker.Stop()
	
	for {
		select {
		case <-a.ctx.Done():
			return
		case <-ticker.C:
			a.collectMetrics()
		}
	}
}

// collectMetrics collects current metrics
func (a *Agent) collectMetrics() {
	// Implementation for metrics collection
	a.logger.Debug("Collecting metrics")
}

// updateMetrics updates performance metrics
func (a *Agent) updateMetrics(duration time.Duration) {
	a.metrics.mutex.Lock()
	defer a.metrics.mutex.Unlock()
	
	a.metrics.RequestsProcessed++
	
	// Update average response time
	if a.metrics.AverageResponseTime == 0 {
		a.metrics.AverageResponseTime = duration
	} else {
		a.metrics.AverageResponseTime = (a.metrics.AverageResponseTime + duration) / 2
	}
}

// generateID generates a unique ID
func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

// Close gracefully shuts down the agent
func (a *Agent) Close() error {
	a.logger.Info("Shutting down agent")
	a.cancel()
	return nil
}
