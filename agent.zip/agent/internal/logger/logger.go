package logger

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"ai-coding-agent/internal/config"

	"github.com/sirupsen/logrus"
	"gopkg.in/natefinch/lumberjack.v2"
)

// Logger interface defines the logging methods
type Logger interface {
	Debug(msg string, fields ...interface{})
	Info(msg string, fields ...interface{})
	Warn(msg string, fields ...interface{})
	Error(msg string, fields ...interface{})
	Fatal(msg string, fields ...interface{})
	WithField(key string, value interface{}) Logger
	WithFields(fields map[string]interface{}) Logger
}

// LogrusLogger implements the Logger interface using logrus
type LogrusLogger struct {
	logger *logrus.Logger
	entry  *logrus.Entry
}

// New creates a new logger instance
func New(config *config.LoggingConfig) Logger {
	logger := logrus.New()

	// Set log level
	level, err := logrus.ParseLevel(config.Level)
	if err != nil {
		level = logrus.InfoLevel
	}
	logger.SetLevel(level)

	// Set formatter
	switch config.Format {
	case "json":
		logger.SetFormatter(&logrus.JSONFormatter{
			TimestampFormat: time.RFC3339,
			FieldMap: logrus.FieldMap{
				logrus.FieldKeyTime:  "timestamp",
				logrus.FieldKeyLevel: "level",
				logrus.FieldKeyMsg:   "message",
				logrus.FieldKeyFunc:  "function",
				logrus.FieldKeyFile:  "file",
			},
		})
	default:
		logger.SetFormatter(&CustomTextFormatter{
			TimestampFormat: "2006-01-02 15:04:05",
			FullTimestamp:   true,
			ForceColors:     true,
		})
	}

	// Set output
	var output io.Writer
	switch config.Output {
	case "file":
		if config.File != "" {
			// Create log directory if it doesn't exist
			logDir := filepath.Dir(config.File)
			if err := os.MkdirAll(logDir, 0755); err != nil {
				fmt.Printf("Failed to create log directory: %v\n", err)
				output = os.Stdout
			} else {
				output = &lumberjack.Logger{
					Filename:   config.File,
					MaxSize:    config.MaxSize,    // megabytes
					MaxBackups: config.MaxBackups,
					MaxAge:     config.MaxAge, // days
					Compress:   config.Compress,
				}
			}
		} else {
			output = os.Stdout
		}
	default:
		output = os.Stdout
	}

	logger.SetOutput(output)

	// Add caller information
	logger.SetReportCaller(true)

	return &LogrusLogger{
		logger: logger,
		entry:  logrus.NewEntry(logger),
	}
}

// Debug logs a debug message
func (l *LogrusLogger) Debug(msg string, fields ...interface{}) {
	entry := l.entry
	if len(fields) > 0 {
		entry = entry.WithFields(parseFields(fields...))
	}
	entry.Debug(msg)
}

// Info logs an info message
func (l *LogrusLogger) Info(msg string, fields ...interface{}) {
	entry := l.entry
	if len(fields) > 0 {
		entry = entry.WithFields(parseFields(fields...))
	}
	entry.Info(msg)
}

// Warn logs a warning message
func (l *LogrusLogger) Warn(msg string, fields ...interface{}) {
	entry := l.entry
	if len(fields) > 0 {
		entry = entry.WithFields(parseFields(fields...))
	}
	entry.Warn(msg)
}

// Error logs an error message
func (l *LogrusLogger) Error(msg string, fields ...interface{}) {
	entry := l.entry
	if len(fields) > 0 {
		entry = entry.WithFields(parseFields(fields...))
	}
	entry.Error(msg)
}

// Fatal logs a fatal message and exits
func (l *LogrusLogger) Fatal(msg string, fields ...interface{}) {
	entry := l.entry
	if len(fields) > 0 {
		entry = entry.WithFields(parseFields(fields...))
	}
	entry.Fatal(msg)
}

// WithField adds a field to the logger
func (l *LogrusLogger) WithField(key string, value interface{}) Logger {
	return &LogrusLogger{
		logger: l.logger,
		entry:  l.entry.WithField(key, value),
	}
}

// WithFields adds multiple fields to the logger
func (l *LogrusLogger) WithFields(fields map[string]interface{}) Logger {
	return &LogrusLogger{
		logger: l.logger,
		entry:  l.entry.WithFields(logrus.Fields(fields)),
	}
}

// parseFields converts variadic arguments to logrus.Fields
func parseFields(fields ...interface{}) logrus.Fields {
	result := make(logrus.Fields)
	
	for i := 0; i < len(fields); i += 2 {
		if i+1 < len(fields) {
			if key, ok := fields[i].(string); ok {
				result[key] = fields[i+1]
			}
		}
	}
	
	return result
}

// CustomTextFormatter is a custom text formatter for logrus
type CustomTextFormatter struct {
	TimestampFormat string
	FullTimestamp   bool
	ForceColors     bool
}

// Format formats the log entry
func (f *CustomTextFormatter) Format(entry *logrus.Entry) ([]byte, error) {
	var b strings.Builder

	// Timestamp
	if f.FullTimestamp {
		timestamp := entry.Time.Format(f.TimestampFormat)
		if f.ForceColors {
			b.WriteString(fmt.Sprintf("\x1b[36m%s\x1b[0m ", timestamp))
		} else {
			b.WriteString(fmt.Sprintf("%s ", timestamp))
		}
	}

	// Level
	level := strings.ToUpper(entry.Level.String())
	if f.ForceColors {
		switch entry.Level {
		case logrus.DebugLevel:
			b.WriteString(fmt.Sprintf("\x1b[37m[%s]\x1b[0m", level))
		case logrus.InfoLevel:
			b.WriteString(fmt.Sprintf("\x1b[32m[%s]\x1b[0m", level))
		case logrus.WarnLevel:
			b.WriteString(fmt.Sprintf("\x1b[33m[%s]\x1b[0m", level))
		case logrus.ErrorLevel:
			b.WriteString(fmt.Sprintf("\x1b[31m[%s]\x1b[0m", level))
		case logrus.FatalLevel:
			b.WriteString(fmt.Sprintf("\x1b[35m[%s]\x1b[0m", level))
		default:
			b.WriteString(fmt.Sprintf("[%s]", level))
		}
	} else {
		b.WriteString(fmt.Sprintf("[%s]", level))
	}

	// Caller information
	if entry.HasCaller() {
		caller := f.formatCaller(entry.Caller)
		if f.ForceColors {
			b.WriteString(fmt.Sprintf(" \x1b[90m%s\x1b[0m", caller))
		} else {
			b.WriteString(fmt.Sprintf(" %s", caller))
		}
	}

	// Message
	b.WriteString(fmt.Sprintf(" %s", entry.Message))

	// Fields
	if len(entry.Data) > 0 {
		b.WriteString(" ")
		if f.ForceColors {
			b.WriteString("\x1b[90m")
		}
		
		first := true
		for key, value := range entry.Data {
			if !first {
				b.WriteString(" ")
			}
			b.WriteString(fmt.Sprintf("%s=%v", key, value))
			first = false
		}
		
		if f.ForceColors {
			b.WriteString("\x1b[0m")
		}
	}

	b.WriteString("\n")
	return []byte(b.String()), nil
}

// formatCaller formats the caller information
func (f *CustomTextFormatter) formatCaller(caller *runtime.Frame) string {
	// Extract just the filename and line number
	filename := filepath.Base(caller.File)
	return fmt.Sprintf("%s:%d", filename, caller.Line)
}

// NullLogger is a logger that discards all log messages
type NullLogger struct{}

// NewNullLogger creates a new null logger
func NewNullLogger() Logger {
	return &NullLogger{}
}

func (n *NullLogger) Debug(msg string, fields ...interface{}) {}
func (n *NullLogger) Info(msg string, fields ...interface{})  {}
func (n *NullLogger) Warn(msg string, fields ...interface{})  {}
func (n *NullLogger) Error(msg string, fields ...interface{}) {}
func (n *NullLogger) Fatal(msg string, fields ...interface{}) {}

func (n *NullLogger) WithField(key string, value interface{}) Logger {
	return n
}

func (n *NullLogger) WithFields(fields map[string]interface{}) Logger {
	return n
}

// TestLogger is a simple logger for testing
type TestLogger struct {
	messages []string
}

// NewTestLogger creates a new test logger
func NewTestLogger() *TestLogger {
	return &TestLogger{
		messages: make([]string, 0),
	}
}

func (t *TestLogger) Debug(msg string, fields ...interface{}) {
	t.messages = append(t.messages, fmt.Sprintf("DEBUG: %s", msg))
}

func (t *TestLogger) Info(msg string, fields ...interface{}) {
	t.messages = append(t.messages, fmt.Sprintf("INFO: %s", msg))
}

func (t *TestLogger) Warn(msg string, fields ...interface{}) {
	t.messages = append(t.messages, fmt.Sprintf("WARN: %s", msg))
}

func (t *TestLogger) Error(msg string, fields ...interface{}) {
	t.messages = append(t.messages, fmt.Sprintf("ERROR: %s", msg))
}

func (t *TestLogger) Fatal(msg string, fields ...interface{}) {
	t.messages = append(t.messages, fmt.Sprintf("FATAL: %s", msg))
}

func (t *TestLogger) WithField(key string, value interface{}) Logger {
	return t
}

func (t *TestLogger) WithFields(fields map[string]interface{}) Logger {
	return t
}

// GetMessages returns all logged messages
func (t *TestLogger) GetMessages() []string {
	return t.messages
}

// Clear clears all logged messages
func (t *TestLogger) Clear() {
	t.messages = make([]string, 0)
}
