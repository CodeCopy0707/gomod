package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"ai-coding-agent/internal/agent"
	"ai-coding-agent/internal/config"
	"ai-coding-agent/internal/logger"
	"ai-coding-agent/internal/server"
	"ai-coding-agent/pkg/ai"
	"ai-coding-agent/pkg/cache"
	"ai-coding-agent/pkg/database"

	"github.com/spf13/cobra"
)

var (
	version = "1.0.0"
	commit  = "dev"
	date    = "unknown"
)

func main() {
	rootCmd := &cobra.Command{
		Use:     "agent",
		Short:   "Advanced AI Coding Agent",
		Long:    `A production-ready AI coding agent with advanced capabilities for code generation, refactoring, debugging, and project management.`,
		Version: fmt.Sprintf("%s (commit: %s, built: %s)", version, commit, date),
		Run:     runAgent,
	}

	// Add flags
	rootCmd.Flags().BoolP("web", "w", false, "Start web interface")
	rootCmd.Flags().IntP("port", "p", 3000, "Port for web interface")
	rootCmd.Flags().StringP("config", "c", "", "Config file path")
	rootCmd.Flags().BoolP("verbose", "v", false, "Verbose logging")
	rootCmd.Flags().BoolP("debug", "d", false, "Debug mode")
	rootCmd.Flags().StringP("mode", "m", "interactive", "Mode: interactive, cli, web, api")
	rootCmd.Flags().StringSliceP("providers", "", []string{"gemini", "mistral", "deepseek"}, "AI providers to use")
	rootCmd.Flags().StringP("language", "l", "en", "Interface language")

	// Add subcommands
	rootCmd.AddCommand(
		createInitCommand(),
		createSetupCommand(),
		createTestCommand(),
		createVersionCommand(),
	)

	if err := rootCmd.Execute(); err != nil {
		log.Fatal(err)
	}
}

func runAgent(cmd *cobra.Command, args []string) {
	// Load configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}

	// Initialize logger
	logger := logger.New(cfg.Logging)

	// Initialize database
	db, err := database.New(cfg.Database)
	if err != nil {
		logger.Fatal("Failed to initialize database", "error", err)
	}
	defer db.Close()

	// Initialize cache
	cache, err := cache.New(cfg.Cache)
	if err != nil {
		logger.Fatal("Failed to initialize cache", "error", err)
	}
	defer cache.Close()

	// Initialize AI providers
	aiManager, err := ai.NewManager(cfg.AI, logger)
	if err != nil {
		logger.Fatal("Failed to initialize AI manager", "error", err)
	}

	// Create agent instance
	agentInstance, err := agent.New(&agent.Config{
		AI:       aiManager,
		Database: db,
		Cache:    cache,
		Logger:   logger,
		Config:   cfg,
	})
	if err != nil {
		logger.Fatal("Failed to create agent", "error", err)
	}

	// Get command line flags
	webMode, _ := cmd.Flags().GetBool("web")
	port, _ := cmd.Flags().GetInt("port")
	mode, _ := cmd.Flags().GetString("mode")

	// Create context for graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Handle shutdown signals
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigChan
		logger.Info("Received shutdown signal, gracefully shutting down...")
		cancel()
	}()

	// Start the appropriate mode
	switch {
	case webMode || mode == "web":
		startWebMode(ctx, agentInstance, port, logger)
	case mode == "api":
		startAPIMode(ctx, agentInstance, port, logger)
	case mode == "cli" && len(args) > 0:
		runCLIMode(ctx, agentInstance, args, logger)
	default:
		startInteractiveMode(ctx, agentInstance, logger)
	}
}

func startWebMode(ctx context.Context, agent *agent.Agent, port int, logger logger.Logger) {
	logger.Info("Starting web interface", "port", port)
	
	srv := server.NewWebServer(agent, port, logger)
	
	go func() {
		if err := srv.Start(); err != nil {
			logger.Error("Web server error", "error", err)
		}
	}()

	<-ctx.Done()
	
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	
	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("Error shutting down web server", "error", err)
	}
}

func startAPIMode(ctx context.Context, agent *agent.Agent, port int, logger logger.Logger) {
	logger.Info("Starting API server", "port", port)
	
	srv := server.NewAPIServer(agent, port, logger)
	
	go func() {
		if err := srv.Start(); err != nil {
			logger.Error("API server error", "error", err)
		}
	}()

	<-ctx.Done()
	
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	
	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("Error shutting down API server", "error", err)
	}
}

func runCLIMode(ctx context.Context, agent *agent.Agent, args []string, logger logger.Logger) {
	logger.Info("Running in CLI mode", "args", args)
	
	input := ""
	for i, arg := range args {
		if i > 0 {
			input += " "
		}
		input += arg
	}
	
	response, err := agent.ProcessInput(ctx, input)
	if err != nil {
		logger.Error("Error processing input", "error", err)
		os.Exit(1)
	}
	
	fmt.Println(response)
}

func startInteractiveMode(ctx context.Context, agent *agent.Agent, logger logger.Logger) {
	logger.Info("Starting interactive mode")
	
	cli := agent.NewCLI()
	if err := cli.Start(ctx); err != nil {
		logger.Error("CLI error", "error", err)
	}
}

func createInitCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "init",
		Short: "Initialize a new project with AI agent",
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Println("Initializing new project...")
			// Implementation for project initialization
		},
	}
}

func createSetupCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "setup",
		Short: "Setup the AI agent environment",
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Println("Setting up AI agent environment...")
			// Implementation for environment setup
		},
	}
}

func createTestCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "test",
		Short: "Run agent tests",
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Println("Running tests...")
			// Implementation for running tests
		},
	}
}

func createVersionCommand() *cobra.Command {
	return &cobra.Command{
		Use:   "version",
		Short: "Show version information",
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Printf("AI Coding Agent %s\n", version)
			fmt.Printf("Commit: %s\n", commit)
			fmt.Printf("Built: %s\n", date)
		},
	}
}
