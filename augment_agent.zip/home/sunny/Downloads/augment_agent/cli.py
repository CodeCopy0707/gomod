"""Command-line interface for Augment Agent."""

import sys
import os
import asyncio
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.prompt import Prompt, Confirm

from .core.config import Config
from .core.agent import AugmentAgent
from .utils.logging import setup_logging


console = Console()


@click.group(invoke_without_command=True)
@click.option(
    "--config", "-c",
    type=click.Path(exists=True),
    help="Path to configuration file"
)
@click.option(
    "--workspace", "-w",
    type=click.Path(exists=True),
    help="Workspace root directory"
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Enable verbose logging"
)
@click.option(
    "--interactive", "-i",
    is_flag=True,
    help="Start interactive mode"
)
@click.option(
    "--model", "-m",
    type=click.Choice(['gemini', 'mistral', 'deepseek', 'openai', 'anthropic', 'auto']),
    default='auto',
    help="AI model to use"
)
@click.pass_context
def main(ctx, config: Optional[str], workspace: Optional[str], verbose: bool, interactive: bool, model: str):
    """Augment Agent - AI-powered coding assistant for the command line."""
    
    # Ensure context object exists
    ctx.ensure_object(dict)
    
    # Load configuration
    try:
        agent_config = Config.load(config)
        if workspace:
            agent_config.workspace_root = workspace
        if verbose:
            agent_config.log_level = "DEBUG"
        if model != 'auto':
            agent_config.model_name = model
        
        agent_config.validate()
        ctx.obj['config'] = agent_config
        
        # Setup logging
        setup_logging(agent_config.log_level)
        
    except Exception as e:
        console.print(f"[red]Configuration error: {e}[/red]")
        sys.exit(1)
    
    # If no subcommand and not interactive, show help
    if ctx.invoked_subcommand is None:
        if interactive:
            asyncio.run(interactive_mode(agent_config))
        else:
            click.echo(ctx.get_help())


@main.command()
@click.argument("query", nargs=-1, required=True)
@click.option(
    "--output", "-o",
    type=click.Choice(["text", "markdown", "json"]),
    default="text",
    help="Output format"
)
@click.pass_context
def ask(ctx, query: tuple, output: str):
    """Ask the agent a question or give it a task."""
    config = ctx.obj['config']
    query_text = " ".join(query)
    
    asyncio.run(single_query_mode(config, query_text, output))


@main.command()
@click.pass_context
def chat(ctx):
    """Start interactive chat mode."""
    config = ctx.obj['config']
    asyncio.run(interactive_mode(config))


@main.command()
@click.option(
    "--output", "-o",
    type=click.Path(),
    help="Output configuration file path"
)
@click.pass_context
def init(ctx, output: Optional[str]):
    """Initialize configuration file."""
    if not output:
        output = "augment_agent.yaml"
    
    # Create default configuration
    config = Config()
    
    # Interactive configuration setup
    console.print(Panel.fit("Augment Agent Configuration Setup", style="bold blue"))
    
    # API Keys
    console.print("\n[bold]API Configuration[/bold]")
    gemini_key = Prompt.ask("Gemini API Key", password=True)
    if gemini_key:
        config.gemini_api_key = gemini_key
    
    if Confirm.ask("Enable web search capabilities?", default=True):
        config.enable_web_search = True
        google_search_key = Prompt.ask("Google Search API Key (optional)", password=True, default="")
        google_search_engine = Prompt.ask("Google Search Engine ID (optional)", default="")
        if google_search_key:
            config.google_search_api_key = google_search_key
        if google_search_engine:
            config.google_search_engine_id = google_search_engine
    else:
        config.enable_web_search = False
    
    # Workspace configuration
    console.print("\n[bold]Workspace Configuration[/bold]")
    workspace = Prompt.ask("Workspace root directory", default=os.getcwd())
    config.workspace_root = workspace
    
    # Safety settings
    console.print("\n[bold]Safety Settings[/bold]")
    config.require_confirmation_for_destructive_actions = Confirm.ask(
        "Require confirmation for destructive actions?", default=True
    )
    config.auto_backup_before_edits = Confirm.ask(
        "Auto-backup files before editing?", default=True
    )
    
    # Save configuration
    try:
        config.save(output)
        console.print(f"\n[green]Configuration saved to {output}[/green]")
        console.print("\n[yellow]Next steps:[/yellow]")
        console.print("1. Set your API keys in environment variables or the config file")
        console.print("2. Run 'augment-agent chat' to start interactive mode")
        console.print("3. Or use 'augment-agent ask \"your question\"' for single queries")
    except Exception as e:
        console.print(f"[red]Error saving configuration: {e}[/red]")
        sys.exit(1)


@main.command()
@click.pass_context
def status(ctx):
    """Show agent status and configuration."""
    config = ctx.obj['config']
    
    console.print(Panel.fit("Augment Agent Status", style="bold blue"))
    
    # Configuration status
    console.print("\n[bold]Configuration:[/bold]")
    console.print(f"  Workspace: {config.workspace_root}")
    console.print(f"  Repository: {config.repository_root}")
    console.print(f"  Data Directory: {config.data_dir}")
    console.print(f"  Model: {config.model_name}")
    
    # API status
    console.print("\n[bold]API Status:[/bold]")
    console.print(f"  Gemini API: {'✓' if config.gemini_api_key else '✗'}")
    console.print(f"  Google Search: {'✓' if config.google_search_api_key else '✗'}")
    
    # Feature status
    console.print("\n[bold]Features:[/bold]")
    console.print(f"  Web Search: {'✓' if config.enable_web_search else '✗'}")
    console.print(f"  Code Analysis: {'✓' if config.enable_code_analysis else '✗'}")
    console.print(f"  Process Management: {'✓' if config.enable_process_management else '✗'}")
    
    # Safety settings
    console.print("\n[bold]Safety:[/bold]")
    console.print(f"  Confirmation Required: {'✓' if config.require_confirmation_for_destructive_actions else '✗'}")
    console.print(f"  Auto Backup: {'✓' if config.auto_backup_before_edits else '✗'}")


@main.command()
@click.argument("path", type=click.Path(exists=True))
@click.pass_context
def index(ctx, path: str):
    """Index a codebase for better retrieval."""
    config = ctx.obj['config']
    
    console.print(f"[blue]Indexing codebase at: {path}[/blue]")
    
    # This will be implemented when we create the codebase indexing tool
    console.print("[yellow]Codebase indexing will be implemented in the next phase[/yellow]")


async def single_query_mode(config: Config, query: str, output_format: str):
    """Handle a single query and exit."""
    try:
        agent = AugmentAgent(config)
        await agent.initialize()
        
        console.print(f"[blue]Processing: {query}[/blue]")
        
        response = await agent.process_query(query)
        
        if output_format == "json":
            import json
            console.print(json.dumps({"query": query, "response": response}, indent=2))
        elif output_format == "markdown":
            console.print(response)
        else:
            console.print(response)
            
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


async def interactive_mode(config: Config):
    """Start interactive chat mode."""
    try:
        agent = AugmentAgent(config)
        await agent.initialize()
        
        console.print(Panel.fit(
            "[bold blue]🚀 Augment Agent - Advanced AI Coding Assistant[/bold blue]\n"
            "🤖 Multi-model AI support (Gemini, Mistral, DeepSeek, OpenAI, Anthropic)\n"
            "🔍 Smart code analysis and context awareness\n"
            "📋 Auto task planning and execution\n"
            "🛠️  20+ advanced coding tools\n\n"
            "💬 [bold]Natural Language Mode:[/bold] Just describe what you want!\n"
            "Examples:\n"
            "• 'Create a Python web scraper for news articles'\n"
            "• 'Find all functions similar to this code: def process_data()...'\n"
            "• 'Fix the malformed code I pasted from a screenshot'\n"
            "• 'Plan and implement a REST API with authentication'\n\n"
            "Type 'help' for commands, 'exit' to quit, or just start chatting!",
            title="🎯 Welcome",
            border_style="blue"
        ))

        # Show initialization status
        available_models = list(agent.models.keys())
        console.print(f"[green]✓[/green] Agent initialized with models: {', '.join(available_models)}")
        console.print(f"[green]✓[/green] Current model: {agent.current_model}")
        console.print(f"[green]✓[/green] Workspace: {config.workspace_root}")

        # Show available tools count
        tools = await agent.tool_manager.get_available_tools()
        console.print(f"[green]✓[/green] {len(tools)} tools available")
        
        while True:
            try:
                # Get user input
                user_input = Prompt.ask("\n[bold blue]You[/bold blue]")
                
                if user_input.lower() in ["exit", "quit", "q"]:
                    console.print("[yellow]Goodbye![/yellow]")
                    break
                elif user_input.lower() == "help":
                    show_help()
                    continue
                elif user_input.lower() == "clear":
                    console.clear()
                    continue
                elif user_input.lower() == "status":
                    await show_agent_status(agent)
                    continue
                
                # Process the query
                console.print("\n[bold green]Agent[/bold green]:")
                response = await agent.process_query(user_input)
                console.print(response)
                
            except KeyboardInterrupt:
                console.print("\n[yellow]Use 'exit' or 'quit' to leave[/yellow]")
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]")
                
    except Exception as e:
        console.print(f"[red]Failed to initialize agent: {e}[/red]")
        sys.exit(1)


def show_help():
    """Show interactive mode help."""
    help_text = """
[bold]Interactive Mode Commands:[/bold]

[blue]General:[/blue]
  help     - Show this help message
  clear    - Clear the screen
  status   - Show agent status
  exit/quit - Exit interactive mode

[blue]Usage:[/blue]
  Simply type your question or request and press Enter.
  The agent will process your request and provide a response.

[blue]Examples:[/blue]
  "Create a Python function to calculate fibonacci numbers"
  "Explain the code in main.py"
  "Help me debug this error: ..."
  "Search for information about React hooks"
"""
    console.print(Panel(help_text, title="Help", border_style="blue"))


async def show_agent_status(agent: AugmentAgent):
    """Show current agent status."""
    status_info = await agent.get_status()
    
    console.print(Panel.fit("Agent Status", style="bold blue"))
    console.print(f"Model: {status_info.get('model', 'Unknown')}")
    console.print(f"Active Tools: {len(status_info.get('tools', []))}")
    console.print(f"Memory Items: {status_info.get('memory_count', 0)}")
    console.print(f"Active Tasks: {status_info.get('active_tasks', 0)}")


if __name__ == "__main__":
    main()

