#!/usr/bin/env python3
"""
Quick verification script to check if Augment Agent is properly implemented.
This script verifies the structure and basic functionality without requiring dependencies.
"""

import os
import sys
from pathlib import Path


def check_file_structure():
    """Check if all required files and directories exist."""
    print("🔍 Checking file structure...")
    
    required_files = [
        "core/__init__.py",
        "core/agent.py",
        "core/config.py", 
        "core/tool_manager.py",
        "core/safety.py",
        "tools/__init__.py",
        "tools/file_operations.py",
        "tools/advanced_file_ops.py",
        "tools/code_analysis.py",
        "tools/advanced_code_finder.py",
        "tools/smart_string_replacer.py",
        "tools/input_fixer.py",
        "tools/long_file_indexer.py",
        "tools/code_translator.py",
        "tools/autonomous_debugger.py",
        "tools/auto_task_planner.py",
        "tools/project_scaffolder.py",
        "tools/task_memory.py",
        "tools/process_tools.py",
        "tools/web_tools.py",
        "tools/visualization.py",
        "tools/base.py",
        "utils/__init__.py",
        "utils/prediction_engine.py",
        "utils/context_compressor.py",
        "utils/logging.py",
        "cli.py",
        "setup.py",
        "README.md",
        "INSTALL.md",
        ".env.example"
    ]
    
    missing_files = []
    existing_files = []
    
    for file_path in required_files:
        if Path(file_path).exists():
            existing_files.append(file_path)
        else:
            missing_files.append(file_path)
    
    print(f"   ✅ Found {len(existing_files)} required files")
    
    if missing_files:
        print(f"   ⚠️  Missing {len(missing_files)} files:")
        for file in missing_files[:5]:  # Show first 5
            print(f"      - {file}")
        if len(missing_files) > 5:
            print(f"      ... and {len(missing_files) - 5} more")
        return False
    else:
        print("   ✅ All required files present")
        return True


def check_tool_implementations():
    """Check if all required tools are implemented."""
    print("🛠️  Checking tool implementations...")
    
    tools_dir = Path("tools")
    if not tools_dir.exists():
        print("   ❌ Tools directory not found")
        return False
    
    # Check for key tool files
    key_tools = [
        "advanced_code_finder.py",
        "smart_string_replacer.py", 
        "input_fixer.py",
        "long_file_indexer.py",
        "code_translator.py",
        "autonomous_debugger.py",
        "auto_task_planner.py",
        "project_scaffolder.py"
    ]
    
    implemented_tools = []
    missing_tools = []
    
    for tool in key_tools:
        tool_path = tools_dir / tool
        if tool_path.exists():
            # Check if it has substantial content (not just a stub)
            try:
                with open(tool_path, 'r') as f:
                    content = f.read()
                    if len(content) > 1000:  # Substantial implementation
                        implemented_tools.append(tool)
                    else:
                        missing_tools.append(f"{tool} (stub)")
            except:
                missing_tools.append(f"{tool} (unreadable)")
        else:
            missing_tools.append(tool)
    
    print(f"   ✅ Implemented tools: {len(implemented_tools)}")
    for tool in implemented_tools:
        print(f"      ✅ {tool}")
    
    if missing_tools:
        print(f"   ⚠️  Missing/incomplete tools: {len(missing_tools)}")
        for tool in missing_tools:
            print(f"      ❌ {tool}")
        return False
    else:
        print("   ✅ All key tools implemented")
        return True


def check_advanced_features():
    """Check if advanced features are implemented."""
    print("🚀 Checking advanced features...")
    
    # Check agent.py for advanced features
    agent_file = Path("core/agent.py")
    if not agent_file.exists():
        print("   ❌ Agent file not found")
        return False
    
    try:
        with open(agent_file, 'r') as f:
            agent_content = f.read()
        
        features_to_check = [
            ("Multi-threading", ["ThreadPoolExecutor", "executor", "concurrent.futures"]),
            ("Predictive prefetching", ["prediction_queue", "prefetch_cache", "prediction_engine"]),
            ("Context compression", ["context_compressor", "rag_enabled"]),
            ("Chain-of-thought", ["reasoning_steps", "current_analysis"]),
            ("Multi-model support", ["mistral", "deepseek", "_send_message_mistral", "_send_message_deepseek"])
        ]
        
        implemented_features = []
        missing_features = []
        
        for feature_name, keywords in features_to_check:
            if any(keyword in agent_content for keyword in keywords):
                implemented_features.append(feature_name)
            else:
                missing_features.append(feature_name)
        
        print(f"   ✅ Implemented features: {len(implemented_features)}")
        for feature in implemented_features:
            print(f"      ✅ {feature}")
        
        if missing_features:
            print(f"   ⚠️  Missing features: {len(missing_features)}")
            for feature in missing_features:
                print(f"      ❌ {feature}")
            return False
        else:
            print("   ✅ All advanced features implemented")
            return True
            
    except Exception as e:
        print(f"   ❌ Error checking agent file: {e}")
        return False


def check_configuration():
    """Check configuration completeness."""
    print("⚙️  Checking configuration...")
    
    config_file = Path("core/config.py")
    if not config_file.exists():
        print("   ❌ Config file not found")
        return False
    
    try:
        with open(config_file, 'r') as f:
            config_content = f.read()
        
        required_configs = [
            "mistral_api_key",
            "deepseek_api_key", 
            "enable_multi_threading",
            "enable_predictive_prefetching",
            "enable_context_compression",
            "enable_chain_of_thought",
            "max_concurrent_tasks",
            "context_window_size"
        ]
        
        missing_configs = []
        for config in required_configs:
            if config not in config_content:
                missing_configs.append(config)
        
        if missing_configs:
            print(f"   ⚠️  Missing configurations: {', '.join(missing_configs)}")
            return False
        else:
            print("   ✅ All required configurations present")
            return True
            
    except Exception as e:
        print(f"   ❌ Error checking config file: {e}")
        return False


def check_env_example():
    """Check .env.example file."""
    print("🔑 Checking environment configuration...")
    
    env_file = Path(".env.example")
    if not env_file.exists():
        print("   ❌ .env.example file not found")
        return False
    
    try:
        with open(env_file, 'r') as f:
            env_content = f.read()
        
        # Check for API keys from plan.md
        required_keys = [
            "GEMINI_API_KEY=AIzaSyDc7u7wTVdDG3zP18xnELKs0HX7-hImkmc",
            "MISTRAL_API_KEY=vlVy39wyXd1jkURNevvMkGuqKaPBj3Ek", 
            "DEEPSEEK_API_KEY=sk-e7e09578837e40aa98687e8494ebb2bd"
        ]
        
        missing_keys = []
        for key in required_keys:
            if key not in env_content:
                missing_keys.append(key.split('=')[0])
        
        if missing_keys:
            print(f"   ⚠️  Missing API keys: {', '.join(missing_keys)}")
            return False
        else:
            print("   ✅ All required API keys present")
            return True
            
    except Exception as e:
        print(f"   ❌ Error checking .env.example: {e}")
        return False


def main():
    """Run all verification checks."""
    print("🎯 AUGMENT AGENT IMPLEMENTATION VERIFICATION")
    print("=" * 50)
    
    checks = [
        ("File Structure", check_file_structure),
        ("Tool Implementations", check_tool_implementations), 
        ("Advanced Features", check_advanced_features),
        ("Configuration", check_configuration),
        ("Environment Setup", check_env_example)
    ]
    
    passed_checks = 0
    total_checks = len(checks)
    
    for check_name, check_func in checks:
        print(f"\n{check_name}:")
        try:
            if check_func():
                passed_checks += 1
        except Exception as e:
            print(f"   ❌ Check failed with error: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 VERIFICATION RESULTS: {passed_checks}/{total_checks} checks passed")
    
    if passed_checks == total_checks:
        print("🎉 IMPLEMENTATION VERIFICATION: PASSED")
        print("✅ Augment Agent is fully implemented according to plan.md")
        print("🚀 Ready for installation and use!")
        return True
    else:
        print("⚠️  IMPLEMENTATION VERIFICATION: INCOMPLETE")
        print(f"❌ {total_checks - passed_checks} checks failed")
        print("🔧 Please address the issues above")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
