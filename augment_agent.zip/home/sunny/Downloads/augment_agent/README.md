# Augment Agent

A comprehensive Python-based AI agent that replicates Augment Agent capabilities for terminal/command-line usage. This standalone application provides an AI-powered coding assistant that runs independently using Google's Gemini 2.0 Flash model.

## Features

- **AI-Powered Assistance**: Uses Google's Gemini 2.0 Flash model for intelligent code analysis and generation
- **Comprehensive Tool System**: Modular tools for file operations, web search, process management, and more
- **Terminal Integration**: Full command-line interface with interactive and single-query modes
- **Conservative Safety**: Built-in confirmation prompts and backup mechanisms for destructive operations
- **Task Management**: Persistent task tracking and planning capabilities
- **Memory System**: Session-persistent memory for context retention
- **Code Analysis**: Local codebase indexing and retrieval capabilities

## Installation

### Prerequisites

- Python 3.8 or higher
- Google Gemini API key
- (Optional) Google Custom Search API key for web search functionality

### Install from Source

```bash
# Clone the repository
git clone https://github.com/augment-code/augment-agent-clone.git
cd augment-agent-clone

# Install the package
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

### Install from PyPI (when available)

```bash
pip install augment-agent
```

## Quick Start

### 1. Configuration

Initialize your configuration:

```bash
augment-agent init
```

This will create a configuration file and prompt you for API keys and settings.

### 2. Set API Keys

Set your Gemini API key:

```bash
export GEMINI_API_KEY="your-gemini-api-key"
```

For web search functionality (optional):

```bash
export GOOGLE_SEARCH_API_KEY="your-google-search-api-key"
export GOOGLE_SEARCH_ENGINE_ID="your-search-engine-id"
```

### 3. Start Using

**Interactive Mode:**
```bash
augment-agent chat
```

**Single Query:**
```bash
augment-agent ask "Create a Python function to calculate fibonacci numbers"
```

**Check Status:**
```bash
augment-agent status
```

## Usage Examples

### File Operations

```bash
# Ask the agent to create a new file
augment-agent ask "Create a Python script that reads a CSV file and prints statistics"

# Ask for code review
augment-agent ask "Review the code in main.py and suggest improvements"

# Request refactoring
augment-agent ask "Refactor the database connection code to use a connection pool"
```

### Web Research

```bash
# Research a topic
augment-agent ask "Search for the latest best practices in Python async programming"

# Get documentation
augment-agent ask "Find and summarize the documentation for FastAPI middleware"
```

### Process Management

```bash
# Run tests and analyze results
augment-agent ask "Run the test suite and analyze any failures"

# Start a development server
augment-agent ask "Start the development server and check if it's running correctly"
```

### Code Analysis

```bash
# Analyze codebase structure
augment-agent ask "Analyze the project structure and suggest improvements"

# Debug issues
augment-agent ask "Help me debug this error: [paste error message]"
```

## Configuration

### Configuration File

The agent looks for configuration files in the following order:

1. `./augment_agent.yaml` (current directory)
2. `~/.config/augment_agent/config.yaml`
3. `~/.augment_agent.yaml`

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `GEMINI_API_KEY` | Google Gemini API key | Yes |
| `GOOGLE_SEARCH_API_KEY` | Google Custom Search API key | No |
| `GOOGLE_SEARCH_ENGINE_ID` | Google Custom Search Engine ID | No |
| `AUGMENT_WORKSPACE_ROOT` | Workspace root directory | No |
| `AUGMENT_DATA_DIR` | Data directory for storage | No |

### Configuration Options

```yaml
# API Configuration
gemini_api_key: "your-api-key"
google_search_api_key: "your-search-key"
google_search_engine_id: "your-engine-id"

# Agent Configuration
model_name: "gemini-2.0-flash-exp"
temperature: 0.1
max_tokens: 8192

# Workspace Configuration
workspace_root: "/path/to/your/project"
repository_root: "/path/to/your/repo"

# Feature Toggles
enable_web_search: true
enable_code_analysis: true
enable_process_management: true

# Safety Settings
require_confirmation_for_destructive_actions: true
auto_backup_before_edits: true
max_concurrent_processes: 5

# UI Configuration
use_rich_formatting: true
show_progress_bars: true
log_level: "INFO"
```

## Available Tools

### File Operations
- **str-replace-editor**: Line-based file editing with string replacement
- **save-file**: Create new files with content validation
- **view**: View files and directories with search capabilities
- **remove-files**: Safe file deletion with backup options

### Web & Network
- **web-search**: Search the web using Google Custom Search
- **web-fetch**: Fetch and convert web pages to markdown
- **open-browser**: Open URLs in the default browser

### Process Management
- **launch-process**: Execute shell commands with process tracking
- **read-process**: Read output from running processes
- **write-process**: Send input to running processes
- **kill-process**: Terminate processes safely
- **list-processes**: List all managed processes

### Task & Memory Management
- **task management**: Create, update, and track tasks
- **memory**: Store and retrieve session information

## Development

### Setting up Development Environment

```bash
# Clone the repository
git clone https://github.com/augment-code/augment-agent-clone.git
cd augment-agent-clone

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install development dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=augment_agent

# Run specific test categories
pytest -m unit
pytest -m integration
```

### Code Quality

```bash
# Format code
black augment_agent/
isort augment_agent/

# Lint code
flake8 augment_agent/
mypy augment_agent/
```

## API Keys Setup

### Google Gemini API

1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Set the `GEMINI_API_KEY` environment variable

### Google Custom Search (Optional)

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the Custom Search API
3. Create credentials (API key)
4. Go to [Custom Search Engine](https://cse.google.com/)
5. Create a new search engine
6. Get the Search Engine ID
7. Set `GOOGLE_SEARCH_API_KEY` and `GOOGLE_SEARCH_ENGINE_ID`

## Troubleshooting

### Common Issues

**"Gemini API key is required"**
- Ensure `GEMINI_API_KEY` environment variable is set
- Check that the API key is valid and has proper permissions

**"Web search functionality requires API configuration"**
- Set up Google Custom Search API keys (optional feature)
- Or disable web search in configuration: `enable_web_search: false`

**"Permission denied" errors**
- Check file permissions in workspace directory
- Ensure the agent has write access to the data directory

**Process management issues**
- Verify that shell commands are available in your PATH
- Check process limits in configuration

### Debug Mode

Enable debug logging:

```bash
export AUGMENT_LOG_LEVEL=DEBUG
augment-agent --verbose chat
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

- GitHub Issues: [Report bugs and request features](https://github.com/augment-code/augment-agent-clone/issues)
- Documentation: [Full documentation](https://github.com/augment-code/augment-agent-clone/docs)
- Examples: [Usage examples](https://github.com/augment-code/augment-agent-clone/examples)
