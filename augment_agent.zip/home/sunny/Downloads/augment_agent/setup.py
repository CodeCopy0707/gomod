#!/usr/bin/env python3
"""Setup script for Augment Agent."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read requirements
requirements = [
    "google-generativeai>=0.3.0",
    "click>=8.0.0",
    "rich>=13.0.0",
    "pydantic>=2.0.0",
    "requests>=2.28.0",
    "beautifulsoup4>=4.11.0",
    "markdown>=3.4.0",
    "html2text>=2020.1.16",
    "pygments>=2.14.0",
    "psutil>=5.9.0",
    "watchdog>=3.0.0",
    "sqlalchemy>=2.0.0",
    "aiosqlite>=0.19.0",
    "python-dotenv>=1.0.0",
    "pyyaml>=6.0",
    "gitpython>=3.1.0",
]

# Optional AI model dependencies
ai_requirements = [
    "openai>=1.0.0",
    "anthropic>=0.7.0",
    "mistralai>=0.1.0",
]

# Optional advanced features
advanced_requirements = [
    "sentence-transformers>=2.2.0",
    "chromadb>=0.4.0",
    "tree-sitter>=0.20.0",
    "tree-sitter-python>=0.20.0",
    "tree-sitter-javascript>=0.20.0",
    "tree-sitter-typescript>=0.20.0",
    "tree-sitter-rust>=0.20.0",
    "tree-sitter-go>=0.20.0",
    "tree-sitter-java>=0.20.0",
    "tree-sitter-cpp>=0.20.0",
]

dev_requirements = [
    "pytest>=7.0.0",
    "pytest-asyncio>=0.21.0",
    "pytest-cov>=4.0.0",
    "black>=23.0.0",
    "isort>=5.12.0",
    "flake8>=6.0.0",
    "mypy>=1.0.0",
    "pre-commit>=3.0.0",
]

setup(
    name="augment-agent",
    version="1.0.0",
    description="A comprehensive Python-based AI agent that replicates Augment Agent capabilities for terminal/command-line usage",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Augment Agent Clone",
    author_email="agent@example.com",
    url="https://github.com/augment-code/augment-agent-clone",
    project_urls={
        "Bug Tracker": "https://github.com/augment-code/augment-agent-clone/issues",
        "Documentation": "https://github.com/augment-code/augment-agent-clone/docs",
        "Source Code": "https://github.com/augment-code/augment-agent-clone",
    },
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": dev_requirements,
        "ai": ai_requirements,
        "advanced": advanced_requirements,
        "all": requirements + ai_requirements + advanced_requirements + dev_requirements,
    },
    entry_points={
        "console_scripts": [
            "augment-agent=augment_agent.cli:main",
            "aa=augment_agent.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai agent coding assistant cli terminal gemini",
    zip_safe=False,
)
