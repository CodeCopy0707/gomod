"""Configuration management for Augment Agent."""

import os
import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict
from dotenv import load_dotenv


@dataclass
class Config:
    """Configuration class for Augment Agent."""
    
    # API Configuration
    gemini_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    mistral_api_key: Optional[str] = None
    deepseek_api_key: Optional[str] = None
    google_search_api_key: Optional[str] = None
    google_search_engine_id: Optional[str] = None
    
    # Agent Configuration
    model_name: str = "gemini-2.0-flash-exp"
    temperature: float = 0.1
    max_tokens: int = 8192
    
    # Workspace Configuration
    workspace_root: Optional[str] = None
    repository_root: Optional[str] = None
    
    # Tool Configuration
    enable_web_search: bool = True
    enable_code_analysis: bool = True
    enable_process_management: bool = True
    enable_task_management: bool = True
    enable_project_management: bool = True
    max_file_size_mb: int = 10
    max_search_results: int = 10

    # Advanced features (as specified in plan.md)
    enable_multi_threading: bool = True
    enable_predictive_prefetching: bool = True
    enable_context_compression: bool = True
    enable_chain_of_thought: bool = True
    max_concurrent_tasks: int = 5
    context_window_size: int = 32000
    chunk_size: int = 1000
    
    # Storage Configuration
    data_dir: Optional[str] = None
    memory_db_path: Optional[str] = None
    task_db_path: Optional[str] = None
    codebase_index_path: Optional[str] = None
    
    # Safety Configuration
    require_confirmation_for_destructive_actions: bool = True
    auto_backup_before_edits: bool = True
    max_concurrent_processes: int = 5
    
    # UI Configuration
    use_rich_formatting: bool = True
    show_progress_bars: bool = True
    log_level: str = "INFO"
    
    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "Config":
        """Load configuration from file and environment variables."""
        # Load environment variables
        load_dotenv()
        
        # Default config
        config_data = {}
        
        # Load from config file if provided
        if config_path and Path(config_path).exists():
            config_data = cls._load_config_file(config_path)
        else:
            # Try to find default config files
            for default_path in cls._get_default_config_paths():
                if default_path.exists():
                    config_data = cls._load_config_file(str(default_path))
                    break
        
        # Override with environment variables
        config_data.update(cls._load_from_env())
        
        # Set default paths if not provided
        if not config_data.get("data_dir"):
            config_data["data_dir"] = str(cls._get_default_data_dir())
        
        data_dir = Path(config_data["data_dir"])
        if not config_data.get("memory_db_path"):
            config_data["memory_db_path"] = str(data_dir / "memory.db")
        if not config_data.get("task_db_path"):
            config_data["task_db_path"] = str(data_dir / "tasks.db")
        if not config_data.get("codebase_index_path"):
            config_data["codebase_index_path"] = str(data_dir / "codebase_index")
        
        # Set workspace root to current directory if not provided
        if not config_data.get("workspace_root"):
            config_data["workspace_root"] = os.getcwd()
        
        # Set repository root (try to detect git repo)
        if not config_data.get("repository_root"):
            config_data["repository_root"] = cls._find_repository_root(
                config_data["workspace_root"]
            )
        
        return cls(**config_data)
    
    @staticmethod
    def _load_config_file(config_path: str) -> Dict[str, Any]:
        """Load configuration from a file (JSON or YAML)."""
        path = Path(config_path)
        
        if path.suffix.lower() in [".yaml", ".yml"]:
            with open(path, "r") as f:
                return yaml.safe_load(f) or {}
        elif path.suffix.lower() == ".json":
            with open(path, "r") as f:
                return json.load(f)
        else:
            raise ValueError(f"Unsupported config file format: {path.suffix}")
    
    @staticmethod
    def _load_from_env() -> Dict[str, Any]:
        """Load configuration from environment variables."""
        env_mapping = {
            "GEMINI_API_KEY": "gemini_api_key",
            "OPENAI_API_KEY": "openai_api_key",
            "ANTHROPIC_API_KEY": "anthropic_api_key",
            "MISTRAL_API_KEY": "mistral_api_key",
            "DEEPSEEK_API_KEY": "deepseek_api_key",
            "GOOGLE_SEARCH_API_KEY": "google_search_api_key",
            "GOOGLE_SEARCH_ENGINE_ID": "google_search_engine_id",
            "AUGMENT_MODEL_NAME": "model_name",
            "AUGMENT_TEMPERATURE": "temperature",
            "AUGMENT_MAX_TOKENS": "max_tokens",
            "AUGMENT_WORKSPACE_ROOT": "workspace_root",
            "AUGMENT_REPOSITORY_ROOT": "repository_root",
            "AUGMENT_DATA_DIR": "data_dir",
            "AUGMENT_LOG_LEVEL": "log_level",
            "AUGMENT_ENABLE_MULTI_THREADING": "enable_multi_threading",
            "AUGMENT_ENABLE_PREDICTIVE_PREFETCHING": "enable_predictive_prefetching",
            "AUGMENT_ENABLE_CONTEXT_COMPRESSION": "enable_context_compression",
            "AUGMENT_ENABLE_CHAIN_OF_THOUGHT": "enable_chain_of_thought",
            "AUGMENT_MAX_CONCURRENT_TASKS": "max_concurrent_tasks",
            "AUGMENT_CONTEXT_WINDOW_SIZE": "context_window_size",
            "AUGMENT_CHUNK_SIZE": "chunk_size",
        }
        
        config = {}
        for env_var, config_key in env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                # Convert string values to appropriate types
                if config_key in ["temperature"]:
                    config[config_key] = float(value)
                elif config_key in ["max_tokens", "max_file_size_mb", "max_search_results", "max_concurrent_processes"]:
                    config[config_key] = int(value)
                elif config_key in ["enable_web_search", "enable_code_analysis", "enable_process_management", 
                                   "require_confirmation_for_destructive_actions", "auto_backup_before_edits",
                                   "use_rich_formatting", "show_progress_bars"]:
                    config[config_key] = value.lower() in ["true", "1", "yes", "on"]
                else:
                    config[config_key] = value
        
        return config
    
    @staticmethod
    def _get_default_config_paths() -> list[Path]:
        """Get list of default configuration file paths to check."""
        home = Path.home()
        cwd = Path.cwd()
        
        return [
            cwd / "augment_agent.yaml",
            cwd / "augment_agent.yml",
            cwd / "augment_agent.json",
            cwd / ".augment_agent.yaml",
            cwd / ".augment_agent.yml",
            cwd / ".augment_agent.json",
            home / ".config" / "augment_agent" / "config.yaml",
            home / ".config" / "augment_agent" / "config.yml",
            home / ".config" / "augment_agent" / "config.json",
            home / ".augment_agent.yaml",
            home / ".augment_agent.yml",
            home / ".augment_agent.json",
        ]
    
    @staticmethod
    def _get_default_data_dir() -> Path:
        """Get default data directory."""
        if os.name == "nt":  # Windows
            data_dir = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming")) / "augment_agent"
        else:  # Unix-like
            data_dir = Path(os.getenv("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "augment_agent"
        
        data_dir.mkdir(parents=True, exist_ok=True)
        return data_dir
    
    @staticmethod
    def _find_repository_root(start_path: str) -> str:
        """Find the repository root by looking for .git directory."""
        current = Path(start_path).resolve()
        
        while current != current.parent:
            if (current / ".git").exists():
                return str(current)
            current = current.parent
        
        # If no git repo found, return the start path
        return start_path
    
    def save(self, config_path: str) -> None:
        """Save configuration to file."""
        path = Path(config_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        config_dict = asdict(self)
        
        if path.suffix.lower() in [".yaml", ".yml"]:
            with open(path, "w") as f:
                yaml.dump(config_dict, f, default_flow_style=False, indent=2)
        elif path.suffix.lower() == ".json":
            with open(path, "w") as f:
                json.dump(config_dict, f, indent=2)
        else:
            raise ValueError(f"Unsupported config file format: {path.suffix}")
    
    def validate(self) -> None:
        """Validate configuration and raise errors for missing required values."""
        if not self.gemini_api_key:
            raise ValueError(
                "Gemini API key is required. Set GEMINI_API_KEY environment variable "
                "or provide it in the configuration file."
            )
        
        if self.enable_web_search and not self.google_search_api_key:
            raise ValueError(
                "Google Search API key is required when web search is enabled. "
                "Set GOOGLE_SEARCH_API_KEY environment variable or disable web search."
            )
        
        if self.enable_web_search and not self.google_search_engine_id:
            raise ValueError(
                "Google Search Engine ID is required when web search is enabled. "
                "Set GOOGLE_SEARCH_ENGINE_ID environment variable or disable web search."
            )
        
        # Validate paths
        if self.workspace_root and not Path(self.workspace_root).exists():
            raise ValueError(f"Workspace root does not exist: {self.workspace_root}")
        
        if self.repository_root and not Path(self.repository_root).exists():
            raise ValueError(f"Repository root does not exist: {self.repository_root}")
    
    def get_workspace_path(self, relative_path: str) -> Path:
        """Convert relative path to absolute path within workspace."""
        if not self.workspace_root:
            raise ValueError("Workspace root not configured")
        
        workspace = Path(self.workspace_root)
        if Path(relative_path).is_absolute():
            return Path(relative_path)
        
        return workspace / relative_path
    
    def get_repository_path(self, relative_path: str) -> Path:
        """Convert relative path to absolute path within repository."""
        if not self.repository_root:
            raise ValueError("Repository root not configured")
        
        repo = Path(self.repository_root)
        if Path(relative_path).is_absolute():
            return Path(relative_path)
        
        return repo / relative_path
