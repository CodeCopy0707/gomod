"""Tool management system for Augment Agent."""

import asyncio
import importlib
import inspect
from typing import Dict, Any, List, Optional, Type, Callable
from pathlib import Path
import logging

from .config import Config
from ..tools.base import BaseTool
from ..utils.logging import get_logger


logger = get_logger(__name__)


class ToolManager:
    """Manages tool registration, validation, and execution."""
    
    def __init__(self, config: Config):
        """Initialize the tool manager."""
        self.config = config
        self.tools: Dict[str, BaseTool] = {}
        self.tool_schemas: Dict[str, Dict[str, Any]] = {}
        self.initialized = False
    
    async def initialize(self) -> None:
        """Initialize the tool manager and load all available tools."""
        if self.initialized:
            return
        
        logger.info("Initializing tool manager...")
        
        # Discover and load tools
        await self._discover_tools()
        
        # Initialize all tools
        for tool_name, tool_instance in self.tools.items():
            try:
                await tool_instance.initialize()
                logger.debug(f"Initialized tool: {tool_name}")
            except Exception as e:
                logger.error(f"Failed to initialize tool {tool_name}: {e}")
                # Remove failed tools
                del self.tools[tool_name]
                if tool_name in self.tool_schemas:
                    del self.tool_schemas[tool_name]
        
        self.initialized = True
        logger.info(f"Tool manager initialized with {len(self.tools)} tools")
    
    async def _discover_tools(self) -> None:
        """Discover and load all available tools."""
        tools_dir = Path(__file__).parent.parent / "tools"
        
        # Get all Python files in the tools directory
        tool_files = []
        for file_path in tools_dir.rglob("*.py"):
            if file_path.name != "__init__.py" and not file_path.name.startswith("_"):
                tool_files.append(file_path)
        
        # Import and register tools
        for tool_file in tool_files:
            try:
                # Convert file path to module name
                relative_path = tool_file.relative_to(tools_dir.parent)
                module_name = str(relative_path.with_suffix("")).replace("/", ".").replace("\\", ".")
                module_name = f"augment_agent.{module_name}"
                
                # Import the module
                module = importlib.import_module(module_name)
                
                # Find tool classes in the module
                for name, obj in inspect.getmembers(module):
                    if (inspect.isclass(obj) and 
                        issubclass(obj, BaseTool) and 
                        obj != BaseTool and
                        not getattr(obj, '_abstract', False)):
                        
                        # Create tool instance
                        tool_instance = obj(self.config)
                        tool_name = tool_instance.name
                        
                        # Check if tool is enabled
                        if not self._is_tool_enabled(tool_name):
                            logger.debug(f"Tool {tool_name} is disabled, skipping")
                            continue
                        
                        # Register the tool
                        self.tools[tool_name] = tool_instance
                        self.tool_schemas[tool_name] = tool_instance.get_schema()
                        
                        logger.debug(f"Registered tool: {tool_name}")
                        
            except Exception as e:
                logger.warning(f"Failed to load tool from {tool_file}: {e}")
    
    def _is_tool_enabled(self, tool_name: str) -> bool:
        """Check if a tool is enabled based on configuration."""
        # Map tool names to configuration flags
        tool_config_map = {
            "web_search": "enable_web_search",
            "web_fetch": "enable_web_search",
            "open_browser": "enable_web_search",
            "codebase_retrieval": "enable_code_analysis",
            "diagnostics": "enable_code_analysis",
            "example-code-finder": "enable_code_analysis",
            "smart-string-replacer": "enable_code_analysis",
            "ultra-smart-grep": "enable_code_analysis",
            "smart-find": "enable_code_analysis",
            "input-fixer": "enable_code_analysis",
            "long-file-indexer": "enable_code_analysis",
            "auto-task-planner": "enable_task_management",
            "code-translator": "enable_code_analysis",
            "autonomous-debugger": "enable_code_analysis",
            "project-scaffolder": "enable_project_management",
            "launch_process": "enable_process_management",
            "read_process": "enable_process_management",
            "write_process": "enable_process_management",
            "kill_process": "enable_process_management",
            "list_processes": "enable_process_management",
            "read_terminal": "enable_process_management",
        }
        
        config_flag = tool_config_map.get(tool_name)
        if config_flag:
            return getattr(self.config, config_flag, True)
        
        # Default to enabled if no specific configuration
        return True
    
    async def get_available_tools(self) -> Dict[str, Dict[str, Any]]:
        """Get all available tools and their schemas."""
        if not self.initialized:
            await self.initialize()
        
        return self.tool_schemas.copy()
    
    async def execute_tool(self, tool_name: str, parameters: Dict[str, Any]) -> Any:
        """Execute a tool with the given parameters."""
        if not self.initialized:
            await self.initialize()
        
        if tool_name not in self.tools:
            raise ValueError(f"Tool '{tool_name}' not found")
        
        tool = self.tools[tool_name]
        
        # Validate parameters
        try:
            validated_params = tool.validate_parameters(parameters)
        except Exception as e:
            raise ValueError(f"Parameter validation failed for tool '{tool_name}': {e}")
        
        # Execute the tool
        try:
            logger.info(f"Executing tool: {tool_name}")
            result = await tool.execute(**validated_params)
            logger.debug(f"Tool {tool_name} executed successfully")
            return result
        except Exception as e:
            logger.error(f"Tool execution failed for {tool_name}: {e}")
            raise
    
    async def get_tool_info(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific tool."""
        if not self.initialized:
            await self.initialize()
        
        if tool_name not in self.tools:
            return None
        
        tool = self.tools[tool_name]
        return {
            "name": tool.name,
            "description": tool.description,
            "schema": tool.get_schema(),
            "enabled": True,
            "initialized": tool.initialized
        }
    
    async def list_tools(self) -> List[str]:
        """Get a list of all available tool names."""
        if not self.initialized:
            await self.initialize()
        
        return list(self.tools.keys())
    
    async def reload_tools(self) -> None:
        """Reload all tools (useful for development)."""
        logger.info("Reloading tools...")
        
        # Shutdown existing tools
        for tool in self.tools.values():
            try:
                await tool.shutdown()
            except Exception as e:
                logger.warning(f"Error shutting down tool {tool.name}: {e}")
        
        # Clear tools
        self.tools.clear()
        self.tool_schemas.clear()
        self.initialized = False
        
        # Reinitialize
        await self.initialize()
    
    async def shutdown(self) -> None:
        """Shutdown the tool manager and all tools."""
        logger.info("Shutting down tool manager...")
        
        # Shutdown all tools
        shutdown_tasks = []
        for tool in self.tools.values():
            shutdown_tasks.append(tool.shutdown())
        
        if shutdown_tasks:
            await asyncio.gather(*shutdown_tasks, return_exceptions=True)
        
        self.tools.clear()
        self.tool_schemas.clear()
        self.initialized = False
        
        logger.info("Tool manager shutdown complete")
    
    def get_tool_by_name(self, tool_name: str) -> Optional[BaseTool]:
        """Get a tool instance by name."""
        return self.tools.get(tool_name)
    
    async def validate_tool_call(self, tool_name: str, parameters: Dict[str, Any]) -> bool:
        """Validate if a tool call is valid without executing it."""
        if tool_name not in self.tools:
            return False
        
        try:
            tool = self.tools[tool_name]
            tool.validate_parameters(parameters)
            return True
        except Exception:
            return False
