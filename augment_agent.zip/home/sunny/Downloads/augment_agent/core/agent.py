"""Core Augment Agent implementation."""

import asyncio
import json
import logging
import re
import threading
import concurrent.futures
import queue
import time
from typing import Dict, Any, List, Optional, Union, Tuple
from datetime import datetime
from pathlib import Path

import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

# Multiple AI model support
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    import requests
    MISTRAL_AVAILABLE = True
except ImportError:
    MISTRAL_AVAILABLE = False

# DeepSeek uses OpenAI-compatible API
DEEPSEEK_AVAILABLE = OPENAI_AVAILABLE

from .config import Config
from .tool_manager import ToolManager
from .prompts import SYSTEM_PROMPT
from .safety import SafetyManager, ConservativeCodeEditor, PlanningMethodology
from ..utils.logging import get_logger


logger = get_logger(__name__)


class AugmentAgent:
    """Main Augment Agent class that handles AI interactions and tool execution."""

    def __init__(self, config: Config):
        """Initialize the agent with configuration."""
        self.config = config
        self.tool_manager = ToolManager(config)
        self.safety_manager = SafetyManager(config)
        self.code_editor = ConservativeCodeEditor(config, self.safety_manager)
        self.planning = PlanningMethodology(config)

        # Multi-model support
        self.models = {}
        self.current_model = "gemini"
        self.chat_session = None

        # Context and state management
        self.conversation_history: List[Dict[str, Any]] = []
        self.project_context = {
            'files_analyzed': set(),
            'current_task': None,
            'task_history': [],
            'code_patterns': {},
            'dependencies': set(),
            'project_type': None
        }
        self.initialized = False

        # Multi-threaded execution components (as specified in plan.md)
        self.executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=getattr(config, 'max_concurrent_tasks', 5)
        )
        self.prediction_queue = queue.Queue()
        self.prefetch_cache = {}
        self.background_tasks = []

        # Chain-of-thought reasoning
        self.reasoning_steps = []
        self.current_analysis = None

        # Context compression and RAG
        self.context_compressor = None
        self.compressed_context = None
        self.rag_enabled = getattr(config, 'enable_context_compression', True)

        # Predictive prefetching
        self.prediction_engine = None
        self.prefetch_enabled = getattr(config, 'enable_predictive_prefetching', True)

        # Multi-threading control
        self.multi_threading_enabled = getattr(config, 'enable_multi_threading', True)
        
    async def initialize(self) -> None:
        """Initialize the agent and its components."""
        if self.initialized:
            return

        logger.info("Initializing Augment Agent with multi-model support...")

        # Initialize Gemini (primary model)
        await self._initialize_gemini()

        # Initialize other models if available
        await self._initialize_openai()
        await self._initialize_anthropic()
        await self._initialize_mistral()
        await self._initialize_deepseek()

        # Initialize tool manager
        await self.tool_manager.initialize()

        # Initialize project context
        await self._initialize_project_context()

        # Initialize advanced components (as specified in plan.md)
        if self.multi_threading_enabled:
            await self._initialize_multi_threading()

        if self.prefetch_enabled:
            await self._initialize_prediction_engine()

        if self.rag_enabled:
            await self._initialize_context_compression()

        # Start background tasks
        await self._start_background_tasks()

        self.initialized = True
        logger.info(f"Agent initialization complete with {len(self.models)} models and advanced features available")

    async def _initialize_gemini(self) -> None:
        """Initialize Gemini model."""
        try:
            genai.configure(api_key=self.config.gemini_api_key)

            generation_config = {
                "temperature": self.config.temperature,
                "top_p": 0.95,
                "top_k": 64,
                "max_output_tokens": self.config.max_tokens,
                "response_mime_type": "text/plain",
            }

            safety_settings = {
                HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
                HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
            }

            model = genai.GenerativeModel(
                model_name=self.config.model_name,
                generation_config=generation_config,
                safety_settings=safety_settings,
                system_instruction=SYSTEM_PROMPT,
            )

            self.models["gemini"] = model
            self.chat_session = model.start_chat(history=[])
            logger.info("Gemini model initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            raise

    async def _initialize_openai(self) -> None:
        """Initialize OpenAI models if available."""
        if not OPENAI_AVAILABLE or not getattr(self.config, 'openai_api_key', None):
            return

        try:
            client = OpenAI(api_key=self.config.openai_api_key)
            self.models["openai"] = client
            logger.info("OpenAI model initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize OpenAI: {e}")

    async def _initialize_anthropic(self) -> None:
        """Initialize Anthropic models if available."""
        if not ANTHROPIC_AVAILABLE or not getattr(self.config, 'anthropic_api_key', None):
            return

        try:
            client = anthropic.Anthropic(api_key=self.config.anthropic_api_key)
            self.models["anthropic"] = client
            logger.info("Anthropic model initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize Anthropic: {e}")

    async def _initialize_mistral(self) -> None:
        """Initialize Mistral AI model if available."""
        if not MISTRAL_AVAILABLE or not getattr(self.config, 'mistral_api_key', None):
            return

        try:
            # Mistral uses HTTP API
            self.models["mistral"] = {
                "api_key": self.config.mistral_api_key,
                "base_url": "https://api.mistral.ai/v1/chat/completions"
            }
            logger.info("Mistral model initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize Mistral: {e}")

    async def _initialize_deepseek(self) -> None:
        """Initialize DeepSeek model if available."""
        if not DEEPSEEK_AVAILABLE or not getattr(self.config, 'deepseek_api_key', None):
            return

        try:
            # DeepSeek uses OpenAI-compatible API
            client = OpenAI(
                api_key=self.config.deepseek_api_key,
                base_url="https://api.deepseek.com/v1"
            )
            self.models["deepseek"] = client
            logger.info("DeepSeek model initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize DeepSeek: {e}")

    async def _initialize_project_context(self) -> None:
        """Initialize project context by analyzing the workspace."""
        try:
            workspace_path = self.config.workspace_root
            if not workspace_path:
                return

            # Detect project type
            self.project_context['project_type'] = await self._detect_project_type(workspace_path)

            # Analyze key files
            await self._analyze_project_structure(workspace_path)

            logger.info(f"Project context initialized: {self.project_context['project_type']}")

        except Exception as e:
            logger.warning(f"Failed to initialize project context: {e}")

    async def _detect_project_type(self, workspace_path: str) -> str:
        """Detect the type of project based on files and structure."""
        from pathlib import Path

        workspace = Path(workspace_path)

        # Check for specific project indicators
        if (workspace / "package.json").exists():
            return "nodejs"
        elif (workspace / "requirements.txt").exists() or (workspace / "pyproject.toml").exists():
            return "python"
        elif (workspace / "Cargo.toml").exists():
            return "rust"
        elif (workspace / "go.mod").exists():
            return "go"
        elif (workspace / "pom.xml").exists() or (workspace / "build.gradle").exists():
            return "java"
        elif (workspace / "composer.json").exists():
            return "php"
        elif (workspace / "Gemfile").exists():
            return "ruby"
        elif (workspace / ".csproj").exists() or any(f.suffix == ".csproj" for f in workspace.glob("*.csproj")):
            return "csharp"
        else:
            return "unknown"

    async def _analyze_project_structure(self, workspace_path: str) -> None:
        """Analyze project structure and extract key information."""
        from pathlib import Path

        workspace = Path(workspace_path)

        # Find important files
        important_files = [
            "README.md", "README.rst", "README.txt",
            "package.json", "requirements.txt", "pyproject.toml",
            "Cargo.toml", "go.mod", "pom.xml", "build.gradle",
            "Dockerfile", "docker-compose.yml",
            ".gitignore", ".env.example"
        ]

        for file_name in important_files:
            file_path = workspace / file_name
            if file_path.exists():
                self.project_context['files_analyzed'].add(str(file_path))

        # Detect common patterns
        if (workspace / "src").exists():
            self.project_context['code_patterns']['has_src_dir'] = True
        if (workspace / "tests" or workspace / "test").exists():
            self.project_context['code_patterns']['has_tests'] = True
        if (workspace / "docs").exists():
            self.project_context['code_patterns']['has_docs'] = True
    
    async def process_query(self, query: str) -> str:
        """Process a user query with advanced NLP and auto task planning."""
        if not self.initialized:
            await self.initialize()

        logger.info(f"Processing query: {query[:100]}...")

        # Analyze query intent and complexity
        query_analysis = await self._analyze_query(query)

        # Add query to conversation history with analysis
        self.conversation_history.append({
            "role": "user",
            "content": query,
            "timestamp": datetime.now().isoformat(),
            "analysis": query_analysis
        })

        try:
            # Check if this requires detailed planning
            if query_analysis['complexity'] >= 7:
                plan = await self.planning.create_detailed_plan(query, self.project_context)
                if plan.get('requires_planning'):
                    plan_text = self.planning.format_plan_for_display(plan)
                    return f"I've analyzed your request and created a detailed plan:\n\n{plan_text}\n\nShould I proceed with this plan?"

            # Get contextual tools based on query and project
            available_tools = await self._get_contextual_tools(query_analysis)

            # Enhance query with project context and smart suggestions
            enhanced_query = await self._enhance_query_with_context(query, query_analysis, available_tools)

            # Process with the appropriate model
            response = await self._process_with_best_model(enhanced_query, query_analysis)

            # Check for tool calls and execute them
            tool_calls = self._extract_tool_calls(response)
            if tool_calls:
                tool_results = await self._execute_tool_calls(tool_calls)
                response = await self._synthesize_final_response(response, tool_results, query_analysis)

            # Update project context based on the interaction
            await self._update_project_context(query, response, tool_calls)

            # Add response to conversation history
            self.conversation_history.append({
                "role": "assistant",
                "content": response,
                "timestamp": datetime.now().isoformat(),
                "tools_used": [call.get('tool_name') for call in tool_calls] if tool_calls else []
            })

            return response

        except Exception as e:
            logger.error(f"Error processing query: {e}")
            error_response = f"I encountered an error while processing your request: {str(e)}"

            self.conversation_history.append({
                "role": "assistant",
                "content": error_response,
                "timestamp": datetime.now().isoformat(),
                "error": True
            })

            return error_response

    async def _analyze_query(self, query: str) -> Dict[str, Any]:
        """Analyze query intent, complexity, and required capabilities."""
        analysis = {
            'intent': 'unknown',
            'complexity': 1,
            'requires_files': False,
            'requires_web': False,
            'requires_execution': False,
            'requires_analysis': False,
            'keywords': [],
            'entities': [],
            'action_type': 'unknown'
        }

        query_lower = query.lower()

        # Intent detection
        if any(word in query_lower for word in ['create', 'make', 'build', 'generate', 'write']):
            analysis['intent'] = 'create'
            analysis['complexity'] += 2
        elif any(word in query_lower for word in ['fix', 'debug', 'solve', 'repair', 'correct']):
            analysis['intent'] = 'fix'
            analysis['complexity'] += 3
        elif any(word in query_lower for word in ['explain', 'describe', 'what', 'how', 'why']):
            analysis['intent'] = 'explain'
            analysis['complexity'] += 1
        elif any(word in query_lower for word in ['refactor', 'improve', 'optimize', 'enhance']):
            analysis['intent'] = 'refactor'
            analysis['complexity'] += 4
        elif any(word in query_lower for word in ['test', 'check', 'verify', 'validate']):
            analysis['intent'] = 'test'
            analysis['complexity'] += 2
        elif any(word in query_lower for word in ['search', 'find', 'look', 'locate']):
            analysis['intent'] = 'search'
            analysis['complexity'] += 1

        # Capability requirements
        if any(word in query_lower for word in ['file', 'directory', 'folder', 'path']):
            analysis['requires_files'] = True
            analysis['complexity'] += 1

        if any(word in query_lower for word in ['search web', 'google', 'online', 'internet']):
            analysis['requires_web'] = True
            analysis['complexity'] += 1

        if any(word in query_lower for word in ['run', 'execute', 'command', 'script']):
            analysis['requires_execution'] = True
            analysis['complexity'] += 2

        if any(word in query_lower for word in ['analyze', 'review', 'examine', 'inspect']):
            analysis['requires_analysis'] = True
            analysis['complexity'] += 2

        # Extract keywords and entities
        analysis['keywords'] = self._extract_keywords(query)
        analysis['entities'] = self._extract_entities(query)

        # Determine action type
        if 'file' in analysis['keywords'] or 'code' in analysis['keywords']:
            analysis['action_type'] = 'code_operation'
        elif 'web' in analysis['keywords'] or 'search' in analysis['keywords']:
            analysis['action_type'] = 'web_operation'
        elif 'run' in analysis['keywords'] or 'execute' in analysis['keywords']:
            analysis['action_type'] = 'system_operation'
        else:
            analysis['action_type'] = 'general'

        return analysis

    def _extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords from text."""
        # Simple keyword extraction - could be enhanced with NLP libraries
        import re

        # Remove common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those'}

        # Extract words
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        keywords = [word for word in words if word not in stop_words]

        # Return most frequent/important keywords
        return list(set(keywords))[:10]

    def _extract_entities(self, text: str) -> List[str]:
        """Extract entities like file names, function names, etc."""
        import re

        entities = []

        # File paths and names
        file_patterns = [
            r'\b\w+\.\w+\b',  # filename.ext
            r'[./]\w+/[\w./]+',  # paths
            r'\b\w+\.py\b',  # Python files
            r'\b\w+\.js\b',  # JavaScript files
        ]

        for pattern in file_patterns:
            matches = re.findall(pattern, text)
            entities.extend(matches)

        # Function/class names (camelCase, snake_case)
        code_patterns = [
            r'\b[a-z_][a-z0-9_]*\(\)',  # function calls
            r'\b[A-Z][a-zA-Z0-9]*\b',  # class names
        ]

        for pattern in code_patterns:
            matches = re.findall(pattern, text)
            entities.extend(matches)

        return list(set(entities))[:5]

    async def _get_contextual_tools(self, query_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Get tools that are most relevant to the current query."""
        all_tools = await self.tool_manager.get_available_tools()

        # Filter tools based on query analysis
        relevant_tools = {}

        if query_analysis['requires_files']:
            file_tools = ['str-replace-editor', 'save-file', 'view', 'remove-files']
            for tool in file_tools:
                if tool in all_tools:
                    relevant_tools[tool] = all_tools[tool]

        if query_analysis['requires_web']:
            web_tools = ['web-search', 'web-fetch', 'open-browser']
            for tool in web_tools:
                if tool in all_tools:
                    relevant_tools[tool] = all_tools[tool]

        if query_analysis['requires_execution']:
            process_tools = ['launch-process', 'read-process', 'write-process', 'kill-process', 'list-processes']
            for tool in process_tools:
                if tool in all_tools:
                    relevant_tools[tool] = all_tools[tool]

        if query_analysis['requires_analysis']:
            analysis_tools = ['codebase-retrieval', 'diagnostics']
            for tool in analysis_tools:
                if tool in all_tools:
                    relevant_tools[tool] = all_tools[tool]

        # Always include basic tools
        basic_tools = ['view_tasklist', 'add_tasks', 'update_tasks', 'remember']
        for tool in basic_tools:
            if tool in all_tools:
                relevant_tools[tool] = all_tools[tool]

        return relevant_tools

    async def _enhance_query_with_context(self, query: str, analysis: Dict[str, Any], tools: Dict[str, Any]) -> str:
        """Enhance query with project context and smart suggestions."""
        enhanced_parts = [query]

        # Add project context
        if self.project_context['project_type'] != 'unknown':
            enhanced_parts.append(f"\nProject Context: This is a {self.project_context['project_type']} project.")

        if self.project_context['files_analyzed']:
            enhanced_parts.append(f"Key files in project: {', '.join(list(self.project_context['files_analyzed'])[:5])}")

        # Add conversation context
        if len(self.conversation_history) > 1:
            recent_context = self.conversation_history[-3:]  # Last 3 interactions
            context_summary = "Recent conversation context:\n"
            for item in recent_context:
                if item['role'] == 'user':
                    context_summary += f"- User asked: {item['content'][:100]}...\n"
                elif item['role'] == 'assistant' and not item.get('error'):
                    context_summary += f"- I responded with actions involving: {', '.join(item.get('tools_used', []))}\n"
            enhanced_parts.append(context_summary)

        # Add available tools information
        tools_info = self._format_tools_for_prompt(tools)
        enhanced_parts.append(f"\nAvailable tools for this query:\n{tools_info}")

        # Add smart suggestions based on analysis
        if analysis['intent'] == 'create' and analysis['action_type'] == 'code_operation':
            enhanced_parts.append("\nSuggestion: Consider using str-replace-editor or save-file for code creation.")
        elif analysis['intent'] == 'fix' and analysis['requires_analysis']:
            enhanced_parts.append("\nSuggestion: Start with codebase-retrieval to understand the current code, then use diagnostics to identify issues.")
        elif analysis['intent'] == 'search' and 'file' in analysis['keywords']:
            enhanced_parts.append("\nSuggestion: Use view tool with search capabilities to find specific content in files.")

        return "\n".join(enhanced_parts)

    async def _process_with_best_model(self, enhanced_query: str, analysis: Dict[str, Any]) -> str:
        """Process query with the most appropriate AI model."""
        # Smart model selection based on query type and complexity

        # For complex code operations, prefer DeepSeek or OpenAI
        if analysis['action_type'] == 'code_operation' and analysis['complexity'] >= 5:
            if "deepseek" in self.models:
                return await self._send_message_deepseek(enhanced_query)
            elif "openai" in self.models:
                return await self._send_message_openai(enhanced_query)

        # For explanations and reasoning, prefer Anthropic or Mistral
        elif analysis['intent'] == 'explain' or analysis['complexity'] >= 7:
            if "anthropic" in self.models:
                return await self._send_message_anthropic(enhanced_query)
            elif "mistral" in self.models:
                return await self._send_message_mistral(enhanced_query)

        # For general tasks, use current model or Gemini
        if self.current_model == "gemini" and "gemini" in self.models:
            return await self._send_message_gemini(enhanced_query)
        elif self.current_model == "mistral" and "mistral" in self.models:
            return await self._send_message_mistral(enhanced_query)
        elif self.current_model == "deepseek" and "deepseek" in self.models:
            return await self._send_message_deepseek(enhanced_query)
        else:
            # Fallback to Gemini
            return await self._send_message_gemini(enhanced_query)

    async def _send_message_gemini(self, message: str) -> str:
        """Send message to Gemini model."""
        try:
            response = await asyncio.to_thread(
                self.chat_session.send_message, message
            )
            return response.text
        except Exception as e:
            logger.error(f"Error sending message to Gemini: {e}")
            raise

    async def _send_message_openai(self, message: str) -> str:
        """Send message to OpenAI model."""
        if "openai" not in self.models:
            return await self._send_message_gemini(message)

        try:
            client = self.models["openai"]
            response = await asyncio.to_thread(
                client.chat.completions.create,
                model="gpt-4",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": message}
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error sending message to OpenAI: {e}")
            return await self._send_message_gemini(message)

    async def _send_message_anthropic(self, message: str) -> str:
        """Send message to Anthropic model."""
        if "anthropic" not in self.models:
            return await self._send_message_gemini(message)

        try:
            client = self.models["anthropic"]
            response = await asyncio.to_thread(
                client.messages.create,
                model="claude-3-sonnet-20240229",
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": message}]
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"Error sending message to Anthropic: {e}")
            return await self._send_message_gemini(message)

    async def _synthesize_final_response(self, initial_response: str, tool_results: List[Dict[str, Any]], analysis: Dict[str, Any]) -> str:
        """Synthesize final response based on initial response and tool results."""
        tool_results_text = self._format_tool_results(tool_results)

        synthesis_prompt = f"""
Based on the initial response and tool execution results, provide a comprehensive final response.

Initial Response:
{initial_response}

Tool Execution Results:
{tool_results_text}

Query Analysis: {analysis['intent']} operation with complexity {analysis['complexity']}

Please provide a final response that:
1. Summarizes what was accomplished
2. Explains any tool results in context
3. Suggests next steps if appropriate
4. Addresses the original user intent: {analysis['intent']}
"""

        return await self._send_message_gemini(synthesis_prompt)

    async def _update_project_context(self, query: str, response: str, tool_calls: List[Dict[str, Any]]) -> None:
        """Update project context based on the interaction."""
        try:
            # Track files that were accessed or modified
            for tool_call in tool_calls or []:
                tool_name = tool_call.get('tool_name', '')
                params = tool_call.get('parameters', {})

                if tool_name in ['str-replace-editor', 'save-file', 'view'] and 'path' in params:
                    file_path = params['path']
                    self.project_context['files_analyzed'].add(file_path)

                # Track dependencies mentioned
                if 'install' in query.lower() or 'dependency' in query.lower():
                    # Extract package names from query
                    import re
                    packages = re.findall(r'\b[a-z-]+(?:\.[a-z-]+)*\b', query.lower())
                    self.project_context['dependencies'].update(packages)

            # Update current task if this seems like a new task
            if any(word in query.lower() for word in ['create', 'build', 'implement', 'add']):
                self.project_context['current_task'] = {
                    'description': query[:100],
                    'started_at': datetime.now().isoformat(),
                    'status': 'in_progress'
                }

            # Add to task history
            self.project_context['task_history'].append({
                'query': query[:100],
                'timestamp': datetime.now().isoformat(),
                'tools_used': [call.get('tool_name') for call in tool_calls or []]
            })

            # Keep only recent history
            if len(self.project_context['task_history']) > 20:
                self.project_context['task_history'] = self.project_context['task_history'][-20:]

        except Exception as e:
            logger.warning(f"Failed to update project context: {e}")

    async def _send_message_mistral(self, message: str) -> str:
        """Send message to Mistral model."""
        if "mistral" not in self.models:
            return await self._send_message_gemini(message)

        try:
            model_config = self.models["mistral"]
            headers = {
                "Authorization": f"Bearer {model_config['api_key']}",
                "Content-Type": "application/json"
            }

            payload = {
                "model": "mistral-large-latest",
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": message}
                ],
                "temperature": self.config.temperature,
                "max_tokens": self.config.max_tokens
            }

            response = await asyncio.to_thread(
                requests.post,
                model_config["base_url"],
                headers=headers,
                json=payload,
                timeout=30
            )
            response.raise_for_status()

            result = response.json()
            return result["choices"][0]["message"]["content"]

        except Exception as e:
            logger.error(f"Error sending message to Mistral: {e}")
            return await self._send_message_gemini(message)

    async def _send_message_deepseek(self, message: str) -> str:
        """Send message to DeepSeek model."""
        if "deepseek" not in self.models:
            return await self._send_message_gemini(message)

        try:
            client = self.models["deepseek"]
            response = await asyncio.to_thread(
                client.chat.completions.create,
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": message}
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error sending message to DeepSeek: {e}")
            return await self._send_message_gemini(message)

    # Keep the original _send_message method for backward compatibility
    async def _send_message(self, message: str) -> str:
        """Send a message using the current model."""
        return await self._send_message_gemini(message)
    
    def _format_tools_for_prompt(self, tools: Dict[str, Any]) -> str:
        """Format available tools for inclusion in the prompt."""
        if not tools:
            return "No tools available."
        
        tools_text = []
        for tool_name, tool_info in tools.items():
            tools_text.append(f"- {tool_name}: {tool_info.get('description', 'No description')}")
            
            if 'parameters' in tool_info:
                params = tool_info['parameters']
                if 'properties' in params:
                    param_list = []
                    required = params.get('required', [])
                    for param_name, param_info in params['properties'].items():
                        param_desc = param_info.get('description', '')
                        param_type = param_info.get('type', 'unknown')
                        required_marker = " (required)" if param_name in required else ""
                        param_list.append(f"    {param_name} ({param_type}){required_marker}: {param_desc}")
                    
                    if param_list:
                        tools_text.append("  Parameters:")
                        tools_text.extend(param_list)
        
        return "\n".join(tools_text)
    
    def _extract_tool_calls(self, response: str) -> List[Dict[str, Any]]:
        """Extract tool calls from the model response."""
        # Look for tool call patterns in the response
        # This is a simplified implementation - in practice, you might want
        # to use a more sophisticated parsing approach
        tool_calls = []
        
        # Look for function call patterns like:
        # TOOL_CALL: tool_name(param1="value1", param2="value2")
        import re
        
        pattern = r'TOOL_CALL:\s*(\w+)\((.*?)\)'
        matches = re.findall(pattern, response, re.DOTALL)
        
        for tool_name, params_str in matches:
            try:
                # Parse parameters (simplified - you might want a more robust parser)
                params = {}
                if params_str.strip():
                    # This is a very basic parameter parser
                    # In practice, you'd want something more sophisticated
                    param_pairs = params_str.split(',')
                    for pair in param_pairs:
                        if '=' in pair:
                            key, value = pair.split('=', 1)
                            key = key.strip().strip('"\'')
                            value = value.strip().strip('"\'')
                            params[key] = value
                
                tool_calls.append({
                    "tool_name": tool_name,
                    "parameters": params
                })
            except Exception as e:
                logger.warning(f"Failed to parse tool call parameters: {e}")
        
        return tool_calls
    
    async def _execute_tool_calls(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Execute a list of tool calls and return results."""
        results = []
        
        for tool_call in tool_calls:
            try:
                tool_name = tool_call["tool_name"]
                parameters = tool_call["parameters"]
                
                logger.info(f"Executing tool: {tool_name} with parameters: {parameters}")
                
                result = await self.tool_manager.execute_tool(tool_name, parameters)
                
                results.append({
                    "tool_name": tool_name,
                    "parameters": parameters,
                    "result": result,
                    "success": True
                })
                
            except Exception as e:
                logger.error(f"Tool execution failed for {tool_call.get('tool_name', 'unknown')}: {e}")
                results.append({
                    "tool_name": tool_call.get("tool_name", "unknown"),
                    "parameters": tool_call.get("parameters", {}),
                    "error": str(e),
                    "success": False
                })
        
        return results
    
    def _format_tool_results(self, tool_results: List[Dict[str, Any]]) -> str:
        """Format tool execution results for the model."""
        if not tool_results:
            return "No tool results."
        
        formatted_results = []
        for result in tool_results:
            tool_name = result.get("tool_name", "unknown")
            
            if result.get("success", False):
                result_text = str(result.get("result", "No result"))
                formatted_results.append(f"Tool '{tool_name}' executed successfully:\n{result_text}")
            else:
                error_text = result.get("error", "Unknown error")
                formatted_results.append(f"Tool '{tool_name}' failed with error: {error_text}")
        
        return "\n\n".join(formatted_results)
    
    async def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        status = {
            "initialized": self.initialized,
            "model": self.config.model_name if self.initialized else None,
            "tools": list((await self.tool_manager.get_available_tools()).keys()) if self.initialized else [],
            "conversation_length": len(self.conversation_history),
            "memory_count": 0,  # Will be implemented with memory tool
            "active_tasks": 0,  # Will be implemented with task management
        }
        
        return status
    
    async def clear_conversation(self) -> None:
        """Clear conversation history and start fresh."""
        self.conversation_history.clear()
        if self.chat_session:
            self.chat_session = self.model.start_chat(history=[])
        logger.info("Conversation history cleared")
    
    async def get_conversation_history(self) -> List[Dict[str, Any]]:
        """Get the current conversation history."""
        return self.conversation_history.copy()
    
    async def _initialize_multi_threading(self) -> None:
        """Initialize multi-threaded execution components."""
        try:
            # Initialize thread pool executor
            if not self.executor:
                self.executor = concurrent.futures.ThreadPoolExecutor(
                    max_workers=getattr(self.config, 'max_concurrent_tasks', 5)
                )

            # Initialize prediction queue
            if not hasattr(self, 'prediction_queue'):
                self.prediction_queue = queue.Queue()

            logger.info("Multi-threading components initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize multi-threading: {e}")

    async def _initialize_prediction_engine(self) -> None:
        """Initialize predictive prefetching engine."""
        try:
            from ..utils.prediction_engine import PredictionEngine
            self.prediction_engine = PredictionEngine(self.config)
            await self.prediction_engine.initialize()
            logger.info("Prediction engine initialized")
        except ImportError:
            logger.warning("Prediction engine not available")
        except Exception as e:
            logger.warning(f"Failed to initialize prediction engine: {e}")

    async def _initialize_context_compression(self) -> None:
        """Initialize context compression and RAG components."""
        try:
            from ..utils.context_compressor import ContextCompressor
            self.context_compressor = ContextCompressor(self.config)
            await self.context_compressor.initialize()
            logger.info("Context compression initialized")
        except ImportError:
            logger.warning("Context compression not available")
        except Exception as e:
            logger.warning(f"Failed to initialize context compression: {e}")

    async def _start_background_tasks(self) -> None:
        """Start background tasks for predictive prefetching."""
        try:
            if self.prefetch_enabled and self.prediction_engine:
                # Start background prediction task
                prediction_task = asyncio.create_task(self._background_prediction_loop())
                self.background_tasks.append(prediction_task)

                # Start prefetch cache cleanup task
                cleanup_task = asyncio.create_task(self._cache_cleanup_loop())
                self.background_tasks.append(cleanup_task)

                logger.info("Background tasks started")
        except Exception as e:
            logger.warning(f"Failed to start background tasks: {e}")

    async def _background_prediction_loop(self) -> None:
        """Background loop for predictive prefetching."""
        while True:
            try:
                await asyncio.sleep(1)  # Check every second

                if not self.prediction_queue.empty():
                    prediction_request = self.prediction_queue.get_nowait()
                    await self._process_prediction_request(prediction_request)

            except Exception as e:
                logger.warning(f"Error in prediction loop: {e}")
                await asyncio.sleep(5)  # Wait before retrying

    async def _cache_cleanup_loop(self) -> None:
        """Background loop for cache cleanup."""
        while True:
            try:
                await asyncio.sleep(300)  # Cleanup every 5 minutes
                await self._cleanup_prefetch_cache()
            except Exception as e:
                logger.warning(f"Error in cache cleanup: {e}")

    async def _process_prediction_request(self, request: Dict[str, Any]) -> None:
        """Process a prediction request in the background."""
        try:
            if self.prediction_engine:
                result = await self.prediction_engine.predict(request)
                if result:
                    cache_key = request.get('cache_key', str(time.time()))
                    self.prefetch_cache[cache_key] = {
                        'result': result,
                        'timestamp': time.time(),
                        'request': request
                    }
        except Exception as e:
            logger.warning(f"Error processing prediction request: {e}")

    async def _cleanup_prefetch_cache(self) -> None:
        """Clean up old entries from prefetch cache."""
        try:
            current_time = time.time()
            cache_ttl = 3600  # 1 hour TTL

            expired_keys = [
                key for key, value in self.prefetch_cache.items()
                if current_time - value['timestamp'] > cache_ttl
            ]

            for key in expired_keys:
                del self.prefetch_cache[key]

            if expired_keys:
                logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")

        except Exception as e:
            logger.warning(f"Error cleaning up cache: {e}")

    async def shutdown(self) -> None:
        """Shutdown the agent and cleanup resources."""
        logger.info("Shutting down agent...")

        # Cancel background tasks
        for task in self.background_tasks:
            if not task.done():
                task.cancel()

        # Shutdown executor
        if self.executor:
            self.executor.shutdown(wait=True)

        if self.tool_manager:
            await self.tool_manager.shutdown()

        self.initialized = False
        logger.info("Agent shutdown complete")
