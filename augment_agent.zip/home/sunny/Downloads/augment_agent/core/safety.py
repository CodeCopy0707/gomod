"""Safety and behavioral implementation for Augment Agent."""

import os
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.panel import Panel

from .config import Config
from ..utils.logging import get_logger


logger = get_logger(__name__)
console = Console()


class SafetyManager:
    """Manages safety checks and user confirmations for potentially destructive operations."""
    
    def __init__(self, config: Config):
        self.config = config
        self.destructive_operations = {
            'file_deletion',
            'file_overwrite', 
            'directory_deletion',
            'process_termination',
            'system_command',
            'package_installation',
            'git_operations',
            'database_operations'
        }
        
        # Track operations for this session
        self.operation_history = []
    
    async def check_destructive_operation(self, operation_type: str, details: Dict[str, Any]) -> bool:
        """Check if a destructive operation should proceed."""
        if not self.config.require_confirmation_for_destructive_actions:
            return True
        
        if operation_type not in self.destructive_operations:
            return True
        
        # Log the operation attempt
        self.operation_history.append({
            'type': operation_type,
            'details': details,
            'timestamp': datetime.now().isoformat(),
            'approved': False
        })
        
        # Show warning and get confirmation
        return await self._get_user_confirmation(operation_type, details)
    
    async def _get_user_confirmation(self, operation_type: str, details: Dict[str, Any]) -> bool:
        """Get user confirmation for destructive operation."""
        console.print(Panel.fit(
            f"[bold red]⚠️  DESTRUCTIVE OPERATION DETECTED[/bold red]\n\n"
            f"Operation: {operation_type}\n"
            f"Details: {self._format_operation_details(details)}\n\n"
            f"This operation may modify or delete files/data.",
            title="Safety Check",
            border_style="red"
        ))
        
        # Show backup options if applicable
        if operation_type in ['file_deletion', 'file_overwrite'] and self.config.auto_backup_before_edits:
            console.print("[yellow]Note: Auto-backup is enabled and will create a backup before proceeding.[/yellow]")
        
        # Get confirmation
        confirmed = Confirm.ask(
            "[bold]Do you want to proceed with this operation?[/bold]",
            default=False
        )
        
        # Update operation history
        if self.operation_history:
            self.operation_history[-1]['approved'] = confirmed
        
        if confirmed:
            logger.info(f"User approved destructive operation: {operation_type}")
        else:
            logger.info(f"User denied destructive operation: {operation_type}")
        
        return confirmed
    
    def _format_operation_details(self, details: Dict[str, Any]) -> str:
        """Format operation details for display."""
        formatted = []
        for key, value in details.items():
            if isinstance(value, (list, tuple)):
                value = ', '.join(str(v) for v in value)
            formatted.append(f"  {key}: {value}")
        return '\n'.join(formatted)
    
    async def create_backup(self, file_path: str, backup_dir: Optional[str] = None) -> str:
        """Create a backup of a file before modification."""
        if not self.config.auto_backup_before_edits:
            return ""
        
        source_path = Path(file_path)
        if not source_path.exists():
            return ""
        
        # Determine backup directory
        if backup_dir:
            backup_root = Path(backup_dir)
        else:
            backup_root = Path(self.config.data_dir) / "backups"
        
        backup_root.mkdir(parents=True, exist_ok=True)
        
        # Create timestamped backup
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{source_path.name}.backup_{timestamp}"
        backup_path = backup_root / backup_name
        
        try:
            shutil.copy2(source_path, backup_path)
            logger.info(f"Created backup: {backup_path}")
            return str(backup_path)
        except Exception as e:
            logger.error(f"Failed to create backup: {e}")
            return ""
    
    def get_operation_history(self) -> List[Dict[str, Any]]:
        """Get the history of operations for this session."""
        return self.operation_history.copy()


class ConservativeCodeEditor:
    """Implements conservative code editing practices."""
    
    def __init__(self, config: Config, safety_manager: SafetyManager):
        self.config = config
        self.safety_manager = safety_manager
    
    async def validate_edit_request(self, file_path: str, edit_type: str, 
                                  edit_details: Dict[str, Any]) -> bool:
        """Validate that an edit request is safe and appropriate."""
        
        # Check if file exists and is writable
        path = Path(file_path)
        if not path.exists():
            if edit_type != 'create':
                raise ValueError(f"File does not exist: {file_path}")
        elif not os.access(path, os.W_OK):
            raise PermissionError(f"File is not writable: {file_path}")
        
        # Check file size limits
        if path.exists():
            file_size = path.stat().st_size
            max_size = self.config.max_file_size_mb * 1024 * 1024
            if file_size > max_size:
                raise ValueError(f"File too large ({file_size / 1024 / 1024:.1f}MB > {self.config.max_file_size_mb}MB)")
        
        # Check for potentially dangerous operations
        if edit_type in ['replace', 'delete']:
            return await self.safety_manager.check_destructive_operation(
                'file_overwrite' if edit_type == 'replace' else 'file_deletion',
                {'file_path': file_path, 'edit_type': edit_type, **edit_details}
            )
        
        return True
    
    async def prepare_edit(self, file_path: str) -> Optional[str]:
        """Prepare for editing by creating backups if needed."""
        if self.config.auto_backup_before_edits:
            return await self.safety_manager.create_backup(file_path)
        return None
    
    def validate_code_changes(self, file_path: str, old_content: str, new_content: str) -> List[str]:
        """Validate code changes and return warnings."""
        warnings = []
        
        # Check for significant size changes
        old_lines = len(old_content.splitlines())
        new_lines = len(new_content.splitlines())
        
        if new_lines > old_lines * 2:
            warnings.append(f"File size doubled from {old_lines} to {new_lines} lines")
        elif new_lines < old_lines * 0.5:
            warnings.append(f"File size halved from {old_lines} to {new_lines} lines")
        
        # Check for removal of important patterns
        important_patterns = [
            r'import\s+\w+',
            r'from\s+\w+\s+import',
            r'def\s+\w+\s*\(',
            r'class\s+\w+\s*\(',
            r'if\s+__name__\s*==\s*["\']__main__["\']'
        ]
        
        import re
        for pattern in important_patterns:
            old_matches = len(re.findall(pattern, old_content))
            new_matches = len(re.findall(pattern, new_content))
            
            if old_matches > 0 and new_matches == 0:
                warnings.append(f"Removed all instances of pattern: {pattern}")
        
        return warnings


class PlanningMethodology:
    """Implements detailed planning methodology for complex tasks."""
    
    def __init__(self, config: Config):
        self.config = config
    
    async def create_detailed_plan(self, user_request: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Create a detailed plan for a complex request."""
        
        # Analyze the request complexity
        complexity = self._assess_complexity(user_request, context)
        
        if complexity < 3:  # Simple request, no detailed planning needed
            return {
                'requires_planning': False,
                'complexity': complexity,
                'reason': 'Request is simple enough to execute directly'
            }
        
        # Create detailed plan
        plan = {
            'requires_planning': True,
            'complexity': complexity,
            'user_request': user_request,
            'context': context,
            'phases': [],
            'estimated_duration': self._estimate_duration(complexity),
            'risks': self._identify_risks(user_request, context),
            'prerequisites': self._identify_prerequisites(user_request, context)
        }
        
        # Break down into phases
        phases = self._break_down_phases(user_request, context)
        plan['phases'] = phases
        
        return plan
    
    def _assess_complexity(self, request: str, context: Dict[str, Any]) -> int:
        """Assess the complexity of a request on a scale of 1-10."""
        complexity_indicators = [
            ('multiple files', 2),
            ('refactor', 3),
            ('database', 2),
            ('api', 2),
            ('test', 1),
            ('deploy', 4),
            ('migrate', 3),
            ('architecture', 4),
            ('framework', 3),
            ('integration', 3),
            ('security', 2),
            ('performance', 2)
        ]
        
        complexity = 1
        request_lower = request.lower()
        
        for indicator, weight in complexity_indicators:
            if indicator in request_lower:
                complexity += weight
        
        # Consider context factors
        if context.get('file_count', 0) > 5:
            complexity += 2
        if context.get('has_dependencies', False):
            complexity += 1
        if context.get('affects_multiple_systems', False):
            complexity += 3
        
        return min(complexity, 10)
    
    def _estimate_duration(self, complexity: int) -> str:
        """Estimate duration based on complexity."""
        duration_map = {
            1: "5-10 minutes",
            2: "10-20 minutes", 
            3: "20-30 minutes",
            4: "30-45 minutes",
            5: "45-60 minutes",
            6: "1-2 hours",
            7: "2-3 hours",
            8: "3-4 hours",
            9: "4-6 hours",
            10: "6+ hours"
        }
        return duration_map.get(complexity, "Unknown")
    
    def _identify_risks(self, request: str, context: Dict[str, Any]) -> List[str]:
        """Identify potential risks in the request."""
        risks = []
        request_lower = request.lower()
        
        risk_patterns = [
            ('delete', "Data loss risk"),
            ('remove', "Data loss risk"),
            ('drop', "Data loss risk"),
            ('truncate', "Data loss risk"),
            ('overwrite', "Data overwrite risk"),
            ('replace all', "Mass replacement risk"),
            ('migrate', "Data migration risk"),
            ('deploy', "Deployment risk"),
            ('production', "Production environment risk"),
            ('database', "Database modification risk"),
            ('schema', "Schema change risk")
        ]
        
        for pattern, risk in risk_patterns:
            if pattern in request_lower:
                risks.append(risk)
        
        return list(set(risks))  # Remove duplicates
    
    def _identify_prerequisites(self, request: str, context: Dict[str, Any]) -> List[str]:
        """Identify prerequisites for the request."""
        prerequisites = []
        request_lower = request.lower()
        
        prereq_patterns = [
            ('test', "Existing tests should pass"),
            ('deploy', "Code should be tested"),
            ('database', "Database backup recommended"),
            ('migrate', "Data backup required"),
            ('refactor', "Comprehensive test coverage needed"),
            ('api', "API documentation should be updated"),
            ('security', "Security review required")
        ]
        
        for pattern, prereq in prereq_patterns:
            if pattern in request_lower:
                prerequisites.append(prereq)
        
        return list(set(prerequisites))
    
    def _break_down_phases(self, request: str, context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Break down the request into manageable phases."""
        phases = []
        
        # Standard phases for most requests
        phases.append({
            'name': 'Information Gathering',
            'description': 'Gather detailed information about the current state and requirements',
            'estimated_time': '5-10 minutes',
            'tasks': [
                'Analyze existing codebase structure',
                'Identify affected files and components',
                'Review current implementation patterns',
                'Understand dependencies and constraints'
            ]
        })
        
        phases.append({
            'name': 'Planning & Design',
            'description': 'Create detailed implementation plan and design',
            'estimated_time': '10-15 minutes',
            'tasks': [
                'Design the solution approach',
                'Identify required changes',
                'Plan the implementation sequence',
                'Consider edge cases and error handling'
            ]
        })
        
        phases.append({
            'name': 'Implementation',
            'description': 'Execute the planned changes',
            'estimated_time': '20-40 minutes',
            'tasks': [
                'Implement core functionality',
                'Handle edge cases',
                'Add error handling',
                'Update documentation'
            ]
        })
        
        phases.append({
            'name': 'Testing & Validation',
            'description': 'Test the implementation and validate results',
            'estimated_time': '10-20 minutes',
            'tasks': [
                'Write or update tests',
                'Run existing test suite',
                'Manual testing of new functionality',
                'Validate against requirements'
            ]
        })
        
        return phases
    
    def format_plan_for_display(self, plan: Dict[str, Any]) -> str:
        """Format the plan for display to the user."""
        if not plan.get('requires_planning'):
            return ""
        
        output = []
        output.append("# Detailed Implementation Plan\n")
        
        output.append(f"**Request:** {plan['user_request']}")
        output.append(f"**Complexity:** {plan['complexity']}/10")
        output.append(f"**Estimated Duration:** {plan['estimated_duration']}\n")
        
        if plan.get('risks'):
            output.append("## ⚠️ Identified Risks")
            for risk in plan['risks']:
                output.append(f"- {risk}")
            output.append("")
        
        if plan.get('prerequisites'):
            output.append("## 📋 Prerequisites")
            for prereq in plan['prerequisites']:
                output.append(f"- {prereq}")
            output.append("")
        
        output.append("## 📅 Implementation Phases")
        for i, phase in enumerate(plan['phases'], 1):
            output.append(f"### Phase {i}: {phase['name']}")
            output.append(f"**Description:** {phase['description']}")
            output.append(f"**Estimated Time:** {phase['estimated_time']}")
            output.append("**Tasks:**")
            for task in phase['tasks']:
                output.append(f"- {task}")
            output.append("")
        
        return "\n".join(output)
