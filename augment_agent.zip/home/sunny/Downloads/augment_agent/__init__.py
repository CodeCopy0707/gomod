"""
Augment Agent - A comprehensive Python-based AI agent for terminal/command-line usage.

This package provides a standalone AI coding assistant that replicates the capabilities
of Augment Agent using Google's Gemini 2.0 Flash model as the underlying AI engine.
"""

__version__ = "1.0.0"
__author__ = "Augment Agent Clone"
__email__ = "agent@example.com"

from .core.agent import AugmentAgent
from .core.config import Config
from .cli import main

__all__ = ["AugmentAgent", "Config", "main"]
