"""Task and memory management tools for Augment Agent."""

import json
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from enum import Enum

from .base import BaseTool
from ..utils.logging import configure_tool_logging


class TaskState(Enum):
    """Task state enumeration."""
    NOT_STARTED = "NOT_STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETE = "COMPLETE"
    CANCELLED = "CANCELLED"


class TaskManagerTool(BaseTool):
    """Base class for task management tools."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("task-manager")
        self.db_path = None
    
    async def initialize(self) -> None:
        """Initialize the task management system."""
        await super().initialize()
        
        self.db_path = Path(self.config.task_db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._init_database()
    
    def _init_database(self) -> None:
        """Initialize the SQLite database for task storage."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    state TEXT NOT NULL DEFAULT 'NOT_STARTED',
                    parent_id TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    completed_at TIMESTAMP,
                    metadata TEXT,
                    FOREIGN KEY (parent_id) REFERENCES tasks (id)
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks (parent_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_tasks_state ON tasks (state)
            """)
    
    def _get_task_hierarchy(self) -> List[Dict[str, Any]]:
        """Get the complete task hierarchy."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT id, name, description, state, parent_id, created_at, updated_at, completed_at, metadata
                FROM tasks
                ORDER BY created_at
            """)
            
            tasks = []
            for row in cursor.fetchall():
                metadata = json.loads(row[8]) if row[8] else {}
                tasks.append({
                    'id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'state': row[3],
                    'parent_id': row[4],
                    'created_at': row[5],
                    'updated_at': row[6],
                    'completed_at': row[7],
                    'metadata': metadata
                })
            
            return self._build_hierarchy(tasks)
    
    def _build_hierarchy(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Build hierarchical task structure."""
        task_map = {task['id']: task for task in tasks}
        root_tasks = []
        
        for task in tasks:
            task['children'] = []
            if task['parent_id'] is None:
                root_tasks.append(task)
            else:
                parent = task_map.get(task['parent_id'])
                if parent:
                    parent['children'].append(task)
        
        return root_tasks


class ViewTasklistTool(TaskManagerTool):
    """Tool for viewing the current task list."""
    
    @property
    def name(self) -> str:
        return "view_tasklist"
    
    @property
    def description(self) -> str:
        return "View the current task list for the conversation."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {},
            "required": []
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute task list viewing."""
        self._ensure_initialized()
        
        self.tool_logger.log_execution_start("view_tasklist")
        
        try:
            tasks = self._get_task_hierarchy()
            formatted_tasks = self._format_task_list(tasks)
            
            self.tool_logger.log_execution_success("view_tasklist", f"Listed {len(tasks)} root tasks")
            return formatted_tasks
            
        except Exception as e:
            self.tool_logger.log_execution_error("view_tasklist", e)
            raise
    
    def _format_task_list(self, tasks: List[Dict[str, Any]], indent: int = 0) -> str:
        """Format task list as markdown."""
        if not tasks:
            return "No tasks found."
        
        lines = []
        if indent == 0:
            lines.append("# Current Task List\n")
        
        for task in tasks:
            # Format task state
            state_symbols = {
                'NOT_STARTED': '[ ]',
                'IN_PROGRESS': '[/]',
                'COMPLETE': '[x]',
                'CANCELLED': '[-]'
            }
            
            state_symbol = state_symbols.get(task['state'], '[ ]')
            indent_str = '-' * indent
            
            # Format task line
            task_line = f"{indent_str}{state_symbol} UUID:{task['id']} NAME:{task['name']}"
            if task['description']:
                task_line += f" DESCRIPTION:{task['description']}"
            
            lines.append(task_line)
            
            # Add children recursively
            if task['children']:
                child_lines = self._format_task_list(task['children'], indent + 1)
                lines.append(child_lines)
        
        return '\n'.join(lines)


class AddTasksTool(TaskManagerTool):
    """Tool for adding new tasks."""
    
    @property
    def name(self) -> str:
        return "add_tasks"
    
    @property
    def description(self) -> str:
        return "Add one or more new tasks to the task list."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "The name of the new task."
                            },
                            "description": {
                                "type": "string",
                                "description": "The description of the new task."
                            },
                            "state": {
                                "type": "string",
                                "enum": ["NOT_STARTED", "IN_PROGRESS", "COMPLETE", "CANCELLED"],
                                "description": "Initial state of the task.",
                                "default": "NOT_STARTED"
                            },
                            "parent_task_id": {
                                "type": "string",
                                "description": "UUID of the parent task if this should be a subtask."
                            },
                            "after_task_id": {
                                "type": "string",
                                "description": "UUID of the task after which this task should be inserted."
                            }
                        },
                        "required": ["name", "description"]
                    }
                }
            },
            "required": ["tasks"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute task addition."""
        self._ensure_initialized()
        
        tasks_to_add = kwargs["tasks"]
        
        self.tool_logger.log_execution_start("add_tasks", count=len(tasks_to_add))
        
        try:
            created_tasks = []
            
            with sqlite3.connect(self.db_path) as conn:
                for task_data in tasks_to_add:
                    task_id = str(uuid.uuid4())
                    name = task_data["name"]
                    description = task_data["description"]
                    state = task_data.get("state", "NOT_STARTED")
                    parent_id = task_data.get("parent_task_id")
                    
                    # Validate parent task exists if specified
                    if parent_id:
                        cursor = conn.execute("SELECT id FROM tasks WHERE id = ?", (parent_id,))
                        if not cursor.fetchone():
                            raise ValueError(f"Parent task {parent_id} not found")
                    
                    # Insert task
                    conn.execute("""
                        INSERT INTO tasks (id, name, description, state, parent_id)
                        VALUES (?, ?, ?, ?, ?)
                    """, (task_id, name, description, state, parent_id))
                    
                    created_tasks.append({
                        'id': task_id,
                        'name': name,
                        'description': description,
                        'state': state
                    })
            
            result = f"Successfully created {len(created_tasks)} tasks:\n"
            for task in created_tasks:
                result += f"- {task['name']} (ID: {task['id']})\n"
            
            self.tool_logger.log_execution_success("add_tasks", f"Created {len(created_tasks)} tasks")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("add_tasks", e)
            raise


class UpdateTasksTool(TaskManagerTool):
    """Tool for updating existing tasks."""
    
    @property
    def name(self) -> str:
        return "update_tasks"
    
    @property
    def description(self) -> str:
        return "Update one or more tasks' properties (state, name, description)."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "task_id": {
                                "type": "string",
                                "description": "The UUID of the task to update."
                            },
                            "name": {
                                "type": "string",
                                "description": "New task name."
                            },
                            "description": {
                                "type": "string",
                                "description": "New task description."
                            },
                            "state": {
                                "type": "string",
                                "enum": ["NOT_STARTED", "IN_PROGRESS", "COMPLETE", "CANCELLED"],
                                "description": "New task state."
                            }
                        },
                        "required": ["task_id"]
                    }
                }
            },
            "required": ["tasks"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute task updates."""
        self._ensure_initialized()
        
        tasks_to_update = kwargs["tasks"]
        
        self.tool_logger.log_execution_start("update_tasks", count=len(tasks_to_update))
        
        try:
            updated_tasks = []
            
            with sqlite3.connect(self.db_path) as conn:
                for task_data in tasks_to_update:
                    task_id = task_data["task_id"]
                    
                    # Check if task exists
                    cursor = conn.execute("SELECT id, name FROM tasks WHERE id = ?", (task_id,))
                    existing_task = cursor.fetchone()
                    if not existing_task:
                        raise ValueError(f"Task {task_id} not found")
                    
                    # Build update query
                    updates = []
                    params = []
                    
                    if "name" in task_data:
                        updates.append("name = ?")
                        params.append(task_data["name"])
                    
                    if "description" in task_data:
                        updates.append("description = ?")
                        params.append(task_data["description"])
                    
                    if "state" in task_data:
                        updates.append("state = ?")
                        params.append(task_data["state"])
                        
                        # Set completed_at if marking as complete
                        if task_data["state"] == "COMPLETE":
                            updates.append("completed_at = CURRENT_TIMESTAMP")
                    
                    updates.append("updated_at = CURRENT_TIMESTAMP")
                    params.append(task_id)
                    
                    # Execute update
                    if updates:
                        query = f"UPDATE tasks SET {', '.join(updates)} WHERE id = ?"
                        conn.execute(query, params)
                        
                        updated_tasks.append({
                            'id': task_id,
                            'name': existing_task[1],
                            'updates': {k: v for k, v in task_data.items() if k != 'task_id'}
                        })
            
            result = f"Successfully updated {len(updated_tasks)} tasks:\n"
            for task in updated_tasks:
                result += f"- {task['name']} (ID: {task['id']}): {task['updates']}\n"
            
            self.tool_logger.log_execution_success("update_tasks", f"Updated {len(updated_tasks)} tasks")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("update_tasks", e)
            raise


class ReorganizeTasklistTool(TaskManagerTool):
    """Tool for reorganizing the task list structure."""

    @property
    def name(self) -> str:
        return "reorganize_tasklist"

    @property
    def description(self) -> str:
        return "Reorganize the task list structure for the current conversation."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "markdown": {
                    "type": "string",
                    "description": "The markdown representation of the task list to update."
                }
            },
            "required": ["markdown"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute task list reorganization."""
        self._ensure_initialized()

        markdown = kwargs["markdown"]

        self.tool_logger.log_execution_start("reorganize_tasklist")

        try:
            # Parse markdown into task structure
            tasks = self._parse_markdown_tasks(markdown)

            # Clear existing tasks and recreate
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("DELETE FROM tasks")

                for task in tasks:
                    self._insert_task_recursive(conn, task, None)

            result = f"Successfully reorganized task list with {len(tasks)} root tasks"

            self.tool_logger.log_execution_success("reorganize_tasklist", result)
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("reorganize_tasklist", e)
            raise

    def _parse_markdown_tasks(self, markdown: str) -> List[Dict[str, Any]]:
        """Parse markdown task list into structured data."""
        lines = markdown.strip().split('\n')
        tasks = []
        task_stack = []

        for line in lines:
            if not line.strip() or line.startswith('#'):
                continue

            # Count indentation level
            indent_level = 0
            stripped = line.lstrip('-')
            if stripped != line:
                indent_level = (len(line) - len(stripped)) // 1  # Each dash is one level

            # Parse task line
            task_match = self._parse_task_line(stripped.strip())
            if not task_match:
                continue

            task = {
                'id': task_match.get('id', str(uuid.uuid4())),
                'name': task_match['name'],
                'description': task_match.get('description', ''),
                'state': task_match.get('state', 'NOT_STARTED'),
                'children': [],
                'indent_level': indent_level
            }

            # Adjust task stack based on indentation
            while len(task_stack) > indent_level:
                task_stack.pop()

            if task_stack:
                # Add as child to parent
                task_stack[-1]['children'].append(task)
            else:
                # Root level task
                tasks.append(task)

            task_stack.append(task)

        return tasks

    def _parse_task_line(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse a single task line."""
        import re

        # Match pattern: [state] UUID:id NAME:name DESCRIPTION:description
        pattern = r'\[(.)\]\s*(?:UUID:(\S+))?\s*NAME:([^D]+?)(?:\s+DESCRIPTION:(.+))?$'
        match = re.match(pattern, line.strip())

        if not match:
            return None

        state_char, task_id, name, description = match.groups()

        state_map = {
            ' ': 'NOT_STARTED',
            '/': 'IN_PROGRESS',
            'x': 'COMPLETE',
            '-': 'CANCELLED'
        }

        return {
            'id': task_id or str(uuid.uuid4()),
            'name': name.strip(),
            'description': description.strip() if description else '',
            'state': state_map.get(state_char, 'NOT_STARTED')
        }

    def _insert_task_recursive(self, conn, task: Dict[str, Any], parent_id: Optional[str]) -> None:
        """Insert task and its children recursively."""
        conn.execute("""
            INSERT INTO tasks (id, name, description, state, parent_id)
            VALUES (?, ?, ?, ?, ?)
        """, (task['id'], task['name'], task['description'], task['state'], parent_id))

        for child in task['children']:
            self._insert_task_recursive(conn, child, task['id'])


class RememberTool(BaseTool):
    """Tool for storing and retrieving memories."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("remember")
        self.db_path = None

    @property
    def name(self) -> str:
        return "remember"

    @property
    def description(self) -> str:
        return "Store information in long-term memory for future reference."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "memory": {
                    "type": "string",
                    "description": "The concise (1 sentence) memory to remember."
                }
            },
            "required": ["memory"]
        }

    async def initialize(self) -> None:
        """Initialize the memory system."""
        await super().initialize()

        self.db_path = Path(self.config.memory_db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # Initialize database
        self._init_database()

    def _init_database(self) -> None:
        """Initialize the SQLite database for memory storage."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    content TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    access_count INTEGER DEFAULT 1,
                    tags TEXT,
                    metadata TEXT
                )
            """)

            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_memories_created ON memories (created_at)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_memories_accessed ON memories (accessed_at)
            """)

    async def execute(self, **kwargs) -> str:
        """Execute memory storage."""
        self._ensure_initialized()

        memory_content = kwargs["memory"]

        self.tool_logger.log_execution_start("remember", content=memory_content[:50])

        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO memories (content)
                    VALUES (?)
                """, (memory_content,))

                memory_id = conn.lastrowid

            result = f"Memory stored successfully (ID: {memory_id}): {memory_content}"

            self.tool_logger.log_execution_success("remember", f"Stored memory {memory_id}")
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("remember", e)
            raise

    async def get_memories(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Retrieve stored memories."""
        self._ensure_initialized()

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT id, content, created_at, accessed_at, access_count
                FROM memories
                ORDER BY accessed_at DESC, created_at DESC
                LIMIT ?
            """, (limit,))

            memories = []
            for row in cursor.fetchall():
                memories.append({
                    'id': row[0],
                    'content': row[1],
                    'created_at': row[2],
                    'accessed_at': row[3],
                    'access_count': row[4]
                })

            return memories

    async def search_memories(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Search memories by content."""
        self._ensure_initialized()

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT id, content, created_at, accessed_at, access_count
                FROM memories
                WHERE content LIKE ?
                ORDER BY access_count DESC, created_at DESC
                LIMIT ?
            """, (f'%{query}%', limit))

            memories = []
            for row in cursor.fetchall():
                # Update access count
                conn.execute("""
                    UPDATE memories
                    SET accessed_at = CURRENT_TIMESTAMP, access_count = access_count + 1
                    WHERE id = ?
                """, (row[0],))

                memories.append({
                    'id': row[0],
                    'content': row[1],
                    'created_at': row[2],
                    'accessed_at': row[3],
                    'access_count': row[4] + 1
                })

            return memories
