"""Project scaffolding tool as specified in plan.md."""

import os
import json
from typing import Dict, Any, List, Optional
from pathlib import Path
import subprocess

from .base import FileOperationTool
from ..utils.logging import configure_tool_logging


class ProjectScaffolderTool(FileOperationTool):
    """Create complete project structures with best practices."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("project-scaffolder")
    
    @property
    def name(self) -> str:
        return "project-scaffolder"
    
    @property
    def description(self) -> str:
        return "Create complete project structures with best practices, dependencies, and configuration."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "project_name": {
                    "type": "string",
                    "description": "Name of the project"
                },
                "project_type": {
                    "type": "string",
                    "enum": [
                        "python_package", "python_web", "python_cli", "python_ml",
                        "react_app", "vue_app", "angular_app", "node_api",
                        "java_spring", "java_maven", "cpp_cmake", "go_module",
                        "rust_binary", "rust_library", "dotnet_api", "dotnet_web"
                    ],
                    "description": "Type of project to scaffold"
                },
                "features": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": [
                            "testing", "linting", "formatting", "ci_cd", "docker",
                            "database", "authentication", "api_docs", "logging",
                            "monitoring", "deployment", "security", "performance"
                        ]
                    },
                    "description": "Additional features to include",
                    "default": ["testing", "linting", "formatting"]
                },
                "target_directory": {
                    "type": "string",
                    "description": "Target directory for the project",
                    "default": "."
                },
                "initialize_git": {
                    "type": "boolean",
                    "description": "Initialize git repository",
                    "default": true
                },
                "install_dependencies": {
                    "type": "boolean",
                    "description": "Install project dependencies",
                    "default": true
                }
            },
            "required": ["project_name", "project_type"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute project scaffolding."""
        self._ensure_initialized()
        
        project_name = kwargs["project_name"]
        project_type = kwargs["project_type"]
        features = kwargs.get("features", ["testing", "linting", "formatting"])
        target_directory = kwargs.get("target_directory", ".")
        initialize_git = kwargs.get("initialize_git", True)
        install_dependencies = kwargs.get("install_dependencies", True)
        
        self.tool_logger.log_execution_start("project_scaffolder", 
                                           project=project_name,
                                           type=project_type)
        
        try:
            # Create project directory
            project_path = Path(target_directory) / project_name
            project_path.mkdir(parents=True, exist_ok=True)
            
            # Generate project structure
            scaffold_result = await self._scaffold_project(
                project_path, project_name, project_type, features
            )
            
            # Initialize git if requested
            if initialize_git:
                await self._initialize_git(project_path)
            
            # Install dependencies if requested
            if install_dependencies:
                await self._install_dependencies(project_path, project_type)
            
            # Format results
            result = self._format_scaffold_results(
                project_name, project_type, features, scaffold_result, str(project_path)
            )
            
            self.tool_logger.log_execution_success("project_scaffolder", 
                                                 f"Created {len(scaffold_result['files'])} files")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("project_scaffolder", e)
            raise
    
    async def _scaffold_project(self, project_path: Path, project_name: str,
                              project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold the project structure."""
        scaffold_result = {
            'files': [],
            'directories': [],
            'commands_run': []
        }
        
        # Create base structure based on project type
        if project_type.startswith('python_'):
            scaffold_result.update(await self._scaffold_python_project(
                project_path, project_name, project_type, features
            ))
        elif project_type.startswith('react_') or project_type.startswith('vue_') or project_type.startswith('angular_'):
            scaffold_result.update(await self._scaffold_frontend_project(
                project_path, project_name, project_type, features
            ))
        elif project_type.startswith('node_'):
            scaffold_result.update(await self._scaffold_node_project(
                project_path, project_name, project_type, features
            ))
        elif project_type.startswith('java_'):
            scaffold_result.update(await self._scaffold_java_project(
                project_path, project_name, project_type, features
            ))
        elif project_type.startswith('go_'):
            scaffold_result.update(await self._scaffold_go_project(
                project_path, project_name, project_type, features
            ))
        elif project_type.startswith('rust_'):
            scaffold_result.update(await self._scaffold_rust_project(
                project_path, project_name, project_type, features
            ))
        else:
            # Generic project
            scaffold_result.update(await self._scaffold_generic_project(
                project_path, project_name, features
            ))
        
        return scaffold_result
    
    async def _scaffold_python_project(self, project_path: Path, project_name: str,
                                     project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold Python project."""
        files = []
        directories = []
        
        # Create directory structure
        src_dir = project_path / project_name.replace('-', '_')
        src_dir.mkdir(exist_ok=True)
        directories.append(str(src_dir))
        
        if 'testing' in features:
            tests_dir = project_path / 'tests'
            tests_dir.mkdir(exist_ok=True)
            directories.append(str(tests_dir))
        
        docs_dir = project_path / 'docs'
        docs_dir.mkdir(exist_ok=True)
        directories.append(str(docs_dir))
        
        # Create files
        files.extend(await self._create_python_files(project_path, project_name, project_type, features))
        
        return {'files': files, 'directories': directories}
    
    async def _create_python_files(self, project_path: Path, project_name: str,
                                 project_type: str, features: List[str]) -> List[str]:
        """Create Python project files."""
        files = []
        
        # setup.py
        setup_content = f'''"""Setup configuration for {project_name}."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="{project_name}",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A short description of {project_name}",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/{project_name}",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Add your dependencies here
    ],
    extras_require={{
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
        ],
    }},
)
'''
        self._write_file(project_path / 'setup.py', setup_content)
        files.append('setup.py')
        
        # pyproject.toml
        pyproject_content = f'''[build-system]
requires = ["setuptools>=45", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{project_name}"
version = "0.1.0"
description = "A short description of {project_name}"
readme = "README.md"
requires-python = ">=3.8"
license = {{text = "MIT"}}
authors = [
    {{name = "Your Name", email = "your.email@example.com"}},
]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
]
dependencies = [
    # Add your dependencies here
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "black>=22.0.0",
    "flake8>=4.0.0",
    "mypy>=0.950",
]

[project.urls]
Homepage = "https://github.com/yourusername/{project_name}"
Repository = "https://github.com/yourusername/{project_name}"
Issues = "https://github.com/yourusername/{project_name}/issues"

[tool.black]
line-length = 88
target-version = ['py38']

[tool.mypy]
python_version = "3.8"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
python_classes = ["Test*"]
python_functions = ["test_*"]
'''
        self._write_file(project_path / 'pyproject.toml', pyproject_content)
        files.append('pyproject.toml')
        
        # README.md
        readme_content = f'''# {project_name}

A short description of your project.

## Installation

```bash
pip install {project_name}
```

## Usage

```python
import {project_name.replace('-', '_')}

# Your usage examples here
```

## Development

```bash
# Clone the repository
git clone https://github.com/yourusername/{project_name}.git
cd {project_name}

# Install in development mode
pip install -e .[dev]

# Run tests
pytest

# Format code
black .

# Lint code
flake8 .
```

## License

MIT License
'''
        self._write_file(project_path / 'README.md', readme_content)
        files.append('README.md')
        
        # Main module
        module_name = project_name.replace('-', '_')
        module_dir = project_path / module_name
        module_dir.mkdir(exist_ok=True)
        
        init_content = f'''"""
{project_name} - A Python package.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Import main classes/functions here
# from .main import MainClass

__all__ = [
    # "MainClass",
]
'''
        self._write_file(module_dir / '__init__.py', init_content)
        files.append(f'{module_name}/__init__.py')
        
        # Main module file
        if project_type == 'python_cli':
            main_content = '''"""Main CLI module."""

import argparse
import sys
from typing import List, Optional


def main(args: Optional[List[str]] = None) -> int:
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(description="Your CLI description")
    parser.add_argument(
        "--version", action="version", version="%(prog)s 0.1.0"
    )
    parser.add_argument(
        "input", nargs="?", help="Input file or argument"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Verbose output"
    )
    
    parsed_args = parser.parse_args(args)
    
    if parsed_args.verbose:
        print("Verbose mode enabled")
    
    if parsed_args.input:
        print(f"Processing: {parsed_args.input}")
    else:
        print("No input provided")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
'''
        elif project_type == 'python_web':
            main_content = '''"""Main web application module."""

from flask import Flask, jsonify, request
from typing import Dict, Any


def create_app() -> Flask:
    """Create and configure the Flask application."""
    app = Flask(__name__)
    
    @app.route("/")
    def index() -> Dict[str, str]:
        """Root endpoint."""
        return {"message": "Hello, World!"}
    
    @app.route("/health")
    def health() -> Dict[str, str]:
        """Health check endpoint."""
        return {"status": "healthy"}
    
    @app.route("/api/data", methods=["GET", "POST"])
    def data() -> Dict[str, Any]:
        """Data endpoint."""
        if request.method == "POST":
            data = request.get_json()
            return {"received": data}
        else:
            return {"data": "sample data"}
    
    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
'''
        else:
            main_content = f'''"""Main module for {project_name}."""

from typing import Any, Dict, List, Optional


class {project_name.replace('-', '_').title()}:
    """Main class for {project_name}."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize the class."""
        self.config = config or {{}}
    
    def process(self, data: Any) -> Any:
        """Process data."""
        # Implement your main logic here
        return data
    
    def get_info(self) -> Dict[str, str]:
        """Get information about the instance."""
        return {{
            "name": "{project_name}",
            "version": "0.1.0",
            "config": str(self.config)
        }}


def main() -> None:
    """Main function."""
    instance = {project_name.replace('-', '_').title()}()
    print(instance.get_info())


if __name__ == "__main__":
    main()
'''
        
        self._write_file(module_dir / 'main.py', main_content)
        files.append(f'{module_name}/main.py')
        
        # Tests
        if 'testing' in features:
            test_content = f'''"""Tests for {project_name}."""

import pytest
from {module_name}.main import {project_name.replace('-', '_').title()}


class Test{project_name.replace('-', '_').title()}:
    """Test class for {project_name.replace('-', '_').title()}."""
    
    def test_init(self):
        """Test initialization."""
        instance = {project_name.replace('-', '_').title()}()
        assert instance is not None
    
    def test_process(self):
        """Test process method."""
        instance = {project_name.replace('-', '_').title()}()
        result = instance.process("test data")
        assert result == "test data"
    
    def test_get_info(self):
        """Test get_info method."""
        instance = {project_name.replace('-', '_').title()}()
        info = instance.get_info()
        assert "name" in info
        assert info["name"] == "{project_name}"


def test_main():
    """Test main function."""
    # This test would need to be adapted based on what main() does
    pass
'''
            self._write_file(project_path / 'tests' / f'test_{module_name}.py', test_content)
            files.append(f'tests/test_{module_name}.py')
            
            # Test init file
            self._write_file(project_path / 'tests' / '__init__.py', '')
            files.append('tests/__init__.py')
        
        # Configuration files
        if 'linting' in features:
            flake8_content = '''[flake8]
max-line-length = 88
extend-ignore = E203, W503
exclude = .git,__pycache__,docs/source/conf.py,old,build,dist
'''
            self._write_file(project_path / '.flake8', flake8_content)
            files.append('.flake8')
        
        # .gitignore
        gitignore_content = '''# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# PyInstaller
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
.hypothesis/
.pytest_cache/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# pyenv
.python-version

# celery beat schedule file
celerybeat-schedule

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json
'''
        self._write_file(project_path / '.gitignore', gitignore_content)
        files.append('.gitignore')
        
        return files
    
    async def _scaffold_frontend_project(self, project_path: Path, project_name: str,
                                       project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold frontend project."""
        commands_run = []
        
        if project_type == 'react_app':
            # Use create-react-app
            cmd = f"npx create-react-app {project_name}"
            commands_run.append(cmd)
        elif project_type == 'vue_app':
            # Use Vue CLI
            cmd = f"npx @vue/cli create {project_name}"
            commands_run.append(cmd)
        elif project_type == 'angular_app':
            # Use Angular CLI
            cmd = f"npx @angular/cli new {project_name}"
            commands_run.append(cmd)
        
        return {'files': [], 'directories': [], 'commands_run': commands_run}
    
    async def _scaffold_node_project(self, project_path: Path, project_name: str,
                                   project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold Node.js project."""
        files = []
        directories = []
        
        # Create basic structure
        src_dir = project_path / 'src'
        src_dir.mkdir(exist_ok=True)
        directories.append(str(src_dir))
        
        # package.json
        package_json = {
            "name": project_name,
            "version": "1.0.0",
            "description": f"A Node.js project: {project_name}",
            "main": "src/index.js",
            "scripts": {
                "start": "node src/index.js",
                "dev": "nodemon src/index.js",
                "test": "jest"
            },
            "keywords": [],
            "author": "Your Name",
            "license": "MIT",
            "dependencies": {
                "express": "^4.18.0"
            },
            "devDependencies": {
                "nodemon": "^2.0.0",
                "jest": "^29.0.0"
            }
        }
        
        self._write_file(project_path / 'package.json', json.dumps(package_json, indent=2))
        files.append('package.json')
        
        # Main server file
        server_content = '''const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// Routes
app.get('/', (req, res) => {
    res.json({ message: 'Hello, World!' });
});

app.get('/health', (req, res) => {
    res.json({ status: 'healthy' });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

module.exports = app;
'''
        self._write_file(src_dir / 'index.js', server_content)
        files.append('src/index.js')
        
        return {'files': files, 'directories': directories}
    
    async def _scaffold_java_project(self, project_path: Path, project_name: str,
                                   project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold Java project."""
        commands_run = []
        
        if project_type == 'java_maven':
            cmd = f"mvn archetype:generate -DgroupId=com.example -DartifactId={project_name} -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false"
            commands_run.append(cmd)
        elif project_type == 'java_spring':
            cmd = f"curl https://start.spring.io/starter.zip -d dependencies=web -d name={project_name} -o {project_name}.zip && unzip {project_name}.zip"
            commands_run.append(cmd)
        
        return {'files': [], 'directories': [], 'commands_run': commands_run}
    
    async def _scaffold_go_project(self, project_path: Path, project_name: str,
                                 project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold Go project."""
        files = []
        commands_run = []
        
        # Initialize Go module
        commands_run.append(f"go mod init {project_name}")
        
        # Main Go file
        main_content = f'''package main

import (
    "fmt"
    "log"
    "net/http"
)

func main() {{
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {{
        fmt.Fprintf(w, "Hello, World!")
    }})
    
    fmt.Println("Server starting on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}}
'''
        self._write_file(project_path / 'main.go', main_content)
        files.append('main.go')
        
        return {'files': files, 'directories': [], 'commands_run': commands_run}
    
    async def _scaffold_rust_project(self, project_path: Path, project_name: str,
                                   project_type: str, features: List[str]) -> Dict[str, Any]:
        """Scaffold Rust project."""
        commands_run = []
        
        if project_type == 'rust_binary':
            commands_run.append(f"cargo init --name {project_name}")
        elif project_type == 'rust_library':
            commands_run.append(f"cargo init --lib --name {project_name}")
        
        return {'files': [], 'directories': [], 'commands_run': commands_run}
    
    async def _scaffold_generic_project(self, project_path: Path, project_name: str,
                                      features: List[str]) -> Dict[str, Any]:
        """Scaffold generic project."""
        files = []
        
        # Basic README
        readme_content = f'''# {project_name}

Project description goes here.

## Getting Started

Instructions for setting up and running the project.

## Usage

Usage examples and documentation.

## Contributing

Guidelines for contributing to the project.

## License

License information.
'''
        self._write_file(project_path / 'README.md', readme_content)
        files.append('README.md')
        
        return {'files': files, 'directories': []}
    
    def _write_file(self, file_path: Path, content: str) -> None:
        """Write content to a file."""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
    
    async def _initialize_git(self, project_path: Path) -> None:
        """Initialize git repository."""
        try:
            subprocess.run(['git', 'init'], cwd=project_path, check=True, capture_output=True)
            subprocess.run(['git', 'add', '.'], cwd=project_path, check=True, capture_output=True)
            subprocess.run(['git', 'commit', '-m', 'Initial commit'], cwd=project_path, check=True, capture_output=True)
            self.tool_logger.log_info("Git repository initialized")
        except subprocess.CalledProcessError as e:
            self.tool_logger.log_warning(f"Failed to initialize git: {e}")
    
    async def _install_dependencies(self, project_path: Path, project_type: str) -> None:
        """Install project dependencies."""
        try:
            if project_type.startswith('python_'):
                if (project_path / 'requirements.txt').exists():
                    subprocess.run(['pip', 'install', '-r', 'requirements.txt'], cwd=project_path, check=True)
                elif (project_path / 'pyproject.toml').exists():
                    subprocess.run(['pip', 'install', '-e', '.[dev]'], cwd=project_path, check=True)
            elif project_type.startswith(('react_', 'vue_', 'angular_', 'node_')):
                if (project_path / 'package.json').exists():
                    subprocess.run(['npm', 'install'], cwd=project_path, check=True)
            elif project_type.startswith('go_'):
                subprocess.run(['go', 'mod', 'tidy'], cwd=project_path, check=True)
            elif project_type.startswith('rust_'):
                subprocess.run(['cargo', 'build'], cwd=project_path, check=True)
            
            self.tool_logger.log_info("Dependencies installed")
        except subprocess.CalledProcessError as e:
            self.tool_logger.log_warning(f"Failed to install dependencies: {e}")
    
    def _format_scaffold_results(self, project_name: str, project_type: str,
                               features: List[str], scaffold_result: Dict[str, Any],
                               project_path: str) -> str:
        """Format scaffolding results."""
        result = [f"# Project Scaffolding Complete\n"]
        result.append(f"**Project Name:** {project_name}")
        result.append(f"**Project Type:** {project_type}")
        result.append(f"**Project Path:** {project_path}")
        result.append(f"**Features:** {', '.join(features)}")
        
        if scaffold_result['files']:
            result.append(f"\n## Files Created ({len(scaffold_result['files'])})\n")
            for file in scaffold_result['files']:
                result.append(f"- {file}")
        
        if scaffold_result['directories']:
            result.append(f"\n## Directories Created ({len(scaffold_result['directories'])})\n")
            for directory in scaffold_result['directories']:
                result.append(f"- {directory}")
        
        if scaffold_result.get('commands_run'):
            result.append(f"\n## Commands to Run\n")
            for command in scaffold_result['commands_run']:
                result.append(f"```bash\n{command}\n```")
        
        result.append("\n## Next Steps\n")
        result.append("1. Navigate to the project directory")
        result.append("2. Review and customize the generated files")
        result.append("3. Install dependencies if not already done")
        result.append("4. Start developing your project!")
        
        if project_type.startswith('python_'):
            result.append("\n### Python-specific next steps:")
            result.append("- Activate virtual environment: `python -m venv venv && source venv/bin/activate`")
            result.append("- Install in development mode: `pip install -e .[dev]`")
            result.append("- Run tests: `pytest`")
        elif project_type.startswith(('react_', 'vue_', 'angular_', 'node_')):
            result.append("\n### Node.js-specific next steps:")
            result.append("- Install dependencies: `npm install`")
            result.append("- Start development server: `npm start` or `npm run dev`")
            result.append("- Run tests: `npm test`")
        
        return "\n".join(result)
