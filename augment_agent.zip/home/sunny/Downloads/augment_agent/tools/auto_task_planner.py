"""Auto Task Planner as specified in plan.md - Splits big asks into sub-steps and executes them."""

import json
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path

from .base import TaskManagementTool
from ..utils.logging import configure_tool_logging


class AutoTaskPlannerTool(TaskManagementTool):
    """Intelligent task planner that breaks down complex requests into manageable sub-tasks."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("auto-task-planner")
    
    @property
    def name(self) -> str:
        return "auto-task-planner"
    
    @property
    def description(self) -> str:
        return "Automatically break down complex requests into detailed sub-tasks with execution planning."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "user_request": {
                    "type": "string",
                    "description": "The complex user request to break down into tasks"
                },
                "project_context": {
                    "type": "object",
                    "description": "Current project context and constraints",
                    "properties": {
                        "project_type": {"type": "string"},
                        "technologies": {"type": "array", "items": {"type": "string"}},
                        "existing_files": {"type": "array", "items": {"type": "string"}},
                        "constraints": {"type": "array", "items": {"type": "string"}}
                    }
                },
                "complexity_level": {
                    "type": "integer",
                    "description": "Complexity level (1-10) for planning granularity",
                    "minimum": 1,
                    "maximum": 10,
                    "default": 5
                },
                "time_estimate": {
                    "type": "string",
                    "description": "Estimated time for completion (e.g., '2 hours', '1 day')"
                },
                "auto_execute": {
                    "type": "boolean",
                    "description": "Whether to automatically start executing tasks",
                    "default": false
                }
            },
            "required": ["user_request"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute auto task planning."""
        self._ensure_initialized()
        
        user_request = kwargs["user_request"]
        project_context = kwargs.get("project_context", {})
        complexity_level = kwargs.get("complexity_level", 5)
        time_estimate = kwargs.get("time_estimate")
        auto_execute = kwargs.get("auto_execute", False)
        
        self.tool_logger.log_execution_start("auto_task_planner", 
                                           request=user_request[:100],
                                           complexity=complexity_level)
        
        try:
            # Analyze the request
            analysis = await self._analyze_request(user_request, project_context, complexity_level)
            
            # Generate task breakdown
            task_plan = await self._generate_task_plan(analysis, time_estimate)
            
            # Create tasks in the task management system
            created_tasks = await self._create_planned_tasks(task_plan)
            
            # Start execution if requested
            execution_status = None
            if auto_execute:
                execution_status = await self._start_execution(created_tasks)
            
            # Format results
            formatted_results = self._format_planning_results(
                task_plan, created_tasks, execution_status, user_request
            )
            
            self.tool_logger.log_execution_success("auto_task_planner", 
                                                 f"Created {len(created_tasks)} tasks")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("auto_task_planner", e)
            raise
    
    async def _analyze_request(self, request: str, context: Dict[str, Any], 
                              complexity: int) -> Dict[str, Any]:
        """Analyze the user request to understand requirements."""
        analysis = {
            'original_request': request,
            'complexity_score': complexity,
            'estimated_tasks': max(2, complexity),
            'project_type': context.get('project_type', 'unknown'),
            'technologies': context.get('technologies', []),
            'requirements': [],
            'dependencies': [],
            'deliverables': [],
            'risks': [],
            'success_criteria': []
        }
        
        # Extract requirements using keyword analysis
        request_lower = request.lower()
        
        # Identify project type if not provided
        if analysis['project_type'] == 'unknown':
            if any(word in request_lower for word in ['web', 'website', 'frontend', 'react', 'vue', 'angular']):
                analysis['project_type'] = 'web_frontend'
            elif any(word in request_lower for word in ['api', 'backend', 'server', 'database']):
                analysis['project_type'] = 'backend'
            elif any(word in request_lower for word in ['app', 'mobile', 'android', 'ios']):
                analysis['project_type'] = 'mobile'
            elif any(word in request_lower for word in ['script', 'automation', 'tool']):
                analysis['project_type'] = 'script'
        
        # Extract technologies mentioned
        tech_keywords = {
            'python': ['python', 'django', 'flask', 'fastapi'],
            'javascript': ['javascript', 'js', 'node', 'npm', 'yarn'],
            'react': ['react', 'jsx', 'next.js', 'nextjs'],
            'vue': ['vue', 'vuejs', 'nuxt'],
            'angular': ['angular', 'ng'],
            'database': ['database', 'db', 'sql', 'mongodb', 'postgres', 'mysql'],
            'docker': ['docker', 'container', 'containerize'],
            'aws': ['aws', 'amazon', 'ec2', 's3', 'lambda'],
            'git': ['git', 'github', 'gitlab', 'version control']
        }
        
        for tech, keywords in tech_keywords.items():
            if any(keyword in request_lower for keyword in keywords):
                if tech not in analysis['technologies']:
                    analysis['technologies'].append(tech)
        
        # Extract action verbs to understand requirements
        action_patterns = [
            ('create', ['create', 'build', 'develop', 'make', 'generate']),
            ('implement', ['implement', 'add', 'integrate', 'include']),
            ('fix', ['fix', 'repair', 'resolve', 'debug']),
            ('optimize', ['optimize', 'improve', 'enhance', 'refactor']),
            ('test', ['test', 'validate', 'verify', 'check']),
            ('deploy', ['deploy', 'publish', 'release', 'launch']),
            ('setup', ['setup', 'configure', 'install', 'initialize'])
        ]
        
        for action, keywords in action_patterns:
            if any(keyword in request_lower for keyword in keywords):
                analysis['requirements'].append(action)
        
        # Estimate deliverables
        if 'create' in analysis['requirements']:
            analysis['deliverables'].append('New code/files')
        if 'test' in analysis['requirements']:
            analysis['deliverables'].append('Test suite')
        if 'deploy' in analysis['requirements']:
            analysis['deliverables'].append('Deployed application')
        if 'setup' in analysis['requirements']:
            analysis['deliverables'].append('Configured environment')
        
        # Identify potential risks
        if complexity >= 7:
            analysis['risks'].append('High complexity may require multiple iterations')
        if len(analysis['technologies']) > 3:
            analysis['risks'].append('Multiple technologies increase integration complexity')
        if 'deploy' in analysis['requirements']:
            analysis['risks'].append('Deployment may require external services')
        
        return analysis
    
    async def _generate_task_plan(self, analysis: Dict[str, Any], 
                                 time_estimate: Optional[str]) -> Dict[str, Any]:
        """Generate a detailed task plan based on the analysis."""
        plan = {
            'plan_id': str(uuid.uuid4()),
            'created_at': datetime.now().isoformat(),
            'analysis': analysis,
            'estimated_duration': time_estimate,
            'phases': [],
            'total_tasks': 0,
            'dependencies': {}
        }
        
        # Generate phases based on project type and requirements
        if analysis['project_type'] == 'web_frontend':
            plan['phases'] = self._generate_frontend_phases(analysis)
        elif analysis['project_type'] == 'backend':
            plan['phases'] = self._generate_backend_phases(analysis)
        elif analysis['project_type'] == 'mobile':
            plan['phases'] = self._generate_mobile_phases(analysis)
        else:
            plan['phases'] = self._generate_generic_phases(analysis)
        
        # Calculate total tasks and dependencies
        task_counter = 0
        for phase in plan['phases']:
            for task in phase['tasks']:
                task_counter += 1
                task['task_id'] = f"task_{task_counter:03d}"
                task['phase'] = phase['name']
        
        plan['total_tasks'] = task_counter
        
        return plan
    
    def _generate_frontend_phases(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate phases for frontend projects."""
        phases = [
            {
                'name': 'Setup & Planning',
                'description': 'Initialize project and setup development environment',
                'tasks': [
                    {
                        'name': 'Project Initialization',
                        'description': 'Create project structure and install dependencies',
                        'estimated_time': '30 minutes',
                        'priority': 'high',
                        'tools_needed': ['npm', 'create-react-app', 'vue-cli'],
                        'deliverables': ['Project structure', 'Package.json', 'Initial files']
                    },
                    {
                        'name': 'Development Environment Setup',
                        'description': 'Configure development tools and environment',
                        'estimated_time': '20 minutes',
                        'priority': 'high',
                        'tools_needed': ['eslint', 'prettier', 'vscode'],
                        'deliverables': ['Configured linting', 'Code formatting rules']
                    }
                ]
            },
            {
                'name': 'Core Development',
                'description': 'Implement main application features',
                'tasks': [
                    {
                        'name': 'Component Development',
                        'description': 'Create main UI components',
                        'estimated_time': '2 hours',
                        'priority': 'high',
                        'tools_needed': ['react', 'vue', 'angular'],
                        'deliverables': ['UI components', 'Component tests']
                    },
                    {
                        'name': 'State Management',
                        'description': 'Implement application state management',
                        'estimated_time': '1 hour',
                        'priority': 'medium',
                        'tools_needed': ['redux', 'vuex', 'ngrx'],
                        'deliverables': ['State management setup', 'Actions and reducers']
                    }
                ]
            }
        ]
        
        # Add testing phase if complexity is high
        if analysis['complexity_score'] >= 6:
            phases.append({
                'name': 'Testing & Quality Assurance',
                'description': 'Implement comprehensive testing',
                'tasks': [
                    {
                        'name': 'Unit Testing',
                        'description': 'Write unit tests for components',
                        'estimated_time': '1 hour',
                        'priority': 'medium',
                        'tools_needed': ['jest', 'testing-library'],
                        'deliverables': ['Unit test suite', 'Test coverage report']
                    }
                ]
            })
        
        return phases
    
    def _generate_backend_phases(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate phases for backend projects."""
        return [
            {
                'name': 'API Design & Setup',
                'description': 'Design API structure and setup backend framework',
                'tasks': [
                    {
                        'name': 'API Design',
                        'description': 'Design REST API endpoints and data models',
                        'estimated_time': '45 minutes',
                        'priority': 'high',
                        'deliverables': ['API specification', 'Data models']
                    },
                    {
                        'name': 'Framework Setup',
                        'description': 'Initialize backend framework and dependencies',
                        'estimated_time': '30 minutes',
                        'priority': 'high',
                        'deliverables': ['Project structure', 'Dependencies installed']
                    }
                ]
            },
            {
                'name': 'Database & Models',
                'description': 'Setup database and implement data models',
                'tasks': [
                    {
                        'name': 'Database Setup',
                        'description': 'Configure database connection and schema',
                        'estimated_time': '40 minutes',
                        'priority': 'high',
                        'deliverables': ['Database schema', 'Connection setup']
                    }
                ]
            }
        ]
    
    def _generate_mobile_phases(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate phases for mobile projects."""
        return [
            {
                'name': 'Mobile App Setup',
                'description': 'Initialize mobile development environment',
                'tasks': [
                    {
                        'name': 'Project Initialization',
                        'description': 'Create mobile app project structure',
                        'estimated_time': '45 minutes',
                        'priority': 'high',
                        'deliverables': ['App project', 'Basic navigation']
                    }
                ]
            }
        ]
    
    def _generate_generic_phases(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate generic phases for unknown project types."""
        return [
            {
                'name': 'Analysis & Planning',
                'description': 'Analyze requirements and plan implementation',
                'tasks': [
                    {
                        'name': 'Requirement Analysis',
                        'description': 'Break down and analyze user requirements',
                        'estimated_time': '30 minutes',
                        'priority': 'high',
                        'deliverables': ['Requirements document', 'Implementation plan']
                    }
                ]
            },
            {
                'name': 'Implementation',
                'description': 'Implement the requested functionality',
                'tasks': [
                    {
                        'name': 'Core Implementation',
                        'description': 'Implement main functionality',
                        'estimated_time': '1-2 hours',
                        'priority': 'high',
                        'deliverables': ['Working implementation', 'Documentation']
                    }
                ]
            }
        ]
    
    async def _create_planned_tasks(self, plan: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create tasks in the task management system."""
        created_tasks = []
        
        # Create a root task for the plan
        root_task_data = {
            "name": f"Auto-planned: {plan['analysis']['original_request'][:50]}...",
            "description": f"Auto-generated task plan with {plan['total_tasks']} sub-tasks",
            "state": "NOT_STARTED"
        }
        
        # Use the add_tasks tool to create the root task
        try:
            from .task_management import AddTasksTool
            add_tasks_tool = AddTasksTool(self.config)
            await add_tasks_tool.initialize()
        except ImportError:
            # Fallback if task management tools not available
            return [{'task_id': 'mock_task', 'name': 'Mock Task', 'phase': 'Mock', 'result': 'Created'}]
        
        root_result = await add_tasks_tool.execute(tasks=[root_task_data])
        
        # Extract root task ID (simplified - in practice you'd parse the result)
        root_task_id = "auto_plan_root"  # This would be extracted from the result
        
        # Create phase and task hierarchy
        for phase in plan['phases']:
            # Create phase task
            phase_task_data = {
                "name": f"Phase: {phase['name']}",
                "description": phase['description'],
                "parent_task_id": root_task_id,
                "state": "NOT_STARTED"
            }
            
            phase_result = await add_tasks_tool.execute(tasks=[phase_task_data])
            phase_task_id = f"phase_{phase['name'].lower().replace(' ', '_')}"
            
            # Create individual tasks
            for task in phase['tasks']:
                task_data = {
                    "name": task['name'],
                    "description": f"{task['description']}\n\nEstimated time: {task.get('estimated_time', 'Unknown')}\nPriority: {task.get('priority', 'medium')}\nDeliverables: {', '.join(task.get('deliverables', []))}",
                    "parent_task_id": phase_task_id,
                    "state": "NOT_STARTED"
                }
                
                task_result = await add_tasks_tool.execute(tasks=[task_data])
                created_tasks.append({
                    'task_id': task['task_id'],
                    'name': task['name'],
                    'phase': phase['name'],
                    'result': task_result
                })
        
        return created_tasks
    
    async def _start_execution(self, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Start automatic execution of planned tasks."""
        # This would integrate with the actual execution engine
        # For now, just return status
        return {
            'execution_started': True,
            'first_task': tasks[0] if tasks else None,
            'status': 'Starting execution of first task...'
        }
    
    def _format_planning_results(self, plan: Dict[str, Any], created_tasks: List[Dict[str, Any]],
                                execution_status: Optional[Dict[str, Any]], 
                                original_request: str) -> str:
        """Format the planning results for display."""
        formatted = [f"# Auto Task Planning Results\n"]
        formatted.append(f"**Original Request:** {original_request}")
        formatted.append(f"**Plan ID:** {plan['plan_id']}")
        formatted.append(f"**Total Tasks Created:** {len(created_tasks)}")
        formatted.append(f"**Project Type:** {plan['analysis']['project_type']}")
        formatted.append(f"**Technologies:** {', '.join(plan['analysis']['technologies'])}")
        
        if plan['estimated_duration']:
            formatted.append(f"**Estimated Duration:** {plan['estimated_duration']}")
        
        formatted.append("\n## 📋 Task Breakdown by Phase\n")
        
        for phase in plan['phases']:
            formatted.append(f"### {phase['name']}")
            formatted.append(f"*{phase['description']}*\n")
            
            for task in phase['tasks']:
                formatted.append(f"- **{task['name']}**")
                formatted.append(f"  - {task['description']}")
                formatted.append(f"  - Time: {task.get('estimated_time', 'TBD')}")
                formatted.append(f"  - Priority: {task.get('priority', 'medium')}")
                if task.get('deliverables'):
                    formatted.append(f"  - Deliverables: {', '.join(task['deliverables'])}")
                formatted.append("")
        
        if plan['analysis']['risks']:
            formatted.append("## ⚠️ Identified Risks\n")
            for risk in plan['analysis']['risks']:
                formatted.append(f"- {risk}")
            formatted.append("")
        
        if execution_status:
            formatted.append("## 🚀 Execution Status\n")
            formatted.append(f"**Status:** {execution_status['status']}")
            if execution_status.get('first_task'):
                formatted.append(f"**Current Task:** {execution_status['first_task']['name']}")
        else:
            formatted.append("## 📝 Next Steps\n")
            formatted.append("Tasks have been created and added to your task list. Use the task management tools to:")
            formatted.append("- View task details with `view_tasklist`")
            formatted.append("- Update task status with `update_tasks`")
            formatted.append("- Start working on the first task")
        
        return "\n".join(formatted)
