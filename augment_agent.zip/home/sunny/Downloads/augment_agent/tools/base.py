"""Base tool class for Augment Agent tools."""

import asyncio
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from pydantic import BaseModel, ValidationError

from ..core.config import Config
from ..utils.logging import get_logger


logger = get_logger(__name__)


class BaseTool(ABC):
    """Base class for all Augment Agent tools."""
    
    def __init__(self, config: Config):
        """Initialize the tool with configuration."""
        self.config = config
        self.initialized = False
        self._logger = get_logger(f"{__name__}.{self.__class__.__name__}")
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Return the tool name."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Return the tool description."""
        pass
    
    @abstractmethod
    def get_schema(self) -> Dict[str, Any]:
        """Return the tool's JSON schema for parameters."""
        pass
    
    @abstractmethod
    async def execute(self, **kwargs) -> Any:
        """Execute the tool with the given parameters."""
        pass
    
    async def initialize(self) -> None:
        """Initialize the tool. Override if needed."""
        self.initialized = True
        self._logger.debug(f"Tool {self.name} initialized")
    
    async def shutdown(self) -> None:
        """Shutdown the tool and cleanup resources. Override if needed."""
        self.initialized = False
        self._logger.debug(f"Tool {self.name} shutdown")
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Validate parameters against the tool's schema."""
        schema = self.get_schema()
        
        # Basic validation - check required parameters
        required_params = schema.get("required", [])
        for param in required_params:
            if param not in parameters:
                raise ValueError(f"Required parameter '{param}' is missing")
        
        # Type validation for known parameters
        properties = schema.get("properties", {})
        validated_params = {}
        
        for param_name, param_value in parameters.items():
            if param_name in properties:
                param_schema = properties[param_name]
                param_type = param_schema.get("type")
                
                # Basic type validation
                if param_type == "string" and not isinstance(param_value, str):
                    try:
                        param_value = str(param_value)
                    except Exception:
                        raise ValueError(f"Parameter '{param_name}' must be a string")
                elif param_type == "integer" and not isinstance(param_value, int):
                    try:
                        param_value = int(param_value)
                    except Exception:
                        raise ValueError(f"Parameter '{param_name}' must be an integer")
                elif param_type == "number" and not isinstance(param_value, (int, float)):
                    try:
                        param_value = float(param_value)
                    except Exception:
                        raise ValueError(f"Parameter '{param_name}' must be a number")
                elif param_type == "boolean" and not isinstance(param_value, bool):
                    if isinstance(param_value, str):
                        param_value = param_value.lower() in ["true", "1", "yes", "on"]
                    else:
                        param_value = bool(param_value)
                elif param_type == "array" and not isinstance(param_value, list):
                    raise ValueError(f"Parameter '{param_name}' must be an array")
                elif param_type == "object" and not isinstance(param_value, dict):
                    raise ValueError(f"Parameter '{param_name}' must be an object")
            
            validated_params[param_name] = param_value
        
        return validated_params
    
    def _ensure_initialized(self) -> None:
        """Ensure the tool is initialized before use."""
        if not self.initialized:
            raise RuntimeError(f"Tool {self.name} is not initialized")
    
    def _log_execution(self, operation: str, **kwargs) -> None:
        """Log tool execution for debugging."""
        self._logger.debug(f"Executing {operation} with parameters: {kwargs}")
    
    def _handle_error(self, error: Exception, operation: str) -> None:
        """Handle and log errors consistently."""
        self._logger.error(f"Error in {operation}: {error}")
        raise error


class FileOperationTool(BaseTool):
    """Base class for file operation tools."""
    
    def _get_absolute_path(self, path: str) -> str:
        """Convert relative path to absolute path within workspace."""
        try:
            abs_path = self.config.get_workspace_path(path)
            return str(abs_path)
        except Exception as e:
            raise ValueError(f"Invalid path '{path}': {e}")
    
    def _validate_file_size(self, file_path: str) -> None:
        """Validate file size against configuration limits."""
        try:
            from pathlib import Path
            file_size = Path(file_path).stat().st_size
            max_size = self.config.max_file_size_mb * 1024 * 1024
            
            if file_size > max_size:
                raise ValueError(
                    f"File size ({file_size / 1024 / 1024:.1f}MB) exceeds "
                    f"maximum allowed size ({self.config.max_file_size_mb}MB)"
                )
        except FileNotFoundError:
            # File doesn't exist yet, which is fine for some operations
            pass


class ProcessTool(BaseTool):
    """Base class for process management tools."""
    
    def __init__(self, config: Config):
        super().__init__(config)
        self.active_processes: Dict[int, Any] = {}
        self.process_counter = 0
    
    def _get_next_process_id(self) -> int:
        """Get the next available process ID."""
        self.process_counter += 1
        return self.process_counter
    
    def _validate_process_limits(self) -> None:
        """Validate that we haven't exceeded process limits."""
        if len(self.active_processes) >= self.config.max_concurrent_processes:
            raise RuntimeError(
                f"Maximum number of concurrent processes "
                f"({self.config.max_concurrent_processes}) reached"
            )


class WebTool(BaseTool):
    """Base class for web-related tools."""
    
    def _validate_web_enabled(self) -> None:
        """Validate that web features are enabled."""
        if not self.config.enable_web_search:
            raise RuntimeError("Web features are disabled in configuration")
    
    def _get_user_agent(self) -> str:
        """Get user agent string for web requests."""
        return "Augment-Agent/1.0.0 (https://github.com/augment-code/augment-agent-clone)"


class CodeAnalysisTool(BaseTool):
    """Base class for code analysis tools."""
    
    def _validate_code_analysis_enabled(self) -> None:
        """Validate that code analysis features are enabled."""
        if not self.config.enable_code_analysis:
            raise RuntimeError("Code analysis features are disabled in configuration")
