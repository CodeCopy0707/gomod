"""Process management tools for Augment Agent."""

import asyncio
import subprocess
import signal
import os
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
import psutil

from .base import ProcessTool
from ..utils.logging import configure_tool_logging


class ProcessInfo:
    """Information about a managed process."""
    
    def __init__(self, terminal_id: int, command: str, cwd: str, wait: bool):
        self.terminal_id = terminal_id
        self.command = command
        self.cwd = cwd
        self.wait = wait
        self.process: Optional[subprocess.Popen] = None
        self.start_time = datetime.now()
        self.output_buffer = []
        self.completed = False
        self.return_code: Optional[int] = None


class LaunchProcessTool(ProcessTool):
    """Tool for launching processes with shell commands."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("launch-process")
    
    @property
    def name(self) -> str:
        return "launch-process"
    
    @property
    def description(self) -> str:
        return "Launch a new process with a shell command. Supports both waiting and non-waiting modes."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute."
                },
                "cwd": {
                    "type": "string",
                    "description": "Absolute path to the working directory for the command."
                },
                "wait": {
                    "type": "boolean",
                    "description": "Whether to wait for the command to complete."
                },
                "max_wait_seconds": {
                    "type": "number",
                    "description": "Number of seconds to wait for the command to complete (only relevant when wait=true)."
                }
            },
            "required": ["command", "wait", "max_wait_seconds", "cwd"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute process launch."""
        self._ensure_initialized()
        
        command = kwargs["command"]
        cwd = kwargs["cwd"]
        wait = kwargs["wait"]
        max_wait_seconds = kwargs["max_wait_seconds"]
        
        self.tool_logger.log_execution_start("launch_process", command=command[:50], wait=wait)
        
        try:
            # Validate process limits
            self._validate_process_limits()
            
            # Get next process ID
            terminal_id = self._get_next_process_id()
            
            # Create process info
            process_info = ProcessInfo(terminal_id, command, cwd, wait)
            
            # Launch the process
            if wait:
                result = await self._launch_waiting_process(process_info, max_wait_seconds)
            else:
                result = await self._launch_background_process(process_info)
            
            # Store process info
            self.active_processes[terminal_id] = process_info
            
            self.tool_logger.log_execution_success("launch_process", f"Terminal ID: {terminal_id}")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("launch_process", e)
            raise
    
    async def _launch_waiting_process(self, process_info: ProcessInfo, max_wait_seconds: float) -> str:
        """Launch a process and wait for completion."""
        try:
            # Start the process
            process = subprocess.Popen(
                process_info.command,
                shell=True,
                cwd=process_info.cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            process_info.process = process
            
            # Wait for completion with timeout
            try:
                stdout, _ = process.communicate(timeout=max_wait_seconds)
                process_info.output_buffer.append(stdout)
                process_info.completed = True
                process_info.return_code = process.returncode
                
                result = f"Process completed (Terminal ID: {process_info.terminal_id})\n"
                result += f"Return code: {process.returncode}\n"
                result += f"Output:\n{stdout}"
                
                return result
                
            except subprocess.TimeoutExpired:
                # Process is still running after timeout
                result = f"Process started (Terminal ID: {process_info.terminal_id})\n"
                result += f"Command: {process_info.command}\n"
                result += f"Status: Running (timeout after {max_wait_seconds}s)\n"
                result += "Use read-process to check output or kill-process to terminate."
                
                return result
                
        except Exception as e:
            raise RuntimeError(f"Failed to launch process: {e}")
    
    async def _launch_background_process(self, process_info: ProcessInfo) -> str:
        """Launch a background process."""
        try:
            # Start the process
            process = subprocess.Popen(
                process_info.command,
                shell=True,
                cwd=process_info.cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            process_info.process = process
            
            result = f"Background process started (Terminal ID: {process_info.terminal_id})\n"
            result += f"Command: {process_info.command}\n"
            result += f"PID: {process.pid}\n"
            result += "Use read-process, write-process, or kill-process to interact with this process."
            
            return result
            
        except Exception as e:
            raise RuntimeError(f"Failed to launch background process: {e}")


class ReadProcessTool(ProcessTool):
    """Tool for reading output from a process."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("read-process")
    
    @property
    def name(self) -> str:
        return "read-process"
    
    @property
    def description(self) -> str:
        return "Read output from a terminal/process."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "terminal_id": {
                    "type": "integer",
                    "description": "Terminal ID to read from."
                },
                "wait": {
                    "type": "boolean",
                    "description": "Whether to wait for the command to complete."
                },
                "max_wait_seconds": {
                    "type": "number",
                    "description": "Number of seconds to wait for the command to complete (only relevant when wait=true)."
                }
            },
            "required": ["terminal_id", "wait", "max_wait_seconds"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute process reading."""
        self._ensure_initialized()
        
        terminal_id = kwargs["terminal_id"]
        wait = kwargs["wait"]
        max_wait_seconds = kwargs["max_wait_seconds"]
        
        self.tool_logger.log_execution_start("read_process", terminal_id=terminal_id, wait=wait)
        
        try:
            if terminal_id not in self.active_processes:
                raise ValueError(f"Terminal ID {terminal_id} not found")
            
            process_info = self.active_processes[terminal_id]
            
            if not process_info.process:
                raise ValueError(f"No active process for terminal ID {terminal_id}")
            
            if wait and not process_info.completed:
                # Wait for process completion
                try:
                    stdout, _ = process_info.process.communicate(timeout=max_wait_seconds)
                    process_info.output_buffer.append(stdout)
                    process_info.completed = True
                    process_info.return_code = process_info.process.returncode
                except subprocess.TimeoutExpired:
                    # Read available output without waiting
                    pass
            
            # Read available output
            output = self._read_available_output(process_info)
            
            result = f"Output from Terminal ID {terminal_id}:\n"
            result += f"Status: {'Completed' if process_info.completed else 'Running'}\n"
            if process_info.completed and process_info.return_code is not None:
                result += f"Return code: {process_info.return_code}\n"
            result += f"Output:\n{output}"
            
            self.tool_logger.log_execution_success("read_process", f"Read {len(output)} characters")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("read_process", e)
            raise
    
    def _read_available_output(self, process_info: ProcessInfo) -> str:
        """Read available output from process."""
        if process_info.completed:
            return "".join(process_info.output_buffer)
        
        # For running processes, try to read available output
        if process_info.process and process_info.process.stdout:
            try:
                # Non-blocking read
                import select
                import sys
                
                if sys.platform != "win32":
                    # Unix-like systems
                    ready, _, _ = select.select([process_info.process.stdout], [], [], 0)
                    if ready:
                        output = process_info.process.stdout.read()
                        if output:
                            process_info.output_buffer.append(output)
                else:
                    # Windows - more limited non-blocking read
                    # This is a simplified approach
                    pass
                    
            except Exception:
                # If non-blocking read fails, return buffered output
                pass
        
        return "".join(process_info.output_buffer)


class WriteProcessTool(ProcessTool):
    """Tool for writing input to a process."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("write-process")

    @property
    def name(self) -> str:
        return "write-process"

    @property
    def description(self) -> str:
        return "Write input to a terminal/process."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "terminal_id": {
                    "type": "integer",
                    "description": "Terminal ID to write to."
                },
                "input_text": {
                    "type": "string",
                    "description": "Text to write to the process's stdin."
                }
            },
            "required": ["terminal_id", "input_text"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute process writing."""
        self._ensure_initialized()

        terminal_id = kwargs["terminal_id"]
        input_text = kwargs["input_text"]

        self.tool_logger.log_execution_start("write_process", terminal_id=terminal_id)

        try:
            if terminal_id not in self.active_processes:
                raise ValueError(f"Terminal ID {terminal_id} not found")

            process_info = self.active_processes[terminal_id]

            if not process_info.process:
                raise ValueError(f"No active process for terminal ID {terminal_id}")

            if process_info.completed:
                raise ValueError(f"Process {terminal_id} has already completed")

            # Write to process stdin
            if process_info.process.stdin:
                process_info.process.stdin.write(input_text)
                process_info.process.stdin.flush()

                result = f"Successfully wrote {len(input_text)} characters to Terminal ID {terminal_id}"
                self.tool_logger.log_execution_success("write_process", result)
                return result
            else:
                raise ValueError(f"Process {terminal_id} does not accept input")

        except Exception as e:
            self.tool_logger.log_execution_error("write_process", e)
            raise


class KillProcessTool(ProcessTool):
    """Tool for killing a process."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("kill-process")

    @property
    def name(self) -> str:
        return "kill-process"

    @property
    def description(self) -> str:
        return "Kill a process by its terminal ID."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "terminal_id": {
                    "type": "integer",
                    "description": "Terminal ID to kill."
                }
            },
            "required": ["terminal_id"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute process killing."""
        self._ensure_initialized()

        terminal_id = kwargs["terminal_id"]

        self.tool_logger.log_execution_start("kill_process", terminal_id=terminal_id)

        try:
            if terminal_id not in self.active_processes:
                raise ValueError(f"Terminal ID {terminal_id} not found")

            process_info = self.active_processes[terminal_id]

            if not process_info.process:
                raise ValueError(f"No active process for terminal ID {terminal_id}")

            if process_info.completed:
                result = f"Process {terminal_id} was already completed"
                self.tool_logger.log_info(result)
                return result

            # Kill the process
            try:
                process_info.process.terminate()

                # Wait a bit for graceful termination
                try:
                    process_info.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    # Force kill if it doesn't terminate gracefully
                    process_info.process.kill()
                    process_info.process.wait()

                process_info.completed = True
                process_info.return_code = process_info.process.returncode

                result = f"Successfully killed process {terminal_id}"
                self.tool_logger.log_execution_success("kill_process", result)
                return result

            except Exception as e:
                raise RuntimeError(f"Failed to kill process {terminal_id}: {e}")

        except Exception as e:
            self.tool_logger.log_execution_error("kill_process", e)
            raise


class ListProcessesTool(ProcessTool):
    """Tool for listing all known processes."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("list-processes")

    @property
    def name(self) -> str:
        return "list-processes"

    @property
    def description(self) -> str:
        return "List all known terminals/processes created with the launch-process tool and their states."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {},
            "required": []
        }

    async def execute(self, **kwargs) -> str:
        """Execute process listing."""
        self._ensure_initialized()

        self.tool_logger.log_execution_start("list_processes")

        try:
            if not self.active_processes:
                return "No active processes."

            result_lines = ["Active Processes:"]

            for terminal_id, process_info in self.active_processes.items():
                status = "Completed" if process_info.completed else "Running"

                # Check if process is actually still running
                if not process_info.completed and process_info.process:
                    poll_result = process_info.process.poll()
                    if poll_result is not None:
                        process_info.completed = True
                        process_info.return_code = poll_result
                        status = "Completed"

                runtime = datetime.now() - process_info.start_time
                runtime_str = str(runtime).split('.')[0]  # Remove microseconds

                result_lines.append(f"  Terminal ID {terminal_id}:")
                result_lines.append(f"    Command: {process_info.command}")
                result_lines.append(f"    Status: {status}")
                result_lines.append(f"    Runtime: {runtime_str}")
                result_lines.append(f"    Working Directory: {process_info.cwd}")

                if process_info.completed and process_info.return_code is not None:
                    result_lines.append(f"    Return Code: {process_info.return_code}")

                if process_info.process:
                    result_lines.append(f"    PID: {process_info.process.pid}")

                result_lines.append("")

            result = "\n".join(result_lines)

            self.tool_logger.log_execution_success("list_processes", f"Listed {len(self.active_processes)} processes")
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("list_processes", e)
            raise


class ReadTerminalTool(ProcessTool):
    """Tool for reading from the active terminal."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("read-terminal")

    @property
    def name(self) -> str:
        return "read-terminal"

    @property
    def description(self) -> str:
        return "Read output from the active or most-recently used terminal."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "only_selected": {
                    "type": "boolean",
                    "description": "Whether to read only the selected text in the terminal.",
                    "default": False
                }
            },
            "required": []
        }

    async def execute(self, **kwargs) -> str:
        """Execute terminal reading."""
        self._ensure_initialized()

        only_selected = kwargs.get("only_selected", False)

        self.tool_logger.log_execution_start("read_terminal", only_selected=only_selected)

        try:
            # This is a simplified implementation
            # In a real terminal integration, you'd read from the actual terminal

            if only_selected:
                # Simulate reading selected text
                result = "Terminal selection reading not implemented in this standalone version."
            else:
                # Find the most recent process
                if not self.active_processes:
                    return "No active terminal processes."

                # Get the most recent process
                latest_process = max(
                    self.active_processes.values(),
                    key=lambda p: p.start_time
                )

                # Read its output
                output = "".join(latest_process.output_buffer)

                result = f"Terminal output from most recent process (Terminal ID {latest_process.terminal_id}):\n"
                result += f"Command: {latest_process.command}\n"
                result += f"Output:\n{output}"

            self.tool_logger.log_execution_success("read_terminal", "Read terminal content")
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("read_terminal", e)
            raise
