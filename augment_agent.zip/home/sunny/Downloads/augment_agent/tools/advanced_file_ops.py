"""Advanced file operation tools for Augment Agent."""

import os
import re
import subprocess
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Iterator
import fnmatch
import mimetypes

from .base import FileOperationTool
from ..utils.logging import configure_tool_logging


class UltraSmartGrepTool(FileOperationTool):
    """Ultra-smart grep tool as specified in plan.md - Grep++ with advanced features."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("ultra-smart-grep")

    @property
    def name(self) -> str:
        return "ultra-smart-grep"

    @property
    def description(self) -> str:
        return "Ultra-smart grep with AI-powered search, semantic understanding, and advanced filtering."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Search pattern (can be regex if regex=true)"
                },
                "path": {
                    "type": "string",
                    "description": "Path to search in (file or directory)",
                    "default": "."
                },
                "regex": {
                    "type": "boolean",
                    "description": "Whether pattern is a regular expression",
                    "default": False
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Whether search is case sensitive",
                    "default": False
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Number of context lines to show around matches",
                    "default": 3
                },
                "file_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File extensions to include (e.g., ['.py', '.js'])"
                },
                "exclude_dirs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Directory names to exclude",
                    "default": [".git", "__pycache__", "node_modules", ".venv"]
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return",
                    "default": 100
                }
            },
            "required": ["pattern"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute smart grep search."""
        self._ensure_initialized()
        
        pattern = kwargs["pattern"]
        search_path = kwargs.get("path", ".")
        use_regex = kwargs.get("regex", False)
        case_sensitive = kwargs.get("case_sensitive", False)
        context_lines = kwargs.get("context_lines", 3)
        file_types = kwargs.get("file_types", [])
        exclude_dirs = kwargs.get("exclude_dirs", [".git", "__pycache__", "node_modules", ".venv"])
        max_results = kwargs.get("max_results", 100)
        
        self.tool_logger.log_execution_start("smart_grep", pattern=pattern[:50], path=search_path)
        
        try:
            abs_path = self._get_absolute_path(search_path)
            
            # Perform the search
            results = await self._smart_search(
                pattern, abs_path, use_regex, case_sensitive, 
                context_lines, file_types, exclude_dirs, max_results
            )
            
            # Format results
            formatted_results = self._format_search_results(results, pattern)
            
            self.tool_logger.log_execution_success("smart_grep", f"Found {len(results)} matches")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("smart_grep", e)
            raise
    
    async def _smart_search(self, pattern: str, search_path: str, use_regex: bool,
                           case_sensitive: bool, context_lines: int, file_types: List[str],
                           exclude_dirs: List[str], max_results: int) -> List[Dict[str, Any]]:
        """Perform smart search with advanced filtering."""
        results = []
        
        # Compile regex pattern
        flags = 0 if case_sensitive else re.IGNORECASE
        if use_regex:
            try:
                regex_pattern = re.compile(pattern, flags)
            except re.error as e:
                raise ValueError(f"Invalid regex pattern: {e}")
        else:
            # Escape special regex characters for literal search
            escaped_pattern = re.escape(pattern)
            regex_pattern = re.compile(escaped_pattern, flags)
        
        # Find files to search
        files_to_search = self._find_files_to_search(search_path, file_types, exclude_dirs)
        
        # Search in each file
        for file_path in files_to_search:
            if len(results) >= max_results:
                break
                
            try:
                file_results = await self._search_in_file(
                    file_path, regex_pattern, context_lines
                )
                results.extend(file_results)
            except Exception as e:
                self.tool_logger.log_warning(f"Failed to search in {file_path}: {e}")
        
        return results[:max_results]
    
    def _find_files_to_search(self, search_path: str, file_types: List[str], 
                             exclude_dirs: List[str]) -> List[str]:
        """Find files to search based on criteria."""
        files = []
        search_path = Path(search_path)
        
        if search_path.is_file():
            return [str(search_path)]
        
        for root, dirs, filenames in os.walk(search_path):
            # Remove excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for filename in filenames:
                file_path = Path(root) / filename
                
                # Check file type filter
                if file_types:
                    if not any(filename.endswith(ext) for ext in file_types):
                        continue
                
                # Skip binary files
                if self._is_binary_file(file_path):
                    continue
                
                files.append(str(file_path))
        
        return files
    
    def _is_binary_file(self, file_path: Path) -> bool:
        """Check if file is binary."""
        try:
            mime_type, _ = mimetypes.guess_type(str(file_path))
            if mime_type and mime_type.startswith('text/'):
                return False
            
            # Check first few bytes
            with open(file_path, 'rb') as f:
                chunk = f.read(1024)
                return b'\0' in chunk
        except Exception:
            return True
    
    async def _search_in_file(self, file_path: str, pattern: re.Pattern, 
                             context_lines: int) -> List[Dict[str, Any]]:
        """Search for pattern in a single file."""
        results = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
        except Exception:
            return results
        
        # Find matches
        for line_num, line in enumerate(lines, 1):
            if pattern.search(line):
                # Get context
                start_line = max(0, line_num - context_lines - 1)
                end_line = min(len(lines), line_num + context_lines)
                
                context = []
                for i in range(start_line, end_line):
                    marker = ">>> " if i == line_num - 1 else "    "
                    context.append(f"{marker}{i+1:4d}: {lines[i].rstrip()}")
                
                results.append({
                    'file': file_path,
                    'line_number': line_num,
                    'line_content': line.rstrip(),
                    'context': context,
                    'match_positions': [m.span() for m in pattern.finditer(line)]
                })
        
        return results
    
    def _format_search_results(self, results: List[Dict[str, Any]], pattern: str) -> str:
        """Format search results for display."""
        if not results:
            return f"No matches found for pattern: {pattern}"
        
        formatted = [f"# Search Results for: {pattern}\n"]
        formatted.append(f"Found {len(results)} matches in {len(set(r['file'] for r in results))} files\n")
        
        current_file = None
        for result in results:
            if result['file'] != current_file:
                current_file = result['file']
                formatted.append(f"## {current_file}")
            
            formatted.append(f"**Line {result['line_number']}:**")
            formatted.append("```")
            formatted.extend(result['context'])
            formatted.append("```")
            formatted.append("")
        
        return "\n".join(formatted)


class SmartFileFindTool(FileOperationTool):
    """Smart file finding tool with advanced filtering."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("smart-find")
    
    @property
    def name(self) -> str:
        return "smart-find"
    
    @property
    def description(self) -> str:
        return "Find files with advanced filtering by name, size, date, content type, etc."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name_pattern": {
                    "type": "string",
                    "description": "File name pattern (supports wildcards like *.py)"
                },
                "path": {
                    "type": "string",
                    "description": "Path to search in",
                    "default": "."
                },
                "file_type": {
                    "type": "string",
                    "enum": ["file", "directory", "any"],
                    "description": "Type of items to find",
                    "default": "any"
                },
                "min_size": {
                    "type": "string",
                    "description": "Minimum file size (e.g., '1MB', '500KB')"
                },
                "max_size": {
                    "type": "string",
                    "description": "Maximum file size (e.g., '10MB', '1GB')"
                },
                "modified_within": {
                    "type": "string",
                    "description": "Modified within timeframe (e.g., '1d', '1w', '1m')"
                },
                "exclude_dirs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Directory names to exclude",
                    "default": [".git", "__pycache__", "node_modules", ".venv"]
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results",
                    "default": 100
                }
            },
            "required": []
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute smart file find."""
        self._ensure_initialized()
        
        name_pattern = kwargs.get("name_pattern", "*")
        search_path = kwargs.get("path", ".")
        file_type = kwargs.get("file_type", "any")
        min_size = kwargs.get("min_size")
        max_size = kwargs.get("max_size")
        modified_within = kwargs.get("modified_within")
        exclude_dirs = kwargs.get("exclude_dirs", [".git", "__pycache__", "node_modules", ".venv"])
        max_results = kwargs.get("max_results", 100)
        
        self.tool_logger.log_execution_start("smart_find", pattern=name_pattern, path=search_path)
        
        try:
            abs_path = self._get_absolute_path(search_path)
            
            # Find files
            results = await self._find_files(
                abs_path, name_pattern, file_type, min_size, max_size,
                modified_within, exclude_dirs, max_results
            )
            
            # Format results
            formatted_results = self._format_find_results(results, name_pattern)
            
            self.tool_logger.log_execution_success("smart_find", f"Found {len(results)} items")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("smart_find", e)
            raise
    
    async def _find_files(self, search_path: str, name_pattern: str, file_type: str,
                         min_size: Optional[str], max_size: Optional[str],
                         modified_within: Optional[str], exclude_dirs: List[str],
                         max_results: int) -> List[Dict[str, Any]]:
        """Find files matching criteria."""
        results = []
        search_path = Path(search_path)
        
        # Parse size filters
        min_size_bytes = self._parse_size(min_size) if min_size else 0
        max_size_bytes = self._parse_size(max_size) if max_size else float('inf')
        
        # Parse time filter
        modified_after = self._parse_time_filter(modified_within) if modified_within else None
        
        for root, dirs, filenames in os.walk(search_path):
            if len(results) >= max_results:
                break
            
            # Remove excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            # Check directories
            if file_type in ["directory", "any"]:
                for dirname in dirs:
                    if fnmatch.fnmatch(dirname, name_pattern):
                        dir_path = Path(root) / dirname
                        if self._matches_filters(dir_path, min_size_bytes, max_size_bytes, modified_after):
                            results.append(self._create_result_entry(dir_path, "directory"))
            
            # Check files
            if file_type in ["file", "any"]:
                for filename in filenames:
                    if fnmatch.fnmatch(filename, name_pattern):
                        file_path = Path(root) / filename
                        if self._matches_filters(file_path, min_size_bytes, max_size_bytes, modified_after):
                            results.append(self._create_result_entry(file_path, "file"))
        
        return results[:max_results]
    
    def _parse_size(self, size_str: str) -> int:
        """Parse size string to bytes."""
        size_str = size_str.upper().strip()
        
        multipliers = {
            'B': 1,
            'KB': 1024,
            'MB': 1024 ** 2,
            'GB': 1024 ** 3,
            'TB': 1024 ** 4
        }
        
        for unit, multiplier in multipliers.items():
            if size_str.endswith(unit):
                number = float(size_str[:-len(unit)])
                return int(number * multiplier)
        
        # Assume bytes if no unit
        return int(size_str)
    
    def _parse_time_filter(self, time_str: str) -> float:
        """Parse time filter to timestamp."""
        import time
        
        time_str = time_str.lower().strip()
        
        multipliers = {
            'd': 86400,    # days
            'w': 604800,   # weeks
            'm': 2592000,  # months (30 days)
            'y': 31536000  # years
        }
        
        for unit, seconds in multipliers.items():
            if time_str.endswith(unit):
                number = float(time_str[:-1])
                return time.time() - (number * seconds)
        
        raise ValueError(f"Invalid time format: {time_str}")
    
    def _matches_filters(self, path: Path, min_size: int, max_size: int, 
                        modified_after: Optional[float]) -> bool:
        """Check if path matches all filters."""
        try:
            stat = path.stat()
            
            # Size filter
            if not (min_size <= stat.st_size <= max_size):
                return False
            
            # Time filter
            if modified_after and stat.st_mtime < modified_after:
                return False
            
            return True
        except Exception:
            return False
    
    def _create_result_entry(self, path: Path, item_type: str) -> Dict[str, Any]:
        """Create result entry for a found item."""
        try:
            stat = path.stat()
            return {
                'path': str(path),
                'name': path.name,
                'type': item_type,
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'permissions': oct(stat.st_mode)[-3:]
            }
        except Exception:
            return {
                'path': str(path),
                'name': path.name,
                'type': item_type,
                'size': 0,
                'modified': 0,
                'permissions': '000'
            }
    
    def _format_find_results(self, results: List[Dict[str, Any]], pattern: str) -> str:
        """Format find results for display."""
        if not results:
            return f"No items found matching pattern: {pattern}"
        
        formatted = [f"# Find Results for: {pattern}\n"]
        formatted.append(f"Found {len(results)} items\n")
        
        for result in results:
            item_type = "📁" if result['type'] == 'directory' else "📄"
            size_str = self._format_size(result['size']) if result['type'] == 'file' else ""
            
            formatted.append(f"{item_type} **{result['name']}**")
            formatted.append(f"   Path: {result['path']}")
            if size_str:
                formatted.append(f"   Size: {size_str}")
            formatted.append(f"   Modified: {self._format_timestamp(result['modified'])}")
            formatted.append("")
        
        return "\n".join(formatted)
    
    def _format_size(self, size_bytes: int) -> str:
        """Format size in human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} PB"
    
    def _format_timestamp(self, timestamp: float) -> str:
        """Format timestamp in human readable format."""
        from datetime import datetime
        return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
