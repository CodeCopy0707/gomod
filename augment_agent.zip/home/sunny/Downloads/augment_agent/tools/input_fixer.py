"""Input Fixer tool as specified in plan.md - Auto-fix malformed code from weird sources."""

import re
import ast
import json
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

from .base import CodeAnalysisTool
from ..utils.logging import configure_tool_logging


class InputFixerTool(CodeAnalysisTool):
    """Automatically fix malformed code pasted from screenshots, PDFs, or other weird sources."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("input-fixer")
    
    @property
    def name(self) -> str:
        return "input-fixer"
    
    @property
    def description(self) -> str:
        return "Automatically fix malformed code from screenshots, PDFs, or corrupted sources."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "malformed_code": {
                    "type": "string",
                    "description": "The malformed or corrupted code to fix"
                },
                "language": {
                    "type": "string",
                    "enum": ["python", "javascript", "java", "cpp", "go", "rust", "auto"],
                    "description": "Programming language of the code",
                    "default": "auto"
                },
                "fix_level": {
                    "type": "string",
                    "enum": ["basic", "aggressive", "conservative"],
                    "description": "Level of fixes to apply",
                    "default": "basic"
                },
                "preserve_comments": {
                    "type": "boolean",
                    "description": "Try to preserve comments and documentation",
                    "default": true
                },
                "output_format": {
                    "type": "string",
                    "enum": ["fixed_code", "diff", "analysis"],
                    "description": "Format of the output",
                    "default": "fixed_code"
                }
            },
            "required": ["malformed_code"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute input fixing."""
        self._ensure_initialized()
        
        malformed_code = kwargs["malformed_code"]
        language = kwargs.get("language", "auto")
        fix_level = kwargs.get("fix_level", "basic")
        preserve_comments = kwargs.get("preserve_comments", True)
        output_format = kwargs.get("output_format", "fixed_code")
        
        self.tool_logger.log_execution_start("input_fixer", 
                                           code_length=len(malformed_code),
                                           language=language,
                                           fix_level=fix_level)
        
        try:
            # Detect language if auto
            if language == "auto":
                language = self._detect_language(malformed_code)
            
            # Analyze the malformed code
            analysis = self._analyze_malformed_code(malformed_code, language)
            
            # Apply fixes based on the level
            fixed_code = await self._apply_fixes(malformed_code, language, fix_level, 
                                               preserve_comments, analysis)
            
            # Format output
            result = self._format_output(malformed_code, fixed_code, analysis, 
                                       output_format, language)
            
            self.tool_logger.log_execution_success("input_fixer", 
                                                 f"Applied {len(analysis['issues'])} fixes")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("input_fixer", e)
            raise
    
    def _detect_language(self, code: str) -> str:
        """Detect the programming language of the code."""
        code_lower = code.lower()
        
        # Language-specific keywords and patterns
        language_indicators = {
            'python': ['def ', 'import ', 'from ', 'class ', 'if __name__', 'print(', 'self.'],
            'javascript': ['function ', 'var ', 'let ', 'const ', 'console.log', '=>', 'require('],
            'java': ['public class', 'private ', 'public static void main', 'System.out'],
            'cpp': ['#include', 'std::', 'cout', 'cin', 'int main()', 'using namespace'],
            'go': ['package ', 'func ', 'import ', 'fmt.', 'go '],
            'rust': ['fn ', 'let mut', 'println!', 'use ', 'struct ', 'impl ']
        }
        
        scores = {}
        for lang, indicators in language_indicators.items():
            score = sum(1 for indicator in indicators if indicator in code_lower)
            if score > 0:
                scores[lang] = score
        
        if scores:
            return max(scores, key=scores.get)
        
        return "python"  # Default fallback
    
    def _analyze_malformed_code(self, code: str, language: str) -> Dict[str, Any]:
        """Analyze the malformed code to identify issues."""
        analysis = {
            'language': language,
            'issues': [],
            'line_count': len(code.splitlines()),
            'encoding_issues': [],
            'formatting_issues': [],
            'syntax_issues': [],
            'ocr_artifacts': []
        }
        
        lines = code.splitlines()
        
        # Check for common OCR/screenshot artifacts
        ocr_patterns = [
            (r'[Il1|]{2,}', 'Multiple similar characters (OCR confusion)'),
            (r'[O0]{2,}(?![a-fA-F0-9])', 'Multiple O/0 characters'),
            (r'[^\x00-\x7F]+', 'Non-ASCII characters'),
            (r'\s{5,}', 'Excessive whitespace'),
            (r'[""''`´]', 'Smart quotes or unusual quote characters'),
            (r'[–—]', 'Em/en dashes instead of hyphens'),
            (r'\.{3,}', 'Multiple dots (ellipsis artifacts)'),
            (r'[^\w\s\(\)\[\]\{\}\.,:;=+\-*/<>!@#$%^&|\\\'\"_]', 'Unusual special characters')
        ]
        
        for pattern, description in ocr_patterns:
            matches = re.findall(pattern, code)
            if matches:
                analysis['ocr_artifacts'].append({
                    'pattern': pattern,
                    'description': description,
                    'matches': matches[:5]  # Limit to first 5 matches
                })
        
        # Check for encoding issues
        try:
            code.encode('ascii')
        except UnicodeEncodeError:
            analysis['encoding_issues'].append('Contains non-ASCII characters')
        
        # Check for formatting issues
        for i, line in enumerate(lines, 1):
            # Mixed tabs and spaces
            if '\t' in line and '    ' in line:
                analysis['formatting_issues'].append(f'Line {i}: Mixed tabs and spaces')
            
            # Trailing whitespace
            if line.endswith(' ') or line.endswith('\t'):
                analysis['formatting_issues'].append(f'Line {i}: Trailing whitespace')
            
            # Very long lines (possible line break issues)
            if len(line) > 200:
                analysis['formatting_issues'].append(f'Line {i}: Very long line ({len(line)} chars)')
        
        # Language-specific syntax checks
        if language == 'python':
            analysis['syntax_issues'].extend(self._check_python_syntax(code, lines))
        elif language == 'javascript':
            analysis['syntax_issues'].extend(self._check_javascript_syntax(code, lines))
        
        # Combine all issues
        analysis['issues'] = (analysis['ocr_artifacts'] + 
                            analysis['encoding_issues'] + 
                            analysis['formatting_issues'] + 
                            analysis['syntax_issues'])
        
        return analysis
    
    def _check_python_syntax(self, code: str, lines: List[str]) -> List[str]:
        """Check for Python-specific syntax issues."""
        issues = []
        
        # Try to parse with AST
        try:
            ast.parse(code)
        except SyntaxError as e:
            issues.append(f'Syntax error at line {e.lineno}: {e.msg}')
        
        # Check for common OCR issues in Python
        for i, line in enumerate(lines, 1):
            # Incorrect indentation characters
            if re.search(r'^[^\s\w]', line.strip()) and line.strip():
                issues.append(f'Line {i}: Possible incorrect indentation character')
            
            # Missing colons
            if re.search(r'(if|for|while|def|class|try|except|with)\s+.*[^:]$', line.strip()):
                issues.append(f'Line {i}: Possible missing colon')
            
            # Incorrect operators
            if '=' in line and not re.search(r'[=!<>]=|==', line):
                if re.search(r'\w\s*=\s*=\s*\w', line):
                    issues.append(f'Line {i}: Possible double equals (==) written as = =')
        
        return issues
    
    def _check_javascript_syntax(self, code: str, lines: List[str]) -> List[str]:
        """Check for JavaScript-specific syntax issues."""
        issues = []
        
        for i, line in enumerate(lines, 1):
            # Missing semicolons (if style requires them)
            if re.search(r'(var|let|const|return)\s+.*[^;{}]$', line.strip()):
                if not line.strip().endswith('{') and not line.strip().endswith('}'):
                    issues.append(f'Line {i}: Possible missing semicolon')
            
            # Incorrect function syntax
            if 'function' in line and not re.search(r'function\s+\w+\s*\(', line):
                issues.append(f'Line {i}: Possible malformed function declaration')
        
        return issues
    
    async def _apply_fixes(self, code: str, language: str, fix_level: str,
                          preserve_comments: bool, analysis: Dict[str, Any]) -> str:
        """Apply fixes to the malformed code."""
        fixed_code = code
        
        # Apply fixes based on level
        if fix_level in ['basic', 'aggressive']:
            fixed_code = self._fix_encoding_issues(fixed_code)
            fixed_code = self._fix_ocr_artifacts(fixed_code)
            fixed_code = self._fix_formatting_issues(fixed_code, language)
        
        if fix_level == 'aggressive':
            fixed_code = self._fix_syntax_issues(fixed_code, language)
            fixed_code = self._fix_smart_quotes(fixed_code)
            fixed_code = self._fix_whitespace_issues(fixed_code)
        
        # Language-specific fixes
        if language == 'python':
            fixed_code = self._fix_python_specific(fixed_code, fix_level)
        elif language == 'javascript':
            fixed_code = self._fix_javascript_specific(fixed_code, fix_level)
        
        return fixed_code
    
    def _fix_encoding_issues(self, code: str) -> str:
        """Fix encoding-related issues."""
        # Replace common Unicode issues
        replacements = {
            ''': "'",  # Smart single quote
            ''': "'",  # Smart single quote
            '"': '"',  # Smart double quote
            '"': '"',  # Smart double quote
            '–': '-',  # En dash
            '—': '-',  # Em dash
            '…': '...',  # Ellipsis
            '´': "'",  # Acute accent
            '`': "'",  # Grave accent
        }
        
        for old, new in replacements.items():
            code = code.replace(old, new)
        
        return code
    
    def _fix_ocr_artifacts(self, code: str) -> str:
        """Fix common OCR artifacts."""
        # Fix common character confusions
        fixes = [
            # OCR often confuses these characters
            (r'\b[Il1|]{2,}\b', 'll'),  # Multiple similar chars to 'll'
            (r'\bO+(?=\s|$)', '0'),     # O at word boundary to 0
            (r'\b0+(?=[a-zA-Z])', 'O'), # 0 before letters to O
            (r'[""''`´]', '"'),         # Various quotes to standard quote
            (r'[–—]', '-'),             # Dashes to hyphen
            (r'\.{3,}', '...'),         # Multiple dots to ellipsis
        ]
        
        for pattern, replacement in fixes:
            code = re.sub(pattern, replacement, code)
        
        return code
    
    def _fix_formatting_issues(self, code: str, language: str) -> str:
        """Fix formatting issues."""
        lines = code.splitlines()
        fixed_lines = []
        
        for line in lines:
            # Remove trailing whitespace
            line = line.rstrip()
            
            # Fix mixed tabs and spaces (convert to spaces)
            if '\t' in line:
                # Convert tabs to 4 spaces (common convention)
                line = line.expandtabs(4)
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_syntax_issues(self, code: str, language: str) -> str:
        """Fix syntax issues."""
        if language == 'python':
            # Fix missing colons
            code = re.sub(r'(if|for|while|def|class|try|except|with)\s+([^:]+)(?<!:)$', 
                         r'\1 \2:', code, flags=re.MULTILINE)
        
        elif language == 'javascript':
            # Add missing semicolons (basic cases)
            code = re.sub(r'(var|let|const|return)\s+([^;{}]+)(?<!;)$', 
                         r'\1 \2;', code, flags=re.MULTILINE)
        
        return code
    
    def _fix_smart_quotes(self, code: str) -> str:
        """Fix smart quotes and similar characters."""
        # Replace smart quotes with regular quotes
        code = re.sub(r'["""]', '"', code)
        code = re.sub(r'[''']', "'", code)
        return code
    
    def _fix_whitespace_issues(self, code: str) -> str:
        """Fix whitespace issues."""
        # Remove excessive whitespace
        code = re.sub(r' {5,}', '    ', code)  # Replace 5+ spaces with 4
        code = re.sub(r'\n{3,}', '\n\n', code)  # Replace 3+ newlines with 2
        return code
    
    def _fix_python_specific(self, code: str, fix_level: str) -> str:
        """Apply Python-specific fixes."""
        if fix_level == 'aggressive':
            # Fix common Python OCR issues
            code = re.sub(r'\bprlnt\b', 'print', code)  # Common OCR error
            code = re.sub(r'\bimport\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*$', r'import \1', code, flags=re.MULTILINE)
            
            # Fix indentation issues (basic)
            lines = code.splitlines()
            fixed_lines = []
            for line in lines:
                if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
                    # Check if this should be indented based on previous line
                    if fixed_lines and fixed_lines[-1].strip().endswith(':'):
                        line = '    ' + line
                fixed_lines.append(line)
            code = '\n'.join(fixed_lines)
        
        return code
    
    def _fix_javascript_specific(self, code: str, fix_level: str) -> str:
        """Apply JavaScript-specific fixes."""
        if fix_level == 'aggressive':
            # Fix common JavaScript OCR issues
            code = re.sub(r'\bconsole\.log\s*\(\s*([^)]+)\s*\)', r'console.log(\1)', code)
            code = re.sub(r'\bfunction\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(', r'function \1(', code)
        
        return code
    
    def _format_output(self, original: str, fixed: str, analysis: Dict[str, Any],
                      output_format: str, language: str) -> str:
        """Format the output based on the requested format."""
        if output_format == "fixed_code":
            return f"# Fixed {language.title()} Code\n\n```{language}\n{fixed}\n```"
        
        elif output_format == "diff":
            import difflib
            diff = difflib.unified_diff(
                original.splitlines(keepends=True),
                fixed.splitlines(keepends=True),
                fromfile="original",
                tofile="fixed",
                lineterm=""
            )
            return f"# Code Diff\n\n```diff\n{''.join(diff)}\n```"
        
        elif output_format == "analysis":
            formatted = [f"# Input Fixer Analysis\n"]
            formatted.append(f"**Language:** {language}")
            formatted.append(f"**Issues Found:** {len(analysis['issues'])}")
            formatted.append(f"**Line Count:** {analysis['line_count']}")
            
            if analysis['ocr_artifacts']:
                formatted.append("\n## OCR Artifacts Found:")
                for artifact in analysis['ocr_artifacts']:
                    formatted.append(f"- {artifact['description']}")
                    if artifact['matches']:
                        formatted.append(f"  Examples: {', '.join(artifact['matches'])}")
            
            if analysis['encoding_issues']:
                formatted.append("\n## Encoding Issues:")
                for issue in analysis['encoding_issues']:
                    formatted.append(f"- {issue}")
            
            if analysis['formatting_issues']:
                formatted.append("\n## Formatting Issues:")
                for issue in analysis['formatting_issues'][:10]:  # Limit to first 10
                    formatted.append(f"- {issue}")
            
            if analysis['syntax_issues']:
                formatted.append("\n## Syntax Issues:")
                for issue in analysis['syntax_issues']:
                    formatted.append(f"- {issue}")
            
            formatted.append(f"\n## Fixed Code\n\n```{language}\n{fixed}\n```")
            
            return "\n".join(formatted)
        
        return fixed
