"""Advanced code finder tools as specified in plan.md - Example.py Style Code Finder."""

import os
import ast
import re
from pathlib import Path
from typing import Dict, Any, List, Optional, Set
import difflib
from collections import defaultdict

from .base import CodeAnalysisTool
from ..utils.logging import configure_tool_logging


class ExampleStyleCodeFinderTool(CodeAnalysisTool):
    """Find code similar to examples with fuzzy matching and pattern recognition."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("example-code-finder")
    
    @property
    def name(self) -> str:
        return "example-code-finder"
    
    @property
    def description(self) -> str:
        return "Find code similar to provided examples using fuzzy matching, pattern recognition, and structural analysis."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "example_code": {
                    "type": "string",
                    "description": "Example code to find similar patterns for"
                },
                "similarity_threshold": {
                    "type": "number",
                    "description": "Similarity threshold (0.0-1.0) for fuzzy matching",
                    "default": 0.6,
                    "minimum": 0.0,
                    "maximum": 1.0
                },
                "search_type": {
                    "type": "string",
                    "enum": ["structural", "textual", "semantic", "all"],
                    "description": "Type of similarity search to perform",
                    "default": "all"
                },
                "file_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File patterns to search in (e.g., ['*.py', '*.js'])",
                    "default": ["*.py"]
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of similar code snippets to return",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 50
                }
            },
            "required": ["example_code"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute example-style code finding."""
        self._ensure_initialized()
        self._validate_code_analysis_enabled()
        
        example_code = kwargs["example_code"]
        similarity_threshold = kwargs.get("similarity_threshold", 0.6)
        search_type = kwargs.get("search_type", "all")
        file_patterns = kwargs.get("file_patterns", ["*.py"])
        max_results = kwargs.get("max_results", 10)
        
        self.tool_logger.log_execution_start("example_code_finder", 
                                           example_length=len(example_code),
                                           search_type=search_type)
        
        try:
            # Analyze the example code
            example_analysis = await self._analyze_example_code(example_code)
            
            # Find similar code in the codebase
            similar_code = await self._find_similar_code(
                example_analysis, similarity_threshold, search_type, 
                file_patterns, max_results
            )
            
            # Format results
            formatted_results = self._format_similarity_results(similar_code, example_code)
            
            self.tool_logger.log_execution_success("example_code_finder", 
                                                 f"Found {len(similar_code)} similar code snippets")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("example_code_finder", e)
            raise
    
    async def _analyze_example_code(self, code: str) -> Dict[str, Any]:
        """Analyze the example code to extract patterns and structure."""
        analysis = {
            'raw_code': code,
            'lines': code.splitlines(),
            'functions': [],
            'classes': [],
            'imports': [],
            'variables': [],
            'patterns': [],
            'structure': {},
            'tokens': [],
            'ast_structure': None
        }
        
        # Try to parse as Python AST
        try:
            tree = ast.parse(code)
            analysis['ast_structure'] = tree
            
            # Extract functions, classes, etc.
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    analysis['functions'].append({
                        'name': node.name,
                        'args': [arg.arg for arg in node.args.args],
                        'line': node.lineno,
                        'docstring': ast.get_docstring(node)
                    })
                elif isinstance(node, ast.ClassDef):
                    analysis['classes'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'methods': [n.name for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))],
                        'docstring': ast.get_docstring(node)
                    })
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            analysis['imports'].append(alias.name)
                    else:
                        module = node.module or ''
                        for alias in node.names:
                            analysis['imports'].append(f"{module}.{alias.name}")
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            analysis['variables'].append(target.id)
                            
        except SyntaxError:
            # Not valid Python, use text-based analysis
            pass
        
        # Extract text patterns
        analysis['patterns'] = self._extract_text_patterns(code)
        
        # Tokenize for similarity comparison
        analysis['tokens'] = self._tokenize_code(code)
        
        # Extract structural information
        analysis['structure'] = self._extract_structure(code)
        
        return analysis
    
    def _extract_text_patterns(self, code: str) -> List[str]:
        """Extract common text patterns from code."""
        patterns = []
        
        # Common code patterns
        pattern_regexes = [
            r'def\s+\w+\s*\([^)]*\):',  # Function definitions
            r'class\s+\w+\s*\([^)]*\):',  # Class definitions
            r'if\s+.*:',  # If statements
            r'for\s+.*:',  # For loops
            r'while\s+.*:',  # While loops
            r'try\s*:',  # Try blocks
            r'except\s+.*:',  # Except blocks
            r'with\s+.*:',  # With statements
            r'import\s+\w+',  # Import statements
            r'from\s+\w+\s+import',  # From import statements
            r'\w+\s*=\s*.*',  # Assignments
            r'\w+\.\w+\([^)]*\)',  # Method calls
        ]
        
        for pattern in pattern_regexes:
            matches = re.findall(pattern, code, re.MULTILINE)
            patterns.extend(matches)
        
        return patterns
    
    def _tokenize_code(self, code: str) -> List[str]:
        """Tokenize code for similarity comparison."""
        # Simple tokenization - split on whitespace and punctuation
        import re
        tokens = re.findall(r'\w+|[^\w\s]', code)
        return [token.lower() for token in tokens if token.strip()]
    
    def _extract_structure(self, code: str) -> Dict[str, Any]:
        """Extract structural information from code."""
        lines = code.splitlines()
        structure = {
            'line_count': len(lines),
            'indentation_levels': [],
            'block_structure': [],
            'complexity_score': 0
        }
        
        # Analyze indentation and block structure
        for line in lines:
            if line.strip():
                indent_level = len(line) - len(line.lstrip())
                structure['indentation_levels'].append(indent_level)
                
                # Count complexity indicators
                if any(keyword in line for keyword in ['if', 'for', 'while', 'try', 'except']):
                    structure['complexity_score'] += 1
        
        return structure
    
    async def _find_similar_code(self, example_analysis: Dict[str, Any], 
                                threshold: float, search_type: str,
                                file_patterns: List[str], max_results: int) -> List[Dict[str, Any]]:
        """Find code similar to the example."""
        similar_code = []
        workspace_root = Path(self.config.workspace_root)
        
        # Find files to search
        files_to_search = self._find_files_to_search(workspace_root, file_patterns)
        
        for file_path in files_to_search:
            try:
                file_similarities = await self._find_similarities_in_file(
                    file_path, example_analysis, threshold, search_type
                )
                similar_code.extend(file_similarities)
            except Exception as e:
                self.tool_logger.log_warning(f"Failed to analyze {file_path}: {e}")
        
        # Sort by similarity score and return top results
        similar_code.sort(key=lambda x: x['similarity_score'], reverse=True)
        return similar_code[:max_results]
    
    def _find_files_to_search(self, workspace_root: Path, file_patterns: List[str]) -> List[Path]:
        """Find files matching the given patterns."""
        files = []
        
        for pattern in file_patterns:
            files.extend(workspace_root.rglob(pattern))
        
        # Filter out ignored files
        filtered_files = []
        for file_path in files:
            if not self._should_ignore_file(file_path):
                filtered_files.append(file_path)
        
        return filtered_files
    
    def _should_ignore_file(self, file_path: Path) -> bool:
        """Check if file should be ignored."""
        ignore_patterns = {
            '.git', '__pycache__', 'node_modules', '.pytest_cache',
            '.mypy_cache', '.tox', 'venv', '.venv', 'env', '.env',
            'dist', 'build', '.next', '.nuxt', 'target'
        }
        
        for parent in file_path.parents:
            if parent.name in ignore_patterns:
                return True
        
        return False
    
    async def _find_similarities_in_file(self, file_path: Path, example_analysis: Dict[str, Any],
                                       threshold: float, search_type: str) -> List[Dict[str, Any]]:
        """Find similar code snippets in a single file."""
        similarities = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
        except Exception:
            return similarities
        
        # Analyze the file
        file_analysis = await self._analyze_example_code(content)
        
        # Different similarity search types
        if search_type in ['structural', 'all']:
            similarities.extend(self._find_structural_similarities(
                file_path, file_analysis, example_analysis, threshold
            ))
        
        if search_type in ['textual', 'all']:
            similarities.extend(self._find_textual_similarities(
                file_path, content, lines, example_analysis, threshold
            ))
        
        if search_type in ['semantic', 'all']:
            similarities.extend(self._find_semantic_similarities(
                file_path, file_analysis, example_analysis, threshold
            ))
        
        return similarities
    
    def _find_structural_similarities(self, file_path: Path, file_analysis: Dict[str, Any],
                                    example_analysis: Dict[str, Any], threshold: float) -> List[Dict[str, Any]]:
        """Find structurally similar code."""
        similarities = []
        
        # Compare functions
        for file_func in file_analysis['functions']:
            for example_func in example_analysis['functions']:
                similarity = self._calculate_function_similarity(file_func, example_func)
                if similarity >= threshold:
                    similarities.append({
                        'file': str(file_path),
                        'type': 'function',
                        'name': file_func['name'],
                        'line': file_func['line'],
                        'similarity_score': similarity,
                        'similarity_type': 'structural',
                        'match_reason': f"Similar to function '{example_func['name']}'"
                    })
        
        # Compare classes
        for file_class in file_analysis['classes']:
            for example_class in example_analysis['classes']:
                similarity = self._calculate_class_similarity(file_class, example_class)
                if similarity >= threshold:
                    similarities.append({
                        'file': str(file_path),
                        'type': 'class',
                        'name': file_class['name'],
                        'line': file_class['line'],
                        'similarity_score': similarity,
                        'similarity_type': 'structural',
                        'match_reason': f"Similar to class '{example_class['name']}'"
                    })
        
        return similarities
    
    def _find_textual_similarities(self, file_path: Path, content: str, lines: List[str],
                                 example_analysis: Dict[str, Any], threshold: float) -> List[Dict[str, Any]]:
        """Find textually similar code using fuzzy matching."""
        similarities = []
        example_lines = example_analysis['lines']
        
        # Use sliding window to find similar code blocks
        window_size = len(example_lines)
        if window_size > len(lines):
            return similarities
        
        for i in range(len(lines) - window_size + 1):
            window_lines = lines[i:i + window_size]
            similarity = self._calculate_text_similarity(window_lines, example_lines)
            
            if similarity >= threshold:
                similarities.append({
                    'file': str(file_path),
                    'type': 'text_block',
                    'line_start': i + 1,
                    'line_end': i + window_size,
                    'content': '\n'.join(window_lines),
                    'similarity_score': similarity,
                    'similarity_type': 'textual',
                    'match_reason': f"Text similarity: {similarity:.2f}"
                })
        
        return similarities
    
    def _find_semantic_similarities(self, file_path: Path, file_analysis: Dict[str, Any],
                                  example_analysis: Dict[str, Any], threshold: float) -> List[Dict[str, Any]]:
        """Find semantically similar code based on patterns and tokens."""
        similarities = []
        
        # Compare token similarity
        file_tokens = set(file_analysis['tokens'])
        example_tokens = set(example_analysis['tokens'])
        
        if file_tokens and example_tokens:
            token_similarity = len(file_tokens & example_tokens) / len(file_tokens | example_tokens)
            
            if token_similarity >= threshold:
                similarities.append({
                    'file': str(file_path),
                    'type': 'semantic',
                    'similarity_score': token_similarity,
                    'similarity_type': 'semantic',
                    'match_reason': f"Token similarity: {token_similarity:.2f}",
                    'common_tokens': list(file_tokens & example_tokens)[:10]
                })
        
        return similarities
    
    def _calculate_function_similarity(self, func1: Dict[str, Any], func2: Dict[str, Any]) -> float:
        """Calculate similarity between two functions."""
        score = 0.0
        
        # Name similarity
        name_sim = difflib.SequenceMatcher(None, func1['name'], func2['name']).ratio()
        score += name_sim * 0.3
        
        # Argument similarity
        args1 = set(func1.get('args', []))
        args2 = set(func2.get('args', []))
        if args1 or args2:
            arg_sim = len(args1 & args2) / len(args1 | args2) if (args1 | args2) else 0
            score += arg_sim * 0.4
        
        # Docstring similarity
        doc1 = func1.get('docstring', '') or ''
        doc2 = func2.get('docstring', '') or ''
        if doc1 and doc2:
            doc_sim = difflib.SequenceMatcher(None, doc1, doc2).ratio()
            score += doc_sim * 0.3
        
        return min(score, 1.0)
    
    def _calculate_class_similarity(self, class1: Dict[str, Any], class2: Dict[str, Any]) -> float:
        """Calculate similarity between two classes."""
        score = 0.0
        
        # Name similarity
        name_sim = difflib.SequenceMatcher(None, class1['name'], class2['name']).ratio()
        score += name_sim * 0.4
        
        # Method similarity
        methods1 = set(class1.get('methods', []))
        methods2 = set(class2.get('methods', []))
        if methods1 or methods2:
            method_sim = len(methods1 & methods2) / len(methods1 | methods2) if (methods1 | methods2) else 0
            score += method_sim * 0.6
        
        return min(score, 1.0)
    
    def _calculate_text_similarity(self, lines1: List[str], lines2: List[str]) -> float:
        """Calculate text similarity between two code blocks."""
        # Normalize lines (remove extra whitespace, comments)
        norm_lines1 = [self._normalize_line(line) for line in lines1]
        norm_lines2 = [self._normalize_line(line) for line in lines2]
        
        # Filter out empty lines
        norm_lines1 = [line for line in norm_lines1 if line.strip()]
        norm_lines2 = [line for line in norm_lines2 if line.strip()]
        
        if not norm_lines1 or not norm_lines2:
            return 0.0
        
        # Calculate similarity using difflib
        text1 = '\n'.join(norm_lines1)
        text2 = '\n'.join(norm_lines2)
        
        return difflib.SequenceMatcher(None, text1, text2).ratio()
    
    def _normalize_line(self, line: str) -> str:
        """Normalize a line of code for comparison."""
        # Remove comments
        if '#' in line:
            line = line[:line.index('#')]
        
        # Normalize whitespace
        line = ' '.join(line.split())
        
        return line.strip()
    
    def _format_similarity_results(self, similarities: List[Dict[str, Any]], example_code: str) -> str:
        """Format similarity search results."""
        if not similarities:
            return f"No similar code found for the provided example.\n\nExample code:\n```\n{example_code}\n```"
        
        formatted = [f"# Similar Code Found ({len(similarities)} matches)\n"]
        formatted.append(f"**Example code:**\n```\n{example_code}\n```\n")
        
        for i, similarity in enumerate(similarities, 1):
            formatted.append(f"## {i}. {similarity.get('name', 'Code Block')} ({similarity['similarity_type']})")
            formatted.append(f"**File:** {similarity['file']}")
            
            if 'line' in similarity:
                formatted.append(f"**Line:** {similarity['line']}")
            elif 'line_start' in similarity:
                formatted.append(f"**Lines:** {similarity['line_start']}-{similarity['line_end']}")
            
            formatted.append(f"**Similarity Score:** {similarity['similarity_score']:.2f}")
            formatted.append(f"**Match Reason:** {similarity['match_reason']}")
            
            if 'content' in similarity:
                content = similarity['content']
                if len(content) > 500:
                    content = content[:500] + "..."
                formatted.append(f"**Code:**\n```\n{content}\n```")
            
            if 'common_tokens' in similarity:
                formatted.append(f"**Common Tokens:** {', '.join(similarity['common_tokens'])}")
            
            formatted.append("")
        
        return "\n".join(formatted)
