"""Advanced string replacer tool as specified in plan.md - Smart String Replacer with context awareness."""

import os
import re
import ast
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import difflib

from .base import FileOperationTool
from ..utils.logging import configure_tool_logging


class SmartStringReplacerTool(FileOperationTool):
    """Advanced string replacement with context awareness, scope detection, and safety checks."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("smart-string-replacer")
    
    @property
    def name(self) -> str:
        return "smart-string-replacer"
    
    @property
    def description(self) -> str:
        return "Advanced string replacement with context awareness, scope detection, and intelligent matching."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "search_pattern": {
                    "type": "string",
                    "description": "Pattern to search for (supports regex if regex=true)"
                },
                "replacement": {
                    "type": "string",
                    "description": "Replacement string (supports capture groups if regex=true)"
                },
                "file_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File patterns to search in (e.g., ['*.py', '*.js'])",
                    "default": ["*"]
                },
                "scope": {
                    "type": "string",
                    "enum": ["global", "function", "class", "method", "variable", "string", "comment"],
                    "description": "Scope to limit replacements to",
                    "default": "global"
                },
                "context_aware": {
                    "type": "boolean",
                    "description": "Use context-aware replacement (considers surrounding code)",
                    "default": true
                },
                "regex": {
                    "type": "boolean",
                    "description": "Treat search pattern as regular expression",
                    "default": false
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Case-sensitive search",
                    "default": true
                },
                "whole_word": {
                    "type": "boolean",
                    "description": "Match whole words only",
                    "default": false
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Show what would be replaced without making changes",
                    "default": false
                },
                "max_replacements": {
                    "type": "integer",
                    "description": "Maximum number of replacements to make",
                    "default": -1
                },
                "exclude_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Patterns to exclude from replacement"
                }
            },
            "required": ["search_pattern", "replacement"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute smart string replacement."""
        self._ensure_initialized()
        
        search_pattern = kwargs["search_pattern"]
        replacement = kwargs["replacement"]
        file_patterns = kwargs.get("file_patterns", ["*"])
        scope = kwargs.get("scope", "global")
        context_aware = kwargs.get("context_aware", True)
        use_regex = kwargs.get("regex", False)
        case_sensitive = kwargs.get("case_sensitive", True)
        whole_word = kwargs.get("whole_word", False)
        dry_run = kwargs.get("dry_run", False)
        max_replacements = kwargs.get("max_replacements", -1)
        exclude_patterns = kwargs.get("exclude_patterns", [])
        
        self.tool_logger.log_execution_start("smart_string_replacer", 
                                           pattern=search_pattern[:50],
                                           scope=scope,
                                           dry_run=dry_run)
        
        try:
            # Validate and prepare search pattern
            compiled_pattern = self._prepare_search_pattern(
                search_pattern, use_regex, case_sensitive, whole_word
            )
            
            # Find files to process
            files_to_process = self._find_files_to_process(file_patterns, exclude_patterns)
            
            # Perform replacements
            replacement_results = await self._perform_replacements(
                files_to_process, compiled_pattern, replacement, scope,
                context_aware, dry_run, max_replacements
            )
            
            # Format results
            formatted_results = self._format_replacement_results(
                replacement_results, search_pattern, replacement, dry_run
            )
            
            total_replacements = sum(r['replacement_count'] for r in replacement_results)
            self.tool_logger.log_execution_success("smart_string_replacer", 
                                                 f"Made {total_replacements} replacements in {len(replacement_results)} files")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("smart_string_replacer", e)
            raise
    
    def _prepare_search_pattern(self, pattern: str, use_regex: bool, 
                               case_sensitive: bool, whole_word: bool) -> re.Pattern:
        """Prepare and compile the search pattern."""
        if not use_regex:
            # Escape special regex characters for literal search
            pattern = re.escape(pattern)
        
        if whole_word:
            pattern = r'\b' + pattern + r'\b'
        
        flags = 0 if case_sensitive else re.IGNORECASE
        
        try:
            return re.compile(pattern, flags)
        except re.error as e:
            raise ValueError(f"Invalid regex pattern: {e}")
    
    def _find_files_to_process(self, file_patterns: List[str], 
                              exclude_patterns: List[str]) -> List[Path]:
        """Find files matching the given patterns."""
        workspace_root = Path(self.config.workspace_root)
        files = set()
        
        # Add files matching include patterns
        for pattern in file_patterns:
            files.update(workspace_root.rglob(pattern))
        
        # Remove files matching exclude patterns
        for pattern in exclude_patterns:
            exclude_files = set(workspace_root.rglob(pattern))
            files -= exclude_files
        
        # Filter out directories and ignored files
        filtered_files = []
        for file_path in files:
            if file_path.is_file() and not self._should_ignore_file(file_path):
                filtered_files.append(file_path)
        
        return filtered_files
    
    def _should_ignore_file(self, file_path: Path) -> bool:
        """Check if file should be ignored."""
        ignore_patterns = {
            '.git', '__pycache__', 'node_modules', '.pytest_cache',
            '.mypy_cache', '.tox', 'venv', '.venv', 'env', '.env',
            'dist', 'build', '.next', '.nuxt', 'target'
        }
        
        for parent in file_path.parents:
            if parent.name in ignore_patterns:
                return True
        
        # Skip binary files
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                f.read(1024)  # Try to read first 1KB
        except (UnicodeDecodeError, PermissionError):
            return True
        
        return False
    
    async def _perform_replacements(self, files: List[Path], pattern: re.Pattern,
                                  replacement: str, scope: str, context_aware: bool,
                                  dry_run: bool, max_replacements: int) -> List[Dict[str, Any]]:
        """Perform replacements in the specified files."""
        results = []
        total_replacements = 0
        
        for file_path in files:
            if max_replacements > 0 and total_replacements >= max_replacements:
                break
            
            try:
                file_result = await self._process_file(
                    file_path, pattern, replacement, scope, context_aware,
                    dry_run, max_replacements - total_replacements if max_replacements > 0 else -1
                )
                
                if file_result['replacement_count'] > 0:
                    results.append(file_result)
                    total_replacements += file_result['replacement_count']
                    
            except Exception as e:
                self.tool_logger.log_warning(f"Failed to process {file_path}: {e}")
        
        return results
    
    async def _process_file(self, file_path: Path, pattern: re.Pattern,
                          replacement: str, scope: str, context_aware: bool,
                          dry_run: bool, max_replacements: int) -> Dict[str, Any]:
        """Process a single file for replacements."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                original_content = f.read()
                lines = original_content.splitlines()
        except Exception as e:
            raise RuntimeError(f"Failed to read file: {e}")
        
        # Analyze file structure if context-aware
        file_structure = None
        if context_aware:
            file_structure = self._analyze_file_structure(original_content, file_path.suffix)
        
        # Find and perform replacements
        replacements = self._find_replacements(
            lines, pattern, replacement, scope, file_structure, max_replacements
        )
        
        # Apply replacements
        new_content = self._apply_replacements(original_content, replacements)
        
        # Write back to file if not dry run
        if not dry_run and new_content != original_content:
            # Create backup first
            await self.safety_manager.create_backup(str(file_path))
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
        
        return {
            'file': str(file_path),
            'replacement_count': len(replacements),
            'replacements': replacements,
            'original_content': original_content if dry_run else None,
            'new_content': new_content if dry_run else None
        }
    
    def _analyze_file_structure(self, content: str, file_extension: str) -> Optional[Dict[str, Any]]:
        """Analyze file structure for context-aware replacements."""
        structure = {
            'functions': [],
            'classes': [],
            'variables': [],
            'imports': [],
            'comments': [],
            'strings': []
        }
        
        if file_extension == '.py':
            # Python-specific analysis
            try:
                tree = ast.parse(content)
                
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        structure['functions'].append({
                            'name': node.name,
                            'line_start': node.lineno,
                            'line_end': getattr(node, 'end_lineno', node.lineno)
                        })
                    elif isinstance(node, ast.ClassDef):
                        structure['classes'].append({
                            'name': node.name,
                            'line_start': node.lineno,
                            'line_end': getattr(node, 'end_lineno', node.lineno)
                        })
                    elif isinstance(node, ast.Assign):
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                structure['variables'].append({
                                    'name': target.id,
                                    'line': node.lineno
                                })
                                
            except SyntaxError:
                pass
        
        # Generic analysis for comments and strings
        lines = content.splitlines()
        for i, line in enumerate(lines, 1):
            # Find comments
            if '#' in line:
                comment_start = line.index('#')
                structure['comments'].append({
                    'line': i,
                    'column': comment_start,
                    'content': line[comment_start:]
                })
            
            # Find strings (simplified)
            for match in re.finditer(r'["\']([^"\']*)["\']', line):
                structure['strings'].append({
                    'line': i,
                    'column': match.start(),
                    'content': match.group(1)
                })
        
        return structure
    
    def _find_replacements(self, lines: List[str], pattern: re.Pattern,
                          replacement: str, scope: str, file_structure: Optional[Dict[str, Any]],
                          max_replacements: int) -> List[Dict[str, Any]]:
        """Find all replacements to make."""
        replacements = []
        replacement_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if max_replacements > 0 and replacement_count >= max_replacements:
                break
            
            # Check if this line is in the specified scope
            if not self._is_in_scope(line_num, scope, file_structure):
                continue
            
            # Find matches in this line
            for match in pattern.finditer(line):
                if max_replacements > 0 and replacement_count >= max_replacements:
                    break
                
                # Calculate replacement text
                replacement_text = pattern.sub(replacement, match.group())
                
                replacements.append({
                    'line': line_num,
                    'column': match.start(),
                    'original': match.group(),
                    'replacement': replacement_text,
                    'context': self._get_context(lines, line_num, 2)
                })
                
                replacement_count += 1
        
        return replacements
    
    def _is_in_scope(self, line_num: int, scope: str, 
                    file_structure: Optional[Dict[str, Any]]) -> bool:
        """Check if a line is within the specified scope."""
        if scope == "global" or not file_structure:
            return True
        
        if scope == "function":
            return any(
                func['line_start'] <= line_num <= func['line_end']
                for func in file_structure['functions']
            )
        elif scope == "class":
            return any(
                cls['line_start'] <= line_num <= cls['line_end']
                for cls in file_structure['classes']
            )
        elif scope == "comment":
            return any(
                comment['line'] == line_num
                for comment in file_structure['comments']
            )
        elif scope == "string":
            return any(
                string['line'] == line_num
                for string in file_structure['strings']
            )
        
        return True
    
    def _get_context(self, lines: List[str], line_num: int, context_size: int) -> Dict[str, Any]:
        """Get context around a line."""
        start = max(0, line_num - context_size - 1)
        end = min(len(lines), line_num + context_size)
        
        return {
            'before': lines[start:line_num-1],
            'current': lines[line_num-1] if line_num <= len(lines) else '',
            'after': lines[line_num:end]
        }
    
    def _apply_replacements(self, content: str, replacements: List[Dict[str, Any]]) -> str:
        """Apply all replacements to the content."""
        if not replacements:
            return content
        
        lines = content.splitlines()
        
        # Sort replacements by line and column (reverse order to avoid offset issues)
        replacements.sort(key=lambda r: (r['line'], r['column']), reverse=True)
        
        for replacement in replacements:
            line_num = replacement['line'] - 1  # Convert to 0-based
            if line_num < len(lines):
                line = lines[line_num]
                col = replacement['column']
                original = replacement['original']
                new_text = replacement['replacement']
                
                # Replace the specific occurrence
                before = line[:col]
                after = line[col + len(original):]
                lines[line_num] = before + new_text + after
        
        return '\n'.join(lines)
    
    def _format_replacement_results(self, results: List[Dict[str, Any]], 
                                  search_pattern: str, replacement: str, 
                                  dry_run: bool) -> str:
        """Format replacement results for display."""
        if not results:
            return f"No replacements found for pattern: {search_pattern}"
        
        total_replacements = sum(r['replacement_count'] for r in results)
        action = "Would replace" if dry_run else "Replaced"
        
        formatted = [f"# Smart String Replacement Results\n"]
        formatted.append(f"**Pattern:** `{search_pattern}`")
        formatted.append(f"**Replacement:** `{replacement}`")
        formatted.append(f"**{action}:** {total_replacements} occurrences in {len(results)} files")
        
        if dry_run:
            formatted.append("\n**⚠️ DRY RUN MODE - No changes were made**")
        
        formatted.append("")
        
        for result in results:
            formatted.append(f"## {Path(result['file']).name}")
            formatted.append(f"**File:** {result['file']}")
            formatted.append(f"**Replacements:** {result['replacement_count']}")
            
            # Show first few replacements
            for i, repl in enumerate(result['replacements'][:5]):
                formatted.append(f"\n**Replacement {i+1}:**")
                formatted.append(f"- Line {repl['line']}, Column {repl['column']}")
                formatted.append(f"- Original: `{repl['original']}`")
                formatted.append(f"- Replacement: `{repl['replacement']}`")
                
                if repl['context']['before']:
                    formatted.append("- Context:")
                    for ctx_line in repl['context']['before'][-2:]:
                        formatted.append(f"  {ctx_line}")
                    formatted.append(f"  **{repl['context']['current']}**  ← Changed")
                    for ctx_line in repl['context']['after'][:2]:
                        formatted.append(f"  {ctx_line}")
            
            if len(result['replacements']) > 5:
                formatted.append(f"\n... and {len(result['replacements']) - 5} more replacements")
            
            formatted.append("")
        
        return "\n".join(formatted)
