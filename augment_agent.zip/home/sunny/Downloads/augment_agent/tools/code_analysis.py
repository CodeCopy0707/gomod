"""Code analysis and retrieval tools for Augment Agent."""

import os
import ast
import json
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional, Set
from datetime import datetime
import hashlib

try:
    import chromadb
    from sentence_transformers import SentenceTransformer
    EMBEDDING_AVAILABLE = True
except ImportError:
    EMBEDDING_AVAILABLE = False

try:
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name, guess_lexer_for_filename
    from pygments.formatters import TerminalFormatter
    SYNTAX_HIGHLIGHTING_AVAILABLE = True
except ImportError:
    SYNTAX_HIGHLIGHTING_AVAILABLE = False

from .base import CodeAnalysisTool
from ..utils.logging import configure_tool_logging


class CodebaseRetrievalTool(CodeAnalysisTool):
    """Tool for retrieving relevant code snippets from the codebase."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("codebase-retrieval")
        self.db_path = None
        self.chroma_client = None
        self.embedding_model = None
        self.collection = None
    
    @property
    def name(self) -> str:
        return "codebase-retrieval"
    
    @property
    def description(self) -> str:
        return "Retrieve relevant code snippets from the codebase using semantic search and indexing."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "information_request": {
                    "type": "string",
                    "description": "A description of the information you need from the codebase."
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return.",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 50
                }
            },
            "required": ["information_request"]
        }
    
    async def initialize(self) -> None:
        """Initialize the codebase retrieval system."""
        await super().initialize()
        
        self.db_path = Path(self.config.codebase_index_path) / "codebase.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize SQLite database
        self._init_database()
        
        # Initialize embedding system if available
        if EMBEDDING_AVAILABLE:
            try:
                self.chroma_client = chromadb.PersistentClient(
                    path=str(Path(self.config.codebase_index_path) / "chroma")
                )
                self.collection = self.chroma_client.get_or_create_collection(
                    name="codebase",
                    metadata={"hnsw:space": "cosine"}
                )
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                self.tool_logger.log_info("Embedding system initialized")
            except Exception as e:
                self.tool_logger.log_warning(f"Failed to initialize embedding system: {e}")
                EMBEDDING_AVAILABLE = False
    
    def _init_database(self) -> None:
        """Initialize the SQLite database for code indexing."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT UNIQUE NOT NULL,
                    file_hash TEXT NOT NULL,
                    last_indexed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    language TEXT,
                    size_bytes INTEGER
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_symbols (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    symbol_name TEXT NOT NULL,
                    symbol_type TEXT NOT NULL,
                    line_start INTEGER,
                    line_end INTEGER,
                    content TEXT,
                    docstring TEXT,
                    FOREIGN KEY (file_id) REFERENCES code_files (id)
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_symbols_name ON code_symbols (symbol_name)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_symbols_type ON code_symbols (symbol_type)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_files_path ON code_files (file_path)
            """)
    
    async def execute(self, **kwargs) -> str:
        """Execute codebase retrieval."""
        self._ensure_initialized()
        self._validate_code_analysis_enabled()
        
        information_request = kwargs["information_request"]
        max_results = kwargs.get("max_results", 10)
        
        self.tool_logger.log_execution_start("codebase_retrieval", request=information_request[:100])
        
        try:
            # Ensure codebase is indexed
            await self._ensure_codebase_indexed()
            
            # Search for relevant code
            results = await self._search_codebase(information_request, max_results)
            
            # Format results
            formatted_results = self._format_search_results(results, information_request)
            
            self.tool_logger.log_execution_success("codebase_retrieval", f"Found {len(results)} results")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("codebase_retrieval", e)
            raise
    
    async def _ensure_codebase_indexed(self) -> None:
        """Ensure the codebase is indexed and up to date."""
        workspace_root = Path(self.config.workspace_root)
        
        # Get all code files
        code_files = self._find_code_files(workspace_root)
        
        # Check which files need indexing
        files_to_index = []
        with sqlite3.connect(self.db_path) as conn:
            for file_path in code_files:
                file_hash = self._get_file_hash(file_path)
                
                cursor = conn.execute(
                    "SELECT file_hash FROM code_files WHERE file_path = ?",
                    (str(file_path.relative_to(workspace_root)),)
                )
                result = cursor.fetchone()
                
                if not result or result[0] != file_hash:
                    files_to_index.append(file_path)
        
        # Index new/changed files
        if files_to_index:
            self.tool_logger.log_info(f"Indexing {len(files_to_index)} files")
            for file_path in files_to_index:
                await self._index_file(file_path, workspace_root)
    
    def _find_code_files(self, root_path: Path) -> List[Path]:
        """Find all code files in the workspace."""
        code_extensions = {
            '.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.cpp', '.c', '.h',
            '.cs', '.php', '.rb', '.go', '.rs', '.swift', '.kt', '.scala',
            '.sh', '.bash', '.sql', '.html', '.css', '.scss', '.less',
            '.yaml', '.yml', '.json', '.xml', '.md', '.rst'
        }
        
        code_files = []
        for file_path in root_path.rglob("*"):
            if (file_path.is_file() and 
                file_path.suffix.lower() in code_extensions and
                not self._should_ignore_file(file_path)):
                code_files.append(file_path)
        
        return code_files
    
    def _should_ignore_file(self, file_path: Path) -> bool:
        """Check if a file should be ignored during indexing."""
        ignore_patterns = {
            '.git', '__pycache__', 'node_modules', '.pytest_cache',
            '.mypy_cache', '.tox', 'venv', '.venv', 'env', '.env',
            'dist', 'build', '.next', '.nuxt', 'target'
        }
        
        # Check if any parent directory matches ignore patterns
        for parent in file_path.parents:
            if parent.name in ignore_patterns:
                return True
        
        # Check file size (skip very large files)
        try:
            if file_path.stat().st_size > 1024 * 1024:  # 1MB limit
                return True
        except OSError:
            return True
        
        return False
    
    def _get_file_hash(self, file_path: Path) -> str:
        """Get SHA-256 hash of file content."""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        except Exception:
            return ""
    
    async def _index_file(self, file_path: Path, workspace_root: Path) -> None:
        """Index a single file."""
        try:
            relative_path = str(file_path.relative_to(workspace_root))
            file_hash = self._get_file_hash(file_path)
            language = self._detect_language(file_path)
            size_bytes = file_path.stat().st_size
            
            with sqlite3.connect(self.db_path) as conn:
                # Insert or update file record
                conn.execute("""
                    INSERT OR REPLACE INTO code_files 
                    (file_path, file_hash, language, size_bytes, last_indexed)
                    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (relative_path, file_hash, language, size_bytes))
                
                file_id = conn.lastrowid or conn.execute(
                    "SELECT id FROM code_files WHERE file_path = ?", (relative_path,)
                ).fetchone()[0]
                
                # Remove old symbols
                conn.execute("DELETE FROM code_symbols WHERE file_id = ?", (file_id,))
                
                # Extract and index symbols
                symbols = self._extract_symbols(file_path, language)
                for symbol in symbols:
                    conn.execute("""
                        INSERT INTO code_symbols 
                        (file_id, symbol_name, symbol_type, line_start, line_end, content, docstring)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (file_id, symbol['name'], symbol['type'], symbol['line_start'],
                          symbol['line_end'], symbol['content'], symbol.get('docstring')))
                
                # Index in vector database if available
                if EMBEDDING_AVAILABLE and self.collection:
                    await self._index_file_embeddings(file_path, relative_path, symbols)
                    
        except Exception as e:
            self.tool_logger.log_warning(f"Failed to index {file_path}: {e}")
    
    def _detect_language(self, file_path: Path) -> str:
        """Detect programming language from file extension."""
        extension_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.jsx': 'javascript',
            '.tsx': 'typescript',
            '.java': 'java',
            '.cpp': 'cpp',
            '.c': 'c',
            '.h': 'c',
            '.cs': 'csharp',
            '.php': 'php',
            '.rb': 'ruby',
            '.go': 'go',
            '.rs': 'rust',
            '.swift': 'swift',
            '.kt': 'kotlin',
            '.scala': 'scala',
            '.sh': 'bash',
            '.bash': 'bash',
            '.sql': 'sql',
            '.html': 'html',
            '.css': 'css',
            '.scss': 'scss',
            '.yaml': 'yaml',
            '.yml': 'yaml',
            '.json': 'json',
            '.xml': 'xml',
            '.md': 'markdown',
            '.rst': 'rst'
        }
        
        return extension_map.get(file_path.suffix.lower(), 'text')
    
    def _extract_symbols(self, file_path: Path, language: str) -> List[Dict[str, Any]]:
        """Extract symbols (functions, classes, etc.) from a file."""
        symbols = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
            
            if language == 'python':
                symbols = self._extract_python_symbols(content, lines)
            else:
                # Basic symbol extraction for other languages
                symbols = self._extract_basic_symbols(content, lines, language)
                
        except Exception as e:
            self.tool_logger.log_warning(f"Failed to extract symbols from {file_path}: {e}")
        
        return symbols
    
    def _extract_python_symbols(self, content: str, lines: List[str]) -> List[Dict[str, Any]]:
        """Extract Python symbols using AST."""
        symbols = []
        
        try:
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    symbols.append({
                        'name': node.name,
                        'type': 'function',
                        'line_start': node.lineno,
                        'line_end': getattr(node, 'end_lineno', node.lineno),
                        'content': '\n'.join(lines[node.lineno-1:getattr(node, 'end_lineno', node.lineno)]),
                        'docstring': ast.get_docstring(node)
                    })
                elif isinstance(node, ast.ClassDef):
                    symbols.append({
                        'name': node.name,
                        'type': 'class',
                        'line_start': node.lineno,
                        'line_end': getattr(node, 'end_lineno', node.lineno),
                        'content': '\n'.join(lines[node.lineno-1:getattr(node, 'end_lineno', node.lineno)]),
                        'docstring': ast.get_docstring(node)
                    })
                    
        except SyntaxError:
            # If AST parsing fails, fall back to basic extraction
            symbols = self._extract_basic_symbols('\n'.join(lines), lines, 'python')
        
        return symbols

    def _extract_basic_symbols(self, content: str, lines: List[str], language: str) -> List[Dict[str, Any]]:
        """Basic symbol extraction using regex patterns."""
        import re
        symbols = []

        patterns = {
            'python': [
                (r'^def\s+(\w+)', 'function'),
                (r'^class\s+(\w+)', 'class'),
                (r'^async\s+def\s+(\w+)', 'function'),
            ],
            'javascript': [
                (r'function\s+(\w+)', 'function'),
                (r'class\s+(\w+)', 'class'),
                (r'const\s+(\w+)\s*=\s*\(', 'function'),
                (r'(\w+)\s*:\s*function', 'function'),
            ],
            'java': [
                (r'public\s+class\s+(\w+)', 'class'),
                (r'private\s+class\s+(\w+)', 'class'),
                (r'public\s+\w+\s+(\w+)\s*\(', 'method'),
                (r'private\s+\w+\s+(\w+)\s*\(', 'method'),
            ]
        }

        lang_patterns = patterns.get(language, patterns.get('python', []))

        for i, line in enumerate(lines):
            for pattern, symbol_type in lang_patterns:
                match = re.search(pattern, line.strip())
                if match:
                    symbols.append({
                        'name': match.group(1),
                        'type': symbol_type,
                        'line_start': i + 1,
                        'line_end': i + 1,
                        'content': line.strip(),
                        'docstring': None
                    })

        return symbols

    async def _index_file_embeddings(self, file_path: Path, relative_path: str, symbols: List[Dict[str, Any]]) -> None:
        """Index file content in vector database."""
        if not EMBEDDING_AVAILABLE or not self.embedding_model:
            return

        try:
            # Create embeddings for symbols
            documents = []
            metadatas = []
            ids = []

            for i, symbol in enumerate(symbols):
                doc_text = f"{symbol['name']} {symbol['type']}"
                if symbol.get('docstring'):
                    doc_text += f" {symbol['docstring']}"
                if symbol.get('content'):
                    doc_text += f" {symbol['content']}"

                documents.append(doc_text)
                metadatas.append({
                    'file_path': relative_path,
                    'symbol_name': symbol['name'],
                    'symbol_type': symbol['type'],
                    'line_start': symbol['line_start'],
                    'line_end': symbol['line_end']
                })
                ids.append(f"{relative_path}:{symbol['name']}:{i}")

            if documents:
                # Remove existing embeddings for this file
                try:
                    existing_ids = self.collection.get(where={"file_path": relative_path})['ids']
                    if existing_ids:
                        self.collection.delete(ids=existing_ids)
                except Exception:
                    pass

                # Add new embeddings
                self.collection.add(
                    documents=documents,
                    metadatas=metadatas,
                    ids=ids
                )

        except Exception as e:
            self.tool_logger.log_warning(f"Failed to create embeddings for {file_path}: {e}")

    async def _search_codebase(self, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Search the codebase for relevant information."""
        results = []

        # Try semantic search first if available
        if EMBEDDING_AVAILABLE and self.collection:
            try:
                semantic_results = self.collection.query(
                    query_texts=[query],
                    n_results=min(max_results, 20)
                )

                for i, doc_id in enumerate(semantic_results['ids'][0]):
                    metadata = semantic_results['metadatas'][0][i]
                    distance = semantic_results['distances'][0][i]

                    results.append({
                        'type': 'semantic',
                        'file_path': metadata['file_path'],
                        'symbol_name': metadata['symbol_name'],
                        'symbol_type': metadata['symbol_type'],
                        'line_start': metadata['line_start'],
                        'line_end': metadata['line_end'],
                        'relevance_score': 1.0 - distance,
                        'content': semantic_results['documents'][0][i]
                    })
            except Exception as e:
                self.tool_logger.log_warning(f"Semantic search failed: {e}")

        # Fallback to keyword search
        keyword_results = await self._keyword_search(query, max_results)
        results.extend(keyword_results)

        # Remove duplicates and sort by relevance
        seen = set()
        unique_results = []
        for result in results:
            key = (result['file_path'], result['symbol_name'], result['line_start'])
            if key not in seen:
                seen.add(key)
                unique_results.append(result)

        # Sort by relevance score (higher is better)
        unique_results.sort(key=lambda x: x.get('relevance_score', 0), reverse=True)

        return unique_results[:max_results]

    async def _keyword_search(self, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Perform keyword-based search in the database."""
        results = []
        keywords = query.lower().split()

        with sqlite3.connect(self.db_path) as conn:
            # Search in symbol names
            for keyword in keywords:
                cursor = conn.execute("""
                    SELECT cf.file_path, cs.symbol_name, cs.symbol_type,
                           cs.line_start, cs.line_end, cs.content, cs.docstring
                    FROM code_symbols cs
                    JOIN code_files cf ON cs.file_id = cf.id
                    WHERE LOWER(cs.symbol_name) LIKE ?
                       OR LOWER(cs.content) LIKE ?
                       OR LOWER(cs.docstring) LIKE ?
                    ORDER BY
                        CASE WHEN LOWER(cs.symbol_name) = ? THEN 3
                             WHEN LOWER(cs.symbol_name) LIKE ? THEN 2
                             ELSE 1 END DESC
                    LIMIT ?
                """, (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%',
                      keyword, f'{keyword}%', max_results))

                for row in cursor.fetchall():
                    # Calculate simple relevance score
                    relevance_score = 0.1
                    symbol_name = row[1].lower()
                    if keyword == symbol_name:
                        relevance_score = 0.9
                    elif symbol_name.startswith(keyword):
                        relevance_score = 0.7
                    elif keyword in symbol_name:
                        relevance_score = 0.5

                    results.append({
                        'type': 'keyword',
                        'file_path': row[0],
                        'symbol_name': row[1],
                        'symbol_type': row[2],
                        'line_start': row[3],
                        'line_end': row[4],
                        'content': row[5] or '',
                        'docstring': row[6] or '',
                        'relevance_score': relevance_score
                    })

        return results

    def _format_search_results(self, results: List[Dict[str, Any]], query: str) -> str:
        """Format search results for display."""
        if not results:
            return f"No relevant code found for query: {query}"

        formatted = [f"# Codebase Search Results for: {query}\n"]

        for i, result in enumerate(results, 1):
            formatted.append(f"## {i}. {result['symbol_name']} ({result['symbol_type']})")
            formatted.append(f"**File:** {result['file_path']}")
            formatted.append(f"**Lines:** {result['line_start']}-{result['line_end']}")

            if result.get('relevance_score'):
                formatted.append(f"**Relevance:** {result['relevance_score']:.2f}")

            if result.get('docstring'):
                formatted.append(f"**Description:** {result['docstring']}")

            if result.get('content'):
                content = result['content']
                if len(content) > 500:
                    content = content[:500] + "..."

                # Apply syntax highlighting if available
                if SYNTAX_HIGHLIGHTING_AVAILABLE:
                    try:
                        lexer = guess_lexer_for_filename(result['file_path'], content)
                        highlighted = highlight(content, lexer, TerminalFormatter())
                        formatted.append(f"**Code:**\n```\n{highlighted}\n```")
                    except Exception:
                        formatted.append(f"**Code:**\n```\n{content}\n```")
                else:
                    formatted.append(f"**Code:**\n```\n{content}\n```")

            formatted.append("")

        return "\n".join(formatted)


class DiagnosticsTool(CodeAnalysisTool):
    """Tool for getting code diagnostics and issues."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("diagnostics")

    @property
    def name(self) -> str:
        return "diagnostics"

    @property
    def description(self) -> str:
        return "Get issues (errors, warnings, etc.) from code analysis tools."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of file paths to get issues for."
                }
            },
            "required": ["paths"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute diagnostics analysis."""
        self._ensure_initialized()
        self._validate_code_analysis_enabled()

        paths = kwargs["paths"]

        self.tool_logger.log_execution_start("diagnostics", paths=len(paths))

        try:
            all_issues = []

            for path in paths:
                abs_path = self.config.get_workspace_path(path)
                if abs_path.exists() and abs_path.is_file():
                    issues = await self._analyze_file(abs_path)
                    all_issues.extend(issues)

            # Format results
            formatted_results = self._format_diagnostic_results(all_issues)

            self.tool_logger.log_execution_success("diagnostics", f"Found {len(all_issues)} issues")
            return formatted_results

        except Exception as e:
            self.tool_logger.log_execution_error("diagnostics", e)
            raise

    async def _analyze_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """Analyze a single file for issues."""
        issues = []

        try:
            # Basic syntax checking for Python files
            if file_path.suffix == '.py':
                issues.extend(await self._check_python_syntax(file_path))

            # Add more language-specific checks here

        except Exception as e:
            issues.append({
                'file': str(file_path),
                'line': 1,
                'column': 1,
                'severity': 'error',
                'message': f"Failed to analyze file: {e}",
                'rule': 'analysis_error'
            })

        return issues

    async def _check_python_syntax(self, file_path: Path) -> List[Dict[str, Any]]:
        """Check Python file for syntax errors."""
        issues = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            try:
                ast.parse(content)
            except SyntaxError as e:
                issues.append({
                    'file': str(file_path),
                    'line': e.lineno or 1,
                    'column': e.offset or 1,
                    'severity': 'error',
                    'message': e.msg or 'Syntax error',
                    'rule': 'syntax_error'
                })
        except Exception as e:
            issues.append({
                'file': str(file_path),
                'line': 1,
                'column': 1,
                'severity': 'error',
                'message': f"Could not read file: {e}",
                'rule': 'file_error'
            })

        return issues

    def _format_diagnostic_results(self, issues: List[Dict[str, Any]]) -> str:
        """Format diagnostic results for display."""
        if not issues:
            return "No issues found."

        formatted = [f"# Code Diagnostics ({len(issues)} issues found)\n"]

        # Group by file
        by_file = {}
        for issue in issues:
            file_path = issue['file']
            if file_path not in by_file:
                by_file[file_path] = []
            by_file[file_path].append(issue)

        for file_path, file_issues in by_file.items():
            formatted.append(f"## {file_path}")

            for issue in file_issues:
                severity_icon = {
                    'error': '❌',
                    'warning': '⚠️',
                    'info': 'ℹ️'
                }.get(issue['severity'], '•')

                formatted.append(
                    f"{severity_icon} Line {issue['line']}, Column {issue['column']}: "
                    f"{issue['message']} ({issue['rule']})"
                )

            formatted.append("")

        return "\n".join(formatted)
