"""Cross-language code translator as specified in plan.md."""

import ast
import re
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

from .base import CodeAnalysisTool
from ..utils.logging import configure_tool_logging


class CodeTranslatorTool(CodeAnalysisTool):
    """Translate code between different programming languages."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("code-translator")
    
    @property
    def name(self) -> str:
        return "code-translator"
    
    @property
    def description(self) -> str:
        return "Translate code between different programming languages with intelligent mapping."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "source_code": {
                    "type": "string",
                    "description": "Source code to translate"
                },
                "source_language": {
                    "type": "string",
                    "enum": ["python", "javascript", "typescript", "java", "cpp", "go", "rust", "csharp"],
                    "description": "Source programming language"
                },
                "target_language": {
                    "type": "string",
                    "enum": ["python", "javascript", "typescript", "java", "cpp", "go", "rust", "csharp"],
                    "description": "Target programming language"
                },
                "translation_style": {
                    "type": "string",
                    "enum": ["literal", "idiomatic", "modern"],
                    "description": "Translation style to use",
                    "default": "idiomatic"
                },
                "preserve_comments": {
                    "type": "boolean",
                    "description": "Preserve comments in translation",
                    "default": true
                },
                "add_type_hints": {
                    "type": "boolean",
                    "description": "Add type hints where applicable",
                    "default": true
                }
            },
            "required": ["source_code", "source_language", "target_language"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute code translation."""
        self._ensure_initialized()
        
        source_code = kwargs["source_code"]
        source_language = kwargs["source_language"]
        target_language = kwargs["target_language"]
        translation_style = kwargs.get("translation_style", "idiomatic")
        preserve_comments = kwargs.get("preserve_comments", True)
        add_type_hints = kwargs.get("add_type_hints", True)
        
        self.tool_logger.log_execution_start("code_translator", 
                                           source=source_language,
                                           target=target_language)
        
        try:
            # Parse source code
            parsed_code = await self._parse_source_code(source_code, source_language)
            
            # Translate to target language
            translated_code = await self._translate_code(
                parsed_code, source_language, target_language,
                translation_style, preserve_comments, add_type_hints
            )
            
            # Format result
            result = self._format_translation_result(
                source_code, translated_code, source_language, target_language
            )
            
            self.tool_logger.log_execution_success("code_translator", "Translation completed")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("code_translator", e)
            raise
    
    async def _parse_source_code(self, code: str, language: str) -> Dict[str, Any]:
        """Parse source code into structured representation."""
        parsed = {
            'language': language,
            'raw_code': code,
            'functions': [],
            'classes': [],
            'variables': [],
            'imports': [],
            'comments': [],
            'structure': {}
        }
        
        if language == 'python':
            parsed.update(await self._parse_python(code))
        elif language in ['javascript', 'typescript']:
            parsed.update(await self._parse_javascript(code))
        elif language == 'java':
            parsed.update(await self._parse_java(code))
        elif language == 'cpp':
            parsed.update(await self._parse_cpp(code))
        else:
            # Generic parsing
            parsed.update(await self._parse_generic(code))
        
        return parsed
    
    async def _parse_python(self, code: str) -> Dict[str, Any]:
        """Parse Python code using AST."""
        result = {'functions': [], 'classes': [], 'variables': [], 'imports': []}
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    func_info = {
                        'name': node.name,
                        'args': [arg.arg for arg in node.args.args],
                        'returns': getattr(node.returns, 'id', None) if node.returns else None,
                        'is_async': isinstance(node, ast.AsyncFunctionDef),
                        'docstring': ast.get_docstring(node),
                        'line_start': node.lineno,
                        'line_end': getattr(node, 'end_lineno', node.lineno)
                    }
                    result['functions'].append(func_info)
                
                elif isinstance(node, ast.ClassDef):
                    class_info = {
                        'name': node.name,
                        'bases': [base.id for base in node.bases if hasattr(base, 'id')],
                        'methods': [],
                        'docstring': ast.get_docstring(node),
                        'line_start': node.lineno,
                        'line_end': getattr(node, 'end_lineno', node.lineno)
                    }
                    
                    # Extract methods
                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            class_info['methods'].append(item.name)
                    
                    result['classes'].append(class_info)
                
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            result['imports'].append({
                                'module': alias.name,
                                'alias': alias.asname,
                                'type': 'import'
                            })
                    else:
                        module = node.module or ''
                        for alias in node.names:
                            result['imports'].append({
                                'module': module,
                                'name': alias.name,
                                'alias': alias.asname,
                                'type': 'from_import'
                            })
                
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            result['variables'].append({
                                'name': target.id,
                                'line': node.lineno,
                                'type': 'assignment'
                            })
        
        except SyntaxError as e:
            self.tool_logger.log_warning(f"Python parsing failed: {e}")
        
        return result
    
    async def _parse_javascript(self, code: str) -> Dict[str, Any]:
        """Parse JavaScript/TypeScript code using regex patterns."""
        result = {'functions': [], 'classes': [], 'variables': [], 'imports': []}
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Function declarations
            func_match = re.search(r'function\s+(\w+)\s*\(([^)]*)\)', line)
            if func_match:
                result['functions'].append({
                    'name': func_match.group(1),
                    'args': [arg.strip() for arg in func_match.group(2).split(',') if arg.strip()],
                    'line': i,
                    'type': 'function'
                })
            
            # Arrow functions
            arrow_match = re.search(r'const\s+(\w+)\s*=\s*\(([^)]*)\)\s*=>', line)
            if arrow_match:
                result['functions'].append({
                    'name': arrow_match.group(1),
                    'args': [arg.strip() for arg in arrow_match.group(2).split(',') if arg.strip()],
                    'line': i,
                    'type': 'arrow_function'
                })
            
            # Class declarations
            class_match = re.search(r'class\s+(\w+)(?:\s+extends\s+(\w+))?', line)
            if class_match:
                result['classes'].append({
                    'name': class_match.group(1),
                    'extends': class_match.group(2),
                    'line': i
                })
            
            # Variable declarations
            var_match = re.search(r'(const|let|var)\s+(\w+)', line)
            if var_match:
                result['variables'].append({
                    'name': var_match.group(2),
                    'type': var_match.group(1),
                    'line': i
                })
            
            # Import statements
            import_match = re.search(r'import\s+(.+?)\s+from\s+[\'"](.+?)[\'"]', line)
            if import_match:
                result['imports'].append({
                    'imports': import_match.group(1),
                    'module': import_match.group(2),
                    'line': i
                })
        
        return result
    
    async def _parse_java(self, code: str) -> Dict[str, Any]:
        """Parse Java code using regex patterns."""
        result = {'functions': [], 'classes': [], 'variables': [], 'imports': []}
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Method declarations
            method_match = re.search(r'(public|private|protected)?\s*(static)?\s*(\w+)\s+(\w+)\s*\(([^)]*)\)', line)
            if method_match and not line.strip().startswith('//'):
                result['functions'].append({
                    'name': method_match.group(4),
                    'return_type': method_match.group(3),
                    'visibility': method_match.group(1),
                    'is_static': bool(method_match.group(2)),
                    'args': [arg.strip() for arg in method_match.group(5).split(',') if arg.strip()],
                    'line': i
                })
            
            # Class declarations
            class_match = re.search(r'(public|private)?\s*class\s+(\w+)(?:\s+extends\s+(\w+))?', line)
            if class_match:
                result['classes'].append({
                    'name': class_match.group(2),
                    'visibility': class_match.group(1),
                    'extends': class_match.group(3),
                    'line': i
                })
            
            # Import statements
            import_match = re.search(r'import\s+(.+?);', line)
            if import_match:
                result['imports'].append({
                    'module': import_match.group(1),
                    'line': i
                })
        
        return result
    
    async def _parse_cpp(self, code: str) -> Dict[str, Any]:
        """Parse C++ code using regex patterns."""
        result = {'functions': [], 'classes': [], 'variables': [], 'imports': []}
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Function declarations
            func_match = re.search(r'(\w+)\s+(\w+)\s*\(([^)]*)\)', line)
            if func_match and '{' in line:
                result['functions'].append({
                    'name': func_match.group(2),
                    'return_type': func_match.group(1),
                    'args': [arg.strip() for arg in func_match.group(3).split(',') if arg.strip()],
                    'line': i
                })
            
            # Class declarations
            class_match = re.search(r'class\s+(\w+)', line)
            if class_match:
                result['classes'].append({
                    'name': class_match.group(1),
                    'line': i
                })
            
            # Include statements
            include_match = re.search(r'#include\s*[<"](.+?)[>"]', line)
            if include_match:
                result['imports'].append({
                    'module': include_match.group(1),
                    'line': i
                })
        
        return result
    
    async def _parse_generic(self, code: str) -> Dict[str, Any]:
        """Generic parsing for unsupported languages."""
        return {
            'functions': [],
            'classes': [],
            'variables': [],
            'imports': [],
            'lines': code.split('\n')
        }
    
    async def _translate_code(self, parsed_code: Dict[str, Any], source_lang: str, 
                            target_lang: str, style: str, preserve_comments: bool,
                            add_type_hints: bool) -> str:
        """Translate parsed code to target language."""
        
        if source_lang == target_lang:
            return parsed_code['raw_code']
        
        # Get translation mapping
        translation_map = self._get_translation_mapping(source_lang, target_lang)
        
        # Translate different components
        translated_parts = []
        
        # Translate imports
        if parsed_code['imports']:
            translated_parts.append(self._translate_imports(parsed_code['imports'], translation_map))
        
        # Translate classes
        for class_info in parsed_code['classes']:
            translated_parts.append(self._translate_class(class_info, translation_map, style))
        
        # Translate functions
        for func_info in parsed_code['functions']:
            translated_parts.append(self._translate_function(func_info, translation_map, style, add_type_hints))
        
        # Translate variables
        for var_info in parsed_code['variables']:
            translated_parts.append(self._translate_variable(var_info, translation_map))
        
        return '\n\n'.join(filter(None, translated_parts))
    
    def _get_translation_mapping(self, source_lang: str, target_lang: str) -> Dict[str, Any]:
        """Get translation mapping between languages."""
        mappings = {
            ('python', 'javascript'): {
                'print': 'console.log',
                'len': 'length',
                'str': 'String',
                'int': 'parseInt',
                'float': 'parseFloat',
                'True': 'true',
                'False': 'false',
                'None': 'null',
                'def': 'function',
                'class': 'class',
                'self': 'this'
            },
            ('javascript', 'python'): {
                'console.log': 'print',
                'length': 'len',
                'String': 'str',
                'parseInt': 'int',
                'parseFloat': 'float',
                'true': 'True',
                'false': 'False',
                'null': 'None',
                'function': 'def',
                'this': 'self'
            },
            ('python', 'java'): {
                'print': 'System.out.println',
                'len': 'length',
                'str': 'String',
                'int': 'Integer.parseInt',
                'True': 'true',
                'False': 'false',
                'None': 'null',
                'def': 'public static',
                'self': 'this'
            }
        }
        
        return mappings.get((source_lang, target_lang), {})
    
    def _translate_function(self, func_info: Dict[str, Any], translation_map: Dict[str, Any], 
                          style: str, add_type_hints: bool) -> str:
        """Translate a function to target language."""
        name = func_info['name']
        args = func_info.get('args', [])
        
        # Basic function translation patterns
        if 'def' in translation_map:
            if translation_map['def'] == 'function':
                # Python to JavaScript
                args_str = ', '.join(args)
                return f"function {name}({args_str}) {{\n    // Function body\n}}"
            elif translation_map['def'] == 'public static':
                # Python to Java
                args_str = ', '.join(f"Object {arg}" for arg in args)
                return f"public static void {name}({args_str}) {{\n    // Function body\n}}"
        
        return f"// TODO: Translate function {name}"
    
    def _translate_class(self, class_info: Dict[str, Any], translation_map: Dict[str, Any], 
                        style: str) -> str:
        """Translate a class to target language."""
        name = class_info['name']
        
        # Basic class translation
        return f"class {name} {{\n    // Class body\n}}"
    
    def _translate_variable(self, var_info: Dict[str, Any], translation_map: Dict[str, Any]) -> str:
        """Translate a variable declaration."""
        name = var_info['name']
        var_type = var_info.get('type', 'var')
        
        # Basic variable translation
        if var_type in ['const', 'let', 'var']:
            return f"let {name};"
        else:
            return f"{name} = None  # TODO: Set appropriate value"
    
    def _translate_imports(self, imports: List[Dict[str, Any]], translation_map: Dict[str, Any]) -> str:
        """Translate import statements."""
        translated_imports = []
        
        for import_info in imports:
            module = import_info.get('module', '')
            
            # Basic import translation
            if import_info.get('type') == 'import':
                translated_imports.append(f"// import {module}")
            elif import_info.get('type') == 'from_import':
                name = import_info.get('name', '')
                translated_imports.append(f"// from {module} import {name}")
        
        return '\n'.join(translated_imports)
    
    def _format_translation_result(self, source_code: str, translated_code: str, 
                                 source_lang: str, target_lang: str) -> str:
        """Format the translation result."""
        return f"""# Code Translation Result

## Source ({source_lang.title()})
```{source_lang}
{source_code}
```

## Translated ({target_lang.title()})
```{target_lang}
{translated_code}
```

## Translation Notes
- This is an automated translation and may require manual review
- Some language-specific idioms may not translate directly
- Consider reviewing and optimizing for the target language's best practices
- Test the translated code thoroughly before use
"""
