"""File operation tools for Augment Agent."""

import os
import re
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
import tempfile
from datetime import datetime

from .base import FileOperationTool
from ..utils.logging import configure_tool_logging


class StrReplaceEditorTool(FileOperationTool):
    """Tool for editing files with string replacement and insertion."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("str-replace-editor")

    @property
    def name(self) -> str:
        return "str-replace-editor"

    @property
    def description(self) -> str:
        return "Tool for editing files with line-based string replacement and insertion capabilities."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "enum": ["str_replace", "insert"],
                    "description": "The command to run. 'str_replace' for replacements, 'insert' for insertions."
                },
                "path": {
                    "type": "string",
                    "description": "Full path to file relative to the workspace root."
                },
                "instruction_reminder": {
                    "type": "string",
                    "description": "Reminder to limit edits to at most 150 lines."
                },
                # String replacement parameters
                "old_str_1": {"type": "string", "description": "String to replace (first replacement)."},
                "new_str_1": {"type": "string", "description": "Replacement string (first replacement)."},
                "old_str_start_line_number_1": {"type": "integer", "description": "Start line number for first replacement."},
                "old_str_end_line_number_1": {"type": "integer", "description": "End line number for first replacement."},
                # Additional replacement parameters (up to 5)
                "old_str_2": {"type": "string", "description": "String to replace (second replacement)."},
                "new_str_2": {"type": "string", "description": "Replacement string (second replacement)."},
                "old_str_start_line_number_2": {"type": "integer", "description": "Start line number for second replacement."},
                "old_str_end_line_number_2": {"type": "integer", "description": "End line number for second replacement."},
                # Insert parameters (note: these use different parameter names to avoid conflicts)
                "insert_line_1": {"type": "integer", "description": "Line number after which to insert (first insertion)."},
                "insert_str_1": {"type": "string", "description": "String to insert (first insertion)."},
                "insert_line_2": {"type": "integer", "description": "Line number after which to insert (second insertion)."},
                "insert_str_2": {"type": "string", "description": "String to insert (second insertion)."},
            },
            "required": ["command", "path", "instruction_reminder"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute the file editing operation."""
        self._ensure_initialized()
        
        command = kwargs["command"]
        path = kwargs["path"]
        
        self.tool_logger.log_execution_start("file_edit", command=command, path=path)
        
        try:
            abs_path = self._get_absolute_path(path)
            
            # Create backup if enabled
            backup_path = None
            if self.config.auto_backup_before_edits and Path(abs_path).exists():
                backup_path = self._create_backup(abs_path)
            
            if command == "str_replace":
                result = await self._handle_str_replace(abs_path, kwargs)
            elif command == "insert":
                result = await self._handle_insert(abs_path, kwargs)
            else:
                raise ValueError(f"Unknown command: {command}")
            
            self.tool_logger.log_execution_success("file_edit", f"Modified {path}")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("file_edit", e)
            raise
    
    async def _handle_str_replace(self, file_path: str, params: Dict[str, Any]) -> str:
        """Handle string replacement operations."""
        if not Path(file_path).exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Read file content
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Collect all replacement operations
        replacements = []
        for i in range(1, 6):  # Support up to 5 replacements
            old_str_key = f"old_str_{i}"
            new_str_key = f"new_str_{i}"
            start_line_key = f"old_str_start_line_number_{i}"
            end_line_key = f"old_str_end_line_number_{i}"
            
            if old_str_key in params and new_str_key in params:
                replacements.append({
                    "old_str": params[old_str_key],
                    "new_str": params[new_str_key],
                    "start_line": params.get(start_line_key),
                    "end_line": params.get(end_line_key)
                })
        
        if not replacements:
            raise ValueError("No replacement operations specified")
        
        # Sort replacements by line number (descending) to avoid line number shifts
        replacements.sort(key=lambda x: x.get("start_line", 0), reverse=True)
        
        # Apply replacements
        modified_lines = lines[:]
        results = []
        
        for replacement in replacements:
            old_str = replacement["old_str"]
            new_str = replacement["new_str"]
            start_line = replacement.get("start_line")
            end_line = replacement.get("end_line")
            
            if start_line is not None and end_line is not None:
                # Line-based replacement
                start_idx = start_line - 1  # Convert to 0-based
                end_idx = end_line  # end_line is inclusive
                
                if start_idx < 0 or end_idx > len(modified_lines):
                    raise ValueError(f"Line range {start_line}-{end_line} is out of bounds")
                
                # Extract the target text
                target_text = "".join(modified_lines[start_idx:end_idx])
                
                if old_str not in target_text:
                    raise ValueError(f"String not found in specified line range: {old_str[:50]}...")
                
                # Replace the text
                new_text = target_text.replace(old_str, new_str)
                new_lines = new_text.splitlines(keepends=True)
                
                # Update the lines
                modified_lines[start_idx:end_idx] = new_lines
                
                results.append(f"Replaced text at lines {start_line}-{end_line}")
            else:
                # Global replacement (fallback)
                content = "".join(modified_lines)
                if old_str not in content:
                    raise ValueError(f"String not found in file: {old_str[:50]}...")
                
                new_content = content.replace(old_str, new_str)
                modified_lines = new_content.splitlines(keepends=True)
                
                results.append("Replaced text globally")
        
        # Write the modified content
        with open(file_path, 'w', encoding='utf-8') as f:
            f.writelines(modified_lines)
        
        return f"File edited successfully. {'; '.join(results)}"
    
    async def _handle_insert(self, file_path: str, params: Dict[str, Any]) -> str:
        """Handle insertion operations."""
        # Read existing content or create empty if file doesn't exist
        if Path(file_path).exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        else:
            lines = []
        
        # Collect all insertion operations
        insertions = []
        for i in range(1, 6):  # Support up to 5 insertions
            insert_line_key = f"insert_line_{i}"
            insert_str_key = f"insert_str_{i}"

            if insert_line_key in params and insert_str_key in params:
                insertions.append({
                    "insert_line": params[insert_line_key],
                    "new_str": params[insert_str_key]
                })
        
        if not insertions:
            raise ValueError("No insertion operations specified")
        
        # Sort insertions by line number (descending) to avoid line number shifts
        insertions.sort(key=lambda x: x["insert_line"], reverse=True)
        
        # Apply insertions
        modified_lines = lines[:]
        results = []
        
        for insertion in insertions:
            insert_line = insertion["insert_line"]
            new_str = insertion["new_str"]
            
            # Ensure new_str ends with newline if it doesn't already
            if new_str and not new_str.endswith('\n'):
                new_str += '\n'
            
            if insert_line == 0:
                # Insert at beginning
                modified_lines.insert(0, new_str)
                results.append("Inserted at beginning of file")
            elif insert_line >= len(modified_lines):
                # Insert at end
                modified_lines.append(new_str)
                results.append("Inserted at end of file")
            else:
                # Insert after specified line
                modified_lines.insert(insert_line, new_str)
                results.append(f"Inserted after line {insert_line}")
        
        # Ensure parent directory exists
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Write the modified content
        with open(file_path, 'w', encoding='utf-8') as f:
            f.writelines(modified_lines)
        
        return f"File edited successfully. {'; '.join(results)}"
    
    def _create_backup(self, file_path: str) -> str:
        """Create a backup of the file before editing."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"{file_path}.backup_{timestamp}"
        shutil.copy2(file_path, backup_path)
        self.tool_logger.log_info(f"Created backup: {backup_path}")
        return backup_path


class SaveFileTool(FileOperationTool):
    """Tool for saving new files with content."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("save-file")

    @property
    def name(self) -> str:
        return "save-file"

    @property
    def description(self) -> str:
        return "Save a new file with the provided content. Cannot modify existing files."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "The path of the file to save."
                },
                "file_content": {
                    "type": "string",
                    "description": "The content of the file."
                },
                "instructions_reminder": {
                    "type": "string",
                    "description": "Reminder to limit file content to at most 300 lines."
                },
                "add_last_line_newline": {
                    "type": "boolean",
                    "description": "Whether to add a newline at the end of the file (default: true).",
                    "default": True
                }
            },
            "required": ["path", "file_content", "instructions_reminder"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute the file saving operation."""
        self._ensure_initialized()

        path = kwargs["path"]
        content = kwargs["file_content"]
        add_newline = kwargs.get("add_last_line_newline", True)

        self.tool_logger.log_execution_start("save_file", path=path)

        try:
            abs_path = self._get_absolute_path(path)

            # Check if file already exists
            if Path(abs_path).exists():
                raise ValueError(f"File already exists: {path}. Use str-replace-editor to modify existing files.")

            # Validate content length (300 lines limit)
            lines = content.splitlines()
            if len(lines) > 300:
                raise ValueError(f"File content exceeds 300 lines limit ({len(lines)} lines)")

            # Ensure parent directory exists
            Path(abs_path).parent.mkdir(parents=True, exist_ok=True)

            # Add final newline if requested and not present
            if add_newline and content and not content.endswith('\n'):
                content += '\n'

            # Write the file
            with open(abs_path, 'w', encoding='utf-8') as f:
                f.write(content)

            self.tool_logger.log_execution_success("save_file", f"Saved {path} ({len(lines)} lines)")
            return f"File saved successfully: {path}"

        except Exception as e:
            self.tool_logger.log_execution_error("save_file", e)
            raise


class ViewTool(FileOperationTool):
    """Tool for viewing files and directories with search capabilities."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("view")

    @property
    def name(self) -> str:
        return "view"

    @property
    def description(self) -> str:
        return "View files and directories with regex search, range viewing, and directory listing capabilities."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Full path to file or directory relative to the workspace root."
                },
                "type": {
                    "type": "string",
                    "enum": ["file", "directory"],
                    "description": "Type of path to view."
                },
                "view_range": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Optional line range for files [start_line, end_line]. Use -1 for end to show to end of file."
                },
                "search_query_regex": {
                    "type": "string",
                    "description": "Optional regex pattern to search for in files."
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Whether regex search should be case-sensitive.",
                    "default": False
                },
                "context_lines_before": {
                    "type": "integer",
                    "description": "Number of lines to show before each regex match.",
                    "default": 5
                },
                "context_lines_after": {
                    "type": "integer",
                    "description": "Number of lines to show after each regex match.",
                    "default": 5
                }
            },
            "required": ["path", "type"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute the view operation."""
        self._ensure_initialized()

        path = kwargs["path"]
        path_type = kwargs["type"]

        self.tool_logger.log_execution_start("view", path=path, type=path_type)

        try:
            abs_path = self._get_absolute_path(path)

            if path_type == "file":
                result = await self._view_file(abs_path, kwargs)
            elif path_type == "directory":
                result = await self._view_directory(abs_path)
            else:
                raise ValueError(f"Invalid type: {path_type}")

            self.tool_logger.log_execution_success("view", f"Viewed {path}")
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("view", e)
            raise

    async def _view_file(self, file_path: str, params: Dict[str, Any]) -> str:
        """View a file with optional range and search."""
        if not Path(file_path).exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Validate file size
        self._validate_file_size(file_path)

        # Read file content
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        except UnicodeDecodeError:
            # Try with different encoding or treat as binary
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    lines = f.readlines()
            except Exception:
                return f"Binary file (cannot display content): {file_path}"

        # Apply search filter if provided
        search_query = params.get("search_query_regex")
        if search_query:
            return self._search_in_lines(lines, search_query, params)

        # Apply range filter if provided
        view_range = params.get("view_range")
        if view_range:
            start_line, end_line = view_range
            if end_line == -1:
                end_line = len(lines)

            # Convert to 0-based indexing
            start_idx = max(0, start_line - 1)
            end_idx = min(len(lines), end_line)

            lines = lines[start_idx:end_idx]

            # Add line numbers
            result_lines = []
            for i, line in enumerate(lines, start=start_line):
                result_lines.append(f"{i:4d}: {line.rstrip()}")

            return "\n".join(result_lines)

        # Return full file with line numbers
        result_lines = []
        for i, line in enumerate(lines, start=1):
            result_lines.append(f"{i:4d}: {line.rstrip()}")

        content = "\n".join(result_lines)

        # Truncate if too long
        if len(content) > 50000:  # 50KB limit
            content = content[:50000] + "\n\n<response clipped - file too large>"

        return content

    def _search_in_lines(self, lines: List[str], pattern: str, params: Dict[str, Any]) -> str:
        """Search for pattern in lines and return matches with context."""
        case_sensitive = params.get("case_sensitive", False)
        context_before = params.get("context_lines_before", 5)
        context_after = params.get("context_lines_after", 5)

        # Compile regex pattern
        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            regex = re.compile(pattern, flags)
        except re.error as e:
            raise ValueError(f"Invalid regex pattern: {e}")

        # Find matches
        matches = []
        for i, line in enumerate(lines):
            if regex.search(line):
                matches.append(i)

        if not matches:
            return f"No matches found for pattern: {pattern}"

        # Build result with context
        result_lines = []
        covered_lines = set()

        for match_line in matches:
            start = max(0, match_line - context_before)
            end = min(len(lines), match_line + context_after + 1)

            # Add separator if there's a gap
            if result_lines and start > max(covered_lines) + 1:
                result_lines.append("...")

            # Add lines with context
            for i in range(start, end):
                if i not in covered_lines:
                    line_num = i + 1
                    marker = ">>> " if i == match_line else "    "
                    result_lines.append(f"{marker}{line_num:4d}: {lines[i].rstrip()}")
                    covered_lines.add(i)

        return "\n".join(result_lines)

    async def _view_directory(self, dir_path: str) -> str:
        """View directory contents up to 2 levels deep."""
        if not Path(dir_path).exists():
            raise FileNotFoundError(f"Directory not found: {dir_path}")

        if not Path(dir_path).is_dir():
            raise ValueError(f"Path is not a directory: {dir_path}")

        result_lines = [f"Directory: {dir_path}"]

        try:
            # Get directory contents
            items = []
            for item in Path(dir_path).iterdir():
                if item.is_dir():
                    items.append(f"📁 {item.name}/")

                    # Add subdirectory contents (1 level deep)
                    try:
                        sub_items = []
                        for sub_item in item.iterdir():
                            if sub_item.is_dir():
                                sub_items.append(f"  📁 {sub_item.name}/")
                            else:
                                size = sub_item.stat().st_size
                                size_str = self._format_file_size(size)
                                sub_items.append(f"  📄 {sub_item.name} ({size_str})")

                        # Limit subdirectory items
                        if len(sub_items) > 20:
                            sub_items = sub_items[:20] + [f"  ... and {len(sub_items) - 20} more items"]

                        items.extend(sub_items)
                    except PermissionError:
                        items.append(f"  [Permission Denied]")
                else:
                    size = item.stat().st_size
                    size_str = self._format_file_size(size)
                    items.append(f"📄 {item.name} ({size_str})")

            # Sort items
            items.sort()

            # Limit total items
            if len(items) > 100:
                items = items[:100] + [f"... and {len(items) - 100} more items"]

            result_lines.extend(items)

        except PermissionError:
            result_lines.append("[Permission Denied]")

        return "\n".join(result_lines)

    def _format_file_size(self, size: int) -> str:
        """Format file size in human-readable format."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f}{unit}"
            size /= 1024
        return f"{size:.1f}TB"


class RemoveFilesTool(FileOperationTool):
    """Tool for safely removing files."""

    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("remove-files")

    @property
    def name(self) -> str:
        return "remove-files"

    @property
    def description(self) -> str:
        return "Remove files safely. Only use this tool to delete files in the user's workspace."

    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "file_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "The paths of the files to remove."
                }
            },
            "required": ["file_paths"]
        }

    async def execute(self, **kwargs) -> str:
        """Execute the file removal operation."""
        self._ensure_initialized()

        file_paths = kwargs["file_paths"]

        self.tool_logger.log_execution_start("remove_files", count=len(file_paths))

        try:
            # Require confirmation for destructive actions
            if self.config.require_confirmation_for_destructive_actions:
                # In a real implementation, you'd prompt the user here
                # For now, we'll just log the requirement
                self.tool_logger.log_warning("Destructive action requires confirmation")

            removed_files = []
            errors = []

            for file_path in file_paths:
                try:
                    abs_path = self._get_absolute_path(file_path)

                    if not Path(abs_path).exists():
                        errors.append(f"File not found: {file_path}")
                        continue

                    if Path(abs_path).is_dir():
                        errors.append(f"Cannot remove directory (use appropriate directory removal tool): {file_path}")
                        continue

                    # Create backup if enabled
                    if self.config.auto_backup_before_edits:
                        backup_path = self._create_backup(abs_path)
                        self.tool_logger.log_info(f"Created backup before removal: {backup_path}")

                    # Remove the file
                    os.remove(abs_path)
                    removed_files.append(file_path)

                except Exception as e:
                    errors.append(f"Failed to remove {file_path}: {str(e)}")

            # Build result message
            result_parts = []
            if removed_files:
                result_parts.append(f"Successfully removed {len(removed_files)} files: {', '.join(removed_files)}")

            if errors:
                result_parts.append(f"Errors: {'; '.join(errors)}")

            result = "; ".join(result_parts) if result_parts else "No files were removed"

            self.tool_logger.log_execution_success("remove_files", f"Removed {len(removed_files)} files")
            return result

        except Exception as e:
            self.tool_logger.log_execution_error("remove_files", e)
            raise

    def _create_backup(self, file_path: str) -> str:
        """Create a backup of the file before removal."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = Path(self.config.data_dir) / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)

        file_name = Path(file_path).name
        backup_path = backup_dir / f"{file_name}.backup_{timestamp}"

        shutil.copy2(file_path, backup_path)
        return str(backup_path)
