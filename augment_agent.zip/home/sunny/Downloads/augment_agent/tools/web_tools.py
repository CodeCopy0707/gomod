"""Web and network tools for Augment Agent."""

import asyncio
import webbrowser
import subprocess
from typing import Dict, Any, List
from urllib.parse import urlparse, quote_plus
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import html2text

from .base import WebTool
from ..utils.logging import configure_tool_logging


class WebSearchTool(WebTool):
    """Tool for searching the web using Google Custom Search."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("web-search")
    
    @property
    def name(self) -> str:
        return "web-search"
    
    @property
    def description(self) -> str:
        return "Search the web for information using Google Custom Search API."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to send."
                },
                "num_results": {
                    "type": "integer",
                    "description": "Number of results to return (1-10).",
                    "minimum": 1,
                    "maximum": 10,
                    "default": 5
                }
            },
            "required": ["query"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute web search."""
        self._ensure_initialized()
        self._validate_web_enabled()
        
        query = kwargs["query"]
        num_results = kwargs.get("num_results", 5)
        
        self.tool_logger.log_execution_start("web_search", query=query[:50])
        
        try:
            if not self.config.google_search_api_key or not self.config.google_search_engine_id:
                # Fallback to DuckDuckGo or basic search
                return await self._fallback_search(query, num_results)
            
            # Use Google Custom Search API
            results = await self._google_search(query, num_results)
            
            # Format results
            formatted_results = self._format_search_results(results)
            
            self.tool_logger.log_execution_success("web_search", f"Found {len(results)} results")
            return formatted_results
            
        except Exception as e:
            self.tool_logger.log_execution_error("web_search", e)
            raise
    
    async def _google_search(self, query: str, num_results: int) -> List[Dict[str, Any]]:
        """Perform Google Custom Search."""
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            "key": self.config.google_search_api_key,
            "cx": self.config.google_search_engine_id,
            "q": query,
            "num": num_results
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        results = []
        for item in data.get("items", []):
            results.append({
                "title": item.get("title", ""),
                "url": item.get("link", ""),
                "snippet": item.get("snippet", "")
            })
        
        return results
    
    async def _fallback_search(self, query: str, num_results: int) -> str:
        """Fallback search method when Google API is not available."""
        # This is a simplified fallback - in practice, you might use DuckDuckGo API
        # or scrape search results (following robots.txt and terms of service)
        
        self.tool_logger.log_warning("Google Search API not configured, using fallback method")
        
        # For now, return a message indicating the limitation
        return f"""Web search functionality requires Google Custom Search API configuration.

Query: {query}
Requested results: {num_results}

To enable web search:
1. Get a Google Custom Search API key from Google Cloud Console
2. Create a Custom Search Engine at https://cse.google.com/
3. Set GOOGLE_SEARCH_API_KEY and GOOGLE_SEARCH_ENGINE_ID environment variables

Alternative: You can manually search for "{query}" in your browser."""
    
    def _format_search_results(self, results: List[Dict[str, Any]]) -> str:
        """Format search results as markdown."""
        if not results:
            return "No search results found."
        
        formatted = ["# Search Results\n"]
        
        for i, result in enumerate(results, 1):
            title = result.get("title", "No title")
            url = result.get("url", "")
            snippet = result.get("snippet", "No description available")
            
            formatted.append(f"## {i}. {title}")
            formatted.append(f"**URL:** {url}")
            formatted.append(f"**Description:** {snippet}")
            formatted.append("")
        
        return "\n".join(formatted)


class WebFetchTool(WebTool):
    """Tool for fetching webpage content and converting to markdown."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("web-fetch")
    
    @property
    def name(self) -> str:
        return "web-fetch"
    
    @property
    def description(self) -> str:
        return "Fetch webpage content and convert it to markdown format."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch."
                }
            },
            "required": ["url"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute web fetch."""
        self._ensure_initialized()
        self._validate_web_enabled()
        
        url = kwargs["url"]
        
        self.tool_logger.log_execution_start("web_fetch", url=url)
        
        try:
            # Validate URL
            parsed_url = urlparse(url)
            if not parsed_url.scheme or not parsed_url.netloc:
                raise ValueError(f"Invalid URL: {url}")
            
            # Fetch the webpage
            headers = {
                "User-Agent": self._get_user_agent(),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate",
                "Connection": "keep-alive",
            }
            
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # Convert to markdown
            markdown_content = self._html_to_markdown(response.text, url)
            
            self.tool_logger.log_execution_success("web_fetch", f"Fetched {len(markdown_content)} characters")
            return markdown_content
            
        except Exception as e:
            self.tool_logger.log_execution_error("web_fetch", e)
            raise
    
    def _html_to_markdown(self, html_content: str, url: str) -> str:
        """Convert HTML content to markdown."""
        try:
            # Parse HTML with BeautifulSoup
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style", "nav", "footer", "aside"]):
                script.decompose()
            
            # Convert to markdown using html2text
            h = html2text.HTML2Text()
            h.ignore_links = False
            h.ignore_images = False
            h.ignore_emphasis = False
            h.body_width = 0  # Don't wrap lines
            h.unicode_snob = True
            
            markdown = h.handle(str(soup))
            
            # Add metadata header
            header = f"# Webpage Content\n\n**URL:** {url}\n**Fetched:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n---\n\n"
            
            return header + markdown
            
        except Exception as e:
            # Fallback to simple text extraction
            soup = BeautifulSoup(html_content, 'html.parser')
            text = soup.get_text()
            
            # Clean up whitespace
            lines = [line.strip() for line in text.splitlines()]
            text = '\n'.join(line for line in lines if line)
            
            header = f"# Webpage Content (Text Only)\n\n**URL:** {url}\n**Note:** HTML parsing failed, showing text content only\n\n---\n\n"
            
            return header + text


class OpenBrowserTool(WebTool):
    """Tool for opening URLs in the default browser."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("open-browser")
    
    @property
    def name(self) -> str:
        return "open-browser"
    
    @property
    def description(self) -> str:
        return "Open a URL in the default browser."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to open in the browser."
                }
            },
            "required": ["url"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute browser opening."""
        self._ensure_initialized()
        
        url = kwargs["url"]
        
        self.tool_logger.log_execution_start("open_browser", url=url)
        
        try:
            # Validate URL
            parsed_url = urlparse(url)
            if not parsed_url.scheme:
                # Add http:// if no scheme provided
                url = f"http://{url}"
            
            # Open in browser
            success = webbrowser.open(url)
            
            if success:
                self.tool_logger.log_execution_success("open_browser", f"Opened {url}")
                return f"Successfully opened {url} in the default browser."
            else:
                raise RuntimeError("Failed to open browser")
            
        except Exception as e:
            self.tool_logger.log_execution_error("open_browser", e)
            raise
