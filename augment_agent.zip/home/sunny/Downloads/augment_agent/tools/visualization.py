"""Visualization and utility tools for Augment Agent."""

import os
import re
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import hashlib

from .base import BaseTool
from ..utils.logging import configure_tool_logging


class RenderMermaidTool(BaseTool):
    """Tool for rendering Mermaid diagrams."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("render-mermaid")
        self.mermaid_cache = {}
    
    @property
    def name(self) -> str:
        return "render-mermaid"
    
    @property
    def description(self) -> str:
        return "Render a Mermaid diagram from the provided definition with interactive controls."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "diagram_definition": {
                    "type": "string",
                    "description": "The Mermaid diagram definition code to render"
                },
                "title": {
                    "type": "string",
                    "description": "Optional title for the diagram",
                    "default": "Mermaid Diagram"
                },
                "output_format": {
                    "type": "string",
                    "enum": ["svg", "png", "pdf", "html"],
                    "description": "Output format for the diagram",
                    "default": "svg"
                }
            },
            "required": ["diagram_definition"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute Mermaid diagram rendering."""
        self._ensure_initialized()
        
        diagram_definition = kwargs["diagram_definition"]
        title = kwargs.get("title", "Mermaid Diagram")
        output_format = kwargs.get("output_format", "svg")
        
        self.tool_logger.log_execution_start("render_mermaid", title=title, format=output_format)
        
        try:
            # Generate cache key
            cache_key = hashlib.md5(
                f"{diagram_definition}{title}{output_format}".encode()
            ).hexdigest()
            
            # Check cache
            if cache_key in self.mermaid_cache:
                cached_result = self.mermaid_cache[cache_key]
                self.tool_logger.log_info("Using cached diagram")
                return cached_result
            
            # Validate Mermaid syntax
            if not self._validate_mermaid_syntax(diagram_definition):
                raise ValueError("Invalid Mermaid diagram syntax")
            
            # Render diagram
            if output_format == "html":
                result = self._render_html_diagram(diagram_definition, title)
            else:
                result = self._render_static_diagram(diagram_definition, title, output_format)
            
            # Cache result
            self.mermaid_cache[cache_key] = result
            
            self.tool_logger.log_execution_success("render_mermaid", f"Rendered {output_format} diagram")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("render_mermaid", e)
            raise
    
    def _validate_mermaid_syntax(self, definition: str) -> bool:
        """Basic validation of Mermaid diagram syntax."""
        definition = definition.strip()
        
        # Check for common Mermaid diagram types
        valid_starts = [
            'graph', 'flowchart', 'sequenceDiagram', 'classDiagram',
            'stateDiagram', 'erDiagram', 'journey', 'gantt', 'pie',
            'gitgraph', 'mindmap', 'timeline'
        ]
        
        first_line = definition.split('\n')[0].strip().lower()
        return any(first_line.startswith(start.lower()) for start in valid_starts)
    
    def _render_html_diagram(self, definition: str, title: str) -> str:
        """Render Mermaid diagram as interactive HTML."""
        html_template = f"""
<!DOCTYPE html>
<html>
<head>
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }}
        .diagram-container {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .controls {{
            margin-bottom: 20px;
        }}
        .controls button {{
            margin-right: 10px;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            background: #007bff;
            color: white;
            cursor: pointer;
        }}
        .controls button:hover {{
            background: #0056b3;
        }}
        #diagram {{
            text-align: center;
            min-height: 200px;
        }}
    </style>
</head>
<body>
    <h1>{title}</h1>
    
    <div class="controls">
        <button onclick="zoomIn()">Zoom In</button>
        <button onclick="zoomOut()">Zoom Out</button>
        <button onclick="resetZoom()">Reset Zoom</button>
        <button onclick="downloadSVG()">Download SVG</button>
        <button onclick="copyDefinition()">Copy Definition</button>
    </div>
    
    <div class="diagram-container">
        <div id="diagram">
            <pre class="mermaid">
{definition}
            </pre>
        </div>
    </div>
    
    <div class="diagram-container">
        <h3>Diagram Definition</h3>
        <pre id="definition" style="background: #f8f9fa; padding: 15px; border-radius: 4px; overflow-x: auto;">{definition}</pre>
    </div>
    
    <script>
        mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
        
        let currentZoom = 1;
        
        function zoomIn() {{
            currentZoom *= 1.2;
            applyZoom();
        }}
        
        function zoomOut() {{
            currentZoom /= 1.2;
            applyZoom();
        }}
        
        function resetZoom() {{
            currentZoom = 1;
            applyZoom();
        }}
        
        function applyZoom() {{
            const diagram = document.querySelector('#diagram svg');
            if (diagram) {{
                diagram.style.transform = `scale(${{currentZoom}})`;
                diagram.style.transformOrigin = 'center top';
            }}
        }}
        
        function downloadSVG() {{
            const svg = document.querySelector('#diagram svg');
            if (svg) {{
                const svgData = new XMLSerializer().serializeToString(svg);
                const blob = new Blob([svgData], {{type: 'image/svg+xml'}});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = '{title.replace(" ", "_")}.svg';
                a.click();
                URL.revokeObjectURL(url);
            }}
        }}
        
        function copyDefinition() {{
            const definition = document.getElementById('definition').textContent;
            navigator.clipboard.writeText(definition).then(() => {{
                alert('Diagram definition copied to clipboard!');
            }});
        }}
        
        // Auto-apply zoom after diagram loads
        setTimeout(() => {{
            const observer = new MutationObserver(() => {{
                const svg = document.querySelector('#diagram svg');
                if (svg) {{
                    applyZoom();
                    observer.disconnect();
                }}
            }});
            observer.observe(document.getElementById('diagram'), {{ childList: true, subtree: true }});
        }}, 100);
    </script>
</body>
</html>
        """
        
        # Save HTML file
        output_dir = Path(self.config.data_dir) / "diagrams"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"mermaid_{hashlib.md5(definition.encode()).hexdigest()[:8]}.html"
        output_path = output_dir / filename
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_template)
        
        return f"Mermaid diagram rendered as interactive HTML: {output_path}\n\nOpen this file in your browser to view the interactive diagram with zoom and download capabilities."
    
    def _render_static_diagram(self, definition: str, title: str, output_format: str) -> str:
        """Render Mermaid diagram as static image using mermaid-cli if available."""
        try:
            # Check if mermaid-cli is available
            result = subprocess.run(['mmdc', '--version'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                raise FileNotFoundError("mermaid-cli not found")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return self._render_fallback_diagram(definition, title, output_format)
        
        try:
            # Create temporary input file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.mmd', delete=False) as f:
                f.write(definition)
                input_path = f.name
            
            # Create output file
            output_dir = Path(self.config.data_dir) / "diagrams"
            output_dir.mkdir(parents=True, exist_ok=True)
            
            filename = f"mermaid_{hashlib.md5(definition.encode()).hexdigest()[:8]}.{output_format}"
            output_path = output_dir / filename
            
            # Render diagram
            cmd = ['mmdc', '-i', input_path, '-o', str(output_path)]
            if output_format == 'svg':
                cmd.extend(['-f', 'svg'])
            elif output_format == 'png':
                cmd.extend(['-f', 'png'])
            elif output_format == 'pdf':
                cmd.extend(['-f', 'pdf'])
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            # Clean up
            os.unlink(input_path)
            
            if result.returncode == 0:
                return f"Mermaid diagram rendered successfully: {output_path}"
            else:
                raise RuntimeError(f"Mermaid rendering failed: {result.stderr}")
                
        except Exception as e:
            # Clean up on error
            if 'input_path' in locals():
                try:
                    os.unlink(input_path)
                except:
                    pass
            raise e
    
    def _render_fallback_diagram(self, definition: str, title: str, output_format: str) -> str:
        """Fallback rendering when mermaid-cli is not available."""
        # Create a simple text representation
        output_dir = Path(self.config.data_dir) / "diagrams"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"mermaid_{hashlib.md5(definition.encode()).hexdigest()[:8]}.txt"
        output_path = output_dir / filename
        
        fallback_content = f"""
{title}
{'=' * len(title)}

Mermaid Diagram Definition:
{'-' * 30}
{definition}

Note: This is a text representation. To render the actual diagram:
1. Install mermaid-cli: npm install -g @mermaid-js/mermaid-cli
2. Or copy the definition above to https://mermaid.live/
3. Or use the HTML output format for interactive viewing

Diagram saved as: {output_path}
        """
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(fallback_content.strip())
        
        return f"Mermaid diagram definition saved (mermaid-cli not available): {output_path}\n\nTo render the diagram:\n1. Install mermaid-cli: npm install -g @mermaid-js/mermaid-cli\n2. Or visit https://mermaid.live/ and paste the definition\n3. Or use output_format='html' for interactive viewing"


class ViewRangeUntruncatedTool(BaseTool):
    """Tool for viewing specific ranges of large content."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("view-range-untruncated")
        self.content_cache = {}
    
    @property
    def name(self) -> str:
        return "view-range-untruncated"
    
    @property
    def description(self) -> str:
        return "View a specific range of lines from untruncated content using a reference ID."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "reference_id": {
                    "type": "string",
                    "description": "The reference ID of the truncated content"
                },
                "start_line": {
                    "type": "integer",
                    "description": "The starting line number (1-based, inclusive)"
                },
                "end_line": {
                    "type": "integer",
                    "description": "The ending line number (1-based, inclusive)"
                }
            },
            "required": ["reference_id", "start_line", "end_line"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute range viewing."""
        self._ensure_initialized()
        
        reference_id = kwargs["reference_id"]
        start_line = kwargs["start_line"]
        end_line = kwargs["end_line"]
        
        self.tool_logger.log_execution_start("view_range", ref_id=reference_id, 
                                           start=start_line, end=end_line)
        
        try:
            # Get content from cache
            if reference_id not in self.content_cache:
                raise ValueError(f"Reference ID {reference_id} not found in cache")
            
            content_data = self.content_cache[reference_id]
            lines = content_data['lines']
            
            # Validate range
            if start_line < 1 or end_line < start_line:
                raise ValueError("Invalid line range")
            
            if start_line > len(lines):
                raise ValueError(f"Start line {start_line} exceeds content length ({len(lines)} lines)")
            
            # Adjust end_line if it exceeds content
            actual_end = min(end_line, len(lines))
            
            # Extract range (convert to 0-based indexing)
            start_idx = start_line - 1
            end_idx = actual_end
            
            selected_lines = lines[start_idx:end_idx]
            
            # Format output with line numbers
            result_lines = []
            for i, line in enumerate(selected_lines, start=start_line):
                result_lines.append(f"{i:4d}: {line.rstrip()}")
            
            result = f"Content range {start_line}-{actual_end} from {content_data.get('source', 'unknown')}:\n\n"
            result += "\n".join(result_lines)
            
            if actual_end < end_line:
                result += f"\n\n(Note: Requested end line {end_line} exceeded content length, showing up to line {actual_end})"
            
            self.tool_logger.log_execution_success("view_range", 
                                                 f"Showed lines {start_line}-{actual_end}")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("view_range", e)
            raise
    
    def cache_content(self, content: str, source: str = "unknown") -> str:
        """Cache content and return a reference ID."""
        reference_id = hashlib.md5(f"{content}{source}".encode()).hexdigest()[:16]
        
        self.content_cache[reference_id] = {
            'lines': content.splitlines(),
            'source': source,
            'cached_at': datetime.now().isoformat()
        }
        
        return reference_id


class SearchUntruncatedTool(BaseTool):
    """Tool for searching within large content."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("search-untruncated")
        # Share cache with ViewRangeUntruncatedTool
        self.content_cache = {}
    
    @property
    def name(self) -> str:
        return "search-untruncated"
    
    @property
    def description(self) -> str:
        return "Search for a term within untruncated content using a reference ID."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "reference_id": {
                    "type": "string",
                    "description": "The reference ID of the truncated content"
                },
                "search_term": {
                    "type": "string",
                    "description": "The term to search for within the content"
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Number of context lines to include before and after matches",
                    "default": 2
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Whether the search should be case-sensitive",
                    "default": False
                },
                "regex": {
                    "type": "boolean",
                    "description": "Whether to treat search_term as a regular expression",
                    "default": False
                }
            },
            "required": ["reference_id", "search_term"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute content search."""
        self._ensure_initialized()
        
        reference_id = kwargs["reference_id"]
        search_term = kwargs["search_term"]
        context_lines = kwargs.get("context_lines", 2)
        case_sensitive = kwargs.get("case_sensitive", False)
        use_regex = kwargs.get("regex", False)
        
        self.tool_logger.log_execution_start("search_untruncated", 
                                           ref_id=reference_id, term=search_term[:50])
        
        try:
            # Get content from cache
            if reference_id not in self.content_cache:
                raise ValueError(f"Reference ID {reference_id} not found in cache")
            
            content_data = self.content_cache[reference_id]
            lines = content_data['lines']
            
            # Perform search
            matches = self._search_lines(lines, search_term, case_sensitive, use_regex)
            
            if not matches:
                result = f"No matches found for '{search_term}' in {content_data.get('source', 'content')}"
                self.tool_logger.log_execution_success("search_untruncated", "No matches found")
                return result
            
            # Format results with context
            result = f"Found {len(matches)} matches for '{search_term}' in {content_data.get('source', 'content')}:\n\n"
            
            formatted_matches = self._format_search_results(lines, matches, context_lines)
            result += formatted_matches
            
            self.tool_logger.log_execution_success("search_untruncated", f"Found {len(matches)} matches")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("search_untruncated", e)
            raise
    
    def _search_lines(self, lines: List[str], search_term: str, 
                     case_sensitive: bool, use_regex: bool) -> List[int]:
        """Search for term in lines and return matching line numbers."""
        matches = []
        
        if use_regex:
            try:
                flags = 0 if case_sensitive else re.IGNORECASE
                pattern = re.compile(search_term, flags)
            except re.error as e:
                raise ValueError(f"Invalid regex pattern: {e}")
        else:
            if not case_sensitive:
                search_term = search_term.lower()
        
        for i, line in enumerate(lines):
            search_line = line if case_sensitive else line.lower()
            
            if use_regex:
                if pattern.search(line):
                    matches.append(i)
            else:
                if search_term in search_line:
                    matches.append(i)
        
        return matches
    
    def _format_search_results(self, lines: List[str], matches: List[int], 
                              context_lines: int) -> str:
        """Format search results with context."""
        result_lines = []
        covered_lines = set()
        
        for match_line in matches:
            start = max(0, match_line - context_lines)
            end = min(len(lines), match_line + context_lines + 1)
            
            # Add separator if there's a gap
            if result_lines and start > max(covered_lines) + 1:
                result_lines.append("...")
            
            # Add lines with context
            for i in range(start, end):
                if i not in covered_lines:
                    line_num = i + 1
                    marker = ">>> " if i == match_line else "    "
                    result_lines.append(f"{marker}{line_num:4d}: {lines[i].rstrip()}")
                    covered_lines.add(i)
            
            result_lines.append("")
        
        return "\n".join(result_lines)
