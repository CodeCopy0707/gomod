"""Long File Indexer as specified in plan.md - Break up and index massive files for context-aware editing."""

import os
import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import ast
import re

from .base import FileOperationTool
from ..utils.logging import configure_tool_logging


class LongFileIndexerTool(FileOperationTool):
    """Index large files by breaking them into manageable chunks with context awareness."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("long-file-indexer")
        self.index_db_path = None
    
    @property
    def name(self) -> str:
        return "long-file-indexer"
    
    @property
    def description(self) -> str:
        return "Index large files by breaking them into chunks with context-aware navigation and editing."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the large file to index"
                },
                "chunk_size": {
                    "type": "integer",
                    "description": "Number of lines per chunk",
                    "default": 100,
                    "minimum": 10,
                    "maximum": 1000
                },
                "overlap_size": {
                    "type": "integer",
                    "description": "Number of overlapping lines between chunks",
                    "default": 10,
                    "minimum": 0,
                    "maximum": 50
                },
                "index_type": {
                    "type": "string",
                    "enum": ["full", "functions_only", "classes_only", "smart"],
                    "description": "Type of indexing to perform",
                    "default": "smart"
                },
                "force_reindex": {
                    "type": "boolean",
                    "description": "Force reindexing even if file hasn't changed",
                    "default": false
                }
            },
            "required": ["file_path"]
        }
    
    async def initialize(self) -> None:
        """Initialize the indexer with database setup."""
        await super().initialize()
        
        # Setup index database
        self.index_db_path = Path(self.config.data_dir) / "file_index.db"
        self.index_db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._init_index_database()
    
    def _init_index_database(self) -> None:
        """Initialize the SQLite database for file indexing."""
        with sqlite3.connect(self.index_db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS indexed_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT UNIQUE NOT NULL,
                    file_hash TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    line_count INTEGER NOT NULL,
                    language TEXT,
                    indexed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    chunk_size INTEGER NOT NULL,
                    overlap_size INTEGER NOT NULL
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS file_chunks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    chunk_number INTEGER NOT NULL,
                    start_line INTEGER NOT NULL,
                    end_line INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    chunk_type TEXT DEFAULT 'code',
                    metadata TEXT,
                    FOREIGN KEY (file_id) REFERENCES indexed_files (id)
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_symbols (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_id INTEGER,
                    chunk_id INTEGER,
                    symbol_name TEXT NOT NULL,
                    symbol_type TEXT NOT NULL,
                    start_line INTEGER NOT NULL,
                    end_line INTEGER NOT NULL,
                    definition TEXT,
                    FOREIGN KEY (file_id) REFERENCES indexed_files (id),
                    FOREIGN KEY (chunk_id) REFERENCES file_chunks (id)
                )
            """)
            
            # Create indexes for better performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_file_path ON indexed_files (file_path)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_chunk_lines ON file_chunks (start_line, end_line)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_symbol_name ON code_symbols (symbol_name)")
    
    async def execute(self, **kwargs) -> str:
        """Execute file indexing."""
        self._ensure_initialized()
        
        file_path = kwargs["file_path"]
        chunk_size = kwargs.get("chunk_size", 100)
        overlap_size = kwargs.get("overlap_size", 10)
        index_type = kwargs.get("index_type", "smart")
        force_reindex = kwargs.get("force_reindex", False)
        
        self.tool_logger.log_execution_start("long_file_indexer", 
                                           file=file_path,
                                           chunk_size=chunk_size)
        
        try:
            # Validate file path
            abs_file_path = self._get_absolute_path(file_path)
            if not abs_file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if not abs_file_path.is_file():
                raise ValueError(f"Path is not a file: {file_path}")
            
            # Check if file needs indexing
            needs_indexing = await self._needs_indexing(abs_file_path, force_reindex)
            
            if not needs_indexing:
                return await self._get_existing_index_info(abs_file_path)
            
            # Perform indexing
            index_result = await self._index_file(
                abs_file_path, chunk_size, overlap_size, index_type
            )
            
            # Format results
            formatted_result = self._format_index_results(index_result, file_path)
            
            self.tool_logger.log_execution_success("long_file_indexer", 
                                                 f"Indexed {index_result['chunk_count']} chunks")
            return formatted_result
            
        except Exception as e:
            self.tool_logger.log_execution_error("long_file_indexer", e)
            raise
    
    async def _needs_indexing(self, file_path: Path, force_reindex: bool) -> bool:
        """Check if file needs to be indexed or reindexed."""
        if force_reindex:
            return True
        
        # Calculate current file hash
        current_hash = self._calculate_file_hash(file_path)
        
        with sqlite3.connect(self.index_db_path) as conn:
            cursor = conn.execute(
                "SELECT file_hash FROM indexed_files WHERE file_path = ?",
                (str(file_path),)
            )
            result = cursor.fetchone()
            
            if not result:
                return True  # File not indexed yet
            
            stored_hash = result[0]
            return current_hash != stored_hash  # File has changed
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of file content."""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    async def _get_existing_index_info(self, file_path: Path) -> str:
        """Get information about existing index."""
        with sqlite3.connect(self.index_db_path) as conn:
            cursor = conn.execute("""
                SELECT f.line_count, f.chunk_size, f.indexed_at, COUNT(c.id) as chunk_count
                FROM indexed_files f
                LEFT JOIN file_chunks c ON f.id = c.file_id
                WHERE f.file_path = ?
                GROUP BY f.id
            """, (str(file_path),))
            
            result = cursor.fetchone()
            if result:
                line_count, chunk_size, indexed_at, chunk_count = result
                return f"""# File Already Indexed

**File:** {file_path}
**Lines:** {line_count}
**Chunks:** {chunk_count}
**Chunk Size:** {chunk_size}
**Last Indexed:** {indexed_at}

Use `force_reindex=true` to reindex the file."""
        
        return "File index not found."
    
    async def _index_file(self, file_path: Path, chunk_size: int, 
                         overlap_size: int, index_type: str) -> Dict[str, Any]:
        """Index the file by breaking it into chunks."""
        # Read file content
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
        except UnicodeDecodeError:
            # Try with different encoding
            with open(file_path, 'r', encoding='latin-1') as f:
                content = f.read()
                lines = content.splitlines()
        
        # Detect language
        language = self._detect_language(file_path, content)
        
        # Calculate file metadata
        file_hash = self._calculate_file_hash(file_path)
        file_size = file_path.stat().st_size
        line_count = len(lines)
        
        # Create chunks based on index type
        if index_type == "smart":
            chunks = self._create_smart_chunks(lines, chunk_size, overlap_size, language)
        elif index_type == "functions_only":
            chunks = self._create_function_chunks(lines, language)
        elif index_type == "classes_only":
            chunks = self._create_class_chunks(lines, language)
        else:  # full
            chunks = self._create_regular_chunks(lines, chunk_size, overlap_size)
        
        # Store in database
        with sqlite3.connect(self.index_db_path) as conn:
            # Remove existing index for this file
            conn.execute("DELETE FROM indexed_files WHERE file_path = ?", (str(file_path),))
            
            # Insert file record
            cursor = conn.execute("""
                INSERT INTO indexed_files 
                (file_path, file_hash, file_size, line_count, language, chunk_size, overlap_size)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (str(file_path), file_hash, file_size, line_count, language, chunk_size, overlap_size))
            
            file_id = cursor.lastrowid
            
            # Insert chunks
            for chunk in chunks:
                chunk_content = '\n'.join(lines[chunk['start_line']-1:chunk['end_line']])
                chunk_hash = hashlib.sha256(chunk_content.encode()).hexdigest()
                
                cursor = conn.execute("""
                    INSERT INTO file_chunks 
                    (file_id, chunk_number, start_line, end_line, content, content_hash, chunk_type, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (file_id, chunk['number'], chunk['start_line'], chunk['end_line'],
                      chunk_content, chunk_hash, chunk.get('type', 'code'), 
                      json.dumps(chunk.get('metadata', {}))))
                
                chunk_id = cursor.lastrowid
                
                # Extract and store symbols for this chunk
                symbols = self._extract_symbols_from_chunk(chunk_content, language, chunk['start_line'])
                for symbol in symbols:
                    conn.execute("""
                        INSERT INTO code_symbols 
                        (file_id, chunk_id, symbol_name, symbol_type, start_line, end_line, definition)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (file_id, chunk_id, symbol['name'], symbol['type'],
                          symbol['start_line'], symbol['end_line'], symbol.get('definition', '')))
        
        return {
            'file_path': str(file_path),
            'file_size': file_size,
            'line_count': line_count,
            'language': language,
            'chunk_count': len(chunks),
            'chunk_size': chunk_size,
            'overlap_size': overlap_size,
            'index_type': index_type,
            'chunks': chunks[:5]  # Return first 5 chunks as preview
        }
    
    def _detect_language(self, file_path: Path, content: str) -> str:
        """Detect programming language from file extension and content."""
        extension_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.java': 'java',
            '.cpp': 'cpp',
            '.c': 'c',
            '.h': 'c',
            '.cs': 'csharp',
            '.go': 'go',
            '.rs': 'rust',
            '.php': 'php',
            '.rb': 'ruby'
        }
        
        return extension_map.get(file_path.suffix.lower(), 'text')
    
    def _create_smart_chunks(self, lines: List[str], chunk_size: int, 
                           overlap_size: int, language: str) -> List[Dict[str, Any]]:
        """Create smart chunks that respect code structure."""
        chunks = []
        current_line = 1
        chunk_number = 1
        
        while current_line <= len(lines):
            # Find natural break points (functions, classes, etc.)
            chunk_end = min(current_line + chunk_size - 1, len(lines))
            
            # Try to extend to a natural break point
            if chunk_end < len(lines):
                for i in range(chunk_end, min(chunk_end + 20, len(lines))):
                    line = lines[i-1].strip()
                    if self._is_natural_break(line, language):
                        chunk_end = i
                        break
            
            chunks.append({
                'number': chunk_number,
                'start_line': current_line,
                'end_line': chunk_end,
                'type': 'smart',
                'metadata': {
                    'line_count': chunk_end - current_line + 1,
                    'has_overlap': chunk_number > 1
                }
            })
            
            # Move to next chunk with overlap
            current_line = chunk_end - overlap_size + 1
            chunk_number += 1
        
        return chunks
    
    def _is_natural_break(self, line: str, language: str) -> bool:
        """Check if a line is a natural break point for chunking."""
        if not line:
            return True
        
        if language == 'python':
            return (line.startswith('def ') or line.startswith('class ') or 
                   line.startswith('if __name__') or line == '' or
                   line.startswith('#'))
        elif language in ['javascript', 'typescript']:
            return (line.startswith('function ') or line.startswith('class ') or
                   line.startswith('const ') or line.startswith('//') or
                   line == '}' or line == '')
        
        return line == '' or line.startswith('#') or line.startswith('//')
    
    def _create_regular_chunks(self, lines: List[str], chunk_size: int, 
                             overlap_size: int) -> List[Dict[str, Any]]:
        """Create regular fixed-size chunks."""
        chunks = []
        current_line = 1
        chunk_number = 1
        
        while current_line <= len(lines):
            chunk_end = min(current_line + chunk_size - 1, len(lines))
            
            chunks.append({
                'number': chunk_number,
                'start_line': current_line,
                'end_line': chunk_end,
                'type': 'regular',
                'metadata': {
                    'line_count': chunk_end - current_line + 1
                }
            })
            
            current_line = chunk_end - overlap_size + 1
            chunk_number += 1
        
        return chunks
    
    def _create_function_chunks(self, lines: List[str], language: str) -> List[Dict[str, Any]]:
        """Create chunks based on function boundaries."""
        chunks = []
        chunk_number = 1
        
        if language == 'python':
            # Use AST to find functions
            try:
                content = '\n'.join(lines)
                tree = ast.parse(content)
                
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        chunks.append({
                            'number': chunk_number,
                            'start_line': node.lineno,
                            'end_line': getattr(node, 'end_lineno', node.lineno + 10),
                            'type': 'function',
                            'metadata': {
                                'function_name': node.name,
                                'is_async': isinstance(node, ast.AsyncFunctionDef)
                            }
                        })
                        chunk_number += 1
            except SyntaxError:
                # Fall back to regex-based detection
                return self._create_regex_function_chunks(lines, language)
        
        return chunks if chunks else self._create_regex_function_chunks(lines, language)
    
    def _create_regex_function_chunks(self, lines: List[str], language: str) -> List[Dict[str, Any]]:
        """Create function chunks using regex patterns."""
        chunks = []
        chunk_number = 1
        
        function_patterns = {
            'python': r'^def\s+(\w+)',
            'javascript': r'function\s+(\w+)',
            'java': r'(public|private|protected)?\s*(static)?\s*\w+\s+(\w+)\s*\(',
            'cpp': r'\w+\s+(\w+)\s*\([^)]*\)\s*{'
        }
        
        pattern = function_patterns.get(language, r'function\s+(\w+)')
        
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line):
                # Find end of function (simplified)
                end_line = i + 20  # Default function size
                for j in range(i, min(i + 100, len(lines))):
                    if j > i and re.search(pattern, lines[j-1]):
                        end_line = j - 1
                        break
                
                chunks.append({
                    'number': chunk_number,
                    'start_line': i,
                    'end_line': min(end_line, len(lines)),
                    'type': 'function',
                    'metadata': {
                        'detected_by': 'regex'
                    }
                })
                chunk_number += 1
        
        return chunks
    
    def _create_class_chunks(self, lines: List[str], language: str) -> List[Dict[str, Any]]:
        """Create chunks based on class boundaries."""
        chunks = []
        chunk_number = 1
        
        class_patterns = {
            'python': r'^class\s+(\w+)',
            'javascript': r'class\s+(\w+)',
            'java': r'(public|private)?\s*class\s+(\w+)',
            'cpp': r'class\s+(\w+)'
        }
        
        pattern = class_patterns.get(language, r'class\s+(\w+)')
        
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line):
                # Find end of class (simplified)
                end_line = len(lines)
                for j in range(i + 1, len(lines)):
                    if re.search(pattern, lines[j-1]):
                        end_line = j - 1
                        break
                
                chunks.append({
                    'number': chunk_number,
                    'start_line': i,
                    'end_line': end_line,
                    'type': 'class',
                    'metadata': {
                        'class_name': re.search(pattern, line).group(1) if re.search(pattern, line) else 'Unknown'
                    }
                })
                chunk_number += 1
        
        return chunks
    
    def _extract_symbols_from_chunk(self, content: str, language: str, 
                                  start_line_offset: int) -> List[Dict[str, Any]]:
        """Extract symbols (functions, classes, variables) from a chunk."""
        symbols = []
        
        if language == 'python':
            try:
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        symbols.append({
                            'name': node.name,
                            'type': 'function',
                            'start_line': start_line_offset + node.lineno - 1,
                            'end_line': start_line_offset + getattr(node, 'end_lineno', node.lineno) - 1,
                            'definition': f"def {node.name}(...)"
                        })
                    elif isinstance(node, ast.ClassDef):
                        symbols.append({
                            'name': node.name,
                            'type': 'class',
                            'start_line': start_line_offset + node.lineno - 1,
                            'end_line': start_line_offset + getattr(node, 'end_lineno', node.lineno) - 1,
                            'definition': f"class {node.name}"
                        })
            except SyntaxError:
                pass
        
        return symbols
    
    def _format_index_results(self, result: Dict[str, Any], original_path: str) -> str:
        """Format indexing results for display."""
        formatted = [f"# File Indexing Complete\n"]
        formatted.append(f"**File:** {original_path}")
        formatted.append(f"**Language:** {result['language']}")
        formatted.append(f"**File Size:** {result['file_size']:,} bytes")
        formatted.append(f"**Lines:** {result['line_count']:,}")
        formatted.append(f"**Chunks Created:** {result['chunk_count']}")
        formatted.append(f"**Chunk Size:** {result['chunk_size']} lines")
        formatted.append(f"**Overlap:** {result['overlap_size']} lines")
        formatted.append(f"**Index Type:** {result['index_type']}")
        
        if result['chunks']:
            formatted.append("\n## Sample Chunks\n")
            for chunk in result['chunks']:
                formatted.append(f"**Chunk {chunk['number']}:** Lines {chunk['start_line']}-{chunk['end_line']} ({chunk['type']})")
                if chunk.get('metadata'):
                    metadata = chunk['metadata']
                    if 'function_name' in metadata:
                        formatted.append(f"  - Function: {metadata['function_name']}")
                    if 'class_name' in metadata:
                        formatted.append(f"  - Class: {metadata['class_name']}")
        
        formatted.append("\n## Usage")
        formatted.append("The file has been indexed and can now be navigated efficiently.")
        formatted.append("Use chunk-aware editing tools to work with specific sections.")
        
        return "\n".join(formatted)
