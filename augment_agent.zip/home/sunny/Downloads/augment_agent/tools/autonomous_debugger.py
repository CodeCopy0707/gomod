"""Autonomous debugging agent as specified in plan.md."""

import ast
import re
import subprocess
import traceback
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import tempfile
import sys

from .base import CodeAnalysisTool
from ..utils.logging import configure_tool_logging


class AutonomousDebuggerTool(CodeAnalysisTool):
    """Autonomous debugging agent that can find and fix bugs automatically."""
    
    def __init__(self, config):
        super().__init__(config)
        self.tool_logger = configure_tool_logging("autonomous-debugger")
    
    @property
    def name(self) -> str:
        return "autonomous-debugger"
    
    @property
    def description(self) -> str:
        return "Autonomous debugging agent that analyzes, identifies, and fixes bugs automatically."
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Code to debug"
                },
                "error_message": {
                    "type": "string",
                    "description": "Error message or description of the bug (optional)"
                },
                "language": {
                    "type": "string",
                    "enum": ["python", "javascript", "java", "cpp", "auto"],
                    "description": "Programming language",
                    "default": "auto"
                },
                "debug_level": {
                    "type": "string",
                    "enum": ["basic", "advanced", "comprehensive"],
                    "description": "Level of debugging analysis",
                    "default": "advanced"
                },
                "auto_fix": {
                    "type": "boolean",
                    "description": "Attempt to automatically fix identified issues",
                    "default": true
                },
                "run_tests": {
                    "type": "boolean",
                    "description": "Run the code to identify runtime errors",
                    "default": true
                }
            },
            "required": ["code"]
        }
    
    async def execute(self, **kwargs) -> str:
        """Execute autonomous debugging."""
        self._ensure_initialized()
        
        code = kwargs["code"]
        error_message = kwargs.get("error_message", "")
        language = kwargs.get("language", "auto")
        debug_level = kwargs.get("debug_level", "advanced")
        auto_fix = kwargs.get("auto_fix", True)
        run_tests = kwargs.get("run_tests", True)
        
        self.tool_logger.log_execution_start("autonomous_debugger", 
                                           language=language,
                                           debug_level=debug_level)
        
        try:
            # Detect language if auto
            if language == "auto":
                language = self._detect_language(code)
            
            # Perform comprehensive debugging analysis
            debug_analysis = await self._analyze_code_for_bugs(
                code, language, error_message, debug_level, run_tests
            )
            
            # Attempt automatic fixes if requested
            fixed_code = code
            if auto_fix and debug_analysis['issues']:
                fixed_code = await self._auto_fix_issues(code, debug_analysis, language)
            
            # Format results
            result = self._format_debug_results(
                code, fixed_code, debug_analysis, language, auto_fix
            )
            
            self.tool_logger.log_execution_success("autonomous_debugger", 
                                                 f"Found {len(debug_analysis['issues'])} issues")
            return result
            
        except Exception as e:
            self.tool_logger.log_execution_error("autonomous_debugger", e)
            raise
    
    def _detect_language(self, code: str) -> str:
        """Detect programming language from code."""
        # Simple heuristics for language detection
        if 'def ' in code and 'import ' in code:
            return 'python'
        elif 'function ' in code or 'const ' in code or 'let ' in code:
            return 'javascript'
        elif 'public class' in code or 'System.out' in code:
            return 'java'
        elif '#include' in code or 'std::' in code:
            return 'cpp'
        else:
            return 'python'  # Default fallback
    
    async def _analyze_code_for_bugs(self, code: str, language: str, error_message: str,
                                   debug_level: str, run_tests: bool) -> Dict[str, Any]:
        """Comprehensive bug analysis."""
        analysis = {
            'language': language,
            'issues': [],
            'warnings': [],
            'suggestions': [],
            'syntax_errors': [],
            'runtime_errors': [],
            'logic_errors': [],
            'performance_issues': [],
            'security_issues': []
        }
        
        # Syntax analysis
        syntax_issues = await self._check_syntax(code, language)
        analysis['syntax_errors'].extend(syntax_issues)
        analysis['issues'].extend(syntax_issues)
        
        # Static analysis
        if debug_level in ['advanced', 'comprehensive']:
            static_issues = await self._static_analysis(code, language)
            analysis['warnings'].extend(static_issues)
            analysis['issues'].extend(static_issues)
        
        # Runtime analysis
        if run_tests and not syntax_issues:
            runtime_issues = await self._runtime_analysis(code, language)
            analysis['runtime_errors'].extend(runtime_issues)
            analysis['issues'].extend(runtime_issues)
        
        # Logic analysis
        if debug_level == 'comprehensive':
            logic_issues = await self._logic_analysis(code, language)
            analysis['logic_errors'].extend(logic_issues)
            analysis['issues'].extend(logic_issues)
        
        # Performance analysis
        if debug_level == 'comprehensive':
            perf_issues = await self._performance_analysis(code, language)
            analysis['performance_issues'].extend(perf_issues)
            analysis['suggestions'].extend(perf_issues)
        
        # Security analysis
        if debug_level == 'comprehensive':
            security_issues = await self._security_analysis(code, language)
            analysis['security_issues'].extend(security_issues)
            analysis['issues'].extend(security_issues)
        
        # Error message analysis
        if error_message:
            error_analysis = await self._analyze_error_message(error_message, code, language)
            analysis['issues'].extend(error_analysis)
        
        return analysis
    
    async def _check_syntax(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Check for syntax errors."""
        issues = []
        
        if language == 'python':
            try:
                ast.parse(code)
            except SyntaxError as e:
                issues.append({
                    'type': 'syntax_error',
                    'severity': 'error',
                    'line': e.lineno,
                    'column': e.offset,
                    'message': e.msg,
                    'suggestion': self._suggest_syntax_fix(e, code)
                })
        
        elif language == 'javascript':
            # Basic JavaScript syntax checks using regex
            issues.extend(self._check_js_syntax(code))
        
        return issues
    
    def _check_js_syntax(self, code: str) -> List[Dict[str, Any]]:
        """Basic JavaScript syntax checking."""
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check for common syntax issues
            if line.strip().endswith(',') and not line.strip().endswith(','):
                issues.append({
                    'type': 'syntax_warning',
                    'severity': 'warning',
                    'line': i,
                    'message': 'Trailing comma may cause issues in older browsers',
                    'suggestion': 'Remove trailing comma'
                })
            
            # Check for missing semicolons
            if (line.strip() and 
                not line.strip().endswith((';', '{', '}', ')', ',')) and
                not line.strip().startswith(('if', 'for', 'while', 'function', 'class'))):
                issues.append({
                    'type': 'syntax_warning',
                    'severity': 'warning',
                    'line': i,
                    'message': 'Missing semicolon',
                    'suggestion': 'Add semicolon at end of statement'
                })
        
        return issues
    
    async def _static_analysis(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Static code analysis for common issues."""
        issues = []
        
        if language == 'python':
            issues.extend(self._python_static_analysis(code))
        elif language == 'javascript':
            issues.extend(self._javascript_static_analysis(code))
        
        return issues
    
    def _python_static_analysis(self, code: str) -> List[Dict[str, Any]]:
        """Python-specific static analysis."""
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check for common Python issues
            if 'print ' in line and not line.strip().startswith('#'):
                issues.append({
                    'type': 'compatibility_warning',
                    'severity': 'warning',
                    'line': i,
                    'message': 'Using print statement (Python 2 style)',
                    'suggestion': 'Use print() function for Python 3 compatibility'
                })
            
            # Check for bare except clauses
            if line.strip() == 'except:':
                issues.append({
                    'type': 'bad_practice',
                    'severity': 'warning',
                    'line': i,
                    'message': 'Bare except clause catches all exceptions',
                    'suggestion': 'Specify exception type: except Exception:'
                })
            
            # Check for unused variables (basic check)
            if line.strip().startswith('import ') and ' as ' not in line:
                module = line.replace('import ', '').strip()
                if module not in code[code.find(line) + len(line):]:
                    issues.append({
                        'type': 'unused_import',
                        'severity': 'info',
                        'line': i,
                        'message': f'Imported module "{module}" appears to be unused',
                        'suggestion': f'Remove unused import: {module}'
                    })
        
        return issues
    
    def _javascript_static_analysis(self, code: str) -> List[Dict[str, Any]]:
        """JavaScript-specific static analysis."""
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check for == vs ===
            if ' == ' in line and ' === ' not in line:
                issues.append({
                    'type': 'best_practice',
                    'severity': 'warning',
                    'line': i,
                    'message': 'Use strict equality (===) instead of loose equality (==)',
                    'suggestion': 'Replace == with ==='
                })
            
            # Check for var usage
            if line.strip().startswith('var '):
                issues.append({
                    'type': 'modern_js',
                    'severity': 'info',
                    'line': i,
                    'message': 'Consider using let or const instead of var',
                    'suggestion': 'Use let for mutable variables, const for constants'
                })
        
        return issues
    
    async def _runtime_analysis(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Runtime analysis by executing code safely."""
        issues = []
        
        if language == 'python':
            issues.extend(await self._python_runtime_analysis(code))
        
        return issues
    
    async def _python_runtime_analysis(self, code: str) -> List[Dict[str, Any]]:
        """Python runtime analysis."""
        issues = []
        
        try:
            # Create a temporary file and run the code
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            # Run the code and capture output
            result = subprocess.run(
                [sys.executable, temp_file],
                capture_output=True,
                text=True,
                timeout=5  # 5 second timeout
            )
            
            if result.returncode != 0:
                # Parse error output
                error_lines = result.stderr.split('\n')
                for line in error_lines:
                    if 'File' in line and 'line' in line:
                        # Extract line number from traceback
                        match = re.search(r'line (\d+)', line)
                        if match:
                            line_num = int(match.group(1))
                            issues.append({
                                'type': 'runtime_error',
                                'severity': 'error',
                                'line': line_num,
                                'message': result.stderr.strip(),
                                'suggestion': 'Check the error message and fix the issue'
                            })
            
            # Clean up
            Path(temp_file).unlink()
            
        except subprocess.TimeoutExpired:
            issues.append({
                'type': 'runtime_error',
                'severity': 'error',
                'message': 'Code execution timed out (possible infinite loop)',
                'suggestion': 'Check for infinite loops or long-running operations'
            })
        except Exception as e:
            issues.append({
                'type': 'runtime_error',
                'severity': 'error',
                'message': f'Runtime analysis failed: {str(e)}',
                'suggestion': 'Manual review required'
            })
        
        return issues
    
    async def _logic_analysis(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Logic error analysis."""
        issues = []
        
        # Check for common logic errors
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check for assignment in conditions
            if ' = ' in line and any(keyword in line for keyword in ['if ', 'while ', 'elif ']):
                if ' == ' not in line:
                    issues.append({
                        'type': 'logic_error',
                        'severity': 'warning',
                        'line': i,
                        'message': 'Possible assignment in condition (should be ==?)',
                        'suggestion': 'Use == for comparison, = for assignment'
                    })
            
            # Check for unreachable code
            if line.strip().startswith('return ') and i < len(lines):
                next_lines = lines[i:i+3]
                if any(line.strip() and not line.strip().startswith('#') for line in next_lines):
                    issues.append({
                        'type': 'logic_error',
                        'severity': 'warning',
                        'line': i + 1,
                        'message': 'Unreachable code after return statement',
                        'suggestion': 'Remove unreachable code or restructure logic'
                    })
        
        return issues
    
    async def _performance_analysis(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Performance issue analysis."""
        issues = []
        
        if language == 'python':
            lines = code.split('\n')
            
            for i, line in enumerate(lines, 1):
                # Check for inefficient string concatenation
                if '+=' in line and 'str' in line.lower():
                    issues.append({
                        'type': 'performance',
                        'severity': 'info',
                        'line': i,
                        'message': 'String concatenation in loop may be inefficient',
                        'suggestion': 'Consider using join() or f-strings'
                    })
                
                # Check for list comprehension opportunities
                if 'for ' in line and 'append(' in line:
                    issues.append({
                        'type': 'performance',
                        'severity': 'info',
                        'line': i,
                        'message': 'Consider using list comprehension',
                        'suggestion': 'List comprehensions are often faster than loops with append'
                    })
        
        return issues
    
    async def _security_analysis(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Security issue analysis."""
        issues = []
        
        # Check for common security issues
        security_patterns = [
            ('eval(', 'Avoid eval() - security risk'),
            ('exec(', 'Avoid exec() - security risk'),
            ('input(', 'Validate user input'),
            ('os.system(', 'Avoid os.system() - use subprocess instead'),
            ('shell=True', 'Avoid shell=True in subprocess calls'),
            ('pickle.load', 'Pickle can execute arbitrary code - security risk')
        ]
        
        lines = code.split('\n')
        for i, line in enumerate(lines, 1):
            for pattern, message in security_patterns:
                if pattern in line:
                    issues.append({
                        'type': 'security',
                        'severity': 'warning',
                        'line': i,
                        'message': message,
                        'suggestion': 'Review security implications'
                    })
        
        return issues
    
    async def _analyze_error_message(self, error_message: str, code: str, language: str) -> List[Dict[str, Any]]:
        """Analyze provided error message."""
        issues = []
        
        # Common error patterns and suggestions
        error_patterns = {
            'NameError': 'Variable not defined - check spelling and scope',
            'IndentationError': 'Fix indentation - use consistent spaces or tabs',
            'SyntaxError': 'Check syntax - missing colons, parentheses, or quotes',
            'TypeError': 'Type mismatch - check data types and operations',
            'AttributeError': 'Object does not have this attribute - check object type',
            'IndexError': 'List index out of range - check list bounds',
            'KeyError': 'Dictionary key not found - check key existence',
            'ImportError': 'Module not found - check import statement and installation'
        }
        
        for error_type, suggestion in error_patterns.items():
            if error_type in error_message:
                issues.append({
                    'type': 'error_analysis',
                    'severity': 'error',
                    'message': f'{error_type} detected in error message',
                    'suggestion': suggestion,
                    'error_details': error_message
                })
        
        return issues
    
    def _suggest_syntax_fix(self, syntax_error: SyntaxError, code: str) -> str:
        """Suggest fixes for syntax errors."""
        error_msg = syntax_error.msg.lower()
        
        if 'invalid syntax' in error_msg:
            return 'Check for missing colons, parentheses, or quotes'
        elif 'unexpected eof' in error_msg:
            return 'Check for unclosed parentheses, brackets, or quotes'
        elif 'indentation' in error_msg:
            return 'Fix indentation - use consistent spaces or tabs'
        else:
            return 'Review syntax around the error location'
    
    async def _auto_fix_issues(self, code: str, analysis: Dict[str, Any], language: str) -> str:
        """Attempt to automatically fix identified issues."""
        fixed_code = code
        lines = fixed_code.split('\n')
        
        # Sort issues by line number (descending) to avoid line number shifts
        fixable_issues = [issue for issue in analysis['issues'] if self._is_auto_fixable(issue)]
        fixable_issues.sort(key=lambda x: x.get('line', 0), reverse=True)
        
        for issue in fixable_issues:
            line_num = issue.get('line', 0)
            if line_num > 0 and line_num <= len(lines):
                fixed_line = self._apply_auto_fix(lines[line_num - 1], issue, language)
                if fixed_line != lines[line_num - 1]:
                    lines[line_num - 1] = fixed_line
        
        return '\n'.join(lines)
    
    def _is_auto_fixable(self, issue: Dict[str, Any]) -> bool:
        """Check if an issue can be automatically fixed."""
        auto_fixable_types = [
            'syntax_warning',
            'best_practice',
            'modern_js',
            'unused_import'
        ]
        return issue.get('type') in auto_fixable_types
    
    def _apply_auto_fix(self, line: str, issue: Dict[str, Any], language: str) -> str:
        """Apply automatic fix to a line."""
        issue_type = issue.get('type')
        
        if issue_type == 'best_practice' and ' == ' in line:
            return line.replace(' == ', ' === ')
        elif issue_type == 'modern_js' and line.strip().startswith('var '):
            return line.replace('var ', 'let ', 1)
        elif issue_type == 'syntax_warning' and 'semicolon' in issue.get('message', ''):
            return line.rstrip() + ';'
        elif issue_type == 'unused_import' and line.strip().startswith('import '):
            return f'# {line}  # Unused import'
        
        return line
    
    def _format_debug_results(self, original_code: str, fixed_code: str, 
                            analysis: Dict[str, Any], language: str, auto_fix: bool) -> str:
        """Format debugging results."""
        result = [f"# Autonomous Debugging Results\n"]
        result.append(f"**Language:** {language}")
        result.append(f"**Issues Found:** {len(analysis['issues'])}")
        result.append(f"**Auto-fix Applied:** {'Yes' if auto_fix else 'No'}")
        
        if analysis['issues']:
            result.append("\n## Issues Detected\n")
            
            for i, issue in enumerate(analysis['issues'], 1):
                severity_icon = {'error': '❌', 'warning': '⚠️', 'info': 'ℹ️'}.get(issue.get('severity', 'info'), '•')
                result.append(f"### {i}. {severity_icon} {issue.get('type', 'Unknown').replace('_', ' ').title()}")
                
                if issue.get('line'):
                    result.append(f"**Line:** {issue['line']}")
                
                result.append(f"**Message:** {issue.get('message', 'No message')}")
                
                if issue.get('suggestion'):
                    result.append(f"**Suggestion:** {issue['suggestion']}")
                
                result.append("")
        
        if auto_fix and fixed_code != original_code:
            result.append("## Fixed Code\n")
            result.append(f"```{language}")
            result.append(fixed_code)
            result.append("```")
        
        if not analysis['issues']:
            result.append("## ✅ No Issues Found\n")
            result.append("The code appears to be free of common issues!")
        
        return "\n".join(result)
