# Installation Guide for Augment Agent

This guide provides detailed instructions for installing and setting up Augment Agent on your system.

## Prerequisites

### System Requirements

- **Python**: 3.8 or higher
- **Operating System**: Linux, macOS, or Windows
- **Memory**: At least 2GB RAM (4GB recommended for large codebases)
- **Storage**: 500MB free space for installation and data

### Required API Keys

1. **Google Gemini API Key** (Required)
   - Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Create a new API key
   - Keep it secure for configuration

2. **Google Custom Search API** (Optional, for web search)
   - Visit [Google Cloud Console](https://console.cloud.google.com/)
   - Enable the Custom Search API
   - Create an API key
   - Set up a Custom Search Engine at [cse.google.com](https://cse.google.com/)

## Installation Methods

### Method 1: Install from Source (Recommended)

```bash
# Clone the repository
git clone https://github.com/augment-code/augment-agent-clone.git
cd augment-agent-clone

# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install the package
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

### Method 2: Install from PyPI (When Available)

```bash
# Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install from PyPI
pip install augment-agent

# Or install with all optional dependencies
pip install "augment-agent[all]"
```

### Method 3: Docker Installation (Future)

```bash
# Pull the Docker image
docker pull augmentcode/augment-agent:latest

# Run the container
docker run -it --rm \
  -e GEMINI_API_KEY="your-api-key" \
  -v $(pwd):/workspace \
  augmentcode/augment-agent:latest
```

## Configuration

### 1. Set Environment Variables

Create a `.env` file in your project directory or set environment variables:

```bash
# Required
export GEMINI_API_KEY="your-gemini-api-key-here"

# Optional (for web search)
export GOOGLE_SEARCH_API_KEY="your-google-search-api-key"
export GOOGLE_SEARCH_ENGINE_ID="your-search-engine-id"

# Optional (custom paths)
export AUGMENT_WORKSPACE_ROOT="/path/to/your/project"
export AUGMENT_DATA_DIR="/path/to/data/directory"
```

### 2. Initialize Configuration

Run the initialization command to create a configuration file:

```bash
augment-agent init
```

This will:
- Create a configuration file (`augment_agent.yaml`)
- Prompt you for API keys and settings
- Set up the data directory structure
- Validate your configuration

### 3. Manual Configuration

Alternatively, create a configuration file manually:

```yaml
# augment_agent.yaml
gemini_api_key: "your-api-key"
google_search_api_key: "your-search-key"  # optional
google_search_engine_id: "your-engine-id"  # optional

# Agent settings
model_name: "gemini-2.0-flash-exp"
temperature: 0.1
max_tokens: 8192

# Workspace settings
workspace_root: "/path/to/your/project"
repository_root: "/path/to/your/repo"

# Feature toggles
enable_web_search: true
enable_code_analysis: true
enable_process_management: true

# Safety settings
require_confirmation_for_destructive_actions: true
auto_backup_before_edits: true
max_concurrent_processes: 5

# UI settings
use_rich_formatting: true
show_progress_bars: true
log_level: "INFO"
```

## Verification

### Test the Installation

```bash
# Check version and status
augment-agent status

# Test basic functionality
augment-agent ask "Hello, can you help me with Python?"

# Start interactive mode
augment-agent chat
```

### Run Example Scripts

```bash
# Run the example usage script
python -m augment_agent.examples.example_usage

# Or run it directly
cd augment_agent/examples
python example_usage.py
```

## Optional Dependencies

### For Enhanced Code Analysis

```bash
# Install tree-sitter parsers for better code analysis
pip install tree-sitter-languages

# Install language servers (optional)
npm install -g typescript-language-server
pip install python-lsp-server
```

### For Mermaid Diagram Rendering

```bash
# Install mermaid-cli for diagram rendering
npm install -g @mermaid-js/mermaid-cli
```

### For Advanced Embedding Features

```bash
# Install additional embedding models
pip install sentence-transformers[all]
```

## Troubleshooting

### Common Issues

**1. "Gemini API key is required" Error**
```bash
# Make sure your API key is set
echo $GEMINI_API_KEY

# If not set, add it to your shell profile
echo 'export GEMINI_API_KEY="your-key"' >> ~/.bashrc
source ~/.bashrc
```

**2. "Permission denied" Errors**
```bash
# Check file permissions
ls -la ~/.local/share/augment_agent/

# Fix permissions if needed
chmod -R 755 ~/.local/share/augment_agent/
```

**3. "Module not found" Errors**
```bash
# Reinstall with all dependencies
pip uninstall augment-agent
pip install -e ".[all]"
```

**4. Web Search Not Working**
- Verify Google Custom Search API is enabled
- Check that your search engine ID is correct
- Ensure you have sufficient API quota

### Debug Mode

Enable debug logging for troubleshooting:

```bash
export AUGMENT_LOG_LEVEL=DEBUG
augment-agent --verbose chat
```

### Getting Help

1. **Check the logs**: Look in `~/.local/share/augment_agent/logs/`
2. **Run diagnostics**: `augment-agent status`
3. **Check configuration**: Review your `augment_agent.yaml` file
4. **GitHub Issues**: Report bugs at the project repository
5. **Documentation**: Read the full documentation

## Uninstallation

To completely remove Augment Agent:

```bash
# Uninstall the package
pip uninstall augment-agent

# Remove data directory (optional)
rm -rf ~/.local/share/augment_agent/

# Remove configuration files (optional)
rm -f ~/.augment_agent.yaml
rm -f ~/.config/augment_agent/config.yaml
```

## Next Steps

After installation:

1. **Read the README**: Understand the features and capabilities
2. **Try the examples**: Run the example scripts to see what's possible
3. **Start with simple tasks**: Begin with basic file operations
4. **Explore advanced features**: Try code analysis, task management, and web search
5. **Customize configuration**: Adjust settings to match your workflow

For more information, see the main [README.md](README.md) file.
