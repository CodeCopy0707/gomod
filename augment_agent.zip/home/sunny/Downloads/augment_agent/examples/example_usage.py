#!/usr/bin/env python3
"""
Example usage script for Augment Agent.

This script demonstrates how to use the Augment Agent programmatically
and showcases various features and capabilities.
"""

import asyncio
import os
import tempfile
from pathlib import Path

# Add the parent directory to the path so we can import augment_agent
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from augment_agent.core.config import Config
from augment_agent.core.agent import AugmentAgent
from augment_agent.utils.logging import setup_logging


async def example_basic_usage():
    """Example of basic agent usage."""
    print("=== Basic Usage Example ===")
    
    # Create a temporary workspace
    with tempfile.TemporaryDirectory() as temp_dir:
        # Configure the agent
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_web_search=False,  # Disable for demo
            require_confirmation_for_destructive_actions=False  # Disable for demo
        )
        
        # Initialize agent
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Example queries
        queries = [
            "Create a simple Python function to calculate fibonacci numbers",
            "Explain what the fibonacci function does",
            "Create a test file for the fibonacci function"
        ]
        
        for query in queries:
            print(f"\n🤖 Query: {query}")
            try:
                response = await agent.process_query(query)
                print(f"📝 Response: {response[:200]}...")
            except Exception as e:
                print(f"❌ Error: {e}")
        
        await agent.shutdown()


async def example_file_operations():
    """Example of file operation tools."""
    print("\n=== File Operations Example ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_web_search=False,
            require_confirmation_for_destructive_actions=False
        )
        
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Create a sample file
        sample_code = '''def hello_world():
    """A simple hello world function."""
    print("Hello, World!")
    return "Hello, World!"

if __name__ == "__main__":
    hello_world()
'''
        
        # Save the file
        query = f'''Create a file called "hello.py" with this content:
{sample_code}'''
        
        print(f"🤖 Creating file...")
        response = await agent.process_query(query)
        print(f"📝 Response: {response}")
        
        # View the file
        print(f"\n🤖 Viewing file...")
        response = await agent.process_query("Show me the contents of hello.py")
        print(f"📝 Response: {response}")
        
        # Edit the file
        print(f"\n🤖 Editing file...")
        response = await agent.process_query(
            'Add a docstring to the hello.py file explaining what the script does'
        )
        print(f"📝 Response: {response}")
        
        await agent.shutdown()


async def example_code_analysis():
    """Example of code analysis capabilities."""
    print("\n=== Code Analysis Example ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create some sample files
        (Path(temp_dir) / "main.py").write_text('''
import math

class Calculator:
    """A simple calculator class."""
    
    def add(self, a, b):
        """Add two numbers."""
        return a + b
    
    def multiply(self, a, b):
        """Multiply two numbers."""
        return a * b
    
    def power(self, base, exponent):
        """Calculate base raised to exponent."""
        return math.pow(base, exponent)

def main():
    calc = Calculator()
    print(f"2 + 3 = {calc.add(2, 3)}")
    print(f"4 * 5 = {calc.multiply(4, 5)}")
    print(f"2^8 = {calc.power(2, 8)}")

if __name__ == "__main__":
    main()
''')
        
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_code_analysis=True,
            enable_web_search=False,
            require_confirmation_for_destructive_actions=False
        )
        
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Analyze the codebase
        queries = [
            "Analyze the structure of this codebase",
            "Find all classes and their methods",
            "Suggest improvements for the Calculator class",
            "Check for any syntax errors in the code"
        ]
        
        for query in queries:
            print(f"\n🤖 Query: {query}")
            try:
                response = await agent.process_query(query)
                print(f"📝 Response: {response[:300]}...")
            except Exception as e:
                print(f"❌ Error: {e}")
        
        await agent.shutdown()


async def example_task_management():
    """Example of task management capabilities."""
    print("\n=== Task Management Example ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_web_search=False,
            require_confirmation_for_destructive_actions=False
        )
        
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Create a complex project plan
        query = """Create a detailed plan for building a web application with the following requirements:
1. User authentication system
2. Database for storing user data
3. REST API endpoints
4. Frontend interface
5. Testing suite
6. Deployment configuration

Break this down into manageable tasks with proper hierarchy."""
        
        print(f"🤖 Creating project plan...")
        response = await agent.process_query(query)
        print(f"📝 Response: {response}")
        
        # View the task list
        print(f"\n🤖 Viewing task list...")
        response = await agent.process_query("Show me the current task list")
        print(f"📝 Response: {response}")
        
        await agent.shutdown()


async def example_memory_system():
    """Example of memory system capabilities."""
    print("\n=== Memory System Example ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_web_search=False,
            require_confirmation_for_destructive_actions=False
        )
        
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Store some memories
        memories = [
            "The user prefers Python over JavaScript for backend development",
            "The project uses PostgreSQL as the primary database",
            "The team follows PEP 8 style guidelines for Python code",
            "The application should support both REST and GraphQL APIs"
        ]
        
        for memory in memories:
            print(f"🧠 Storing memory: {memory}")
            response = await agent.process_query(f"Remember: {memory}")
            print(f"📝 Response: {response}")
        
        # Test memory recall
        print(f"\n🤖 Testing memory recall...")
        response = await agent.process_query(
            "What do you remember about my preferences and project requirements?"
        )
        print(f"📝 Response: {response}")
        
        await agent.shutdown()


async def example_process_management():
    """Example of process management capabilities."""
    print("\n=== Process Management Example ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        config = Config(
            gemini_api_key=os.getenv("GEMINI_API_KEY", "demo-key"),
            workspace_root=temp_dir,
            enable_process_management=True,
            enable_web_search=False,
            require_confirmation_for_destructive_actions=False
        )
        
        agent = AugmentAgent(config)
        await agent.initialize()
        
        # Run some commands
        commands = [
            "Run 'echo Hello from Augment Agent' and show me the output",
            "List all running processes managed by the agent",
            "Run 'python --version' to check the Python version"
        ]
        
        for command in commands:
            print(f"\n🤖 Command: {command}")
            try:
                response = await agent.process_query(command)
                print(f"📝 Response: {response}")
            except Exception as e:
                print(f"❌ Error: {e}")
        
        await agent.shutdown()


async def main():
    """Run all examples."""
    # Setup logging
    setup_logging("INFO")
    
    print("🚀 Augment Agent Examples")
    print("=" * 50)
    
    # Check if API key is available
    if not os.getenv("GEMINI_API_KEY"):
        print("⚠️  Warning: GEMINI_API_KEY not set. Examples will use demo mode.")
        print("   Set your API key with: export GEMINI_API_KEY='your-key-here'")
        print()
    
    try:
        # Run examples
        await example_basic_usage()
        await example_file_operations()
        await example_code_analysis()
        await example_task_management()
        await example_memory_system()
        await example_process_management()
        
        print("\n✅ All examples completed successfully!")
        
    except KeyboardInterrupt:
        print("\n⏹️  Examples interrupted by user")
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
