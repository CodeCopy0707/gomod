"""Logging utilities for Augment Agent."""

import logging
import sys
from pathlib import Path
from typing import Optional
from rich.logging import RichHandler
from rich.console import Console


# Global console instance for consistent formatting
console = Console()

# Logger cache to avoid creating multiple loggers for the same name
_loggers = {}


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> None:
    """Setup logging configuration for the application."""
    
    # Convert string level to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Create rich handler for console output
    rich_handler = RichHandler(
        console=console,
        show_time=True,
        show_path=True,
        markup=True,
        rich_tracebacks=True,
        tracebacks_show_locals=False
    )
    rich_handler.setLevel(numeric_level)
    
    # Create formatter
    formatter = logging.Formatter(
        fmt="%(message)s",
        datefmt="[%X]"
    )
    rich_handler.setFormatter(formatter)
    
    # Add console handler
    root_logger.addHandler(rich_handler)
    
    # Add file handler if specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(numeric_level)
        
        file_formatter = logging.Formatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        file_handler.setFormatter(file_formatter)
        
        root_logger.addHandler(file_handler)
    
    # Set levels for noisy third-party libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("google").setLevel(logging.WARNING)
    logging.getLogger("chromadb").setLevel(logging.WARNING)
    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance with the given name."""
    if name in _loggers:
        return _loggers[name]
    
    logger = logging.getLogger(name)
    _loggers[name] = logger
    return logger


class ToolLogger:
    """Specialized logger for tool operations with structured output."""
    
    def __init__(self, tool_name: str):
        self.tool_name = tool_name
        self.logger = get_logger(f"tool.{tool_name}")
    
    def log_execution_start(self, operation: str, **kwargs) -> None:
        """Log the start of a tool execution."""
        params_str = ", ".join(f"{k}={v}" for k, v in kwargs.items())
        self.logger.info(f"[bold blue]{self.tool_name}[/bold blue]: Starting {operation}({params_str})")
    
    def log_execution_success(self, operation: str, result_summary: str = "") -> None:
        """Log successful tool execution."""
        message = f"[bold green]{self.tool_name}[/bold green]: {operation} completed"
        if result_summary:
            message += f" - {result_summary}"
        self.logger.info(message)
    
    def log_execution_error(self, operation: str, error: Exception) -> None:
        """Log tool execution error."""
        self.logger.error(
            f"[bold red]{self.tool_name}[/bold red]: {operation} failed - {str(error)}"
        )
    
    def log_warning(self, message: str) -> None:
        """Log a warning message."""
        self.logger.warning(f"[bold yellow]{self.tool_name}[/bold yellow]: {message}")
    
    def log_info(self, message: str) -> None:
        """Log an info message."""
        self.logger.info(f"[blue]{self.tool_name}[/blue]: {message}")
    
    def log_debug(self, message: str) -> None:
        """Log a debug message."""
        self.logger.debug(f"{self.tool_name}: {message}")


class ConversationLogger:
    """Logger for conversation and interaction tracking."""
    
    def __init__(self):
        self.logger = get_logger("conversation")
    
    def log_user_query(self, query: str) -> None:
        """Log a user query."""
        truncated_query = query[:100] + "..." if len(query) > 100 else query
        self.logger.info(f"[bold cyan]User[/bold cyan]: {truncated_query}")
    
    def log_agent_response(self, response_length: int, tool_calls: int = 0) -> None:
        """Log agent response metadata."""
        self.logger.info(
            f"[bold green]Agent[/bold green]: Response generated "
            f"({response_length} chars, {tool_calls} tool calls)"
        )
    
    def log_tool_call(self, tool_name: str, success: bool) -> None:
        """Log tool call result."""
        status = "✓" if success else "✗"
        color = "green" if success else "red"
        self.logger.info(f"[{color}]{status} Tool: {tool_name}[/{color}]")
    
    def log_error(self, error: Exception) -> None:
        """Log conversation error."""
        self.logger.error(f"[bold red]Error[/bold red]: {str(error)}")


def configure_tool_logging(tool_name: str) -> ToolLogger:
    """Configure and return a tool logger."""
    return ToolLogger(tool_name)


def configure_conversation_logging() -> ConversationLogger:
    """Configure and return a conversation logger."""
    return ConversationLogger()
