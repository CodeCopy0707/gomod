"""Context compression and RAG implementation as specified in plan.md."""

import asyncio
import json
import hashlib
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import time
import re
from collections import defaultdict

from .logging import configure_tool_logging

# Optional imports for advanced features
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False


class ContextCompressor:
    """Context compression and RAG system for managing large contexts."""
    
    def __init__(self, config):
        self.config = config
        self.logger = configure_tool_logging("context-compressor")
        self.compression_cache = {}
        self.embedding_model = None
        self.context_chunks = []
        self.similarity_threshold = 0.7
        self.max_context_size = getattr(config, 'context_window_size', 32000)
        self.chunk_size = getattr(config, 'chunk_size', 1000)
        self.initialized = False
    
    async def initialize(self) -> None:
        """Initialize the context compression system."""
        try:
            # Initialize embedding model if available
            if EMBEDDINGS_AVAILABLE:
                await self._initialize_embeddings()
            
            # Load compression cache
            await self._load_compression_cache()
            
            self.initialized = True
            self.logger.info("Context compressor initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize context compressor: {e}")
            raise
    
    async def _initialize_embeddings(self) -> None:
        """Initialize sentence embeddings model."""
        try:
            # Use a lightweight model for embeddings
            self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
            self.logger.info("Embedding model loaded")
        except Exception as e:
            self.logger.warning(f"Failed to load embedding model: {e}")
            self.embedding_model = None
    
    async def compress_context(self, context: str, target_size: Optional[int] = None) -> Dict[str, Any]:
        """Compress context to fit within size limits while preserving important information."""
        if not self.initialized:
            return {'compressed': context, 'compression_ratio': 1.0, 'method': 'none'}
        
        try:
            target_size = target_size or self.max_context_size
            
            if len(context) <= target_size:
                return {
                    'compressed': context,
                    'compression_ratio': 1.0,
                    'method': 'none',
                    'original_size': len(context),
                    'compressed_size': len(context)
                }
            
            # Try different compression methods
            compression_methods = [
                self._compress_by_importance,
                self._compress_by_similarity,
                self._compress_by_chunking,
                self._compress_by_summarization
            ]
            
            best_result = None
            best_score = 0
            
            for method in compression_methods:
                try:
                    result = await method(context, target_size)
                    score = self._evaluate_compression(context, result)
                    
                    if score > best_score:
                        best_score = score
                        best_result = result
                        
                except Exception as e:
                    self.logger.warning(f"Compression method failed: {e}")
                    continue
            
            if best_result:
                return best_result
            else:
                # Fallback to simple truncation
                return await self._compress_by_truncation(context, target_size)
                
        except Exception as e:
            self.logger.error(f"Context compression failed: {e}")
            return {'compressed': context[:target_size], 'compression_ratio': target_size/len(context), 'method': 'truncation'}
    
    async def _compress_by_importance(self, context: str, target_size: int) -> Dict[str, Any]:
        """Compress by identifying and preserving important sections."""
        lines = context.split('\n')
        scored_lines = []
        
        for i, line in enumerate(lines):
            importance_score = self._calculate_importance_score(line, i, len(lines))
            scored_lines.append((importance_score, line))
        
        # Sort by importance and select top lines
        scored_lines.sort(key=lambda x: x[0], reverse=True)
        
        compressed_lines = []
        current_size = 0
        
        for score, line in scored_lines:
            if current_size + len(line) + 1 <= target_size:
                compressed_lines.append(line)
                current_size += len(line) + 1
            else:
                break
        
        compressed = '\n'.join(compressed_lines)
        
        return {
            'compressed': compressed,
            'compression_ratio': len(compressed) / len(context),
            'method': 'importance',
            'original_size': len(context),
            'compressed_size': len(compressed),
            'lines_kept': len(compressed_lines),
            'lines_total': len(lines)
        }
    
    def _calculate_importance_score(self, line: str, position: int, total_lines: int) -> float:
        """Calculate importance score for a line of text."""
        score = 0.0
        
        # Position-based scoring (beginning and end are more important)
        if position < total_lines * 0.1 or position > total_lines * 0.9:
            score += 0.3
        
        # Content-based scoring
        important_keywords = [
            'def ', 'class ', 'import ', 'from ', 'return ', 'raise ',
            'TODO', 'FIXME', 'NOTE', 'WARNING', 'ERROR',
            'function', 'method', 'variable', 'parameter',
            'async ', 'await ', 'try:', 'except:', 'finally:'
        ]
        
        for keyword in important_keywords:
            if keyword in line:
                score += 0.2
        
        # Code structure indicators
        if line.strip().startswith(('#', '//', '/*', '"""', "'''")):
            score += 0.1  # Comments are somewhat important
        
        if re.match(r'^\s*(def|class|function|var|let|const)\s+', line):
            score += 0.5  # Definitions are very important
        
        # Length penalty for very long lines
        if len(line) > 200:
            score -= 0.1
        
        # Empty line penalty
        if not line.strip():
            score -= 0.2
        
        return max(0.0, score)
    
    async def _compress_by_similarity(self, context: str, target_size: int) -> Dict[str, Any]:
        """Compress by removing similar/redundant sections."""
        if not self.embedding_model:
            return await self._compress_by_truncation(context, target_size)
        
        try:
            # Split into chunks
            chunks = self._split_into_chunks(context, self.chunk_size)
            
            if len(chunks) <= 1:
                return await self._compress_by_truncation(context, target_size)
            
            # Generate embeddings for chunks
            chunk_texts = [chunk['text'] for chunk in chunks]
            embeddings = self.embedding_model.encode(chunk_texts)
            
            # Find similar chunks
            selected_chunks = []
            selected_indices = set()
            
            for i, chunk in enumerate(chunks):
                if i in selected_indices:
                    continue
                
                # Check if this chunk is similar to any already selected
                is_similar = False
                for j in selected_indices:
                    similarity = np.dot(embeddings[i], embeddings[j]) / (
                        np.linalg.norm(embeddings[i]) * np.linalg.norm(embeddings[j])
                    )
                    if similarity > self.similarity_threshold:
                        is_similar = True
                        break
                
                if not is_similar:
                    selected_chunks.append(chunk)
                    selected_indices.add(i)
                    
                    # Check if we've reached target size
                    current_size = sum(len(c['text']) for c in selected_chunks)
                    if current_size >= target_size:
                        break
            
            compressed = '\n'.join(chunk['text'] for chunk in selected_chunks)
            
            return {
                'compressed': compressed,
                'compression_ratio': len(compressed) / len(context),
                'method': 'similarity',
                'original_size': len(context),
                'compressed_size': len(compressed),
                'chunks_kept': len(selected_chunks),
                'chunks_total': len(chunks)
            }
            
        except Exception as e:
            self.logger.warning(f"Similarity compression failed: {e}")
            return await self._compress_by_truncation(context, target_size)
    
    async def _compress_by_chunking(self, context: str, target_size: int) -> Dict[str, Any]:
        """Compress by intelligent chunking and selection."""
        chunks = self._split_into_chunks(context, self.chunk_size)
        
        # Score chunks by importance
        scored_chunks = []
        for chunk in chunks:
            score = self._calculate_chunk_importance(chunk)
            scored_chunks.append((score, chunk))
        
        # Sort by importance and select top chunks
        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        
        selected_chunks = []
        current_size = 0
        
        for score, chunk in scored_chunks:
            chunk_size = len(chunk['text'])
            if current_size + chunk_size <= target_size:
                selected_chunks.append(chunk)
                current_size += chunk_size
            else:
                break
        
        # Sort selected chunks by original order
        selected_chunks.sort(key=lambda x: x['start_pos'])
        
        compressed = '\n'.join(chunk['text'] for chunk in selected_chunks)
        
        return {
            'compressed': compressed,
            'compression_ratio': len(compressed) / len(context),
            'method': 'chunking',
            'original_size': len(context),
            'compressed_size': len(compressed),
            'chunks_kept': len(selected_chunks),
            'chunks_total': len(chunks)
        }
    
    def _split_into_chunks(self, text: str, chunk_size: int) -> List[Dict[str, Any]]:
        """Split text into intelligent chunks."""
        chunks = []
        lines = text.split('\n')
        current_chunk = []
        current_size = 0
        start_pos = 0
        
        for i, line in enumerate(lines):
            line_size = len(line) + 1  # +1 for newline
            
            if current_size + line_size > chunk_size and current_chunk:
                # Save current chunk
                chunks.append({
                    'text': '\n'.join(current_chunk),
                    'start_pos': start_pos,
                    'end_pos': i - 1,
                    'line_count': len(current_chunk)
                })
                
                # Start new chunk
                current_chunk = [line]
                current_size = line_size
                start_pos = i
            else:
                current_chunk.append(line)
                current_size += line_size
        
        # Add final chunk
        if current_chunk:
            chunks.append({
                'text': '\n'.join(current_chunk),
                'start_pos': start_pos,
                'end_pos': len(lines) - 1,
                'line_count': len(current_chunk)
            })
        
        return chunks
    
    def _calculate_chunk_importance(self, chunk: Dict[str, Any]) -> float:
        """Calculate importance score for a chunk."""
        text = chunk['text']
        lines = text.split('\n')
        
        score = 0.0
        
        # Content-based scoring
        for line in lines:
            score += self._calculate_importance_score(line, 0, len(lines))
        
        # Normalize by chunk size
        score = score / len(lines) if lines else 0
        
        # Bonus for chunks with code structure
        if any(keyword in text for keyword in ['def ', 'class ', 'function ', 'import ']):
            score += 0.5
        
        # Bonus for chunks with documentation
        if any(marker in text for marker in ['"""', "'''", '/*', '//']):
            score += 0.2
        
        return score
    
    async def _compress_by_summarization(self, context: str, target_size: int) -> Dict[str, Any]:
        """Compress by creating summaries of less important sections."""
        # This is a simplified version - in practice, you'd use an LLM for summarization
        lines = context.split('\n')
        
        # Identify sections that can be summarized
        summarizable_sections = []
        current_section = []
        
        for line in lines:
            if self._is_summarizable_line(line):
                current_section.append(line)
            else:
                if len(current_section) > 5:  # Only summarize longer sections
                    summarizable_sections.append(current_section)
                current_section = []
        
        # Create compressed version
        compressed_lines = []
        section_index = 0
        
        for line in lines:
            if section_index < len(summarizable_sections) and line in summarizable_sections[section_index]:
                if line == summarizable_sections[section_index][0]:  # First line of section
                    summary = f"# [SUMMARIZED: {len(summarizable_sections[section_index])} lines of {self._identify_section_type(summarizable_sections[section_index])}]"
                    compressed_lines.append(summary)
                # Skip other lines in the section
                if line == summarizable_sections[section_index][-1]:  # Last line of section
                    section_index += 1
            else:
                compressed_lines.append(line)
        
        compressed = '\n'.join(compressed_lines)
        
        return {
            'compressed': compressed,
            'compression_ratio': len(compressed) / len(context),
            'method': 'summarization',
            'original_size': len(context),
            'compressed_size': len(compressed),
            'sections_summarized': len(summarizable_sections)
        }
    
    def _is_summarizable_line(self, line: str) -> bool:
        """Check if a line can be part of a summarizable section."""
        # Comments, docstrings, and simple assignments are summarizable
        stripped = line.strip()
        return (
            stripped.startswith('#') or
            stripped.startswith('//') or
            stripped.startswith('/*') or
            stripped.startswith('"""') or
            stripped.startswith("'''") or
            ('=' in stripped and not any(keyword in stripped for keyword in ['def ', 'class ', 'function ']))
        )
    
    def _identify_section_type(self, section: List[str]) -> str:
        """Identify the type of a section for summarization."""
        text = '\n'.join(section)
        
        if any(line.strip().startswith('#') for line in section):
            return "comments"
        elif '"""' in text or "'''" in text:
            return "docstring"
        elif any('=' in line for line in section):
            return "variable assignments"
        else:
            return "code block"
    
    async def _compress_by_truncation(self, context: str, target_size: int) -> Dict[str, Any]:
        """Simple truncation compression as fallback."""
        if len(context) <= target_size:
            compressed = context
        else:
            # Try to truncate at a natural boundary
            truncated = context[:target_size]
            last_newline = truncated.rfind('\n')
            if last_newline > target_size * 0.8:  # If we can save most content
                compressed = truncated[:last_newline]
            else:
                compressed = truncated
        
        return {
            'compressed': compressed,
            'compression_ratio': len(compressed) / len(context),
            'method': 'truncation',
            'original_size': len(context),
            'compressed_size': len(compressed)
        }
    
    def _evaluate_compression(self, original: str, result: Dict[str, Any]) -> float:
        """Evaluate the quality of compression."""
        compressed = result['compressed']
        compression_ratio = result['compression_ratio']
        
        # Base score from compression ratio
        score = compression_ratio
        
        # Bonus for preserving important content
        important_keywords = ['def ', 'class ', 'import ', 'function ', 'return ']
        original_keywords = sum(1 for keyword in important_keywords if keyword in original)
        compressed_keywords = sum(1 for keyword in important_keywords if keyword in compressed)
        
        if original_keywords > 0:
            keyword_preservation = compressed_keywords / original_keywords
            score += keyword_preservation * 0.3
        
        # Penalty for very aggressive compression
        if compression_ratio < 0.1:
            score -= 0.2
        
        return score
    
    async def _load_compression_cache(self) -> None:
        """Load compression cache from storage."""
        try:
            cache_file = Path(self.config.data_dir) / "compression_cache.json"
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    self.compression_cache = json.load(f)
                self.logger.info("Loaded compression cache")
        except Exception as e:
            self.logger.warning(f"Failed to load compression cache: {e}")
    
    async def save_compression_cache(self) -> None:
        """Save compression cache to storage."""
        try:
            cache_file = Path(self.config.data_dir) / "compression_cache.json"
            cache_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(cache_file, 'w') as f:
                json.dump(self.compression_cache, f, indent=2)
                
            self.logger.debug("Saved compression cache")
        except Exception as e:
            self.logger.warning(f"Failed to save compression cache: {e}")
    
    async def get_relevant_context(self, query: str, context_pool: List[str], max_size: int) -> str:
        """Retrieve most relevant context for a query using RAG."""
        if not self.embedding_model or not context_pool:
            return '\n'.join(context_pool)[:max_size]
        
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode([query])[0]
            
            # Generate embeddings for context chunks
            context_embeddings = self.embedding_model.encode(context_pool)
            
            # Calculate similarities
            similarities = []
            for i, context_embedding in enumerate(context_embeddings):
                similarity = np.dot(query_embedding, context_embedding) / (
                    np.linalg.norm(query_embedding) * np.linalg.norm(context_embedding)
                )
                similarities.append((similarity, i, context_pool[i]))
            
            # Sort by similarity and select top contexts
            similarities.sort(key=lambda x: x[0], reverse=True)
            
            selected_contexts = []
            current_size = 0
            
            for similarity, index, context in similarities:
                if current_size + len(context) <= max_size:
                    selected_contexts.append(context)
                    current_size += len(context)
                else:
                    break
            
            return '\n'.join(selected_contexts)
            
        except Exception as e:
            self.logger.warning(f"RAG context retrieval failed: {e}")
            return '\n'.join(context_pool)[:max_size]
