"""Predictive prefetching engine as specified in plan.md."""

import asyncio
import json
import re
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import time
from collections import defaultdict, deque

from .logging import configure_tool_logging


class PredictionEngine:
    """Predictive prefetching engine for anticipating user actions."""
    
    def __init__(self, config):
        self.config = config
        self.logger = configure_tool_logging("prediction-engine")
        self.user_patterns = defaultdict(list)
        self.code_patterns = defaultdict(int)
        self.recent_actions = deque(maxlen=50)
        self.prediction_cache = {}
        self.initialized = False
    
    async def initialize(self) -> None:
        """Initialize the prediction engine."""
        try:
            # Load historical patterns if available
            await self._load_patterns()
            
            # Initialize pattern recognition
            await self._initialize_pattern_recognition()
            
            self.initialized = True
            self.logger.info("Prediction engine initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize prediction engine: {e}")
            raise
    
    async def predict(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Generate predictions based on current context and patterns."""
        if not self.initialized:
            return None
        
        try:
            prediction_type = request.get('type', 'general')
            context = request.get('context', {})
            
            if prediction_type == 'next_action':
                return await self._predict_next_action(context)
            elif prediction_type == 'code_completion':
                return await self._predict_code_completion(context)
            elif prediction_type == 'file_suggestion':
                return await self._predict_file_suggestions(context)
            elif prediction_type == 'test_generation':
                return await self._predict_test_generation(context)
            else:
                return await self._predict_general(context)
                
        except Exception as e:
            self.logger.warning(f"Prediction failed: {e}")
            return None
    
    async def learn_from_action(self, action: Dict[str, Any]) -> None:
        """Learn from user actions to improve predictions."""
        try:
            # Record the action
            self.recent_actions.append({
                'action': action,
                'timestamp': time.time(),
                'context': action.get('context', {})
            })
            
            # Update patterns
            await self._update_patterns(action)
            
            # Save patterns periodically
            if len(self.recent_actions) % 10 == 0:
                await self._save_patterns()
                
        except Exception as e:
            self.logger.warning(f"Failed to learn from action: {e}")
    
    async def _predict_next_action(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Predict the next likely action based on context and patterns."""
        current_file = context.get('current_file')
        recent_commands = context.get('recent_commands', [])
        project_type = context.get('project_type')
        
        predictions = []
        
        # Pattern-based predictions
        if recent_commands:
            last_command = recent_commands[-1] if recent_commands else None
            
            # Common command sequences
            command_sequences = {
                'create_file': ['edit_file', 'run_tests', 'git_add'],
                'edit_file': ['run_tests', 'git_add', 'git_commit'],
                'run_tests': ['edit_file', 'git_add'],
                'git_add': ['git_commit'],
                'npm_install': ['npm_start', 'npm_test'],
                'pip_install': ['python_run', 'pytest']
            }
            
            if last_command in command_sequences:
                for next_cmd in command_sequences[last_command]:
                    predictions.append({
                        'action': next_cmd,
                        'confidence': 0.7,
                        'reason': f'Common sequence after {last_command}'
                    })
        
        # File-based predictions
        if current_file:
            file_ext = Path(current_file).suffix
            
            if file_ext == '.py':
                predictions.extend([
                    {'action': 'run_tests', 'confidence': 0.8, 'reason': 'Python file often needs testing'},
                    {'action': 'check_imports', 'confidence': 0.6, 'reason': 'Python imports validation'},
                    {'action': 'format_code', 'confidence': 0.5, 'reason': 'Code formatting'}
                ])
            elif file_ext in ['.js', '.ts']:
                predictions.extend([
                    {'action': 'npm_test', 'confidence': 0.7, 'reason': 'JavaScript testing'},
                    {'action': 'eslint_check', 'confidence': 0.6, 'reason': 'Linting check'},
                    {'action': 'npm_build', 'confidence': 0.5, 'reason': 'Build process'}
                ])
        
        # Project-type based predictions
        if project_type:
            if project_type == 'web_frontend':
                predictions.extend([
                    {'action': 'npm_start', 'confidence': 0.6, 'reason': 'Start dev server'},
                    {'action': 'build_project', 'confidence': 0.4, 'reason': 'Build for production'}
                ])
            elif project_type == 'backend':
                predictions.extend([
                    {'action': 'run_server', 'confidence': 0.6, 'reason': 'Start backend server'},
                    {'action': 'test_api', 'confidence': 0.5, 'reason': 'API testing'}
                ])
        
        return {
            'type': 'next_action',
            'predictions': sorted(predictions, key=lambda x: x['confidence'], reverse=True)[:5],
            'context': context
        }
    
    async def _predict_code_completion(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Predict code completions based on current context."""
        current_code = context.get('current_code', '')
        cursor_position = context.get('cursor_position', 0)
        file_type = context.get('file_type', '')
        
        predictions = []
        
        # Language-specific predictions
        if file_type == 'python':
            predictions.extend(await self._predict_python_completion(current_code, cursor_position))
        elif file_type in ['javascript', 'typescript']:
            predictions.extend(await self._predict_js_completion(current_code, cursor_position))
        
        return {
            'type': 'code_completion',
            'predictions': predictions,
            'context': context
        }
    
    async def _predict_python_completion(self, code: str, cursor_pos: int) -> List[Dict[str, Any]]:
        """Predict Python code completions."""
        predictions = []
        
        # Get the line at cursor
        lines = code[:cursor_pos].split('\n')
        current_line = lines[-1] if lines else ''
        
        # Common Python patterns
        if current_line.strip().startswith('def '):
            predictions.append({
                'completion': ':\n    """Function docstring."""\n    pass',
                'confidence': 0.9,
                'reason': 'Function definition completion'
            })
        elif current_line.strip().startswith('class '):
            predictions.append({
                'completion': ':\n    """Class docstring."""\n    pass',
                'confidence': 0.9,
                'reason': 'Class definition completion'
            })
        elif 'import ' in current_line:
            # Common imports
            common_imports = ['os', 'sys', 'json', 'time', 'datetime', 'pathlib', 'typing']
            for imp in common_imports:
                if imp not in code:
                    predictions.append({
                        'completion': imp,
                        'confidence': 0.6,
                        'reason': f'Common import: {imp}'
                    })
        
        return predictions
    
    async def _predict_js_completion(self, code: str, cursor_pos: int) -> List[Dict[str, Any]]:
        """Predict JavaScript/TypeScript code completions."""
        predictions = []
        
        lines = code[:cursor_pos].split('\n')
        current_line = lines[-1] if lines else ''
        
        # Common JS patterns
        if current_line.strip().startswith('function '):
            predictions.append({
                'completion': ' {\n  // Function body\n}',
                'confidence': 0.9,
                'reason': 'Function definition completion'
            })
        elif current_line.strip().startswith('const ') and '=' not in current_line:
            predictions.append({
                'completion': ' = ',
                'confidence': 0.8,
                'reason': 'Const assignment'
            })
        elif 'import ' in current_line and 'from' not in current_line:
            predictions.append({
                'completion': ' from \'\'',
                'confidence': 0.8,
                'reason': 'Import statement completion'
            })
        
        return predictions
    
    async def _predict_file_suggestions(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Predict files that might be needed next."""
        current_file = context.get('current_file')
        project_files = context.get('project_files', [])
        recent_files = context.get('recent_files', [])
        
        suggestions = []
        
        if current_file:
            current_path = Path(current_file)
            
            # Suggest related files
            if current_path.suffix == '.py':
                # Look for test files
                test_file = current_path.parent / f"test_{current_path.stem}.py"
                if str(test_file) in project_files:
                    suggestions.append({
                        'file': str(test_file),
                        'confidence': 0.8,
                        'reason': 'Related test file'
                    })
                
                # Look for __init__.py
                init_file = current_path.parent / "__init__.py"
                if str(init_file) in project_files:
                    suggestions.append({
                        'file': str(init_file),
                        'confidence': 0.6,
                        'reason': 'Package init file'
                    })
            
            elif current_path.suffix in ['.js', '.jsx']:
                # Look for test files
                test_patterns = [
                    f"{current_path.stem}.test.js",
                    f"{current_path.stem}.spec.js",
                    f"__tests__/{current_path.stem}.test.js"
                ]
                
                for pattern in test_patterns:
                    test_file = current_path.parent / pattern
                    if str(test_file) in project_files:
                        suggestions.append({
                            'file': str(test_file),
                            'confidence': 0.8,
                            'reason': 'Related test file'
                        })
        
        return {
            'type': 'file_suggestions',
            'suggestions': suggestions,
            'context': context
        }
    
    async def _predict_test_generation(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Predict test cases that should be generated."""
        current_file = context.get('current_file')
        code_content = context.get('code_content', '')
        
        test_suggestions = []
        
        if current_file and code_content:
            # Extract functions and classes for testing
            if current_file.endswith('.py'):
                # Find Python functions and classes
                function_matches = re.findall(r'def\s+(\w+)\s*\(([^)]*)\):', code_content)
                class_matches = re.findall(r'class\s+(\w+)\s*(?:\([^)]*\))?:', code_content)
                
                for func_name, params in function_matches:
                    if not func_name.startswith('_'):  # Skip private functions
                        test_suggestions.append({
                            'test_type': 'unit_test',
                            'target': func_name,
                            'confidence': 0.8,
                            'reason': f'Public function {func_name} needs testing'
                        })
                
                for class_name in class_matches:
                    test_suggestions.append({
                        'test_type': 'class_test',
                        'target': class_name,
                        'confidence': 0.7,
                        'reason': f'Class {class_name} needs testing'
                    })
        
        return {
            'type': 'test_generation',
            'suggestions': test_suggestions,
            'context': context
        }
    
    async def _predict_general(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """General predictions based on context."""
        return {
            'type': 'general',
            'predictions': [
                {'action': 'save_file', 'confidence': 0.5, 'reason': 'Regular save'},
                {'action': 'run_tests', 'confidence': 0.4, 'reason': 'Testing is good practice'},
                {'action': 'git_status', 'confidence': 0.3, 'reason': 'Check git status'}
            ],
            'context': context
        }
    
    async def _update_patterns(self, action: Dict[str, Any]) -> None:
        """Update learned patterns from user actions."""
        action_type = action.get('type', 'unknown')
        context = action.get('context', {})
        
        # Update action frequency patterns
        self.code_patterns[action_type] += 1
        
        # Update sequence patterns
        if len(self.recent_actions) >= 2:
            prev_action = self.recent_actions[-2]['action']
            prev_type = prev_action.get('type', 'unknown')
            sequence_key = f"{prev_type}->{action_type}"
            self.code_patterns[sequence_key] += 1
    
    async def _load_patterns(self) -> None:
        """Load historical patterns from storage."""
        try:
            patterns_file = Path(self.config.data_dir) / "prediction_patterns.json"
            if patterns_file.exists():
                with open(patterns_file, 'r') as f:
                    data = json.load(f)
                    self.code_patterns.update(data.get('code_patterns', {}))
                    self.logger.info("Loaded prediction patterns")
        except Exception as e:
            self.logger.warning(f"Failed to load patterns: {e}")
    
    async def _save_patterns(self) -> None:
        """Save learned patterns to storage."""
        try:
            patterns_file = Path(self.config.data_dir) / "prediction_patterns.json"
            patterns_file.parent.mkdir(parents=True, exist_ok=True)
            
            data = {
                'code_patterns': dict(self.code_patterns),
                'last_updated': time.time()
            }
            
            with open(patterns_file, 'w') as f:
                json.dump(data, f, indent=2)
                
            self.logger.debug("Saved prediction patterns")
        except Exception as e:
            self.logger.warning(f"Failed to save patterns: {e}")
    
    async def _initialize_pattern_recognition(self) -> None:
        """Initialize pattern recognition algorithms."""
        # Initialize with common patterns
        common_patterns = {
            'create_file->edit_file': 10,
            'edit_file->run_tests': 8,
            'run_tests->git_add': 6,
            'git_add->git_commit': 9,
            'npm_install->npm_start': 7,
            'pip_install->python_run': 6
        }
        
        for pattern, weight in common_patterns.items():
            if pattern not in self.code_patterns:
                self.code_patterns[pattern] = weight
