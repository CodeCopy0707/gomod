"""Tests for configuration management."""

import os
import tempfile
import pytest
from pathlib import Path

from augment_agent.core.config import Config


class TestConfig:
    """Test configuration loading and validation."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = Config()
        
        assert config.model_name == "gemini-2.0-flash-exp"
        assert config.temperature == 0.1
        assert config.max_tokens == 8192
        assert config.enable_web_search is True
        assert config.require_confirmation_for_destructive_actions is True
    
    def test_config_from_env(self, monkeypatch):
        """Test configuration loading from environment variables."""
        monkeypatch.setenv("GEMINI_API_KEY", "test-key")
        monkeypatch.setenv("AUGMENT_TEMPERATURE", "0.5")
        monkeypatch.setenv("AUGMENT_MAX_TOKENS", "4096")
        
        config = Config.load()
        
        assert config.gemini_api_key == "test-key"
        assert config.temperature == 0.5
        assert config.max_tokens == 4096
    
    def test_config_from_yaml_file(self):
        """Test configuration loading from YAML file."""
        config_data = """
        gemini_api_key: "yaml-key"
        temperature: 0.7
        enable_web_search: false
        """
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_data)
            config_path = f.name
        
        try:
            config = Config.load(config_path)
            
            assert config.gemini_api_key == "yaml-key"
            assert config.temperature == 0.7
            assert config.enable_web_search is False
        finally:
            os.unlink(config_path)
    
    def test_config_from_json_file(self):
        """Test configuration loading from JSON file."""
        config_data = """
        {
            "gemini_api_key": "json-key",
            "temperature": 0.3,
            "max_tokens": 2048
        }
        """
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write(config_data)
            config_path = f.name
        
        try:
            config = Config.load(config_path)
            
            assert config.gemini_api_key == "json-key"
            assert config.temperature == 0.3
            assert config.max_tokens == 2048
        finally:
            os.unlink(config_path)
    
    def test_config_validation_missing_api_key(self):
        """Test configuration validation with missing API key."""
        config = Config()
        
        with pytest.raises(ValueError, match="Gemini API key is required"):
            config.validate()
    
    def test_config_validation_web_search_missing_keys(self):
        """Test configuration validation with web search enabled but missing keys."""
        config = Config(
            gemini_api_key="test-key",
            enable_web_search=True
        )
        
        with pytest.raises(ValueError, match="Google Search API key is required"):
            config.validate()
    
    def test_config_validation_success(self):
        """Test successful configuration validation."""
        config = Config(
            gemini_api_key="test-key",
            enable_web_search=False
        )
        
        # Should not raise any exception
        config.validate()
    
    def test_workspace_path_resolution(self):
        """Test workspace path resolution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config = Config(workspace_root=temp_dir)
            
            # Test relative path
            relative_path = "test/file.py"
            abs_path = config.get_workspace_path(relative_path)
            
            expected = Path(temp_dir) / "test" / "file.py"
            assert abs_path == expected
            
            # Test absolute path
            abs_input = "/absolute/path.py"
            abs_path = config.get_workspace_path(abs_input)
            assert abs_path == Path(abs_input)
    
    def test_repository_path_resolution(self):
        """Test repository path resolution."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config = Config(repository_root=temp_dir)
            
            # Test relative path
            relative_path = "src/main.py"
            abs_path = config.get_repository_path(relative_path)
            
            expected = Path(temp_dir) / "src" / "main.py"
            assert abs_path == expected
    
    def test_config_save_yaml(self):
        """Test saving configuration to YAML file."""
        config = Config(
            gemini_api_key="test-key",
            temperature=0.5,
            enable_web_search=False
        )
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            config_path = f.name
        
        try:
            config.save(config_path)
            
            # Load and verify
            loaded_config = Config.load(config_path)
            assert loaded_config.gemini_api_key == "test-key"
            assert loaded_config.temperature == 0.5
            assert loaded_config.enable_web_search is False
        finally:
            os.unlink(config_path)
    
    def test_config_save_json(self):
        """Test saving configuration to JSON file."""
        config = Config(
            gemini_api_key="test-key",
            temperature=0.8,
            max_tokens=1024
        )
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            config_path = f.name
        
        try:
            config.save(config_path)
            
            # Load and verify
            loaded_config = Config.load(config_path)
            assert loaded_config.gemini_api_key == "test-key"
            assert loaded_config.temperature == 0.8
            assert loaded_config.max_tokens == 1024
        finally:
            os.unlink(config_path)
    
    def test_find_repository_root(self):
        """Test repository root detection."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create a fake git repository
            git_dir = Path(temp_dir) / ".git"
            git_dir.mkdir()
            
            # Create a subdirectory
            sub_dir = Path(temp_dir) / "src" / "deep"
            sub_dir.mkdir(parents=True)
            
            # Test detection from subdirectory
            repo_root = Config._find_repository_root(str(sub_dir))
            assert repo_root == temp_dir
    
    def test_find_repository_root_no_git(self):
        """Test repository root detection when no git repo exists."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # No .git directory
            repo_root = Config._find_repository_root(temp_dir)
            assert repo_root == temp_dir  # Should return the start path
