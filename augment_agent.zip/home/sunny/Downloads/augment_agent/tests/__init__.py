"""Tests for Augment Agent."""
